import Intro4
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice4x7 : ((leaves4.drop 7).take 5).all test4=true := by decide +kernel
end E1182TwelveBlock.Word32
