import TwinRule
import ValidHost3
import WordCut42
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem blocked42 : ¬ (codeGraph 11 pat42.mask) ⊑ (triGraph 21 host3.original)ᶜ := by
  apply null_of_test host3 pat42 hostValid3 (by decide +kernel) (twins_from_types pat42 469903233124347612165998777369319914 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact Word32.miss42
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked42
