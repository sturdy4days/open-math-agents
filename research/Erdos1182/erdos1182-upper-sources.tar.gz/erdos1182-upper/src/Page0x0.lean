import Intro0
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice0x0 : ((leaves0.drop 0).take 2).all test0=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice0x2 : ((leaves0.drop 2).take 2).all test0=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice0x4 : ((leaves0.drop 4).take 2).all test0=true := by decide +kernel
end E1182TwelveBlock.Word32
