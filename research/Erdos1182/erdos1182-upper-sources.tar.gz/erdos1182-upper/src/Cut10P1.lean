import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf10_0_3_11 : failed host0 pat10 (atPath host0 pat10 [11,3,0]) = true := by
  decide +kernel

theorem leaf10_0_3_12 : failed host0 pat10 (atPath host0 pat10 [12,3,0]) = true := by
  decide +kernel

theorem leaf10_0_3_13 : failed host0 pat10 (atPath host0 pat10 [13,3,0]) = true := by
  decide +kernel

theorem leaf10_0_3_14 : failed host0 pat10 (atPath host0 pat10 [14,3,0]) = true := by
  decide +kernel

theorem leaf10_0_3_17 : failed host0 pat10 (atPath host0 pat10 [17,3,0]) = true := by
  decide +kernel

theorem leaf10_0_3_20 : failed host0 pat10 (atPath host0 pat10 [20,3,0]) = true := by
  decide +kernel

theorem leaf10_0_4_7 : failed host0 pat10 (atPath host0 pat10 [7,4,0]) = true := by
  decide +kernel

end E1182ElevenBlock
