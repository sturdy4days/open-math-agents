import Intro2
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x220 : ((leaves2.drop 220).take 1).all test2=true := by decide +kernel
end E1182TwelveBlock.Word32
