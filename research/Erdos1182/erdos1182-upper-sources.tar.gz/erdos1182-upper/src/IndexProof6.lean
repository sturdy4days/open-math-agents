import Page6cov0
import Page6cov3
import Page6cov6
import Page6cov9
import Page6cov12
import Page6cov15
import Page6cov18
import Page6cov21
import Page6cov24
import Page6cov27
import Page6cov30
import Page6cov33
import Page6cov36
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem tail6x39 : indexedParents perm6 apart6 start6 506 indexStore6x39 indexWork6x39 = true := by decide +kernel
theorem tail6x38 : indexedParents perm6 apart6 start6 506 indexStore6x38 indexWork6x38 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x38 indexRow6x38.1 indexRow6x38.2 indexWork6x39 ref6x38 tail6x39
theorem tail6x37 : indexedParents perm6 apart6 start6 506 indexStore6x37 indexWork6x37 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x37 indexRow6x37.1 indexRow6x37.2 indexWork6x38 ref6x37 tail6x38
theorem tail6x36 : indexedParents perm6 apart6 start6 506 indexStore6x36 indexWork6x36 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x36 indexRow6x36.1 indexRow6x36.2 indexWork6x37 ref6x36 tail6x37
theorem tail6x35 : indexedParents perm6 apart6 start6 506 indexStore6x35 indexWork6x35 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x35 indexRow6x35.1 indexRow6x35.2 indexWork6x36 ref6x35 tail6x36
theorem tail6x34 : indexedParents perm6 apart6 start6 506 indexStore6x34 indexWork6x34 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x34 indexRow6x34.1 indexRow6x34.2 indexWork6x35 ref6x34 tail6x35
theorem tail6x33 : indexedParents perm6 apart6 start6 506 indexStore6x33 indexWork6x33 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x33 indexRow6x33.1 indexRow6x33.2 indexWork6x34 ref6x33 tail6x34
theorem tail6x32 : indexedParents perm6 apart6 start6 506 indexStore6x32 indexWork6x32 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x32 indexRow6x32.1 indexRow6x32.2 indexWork6x33 ref6x32 tail6x33
theorem tail6x31 : indexedParents perm6 apart6 start6 506 indexStore6x31 indexWork6x31 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x31 indexRow6x31.1 indexRow6x31.2 indexWork6x32 ref6x31 tail6x32
theorem tail6x30 : indexedParents perm6 apart6 start6 506 indexStore6x30 indexWork6x30 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x30 indexRow6x30.1 indexRow6x30.2 indexWork6x31 ref6x30 tail6x31
theorem tail6x29 : indexedParents perm6 apart6 start6 506 indexStore6x29 indexWork6x29 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x29 indexRow6x29.1 indexRow6x29.2 indexWork6x30 ref6x29 tail6x30
theorem tail6x28 : indexedParents perm6 apart6 start6 506 indexStore6x28 indexWork6x28 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x28 indexRow6x28.1 indexRow6x28.2 indexWork6x29 ref6x28 tail6x29
theorem tail6x27 : indexedParents perm6 apart6 start6 506 indexStore6x27 indexWork6x27 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x27 indexRow6x27.1 indexRow6x27.2 indexWork6x28 ref6x27 tail6x28
theorem tail6x26 : indexedParents perm6 apart6 start6 506 indexStore6x26 indexWork6x26 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x26 indexRow6x26.1 indexRow6x26.2 indexWork6x27 ref6x26 tail6x27
theorem tail6x25 : indexedParents perm6 apart6 start6 506 indexStore6x25 indexWork6x25 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x25 indexRow6x25.1 indexRow6x25.2 indexWork6x26 ref6x25 tail6x26
theorem tail6x24 : indexedParents perm6 apart6 start6 506 indexStore6x24 indexWork6x24 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x24 indexRow6x24.1 indexRow6x24.2 indexWork6x25 ref6x24 tail6x25
theorem tail6x23 : indexedParents perm6 apart6 start6 506 indexStore6x23 indexWork6x23 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x23 indexRow6x23.1 indexRow6x23.2 indexWork6x24 ref6x23 tail6x24
theorem tail6x22 : indexedParents perm6 apart6 start6 506 indexStore6x22 indexWork6x22 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x22 indexRow6x22.1 indexRow6x22.2 indexWork6x23 ref6x22 tail6x23
theorem tail6x21 : indexedParents perm6 apart6 start6 506 indexStore6x21 indexWork6x21 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x21 indexRow6x21.1 indexRow6x21.2 indexWork6x22 ref6x21 tail6x22
theorem tail6x20 : indexedParents perm6 apart6 start6 506 indexStore6x20 indexWork6x20 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x20 indexRow6x20.1 indexRow6x20.2 indexWork6x21 ref6x20 tail6x21
theorem tail6x19 : indexedParents perm6 apart6 start6 506 indexStore6x19 indexWork6x19 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x19 indexRow6x19.1 indexRow6x19.2 indexWork6x20 ref6x19 tail6x20
theorem tail6x18 : indexedParents perm6 apart6 start6 506 indexStore6x18 indexWork6x18 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x18 indexRow6x18.1 indexRow6x18.2 indexWork6x19 ref6x18 tail6x19
theorem tail6x17 : indexedParents perm6 apart6 start6 506 indexStore6x17 indexWork6x17 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x17 indexRow6x17.1 indexRow6x17.2 indexWork6x18 ref6x17 tail6x18
theorem tail6x16 : indexedParents perm6 apart6 start6 506 indexStore6x16 indexWork6x16 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x16 indexRow6x16.1 indexRow6x16.2 indexWork6x17 ref6x16 tail6x17
theorem tail6x15 : indexedParents perm6 apart6 start6 506 indexStore6x15 indexWork6x15 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x15 indexRow6x15.1 indexRow6x15.2 indexWork6x16 ref6x15 tail6x16
theorem tail6x14 : indexedParents perm6 apart6 start6 506 indexStore6x14 indexWork6x14 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x14 indexRow6x14.1 indexRow6x14.2 indexWork6x15 ref6x14 tail6x15
theorem tail6x13 : indexedParents perm6 apart6 start6 506 indexStore6x13 indexWork6x13 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x13 indexRow6x13.1 indexRow6x13.2 indexWork6x14 ref6x13 tail6x14
theorem tail6x12 : indexedParents perm6 apart6 start6 506 indexStore6x12 indexWork6x12 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x12 indexRow6x12.1 indexRow6x12.2 indexWork6x13 ref6x12 tail6x13
theorem tail6x11 : indexedParents perm6 apart6 start6 506 indexStore6x11 indexWork6x11 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x11 indexRow6x11.1 indexRow6x11.2 indexWork6x12 ref6x11 tail6x12
theorem tail6x10 : indexedParents perm6 apart6 start6 506 indexStore6x10 indexWork6x10 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x10 indexRow6x10.1 indexRow6x10.2 indexWork6x11 ref6x10 tail6x11
theorem tail6x9 : indexedParents perm6 apart6 start6 506 indexStore6x9 indexWork6x9 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x9 indexRow6x9.1 indexRow6x9.2 indexWork6x10 ref6x9 tail6x10
theorem tail6x8 : indexedParents perm6 apart6 start6 506 indexStore6x8 indexWork6x8 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x8 indexRow6x8.1 indexRow6x8.2 indexWork6x9 ref6x8 tail6x9
theorem tail6x7 : indexedParents perm6 apart6 start6 506 indexStore6x7 indexWork6x7 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x7 indexRow6x7.1 indexRow6x7.2 indexWork6x8 ref6x7 tail6x8
theorem tail6x6 : indexedParents perm6 apart6 start6 506 indexStore6x6 indexWork6x6 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x6 indexRow6x6.1 indexRow6x6.2 indexWork6x7 ref6x6 tail6x7
theorem tail6x5 : indexedParents perm6 apart6 start6 506 indexStore6x5 indexWork6x5 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x5 indexRow6x5.1 indexRow6x5.2 indexWork6x6 ref6x5 tail6x6
theorem tail6x4 : indexedParents perm6 apart6 start6 506 indexStore6x4 indexWork6x4 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x4 indexRow6x4.1 indexRow6x4.2 indexWork6x5 ref6x4 tail6x5
theorem tail6x3 : indexedParents perm6 apart6 start6 506 indexStore6x3 indexWork6x3 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x3 indexRow6x3.1 indexRow6x3.2 indexWork6x4 ref6x3 tail6x4
theorem tail6x2 : indexedParents perm6 apart6 start6 506 indexStore6x2 indexWork6x2 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x2 indexRow6x2.1 indexRow6x2.2 indexWork6x3 ref6x2 tail6x3
theorem tail6x1 : indexedParents perm6 apart6 start6 506 indexStore6x1 indexWork6x1 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x1 indexRow6x1.1 indexRow6x1.2 indexWork6x2 ref6x1 tail6x2
theorem tail6x0 : indexedParents perm6 apart6 start6 506 indexStore6x0 indexWork6x0 = true :=
  index_cons perm6 apart6 start6 506 indexStore6x0 indexRow6x0.1 indexRow6x0.2 indexWork6x1 ref6x0 tail6x1
end E1182TwelveBlock.Word32
#print axioms E1182TwelveBlock.Word32.tail6x0
