import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf24_0_3_7 : failed host0 pat24 (atPath host0 pat24 [7,3,0]) = true := by
  decide +kernel

theorem leaf24_0_3_10 : failed host0 pat24 (atPath host0 pat24 [10,3,0]) = true := by
  decide +kernel

theorem leaf24_0_3_11 : failed host0 pat24 (atPath host0 pat24 [11,3,0]) = true := by
  decide +kernel

theorem leaf24_0_3_12 : failed host0 pat24 (atPath host0 pat24 [12,3,0]) = true := by
  decide +kernel

theorem leaf24_0_3_13 : failed host0 pat24 (atPath host0 pat24 [13,3,0]) = true := by
  decide +kernel

theorem leaf24_0_3_14 : failed host0 pat24 (atPath host0 pat24 [14,3,0]) = true := by
  decide +kernel

theorem leaf24_0_3_17 : failed host0 pat24 (atPath host0 pat24 [17,3,0]) = true := by
  decide +kernel

theorem leaf24_0_4_1 : failed host0 pat24 (atPath host0 pat24 [1,4,0]) = true := by
  decide +kernel

end E1182ElevenBlock
