import TwinRule
import ValidHost4
import WordCut18
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem blocked18 : ¬ (codeGraph 11 pat18.mask) ⊑ (triGraph 21 host4.original)ᶜ := by
  apply null_of_test host4 pat18 hostValid4 (by decide +kernel) (twins_from_types pat18 34935961949610274343340289145558 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact Word32.miss18
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked18
