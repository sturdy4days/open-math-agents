import Intro11
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice11x25 : ((leaves11.drop 25).take 1).all test11=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice11x26 : ((leaves11.drop 26).take 4).all test11=true := by decide +kernel
end E1182TwelveBlock.Word32
