import Descent
import ValidHost1
namespace E1182ElevenBlock
theorem leaf4_7_0_4 : failed host1 pat4 (atPath host1 pat4 [4,0,7]) = true := by
  decide +kernel

theorem leaf4_7_0_9 : failed host1 pat4 (atPath host1 pat4 [9,0,7]) = true := by
  decide +kernel

theorem leaf4_7_0_10 : failed host1 pat4 (atPath host1 pat4 [10,0,7]) = true := by
  decide +kernel

theorem leaf4_7_0_11 : failed host1 pat4 (atPath host1 pat4 [11,0,7]) = true := by
  decide +kernel

theorem leaf4_7_0_12 : failed host1 pat4 (atPath host1 pat4 [12,0,7]) = true := by
  decide +kernel

theorem leaf4_7_0_13 : failed host1 pat4 (atPath host1 pat4 [13,0,7]) = true := by
  decide +kernel

theorem leaf4_7_1_1 : failed host1 pat4 (atPath host1 pat4 [1,1,7]) = true := by
  decide +kernel

theorem leaf4_7_1_2 : failed host1 pat4 (atPath host1 pat4 [2,1,7]) = true := by
  decide +kernel

theorem leaf4_7_1_4 : failed host1 pat4 (atPath host1 pat4 [4,1,7]) = true := by
  decide +kernel

theorem leaf4_7_1_9 : failed host1 pat4 (atPath host1 pat4 [9,1,7]) = true := by
  decide +kernel

end E1182ElevenBlock
