import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf19_0_11 : failed host0 pat19 (atPath host0 pat19 [11,0]) = true := by
  decide +kernel

theorem leaf19_0_12 : failed host0 pat19 (atPath host0 pat19 [12,0]) = true := by
  decide +kernel

theorem leaf19_0_13 : failed host0 pat19 (atPath host0 pat19 [13,0]) = true := by
  decide +kernel

theorem leaf19_0_14 : failed host0 pat19 (atPath host0 pat19 [14,0]) = true := by
  decide +kernel

end E1182ElevenBlock
