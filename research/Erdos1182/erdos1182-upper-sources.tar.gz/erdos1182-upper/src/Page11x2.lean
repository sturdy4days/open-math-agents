import Intro11
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice11x3 : ((leaves11.drop 3).take 1).all test11=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice11x4 : ((leaves11.drop 4).take 2).all test11=true := by decide +kernel
end E1182TwelveBlock.Word32
