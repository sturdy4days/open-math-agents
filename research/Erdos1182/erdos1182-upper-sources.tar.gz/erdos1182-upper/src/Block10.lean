import Cut10P0
import Cut10P1
import Cut10P2
import Cut10P3
import Cut10P4
import Cut10P5
import Cut10P6
import Cut10P7
import Descent
import Descent
import TwinRule
import ValidHost0
namespace E1182ElevenBlock
open SimpleGraph E1182Cover

private theorem leaf10_0_3 : failed host0 pat10 (atPath host0 pat10 [3,0]) = true := by
  apply failed_atPath _ _ _ [4,7,10,11,12,13,14,17,20] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf10_0_3_4
  · exact leaf10_0_3_7
  · exact leaf10_0_3_10
  · exact leaf10_0_3_11
  · exact leaf10_0_3_12
  · exact leaf10_0_3_13
  · exact leaf10_0_3_14
  · exact leaf10_0_3_17
  · exact leaf10_0_3_20

private theorem leaf10_0_4 : failed host0 pat10 (atPath host0 pat10 [4,0]) = true := by
  apply failed_atPath _ _ _ [7,8,11,12,13,14,17,18] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf10_0_4_7
  · exact leaf10_0_4_8
  · exact leaf10_0_4_11
  · exact leaf10_0_4_12
  · exact leaf10_0_4_13
  · exact leaf10_0_4_14
  · exact leaf10_0_4_17
  · exact leaf10_0_4_18

private theorem leaf10_0_7 : failed host0 pat10 (atPath host0 pat10 [7,0]) = true := by
  apply failed_atPath _ _ _ [8,10,11,14,17,18,20] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf10_0_7_8
  · exact leaf10_0_7_10
  · exact leaf10_0_7_11
  · exact leaf10_0_7_14
  · exact leaf10_0_7_17
  · exact leaf10_0_7_18
  · exact leaf10_0_7_20

private theorem leaf10_0_10 : failed host0 pat10 (atPath host0 pat10 [10,0]) = true := by
  apply failed_atPath _ _ _ [11,13,14,17,18,20] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf10_0_10_11
  · exact leaf10_0_10_13
  · exact leaf10_0_10_14
  · exact leaf10_0_10_17
  · exact leaf10_0_10_18
  · exact leaf10_0_10_20

private theorem leaf10_0_11 : failed host0 pat10 (atPath host0 pat10 [11,0]) = true := by
  apply failed_atPath _ _ _ [12,14,18,20] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl
  · exact leaf10_0_11_12
  · exact leaf10_0_11_14
  · exact leaf10_0_11_18
  · exact leaf10_0_11_20

private theorem leaf10_0 : failed host0 pat10 (atPath host0 pat10 [0]) = true := by
  apply failed_atPath _ _ _ [1,3,4,7,8,9,10,11,12,13,14,17] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf10_0_1
  · exact leaf10_0_3
  · exact leaf10_0_4
  · exact leaf10_0_7
  · exact leaf10_0_8
  · exact leaf10_0_9
  · exact leaf10_0_10
  · exact leaf10_0_11
  · exact leaf10_0_12
  · exact leaf10_0_13
  · exact leaf10_0_14
  · exact leaf10_0_17

private theorem leaf10_root : failed host0 pat10 (atPath host0 pat10 []) = true := by
  apply failed_atPath _ _ _ [0] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  subst v
  exact leaf10_0

theorem blocked10 : ¬ (codeGraph 11 pat10.mask) ⊑ (triGraph 21 host0.original)ᶜ := by
  apply null_of_test host0 pat10 hostValid0 (by decide +kernel) (twins_from_types pat10 163102053333376055622609790786538 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact rejects_of_failed_root _ _ leaf10_root
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked10
