import Intro1
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice1x0 : ((leaves1.drop 0).take 2).all test1=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice1x2 : ((leaves1.drop 2).take 1).all test1=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice1x3 : ((leaves1.drop 3).take 2).all test1=true := by decide +kernel
end E1182TwelveBlock.Word32
