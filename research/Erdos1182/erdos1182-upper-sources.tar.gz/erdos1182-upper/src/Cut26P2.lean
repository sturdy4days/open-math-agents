import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf26_0_4_18 : failed host0 pat26 (atPath host0 pat26 [18,4,0]) = true := by
  decide +kernel

theorem leaf26_0_7_8 : failed host0 pat26 (atPath host0 pat26 [8,7,0]) = true := by
  decide +kernel

theorem leaf26_0_7_10 : failed host0 pat26 (atPath host0 pat26 [10,7,0]) = true := by
  decide +kernel

theorem leaf26_0_7_11 : failed host0 pat26 (atPath host0 pat26 [11,7,0]) = true := by
  decide +kernel

theorem leaf26_0_7_14 : failed host0 pat26 (atPath host0 pat26 [14,7,0]) = true := by
  decide +kernel

theorem leaf26_0_7_17 : failed host0 pat26 (atPath host0 pat26 [17,7,0]) = true := by
  decide +kernel

theorem leaf26_0_7_18 : failed host0 pat26 (atPath host0 pat26 [18,7,0]) = true := by
  decide +kernel

theorem leaf26_0_7_20 : failed host0 pat26 (atPath host0 pat26 [20,7,0]) = true := by
  decide +kernel

end E1182ElevenBlock
