import Intro12
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice12x61 : ((leaves12.drop 61).take 3).all test12=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice12x64 : ((leaves12.drop 64).take 4).all test12=true := by decide +kernel
end E1182TwelveBlock.Word32
