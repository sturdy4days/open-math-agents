import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf35_0_1 : failed host0 pat35 (atPath host0 pat35 [1,0]) = true := by
  decide +kernel

theorem leaf35_0_3_4 : failed host0 pat35 (atPath host0 pat35 [4,3,0]) = true := by
  decide +kernel

theorem leaf35_0_3_7 : failed host0 pat35 (atPath host0 pat35 [7,3,0]) = true := by
  decide +kernel

theorem leaf35_0_3_10 : failed host0 pat35 (atPath host0 pat35 [10,3,0]) = true := by
  decide +kernel

theorem leaf35_0_3_11 : failed host0 pat35 (atPath host0 pat35 [11,3,0]) = true := by
  decide +kernel

theorem leaf35_0_3_12 : failed host0 pat35 (atPath host0 pat35 [12,3,0]) = true := by
  decide +kernel

theorem leaf35_0_3_13 : failed host0 pat35 (atPath host0 pat35 [13,3,0]) = true := by
  decide +kernel

theorem leaf35_0_3_14 : failed host0 pat35 (atPath host0 pat35 [14,3,0]) = true := by
  decide +kernel

theorem leaf35_0_3_17 : failed host0 pat35 (atPath host0 pat35 [17,3,0]) = true := by
  decide +kernel

end E1182ElevenBlock
