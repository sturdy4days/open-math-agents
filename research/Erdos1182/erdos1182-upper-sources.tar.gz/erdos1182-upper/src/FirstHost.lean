import ProfileBase
import Mathlib.Tactic.FinCases
import Mathlib.Algebra.BigOperators.Fin
open SimpleGraph

namespace E1182Cover

private def seedMasks : List ℕ := [61500,58777656,1080899112137670672]

private def HasSeed (k : Fin 5 → ℕ) : Prop :=
  ∃ m ∈ seedMasks, ∃ e : Fin 10 ↪ Slots k, ∀ i j, (codeGraph 10 m).Adj i j →
    classAdj (e i).1 (e j).1

private def sparseProfiles : List (Fin 5 → ℕ) := [
  seedSizes 0 2 4 0 4,
  seedSizes 0 3 3 0 4,
  seedSizes 0 4 0 2 4,
  seedSizes 0 4 0 3 3,
  seedSizes 0 4 0 4 2,
  seedSizes 0 4 1 1 4,
  seedSizes 0 4 2 0 4,
  seedSizes 1 1 4 0 4,
  seedSizes 1 4 0 4 1,
  seedSizes 2 0 4 0 4,
  seedSizes 2 4 0 4 0,
  seedSizes 3 0 4 0 3,
  seedSizes 3 3 0 4 0]

set_option maxRecDepth 10000 in
set_option maxHeartbeats 2500000 in
private theorem count_cases :
    ∀ (a : Fin 4) (b c d e : Fin 5), a.val+b.val+c.val+d.val+e.val = 10 →
    a.val*b.val+b.val*c.val+c.val*d.val+d.val*e.val+e.val*a.val ≤ 11 →
    seedSizes a.val b.val c.val d.val e.val ∈ sparseProfiles := by
  intro a b
  fin_cases a <;> fin_cases b <;> decide

set_option maxRecDepth 10000 in
private theorem profile_0 : HasSeed (seedSizes 0 2 4 0 4) := by
  let push : Fin 10 → Slots (seedSizes 0 2 4 0 4) := ![
    ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨2, ⟨3, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩]
  exact ⟨61500, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_1 : HasSeed (seedSizes 0 3 3 0 4) := by
  let push : Fin 10 → Slots (seedSizes 0 3 3 0 4) := ![
    ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨1, ⟨2, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩]
  exact ⟨58777656, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_2 : HasSeed (seedSizes 0 4 0 2 4) := by
  let push : Fin 10 → Slots (seedSizes 0 4 0 2 4) := ![
    ⟨3, ⟨0, by decide⟩⟩, ⟨3, ⟨1, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩, ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨1, ⟨2, by decide⟩⟩, ⟨1, ⟨3, by decide⟩⟩]
  exact ⟨61500, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_3 : HasSeed (seedSizes 0 4 0 3 3) := by
  let push : Fin 10 → Slots (seedSizes 0 4 0 3 3) := ![
    ⟨3, ⟨0, by decide⟩⟩, ⟨3, ⟨1, by decide⟩⟩, ⟨3, ⟨2, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨1, ⟨2, by decide⟩⟩, ⟨1, ⟨3, by decide⟩⟩]
  exact ⟨58777656, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_4 : HasSeed (seedSizes 0 4 0 4 2) := by
  let push : Fin 10 → Slots (seedSizes 0 4 0 4 2) := ![
    ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨3, ⟨0, by decide⟩⟩, ⟨3, ⟨1, by decide⟩⟩, ⟨3, ⟨2, by decide⟩⟩, ⟨3, ⟨3, by decide⟩⟩, ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨1, ⟨2, by decide⟩⟩, ⟨1, ⟨3, by decide⟩⟩]
  exact ⟨61500, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_5 : HasSeed (seedSizes 0 4 1 1 4) := by
  let push : Fin 10 → Slots (seedSizes 0 4 1 1 4) := ![
    ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨1, ⟨2, by decide⟩⟩, ⟨1, ⟨3, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨3, ⟨0, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩]
  exact ⟨1080899112137670672, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_6 : HasSeed (seedSizes 0 4 2 0 4) := by
  let push : Fin 10 → Slots (seedSizes 0 4 2 0 4) := ![
    ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨1, ⟨2, by decide⟩⟩, ⟨1, ⟨3, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩]
  exact ⟨61500, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_7 : HasSeed (seedSizes 1 1 4 0 4) := by
  let push : Fin 10 → Slots (seedSizes 1 1 4 0 4) := ![
    ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩, ⟨0, ⟨0, by decide⟩⟩, ⟨1, ⟨0, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨2, ⟨3, by decide⟩⟩]
  exact ⟨1080899112137670672, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_8 : HasSeed (seedSizes 1 4 0 4 1) := by
  let push : Fin 10 → Slots (seedSizes 1 4 0 4 1) := ![
    ⟨3, ⟨0, by decide⟩⟩, ⟨3, ⟨1, by decide⟩⟩, ⟨3, ⟨2, by decide⟩⟩, ⟨3, ⟨3, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨0, ⟨0, by decide⟩⟩, ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨1, ⟨2, by decide⟩⟩, ⟨1, ⟨3, by decide⟩⟩]
  exact ⟨1080899112137670672, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_9 : HasSeed (seedSizes 2 0 4 0 4) := by
  let push : Fin 10 → Slots (seedSizes 2 0 4 0 4) := ![
    ⟨0, ⟨0, by decide⟩⟩, ⟨0, ⟨1, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨2, ⟨3, by decide⟩⟩]
  exact ⟨61500, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_10 : HasSeed (seedSizes 2 4 0 4 0) := by
  let push : Fin 10 → Slots (seedSizes 2 4 0 4 0) := ![
    ⟨0, ⟨0, by decide⟩⟩, ⟨0, ⟨1, by decide⟩⟩, ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨1, ⟨2, by decide⟩⟩, ⟨1, ⟨3, by decide⟩⟩, ⟨3, ⟨0, by decide⟩⟩, ⟨3, ⟨1, by decide⟩⟩, ⟨3, ⟨2, by decide⟩⟩, ⟨3, ⟨3, by decide⟩⟩]
  exact ⟨61500, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_11 : HasSeed (seedSizes 3 0 4 0 3) := by
  let push : Fin 10 → Slots (seedSizes 3 0 4 0 3) := ![
    ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨0, ⟨0, by decide⟩⟩, ⟨0, ⟨1, by decide⟩⟩, ⟨0, ⟨2, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨2, ⟨3, by decide⟩⟩]
  exact ⟨58777656, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_12 : HasSeed (seedSizes 3 3 0 4 0) := by
  let push : Fin 10 → Slots (seedSizes 3 3 0 4 0) := ![
    ⟨0, ⟨0, by decide⟩⟩, ⟨0, ⟨1, by decide⟩⟩, ⟨0, ⟨2, by decide⟩⟩, ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨1, ⟨2, by decide⟩⟩, ⟨3, ⟨0, by decide⟩⟩, ⟨3, ⟨1, by decide⟩⟩, ⟨3, ⟨2, by decide⟩⟩, ⟨3, ⟨3, by decide⟩⟩]
  exact ⟨58777656, by decide, ⟨push, by decide⟩, by decide⟩

private theorem profile_has_seed (k : Fin 5 → ℕ)
    (cap : ∀ i, k i ≤ seedSizes 3 4 4 4 4 i)
    (total : ∑ i, k i = 10) (edge : ∑ i, k i * k (classNext i) ≤ 11) : HasSeed k := by
  let a : Fin 4 := ⟨k 0, Nat.lt_succ_of_le (cap 0)⟩
  let b : Fin 5 := ⟨k 1, Nat.lt_succ_of_le (cap 1)⟩
  let c : Fin 5 := ⟨k 2, Nat.lt_succ_of_le (cap 2)⟩
  let d : Fin 5 := ⟨k 3, Nat.lt_succ_of_le (cap 3)⟩
  let e : Fin 5 := ⟨k 4, Nat.lt_succ_of_le (cap 4)⟩
  have members := count_cases a b c d e
  have ht : a.val+b.val+c.val+d.val+e.val = 10 := by
    simpa [a,b,c,d,e, Fin.sum_univ_succ, add_assoc] using total
  have he : a.val*b.val+b.val*c.val+c.val*d.val+d.val*e.val+e.val*a.val ≤ 11 := by
    simpa [a,b,c,d,e, Fin.sum_univ_succ, classNext, add_assoc] using edge
  have ks : seedSizes a.val b.val c.val d.val e.val = k := by
    funext i
    fin_cases i <;> rfl
  have hm := ks ▸ members ht he
  simp only [sparseProfiles, List.mem_cons, List.not_mem_nil, or_false] at hm
  rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact profile_0
  · exact profile_1
  · exact profile_2
  · exact profile_3
  · exact profile_4
  · exact profile_5
  · exact profile_6
  · exact profile_7
  · exact profile_8
  · exact profile_9
  · exact profile_10
  · exact profile_11
  · exact profile_12

theorem from_first_host (D : SimpleGraph (Fin 10)) (edge : D.edgeSet.ncard = 11)
    (f : Fin 10 ↪ Fin 19)
    (copy : ∀ i j, (codeGraph 19 58280177927389562003304118167894045837298871419233698940907216524622014388169689497720).Adj (f i) (f j) → D.Adj i j) :
    ∃ m ∈ [61500,58777656,1080899112137670672], codeGraph 10 m ⊑ D := by
  obtain ⟨k,u,cap,total,bound,adj⟩ := first_host_slots D f copy
  obtain ⟨m,hm,p,hp⟩ := profile_has_seed k cap total (edge ▸ bound)
  exact ⟨m, hm, ⟨⟨⟨u ∘ p, fun h => adj _ _ (hp _ _ h)⟩, u.injective.comp p.injective⟩⟩⟩

#print axioms from_first_host

end E1182Cover
