import Submission
import H4Left

/-! The explicit 21-vertex hosts give an upper bound for the article's extremal function. -/

open SimpleGraph
namespace E1182Complete

theorem upper_of_hosts {n r q : ℕ} (large : 2 ≤ n) (C : Fin r → SimpleGraph (Fin (2*n-1)))
    (tri : ∀ a, (C a).CliqueFree 3) (cap : ∀ f : Fin r → Fin n ↪ Fin (2*n-1),
      let D := ⨅ a, (C a)ᶜ.comap (f a)
      D.Connected → D.edgeSet.ncard ≤ q) : Erdos1182.f n ≤ q := by
  classical
  unfold Erdos1182.f
  apply csSup_le'
  rintro k ⟨G,connected,rfl,good⟩
  by_contra! high
  obtain ⟨T,free,miss⟩ := SmallTable.Blockers.common C tri cap G connected high
  exact miss ((SmallTable.Dense.good_iff large connected).mp good T free)

theorem upper_eleven : Erdos1182.f 11 ≤ 41 := by
  let C (a : Fin E1182Eleven.masks.length) := E1182Eleven.triGraph 21 E1182Eleven.masks[a.val]
  exact upper_of_hosts (by decide) C (FixedRamseyHosts.families_free 0) E1182Eleven.h4_eleven

end E1182Complete
#print axioms E1182Complete.upper_eleven
