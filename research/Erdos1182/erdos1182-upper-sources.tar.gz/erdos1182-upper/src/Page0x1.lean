import Intro0
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice0x6 : ((leaves0.drop 6).take 2).all test0=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice0x8 : ((leaves0.drop 8).take 2).all test0=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice0x10 : ((leaves0.drop 10).take 1).all test0=true := by decide +kernel
end E1182TwelveBlock.Word32
