import Intro11
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice11x0 : ((leaves11.drop 0).take 1).all test11=true := by decide +kernel
end E1182TwelveBlock.Word32
