import Intro14
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice14x9 : ((leaves14.drop 9).take 1).all test14=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice14x10 : ((leaves14.drop 10).take 3).all test14=true := by decide +kernel
end E1182TwelveBlock.Word32
