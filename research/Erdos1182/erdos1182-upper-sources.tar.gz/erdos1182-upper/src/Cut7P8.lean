import Descent
import ValidHost3
namespace E1182ElevenBlock
theorem leaf7_18_13 : failed host3 pat7 (atPath host3 pat7 [13,18]) = true := by
  decide +kernel

theorem leaf7_18_14 : failed host3 pat7 (atPath host3 pat7 [14,18]) = true := by
  decide +kernel

theorem leaf7_18_15 : failed host3 pat7 (atPath host3 pat7 [15,18]) = true := by
  decide +kernel

theorem leaf7_18_16 : failed host3 pat7 (atPath host3 pat7 [16,18]) = true := by
  decide +kernel

theorem leaf7_18_17 : failed host3 pat7 (atPath host3 pat7 [17,18]) = true := by
  decide +kernel

end E1182ElevenBlock
