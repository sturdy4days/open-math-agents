import OriginalH4
import H4Right

/-! Discharge the two remaining finite host cases in the published fourth hypothesis. -/

theorem E1182Complete.fixed_hosts :
    OMA.R_Erdos1182_erdos_1182_variants_small_values_R2.H4 :=
  E1182Eleven.original_H4_from_twelve E1182Twelve.h4_twelve

#print axioms E1182Complete.fixed_hosts
