import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf24_0_14_3 : failed host0 pat24 (atPath host0 pat24 [3,14,0]) = true := by
  decide +kernel

theorem leaf24_0_14_4 : failed host0 pat24 (atPath host0 pat24 [4,14,0]) = true := by
  decide +kernel

theorem leaf24_0_14_7 : failed host0 pat24 (atPath host0 pat24 [7,14,0]) = true := by
  decide +kernel

theorem leaf24_0_14_10 : failed host0 pat24 (atPath host0 pat24 [10,14,0]) = true := by
  decide +kernel

theorem leaf24_0_14_11 : failed host0 pat24 (atPath host0 pat24 [11,14,0]) = true := by
  decide +kernel

theorem leaf24_0_14_13 : failed host0 pat24 (atPath host0 pat24 [13,14,0]) = true := by
  decide +kernel

theorem leaf24_0_14_17 : failed host0 pat24 (atPath host0 pat24 [17,14,0]) = true := by
  decide +kernel

theorem leaf24_0_17 : failed host0 pat24 (atPath host0 pat24 [17,0]) = true := by
  decide +kernel

theorem leaf24_0_18 : failed host0 pat24 (atPath host0 pat24 [18,0]) = true := by
  decide +kernel

end E1182ElevenBlock
