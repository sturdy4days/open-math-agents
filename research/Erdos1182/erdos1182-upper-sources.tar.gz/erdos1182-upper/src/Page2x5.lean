import Intro2
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x18 : ((leaves2.drop 18).take 2).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x20 : ((leaves2.drop 20).take 9).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x29 : ((leaves2.drop 29).take 3).all test2=true := by decide +kernel
end E1182TwelveBlock.Word32
