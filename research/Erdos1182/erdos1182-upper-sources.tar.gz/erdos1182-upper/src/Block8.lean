import TwinRule
import ValidHost3
import WordCut8
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem blocked8 : ¬ (codeGraph 11 pat8.mask) ⊑ (triGraph 21 host3.original)ᶜ := by
  apply null_of_test host3 pat8 hostValid3 (by decide +kernel) (twins_from_types pat8 1395683408018693331779033423469722 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact Word32.miss8
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked8
