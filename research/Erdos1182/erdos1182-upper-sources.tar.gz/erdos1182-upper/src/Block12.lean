import Descent
import TwinRule
import ValidHost0
namespace E1182ElevenBlock
open SimpleGraph E1182Cover

private theorem leaf12_0_1 : failed host0 pat12 (atPath host0 pat12 [1,0]) = true := by
  decide +kernel

private theorem leaf12_0_3 : failed host0 pat12 (atPath host0 pat12 [3,0]) = true := by
  decide +kernel

private theorem leaf12_0_4 : failed host0 pat12 (atPath host0 pat12 [4,0]) = true := by
  decide +kernel

private theorem leaf12_0_7 : failed host0 pat12 (atPath host0 pat12 [7,0]) = true := by
  decide +kernel

private theorem leaf12_0_8 : failed host0 pat12 (atPath host0 pat12 [8,0]) = true := by
  decide +kernel

private theorem leaf12_0_9 : failed host0 pat12 (atPath host0 pat12 [9,0]) = true := by
  decide +kernel

private theorem leaf12_0_10 : failed host0 pat12 (atPath host0 pat12 [10,0]) = true := by
  decide +kernel

private theorem leaf12_0_11 : failed host0 pat12 (atPath host0 pat12 [11,0]) = true := by
  decide +kernel

private theorem leaf12_0_12 : failed host0 pat12 (atPath host0 pat12 [12,0]) = true := by
  decide +kernel

private theorem leaf12_0_13 : failed host0 pat12 (atPath host0 pat12 [13,0]) = true := by
  decide +kernel

private theorem leaf12_0_14 : failed host0 pat12 (atPath host0 pat12 [14,0]) = true := by
  decide +kernel

private theorem leaf12_0_17 : failed host0 pat12 (atPath host0 pat12 [17,0]) = true := by
  decide +kernel

private theorem leaf12_0 : failed host0 pat12 (atPath host0 pat12 [0]) = true := by
  apply failed_atPath _ _ _ [1,3,4,7,8,9,10,11,12,13,14,17] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf12_0_1
  · exact leaf12_0_3
  · exact leaf12_0_4
  · exact leaf12_0_7
  · exact leaf12_0_8
  · exact leaf12_0_9
  · exact leaf12_0_10
  · exact leaf12_0_11
  · exact leaf12_0_12
  · exact leaf12_0_13
  · exact leaf12_0_14
  · exact leaf12_0_17

private theorem leaf12_root : failed host0 pat12 (atPath host0 pat12 []) = true := by
  apply failed_atPath _ _ _ [0] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  subst v
  exact leaf12_0

theorem blocked12 : ¬ (codeGraph 11 pat12.mask) ⊑ (triGraph 21 host0.original)ᶜ := by
  apply null_of_test host0 pat12 hostValid0 (by decide +kernel) (twins_from_types pat12 124149428124808332755016456498 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact rejects_of_failed_root _ _ leaf12_root
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked12
