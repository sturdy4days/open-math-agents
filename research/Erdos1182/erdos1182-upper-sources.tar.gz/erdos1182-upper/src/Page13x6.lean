import Intro13
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x31 : ((leaves13.drop 31).take 1).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x32 : ((leaves13.drop 32).take 1).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x33 : ((leaves13.drop 33).take 2).all test13=true := by decide +kernel
end E1182TwelveBlock.Word32
