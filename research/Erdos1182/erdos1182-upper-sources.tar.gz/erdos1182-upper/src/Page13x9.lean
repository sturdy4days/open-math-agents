import Intro13
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x47 : ((leaves13.drop 47).take 3).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x50 : ((leaves13.drop 50).take 5).all test13=true := by decide +kernel
end E1182TwelveBlock.Word32
