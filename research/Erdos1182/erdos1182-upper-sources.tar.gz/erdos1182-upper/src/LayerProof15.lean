import Check15_0
import Check15_10
import Check15_20
import Check15_30
import Check15_40
import Check15_50
import Check15_60
import Check15_70
import Check15_80
import Check15_90
import Check15_100
import Check15_110
import Check15_120
import Check15_130
import Check15_140
import Check15_150
import Check15_160
import Check15_170
import Check15_180
import Check15_190
import Check15_200
import Check15_210
import Check15_220
import Check15_230
import Check15_240
import Check15_250
import Check15_260
import Check15_270
import Check15_280
import Check15_290
import Check15_300
import Check15_310
import Check15_320
import Check15_330
import Check15_340
import Check15_350
import Check15_360
import Check15_370
import Check15_380
import Check15_390
import Check15_400
import Check15_410
import Check15_420
import Check15_430
import Check15_440
import Check15_450
import Check15_460
import Check15_470
import Check15_480
import Check15_490
import Check15_500
import Check15_510
import Check15_520
import Check15_530
import Check15_540
import Check15_550
import Check15_560
import Check15_570
import Check15_580
import Check15_590
import Check15_600
import Check15_610
import Check15_620
import Check15_630
import Check15_640
import Check15_650
import Check15_660
import Check15_670
import Check15_680
import Check15_690
import Check15_700
import Check15_710
namespace E1182Twelve
theorem cover15_0_20 : rows l15 l16 3130 b15 o15 z15 0 20 := rows_append (d:=10) (e:=10) r15_0 r15_10
theorem cover15_20_20 : rows l15 l16 3130 b15 o15 z15 20 20 := rows_append (d:=10) (e:=10) r15_20 r15_30
theorem cover15_40_20 : rows l15 l16 3130 b15 o15 z15 40 20 := rows_append (d:=10) (e:=10) r15_40 r15_50
theorem cover15_60_20 : rows l15 l16 3130 b15 o15 z15 60 20 := rows_append (d:=10) (e:=10) r15_60 r15_70
theorem cover15_80_20 : rows l15 l16 3130 b15 o15 z15 80 20 := rows_append (d:=10) (e:=10) r15_80 r15_90
theorem cover15_100_20 : rows l15 l16 3130 b15 o15 z15 100 20 := rows_append (d:=10) (e:=10) r15_100 r15_110
theorem cover15_120_20 : rows l15 l16 3130 b15 o15 z15 120 20 := rows_append (d:=10) (e:=10) r15_120 r15_130
theorem cover15_140_20 : rows l15 l16 3130 b15 o15 z15 140 20 := rows_append (d:=10) (e:=10) r15_140 r15_150
theorem cover15_160_20 : rows l15 l16 3130 b15 o15 z15 160 20 := rows_append (d:=10) (e:=10) r15_160 r15_170
theorem cover15_180_20 : rows l15 l16 3130 b15 o15 z15 180 20 := rows_append (d:=10) (e:=10) r15_180 r15_190
theorem cover15_200_20 : rows l15 l16 3130 b15 o15 z15 200 20 := rows_append (d:=10) (e:=10) r15_200 r15_210
theorem cover15_220_20 : rows l15 l16 3130 b15 o15 z15 220 20 := rows_append (d:=10) (e:=10) r15_220 r15_230
theorem cover15_240_20 : rows l15 l16 3130 b15 o15 z15 240 20 := rows_append (d:=10) (e:=10) r15_240 r15_250
theorem cover15_260_20 : rows l15 l16 3130 b15 o15 z15 260 20 := rows_append (d:=10) (e:=10) r15_260 r15_270
theorem cover15_280_20 : rows l15 l16 3130 b15 o15 z15 280 20 := rows_append (d:=10) (e:=10) r15_280 r15_290
theorem cover15_300_20 : rows l15 l16 3130 b15 o15 z15 300 20 := rows_append (d:=10) (e:=10) r15_300 r15_310
theorem cover15_320_20 : rows l15 l16 3130 b15 o15 z15 320 20 := rows_append (d:=10) (e:=10) r15_320 r15_330
theorem cover15_340_20 : rows l15 l16 3130 b15 o15 z15 340 20 := rows_append (d:=10) (e:=10) r15_340 r15_350
theorem cover15_360_20 : rows l15 l16 3130 b15 o15 z15 360 20 := rows_append (d:=10) (e:=10) r15_360 r15_370
theorem cover15_380_20 : rows l15 l16 3130 b15 o15 z15 380 20 := rows_append (d:=10) (e:=10) r15_380 r15_390
theorem cover15_400_20 : rows l15 l16 3130 b15 o15 z15 400 20 := rows_append (d:=10) (e:=10) r15_400 r15_410
theorem cover15_420_20 : rows l15 l16 3130 b15 o15 z15 420 20 := rows_append (d:=10) (e:=10) r15_420 r15_430
theorem cover15_440_20 : rows l15 l16 3130 b15 o15 z15 440 20 := rows_append (d:=10) (e:=10) r15_440 r15_450
theorem cover15_460_20 : rows l15 l16 3130 b15 o15 z15 460 20 := rows_append (d:=10) (e:=10) r15_460 r15_470
theorem cover15_480_20 : rows l15 l16 3130 b15 o15 z15 480 20 := rows_append (d:=10) (e:=10) r15_480 r15_490
theorem cover15_500_20 : rows l15 l16 3130 b15 o15 z15 500 20 := rows_append (d:=10) (e:=10) r15_500 r15_510
theorem cover15_520_20 : rows l15 l16 3130 b15 o15 z15 520 20 := rows_append (d:=10) (e:=10) r15_520 r15_530
theorem cover15_540_20 : rows l15 l16 3130 b15 o15 z15 540 20 := rows_append (d:=10) (e:=10) r15_540 r15_550
theorem cover15_560_20 : rows l15 l16 3130 b15 o15 z15 560 20 := rows_append (d:=10) (e:=10) r15_560 r15_570
theorem cover15_580_20 : rows l15 l16 3130 b15 o15 z15 580 20 := rows_append (d:=10) (e:=10) r15_580 r15_590
theorem cover15_600_20 : rows l15 l16 3130 b15 o15 z15 600 20 := rows_append (d:=10) (e:=10) r15_600 r15_610
theorem cover15_620_20 : rows l15 l16 3130 b15 o15 z15 620 20 := rows_append (d:=10) (e:=10) r15_620 r15_630
theorem cover15_640_20 : rows l15 l16 3130 b15 o15 z15 640 20 := rows_append (d:=10) (e:=10) r15_640 r15_650
theorem cover15_660_20 : rows l15 l16 3130 b15 o15 z15 660 20 := rows_append (d:=10) (e:=10) r15_660 r15_670
theorem cover15_680_20 : rows l15 l16 3130 b15 o15 z15 680 20 := rows_append (d:=10) (e:=10) r15_680 r15_690
theorem cover15_700_19 : rows l15 l16 3130 b15 o15 z15 700 19 := rows_append (d:=10) (e:=9) r15_700 r15_710
theorem cover15_0_40 : rows l15 l16 3130 b15 o15 z15 0 40 := rows_append (d:=20) (e:=20) cover15_0_20 cover15_20_20
theorem cover15_40_40 : rows l15 l16 3130 b15 o15 z15 40 40 := rows_append (d:=20) (e:=20) cover15_40_20 cover15_60_20
theorem cover15_80_40 : rows l15 l16 3130 b15 o15 z15 80 40 := rows_append (d:=20) (e:=20) cover15_80_20 cover15_100_20
theorem cover15_120_40 : rows l15 l16 3130 b15 o15 z15 120 40 := rows_append (d:=20) (e:=20) cover15_120_20 cover15_140_20
theorem cover15_160_40 : rows l15 l16 3130 b15 o15 z15 160 40 := rows_append (d:=20) (e:=20) cover15_160_20 cover15_180_20
theorem cover15_200_40 : rows l15 l16 3130 b15 o15 z15 200 40 := rows_append (d:=20) (e:=20) cover15_200_20 cover15_220_20
theorem cover15_240_40 : rows l15 l16 3130 b15 o15 z15 240 40 := rows_append (d:=20) (e:=20) cover15_240_20 cover15_260_20
theorem cover15_280_40 : rows l15 l16 3130 b15 o15 z15 280 40 := rows_append (d:=20) (e:=20) cover15_280_20 cover15_300_20
theorem cover15_320_40 : rows l15 l16 3130 b15 o15 z15 320 40 := rows_append (d:=20) (e:=20) cover15_320_20 cover15_340_20
theorem cover15_360_40 : rows l15 l16 3130 b15 o15 z15 360 40 := rows_append (d:=20) (e:=20) cover15_360_20 cover15_380_20
theorem cover15_400_40 : rows l15 l16 3130 b15 o15 z15 400 40 := rows_append (d:=20) (e:=20) cover15_400_20 cover15_420_20
theorem cover15_440_40 : rows l15 l16 3130 b15 o15 z15 440 40 := rows_append (d:=20) (e:=20) cover15_440_20 cover15_460_20
theorem cover15_480_40 : rows l15 l16 3130 b15 o15 z15 480 40 := rows_append (d:=20) (e:=20) cover15_480_20 cover15_500_20
theorem cover15_520_40 : rows l15 l16 3130 b15 o15 z15 520 40 := rows_append (d:=20) (e:=20) cover15_520_20 cover15_540_20
theorem cover15_560_40 : rows l15 l16 3130 b15 o15 z15 560 40 := rows_append (d:=20) (e:=20) cover15_560_20 cover15_580_20
theorem cover15_600_40 : rows l15 l16 3130 b15 o15 z15 600 40 := rows_append (d:=20) (e:=20) cover15_600_20 cover15_620_20
theorem cover15_640_40 : rows l15 l16 3130 b15 o15 z15 640 40 := rows_append (d:=20) (e:=20) cover15_640_20 cover15_660_20
theorem cover15_680_39 : rows l15 l16 3130 b15 o15 z15 680 39 := rows_append (d:=20) (e:=19) cover15_680_20 cover15_700_19
theorem cover15_0_80 : rows l15 l16 3130 b15 o15 z15 0 80 := rows_append (d:=40) (e:=40) cover15_0_40 cover15_40_40
theorem cover15_80_80 : rows l15 l16 3130 b15 o15 z15 80 80 := rows_append (d:=40) (e:=40) cover15_80_40 cover15_120_40
theorem cover15_160_80 : rows l15 l16 3130 b15 o15 z15 160 80 := rows_append (d:=40) (e:=40) cover15_160_40 cover15_200_40
theorem cover15_240_80 : rows l15 l16 3130 b15 o15 z15 240 80 := rows_append (d:=40) (e:=40) cover15_240_40 cover15_280_40
theorem cover15_320_80 : rows l15 l16 3130 b15 o15 z15 320 80 := rows_append (d:=40) (e:=40) cover15_320_40 cover15_360_40
theorem cover15_400_80 : rows l15 l16 3130 b15 o15 z15 400 80 := rows_append (d:=40) (e:=40) cover15_400_40 cover15_440_40
theorem cover15_480_80 : rows l15 l16 3130 b15 o15 z15 480 80 := rows_append (d:=40) (e:=40) cover15_480_40 cover15_520_40
theorem cover15_560_80 : rows l15 l16 3130 b15 o15 z15 560 80 := rows_append (d:=40) (e:=40) cover15_560_40 cover15_600_40
theorem cover15_640_79 : rows l15 l16 3130 b15 o15 z15 640 79 := rows_append (d:=40) (e:=39) cover15_640_40 cover15_680_39
theorem cover15_0_160 : rows l15 l16 3130 b15 o15 z15 0 160 := rows_append (d:=80) (e:=80) cover15_0_80 cover15_80_80
theorem cover15_160_160 : rows l15 l16 3130 b15 o15 z15 160 160 := rows_append (d:=80) (e:=80) cover15_160_80 cover15_240_80
theorem cover15_320_160 : rows l15 l16 3130 b15 o15 z15 320 160 := rows_append (d:=80) (e:=80) cover15_320_80 cover15_400_80
theorem cover15_480_160 : rows l15 l16 3130 b15 o15 z15 480 160 := rows_append (d:=80) (e:=80) cover15_480_80 cover15_560_80
theorem cover15_0_320 : rows l15 l16 3130 b15 o15 z15 0 320 := rows_append (d:=160) (e:=160) cover15_0_160 cover15_160_160
theorem cover15_320_320 : rows l15 l16 3130 b15 o15 z15 320 320 := rows_append (d:=160) (e:=160) cover15_320_160 cover15_480_160
theorem cover15_0_640 : rows l15 l16 3130 b15 o15 z15 0 640 := rows_append (d:=320) (e:=320) cover15_0_320 cover15_320_320
theorem cover15_0_719 : rows l15 l16 3130 b15 o15 z15 0 719 := rows_append (d:=640) (e:=79) cover15_0_640 cover15_640_79
theorem layer15 : rows l15 l16 3130 b15 o15 z15 0 719 := cover15_0_719
end E1182Twelve
