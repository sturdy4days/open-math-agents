import Intro4
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice4x13 : ((leaves4.drop 13).take 1).all test4=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice4x14 : ((leaves4.drop 14).take 1).all test4=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice4x15 : ((leaves4.drop 15).take 1).all test4=true := by decide +kernel
end E1182TwelveBlock.Word32
