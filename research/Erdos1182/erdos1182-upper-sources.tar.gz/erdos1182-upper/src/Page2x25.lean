import Intro2
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x181 : ((leaves2.drop 181).take 1).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x182 : ((leaves2.drop 182).take 2).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x184 : ((leaves2.drop 184).take 8).all test2=true := by decide +kernel
end E1182TwelveBlock.Word32
