import Intro10
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice10x0 : ((leaves10.drop 0).take 1).all test10=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice10x1 : ((leaves10.drop 1).take 2).all test10=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice10x3 : ((leaves10.drop 3).take 2).all test10=true := by decide +kernel
end E1182TwelveBlock.Word32
