import Descent
import ValidHost1
namespace E1182ElevenBlock
theorem leaf4_0_3_6 : failed host1 pat4 (atPath host1 pat4 [6,3,0]) = true := by
  decide +kernel

theorem leaf4_0_3_7 : failed host1 pat4 (atPath host1 pat4 [7,3,0]) = true := by
  decide +kernel

theorem leaf4_0_3_9 : failed host1 pat4 (atPath host1 pat4 [9,3,0]) = true := by
  decide +kernel

theorem leaf4_0_3_10 : failed host1 pat4 (atPath host1 pat4 [10,3,0]) = true := by
  decide +kernel

theorem leaf4_0_3_11 : failed host1 pat4 (atPath host1 pat4 [11,3,0]) = true := by
  decide +kernel

theorem leaf4_0_3_12 : failed host1 pat4 (atPath host1 pat4 [12,3,0]) = true := by
  decide +kernel

theorem leaf4_0_3_13 : failed host1 pat4 (atPath host1 pat4 [13,3,0]) = true := by
  decide +kernel

theorem leaf4_0_5_6 : failed host1 pat4 (atPath host1 pat4 [6,5,0]) = true := by
  decide +kernel

theorem leaf4_0_5_7 : failed host1 pat4 (atPath host1 pat4 [7,5,0]) = true := by
  decide +kernel

theorem leaf4_0_5_9 : failed host1 pat4 (atPath host1 pat4 [9,5,0]) = true := by
  decide +kernel

end E1182ElevenBlock
