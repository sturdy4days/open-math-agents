import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf17_0_14 : failed host0 pat17 (atPath host0 pat17 [14,0]) = true := by
  decide +kernel

theorem leaf17_0_17 : failed host0 pat17 (atPath host0 pat17 [17,0]) = true := by
  decide +kernel

end E1182ElevenBlock
