import Descent
import ValidHost1
namespace E1182ElevenBlock
theorem leaf41_2_7 : failed host1 pat41 (atPath host1 pat41 [7,2]) = true := by
  decide +kernel

theorem leaf41_2_8 : failed host1 pat41 (atPath host1 pat41 [8,2]) = true := by
  decide +kernel

theorem leaf41_2_9 : failed host1 pat41 (atPath host1 pat41 [9,2]) = true := by
  decide +kernel

theorem leaf41_2_11 : failed host1 pat41 (atPath host1 pat41 [11,2]) = true := by
  decide +kernel

theorem leaf41_2_12 : failed host1 pat41 (atPath host1 pat41 [12,2]) = true := by
  decide +kernel

theorem leaf41_3_0 : failed host1 pat41 (atPath host1 pat41 [0,3]) = true := by
  decide +kernel

theorem leaf41_3_4 : failed host1 pat41 (atPath host1 pat41 [4,3]) = true := by
  decide +kernel

theorem leaf41_3_5 : failed host1 pat41 (atPath host1 pat41 [5,3]) = true := by
  decide +kernel

theorem leaf41_3_6 : failed host1 pat41 (atPath host1 pat41 [6,3]) = true := by
  decide +kernel

theorem leaf41_3_8 : failed host1 pat41 (atPath host1 pat41 [8,3]) = true := by
  decide +kernel

end E1182ElevenBlock
