import FastTables
namespace E1182ElevenBlock

/-- Enumerate candidate colours using bit tests on a fixed-width machine word. -/
def anyMask (mask : ℕ) (f : ℕ → Bool) : ℕ → Bool
  | 0 => false
  | k+1 => (mask.testBit k && f k) || anyMask mask f k

theorem anyMask_complete {mask k v : ℕ} (f : ℕ → Bool) (small : v < k)
    (mem : mask.testBit v = true) (hit : f v = true) : anyMask mask f k=true := by
  induction k with
  | zero => omega
  | succ k ih =>
    rw [anyMask,Bool.or_eq_true]
    rcases Nat.lt_or_eq_of_le (Nat.le_of_lt_succ small) with lt|rfl
    · exact Or.inr (ih lt)
    · left
      simp only [mem,hit,Bool.true_and]

def compactSearch (perm : Fin 11 → ℕ → ℕ) (apart : ℕ → ℕ) :
    List (Fin 11) → ℕ → List ℕ → Bool
  | [],_,_ => true
  | i::t,word,supply =>
    anyMask (extractDomain word i) (fun v =>
      supply.contains v && (let remv := supply.erase v
                            let mask := word &&& perm i v
                            let ns := if remv.contains v then mask else mask &&& apart v
                            t.all (fun j => extractDomain ns j != 0) &&
                            compactSearch perm apart t ns remv)) 21

theorem search_complete (perm : Fin 11 → ℕ → ℕ) (apart : ℕ → ℕ) (xs : List (Fin 11))
    (word : ℕ) (supply : List ℕ) (found : fastSearch perm apart xs word supply = true) :
    compactSearch perm apart xs word supply = true := by
  induction xs generalizing word supply with
  | nil => rfl
  | cons i t ih =>
    obtain ⟨v,hv,ok⟩ := List.any_eq_true.mp found
    have bit := Nat.mem_bitIndices.mp hv
    have small : v < 21 := by
      by_contra! le
      have lt : extractDomain word i < 2^v := (Nat.mod_lt _ (by decide : 0 < 2^21)).trans_le
        (Nat.pow_le_pow_right (by decide : 0 < 2) le)
      rw [Nat.testBit_lt_two_pow lt] at bit
      exact Bool.noConfusion bit
    apply anyMask_complete _ small bit
    simp only [Bool.and_eq_true] at ok ⊢
    exact ⟨ok.1,ok.2.1,ih _ _ ok.2.2⟩

end E1182ElevenBlock
#print axioms E1182ElevenBlock.search_complete
