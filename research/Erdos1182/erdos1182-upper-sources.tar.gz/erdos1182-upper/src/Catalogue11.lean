import Groups
open SimpleGraph E1182Cover E1182ElevenBlock
namespace E1182Portfolio
def catalogue11 (a : Fin 8) : SimpleGraph (Fin 21) := triGraph 21 E1182Sharp.masks11[a.val]!
instance (a : Fin 8) : DecidableRel (catalogue11 a).Adj := inferInstanceAs (DecidableRel (triGraph 21 E1182Sharp.masks11[a.val]!).Adj)
def total11 (j : Fin 7) : Finset (Fin 8) := Finset.univ.filter (fun a => (([254, 253, 251, 247, 239, 191, 127] : List Nat)[j.val]!).testBit a.val)

set_option maxRecDepth 4000 in
set_option maxHeartbeats 0 in
theorem portfolio11x0 : ∃ G : SimpleGraph (Fin 11), G.Connected ∧ 42≤G.edgeSet.ncard ∧ ∀ a∈total11 0, G ⊑ (catalogue11 a)ᶜ := by
  apply graph_from_chart catalogue11 (total11 0) 42 158495020111019088292941701130 0x5265231b258c416c166428038cc023a68c9414640412640d478c4e0be2b321401b60029c6c74e505a404521cc93423580000000000000 (0:Fin 11) <;> decide +kernel

set_option maxRecDepth 4000 in
set_option maxHeartbeats 0 in
theorem portfolio11x1 : ∃ G : SimpleGraph (Fin 11), G.Connected ∧ 42≤G.edgeSet.ncard ∧ ∀ a∈total11 1, G ⊑ (catalogue11 a)ᶜ := by
  apply graph_from_chart catalogue11 (total11 1) 42 158495020111018525343021834250 0x2e652329268c401053193a0831402a4d8a941264402971474931e008ce0542347acc029c6c74e505a4000000000000042343ce4649504 (0:Fin 11) <;> decide +kernel

set_option maxRecDepth 4000 in
set_option maxHeartbeats 0 in
theorem portfolio11x2 : ∃ G : SimpleGraph (Fin 11), G.Connected ∧ 42≤G.edgeSet.ncard ∧ ∀ a∈total11 2, G ⊑ (catalogue11 a)ᶜ := by
  apply graph_from_chart catalogue11 (total11 2) 42 158456325028528675600680059120 0xdb46402b94c806c428716638180a60a903251390412815e2a31c350ce17d1668448000000000000000451e2e1c90b0c2538d128290e6 (0:Fin 11) <;> decide +kernel

set_option maxRecDepth 4000 in
set_option maxHeartbeats 0 in
theorem portfolio11x3 : ∃ G : SimpleGraph (Fin 11), G.Connected ∧ 42≤G.edgeSet.ncard ∧ ∀ a∈total11 3, G ⊑ (catalogue11 a)ᶜ := by
  apply graph_from_chart catalogue11 (total11 3) 42 316912706725455145222436913264 0x509a733d337117114801819c82a5426029034d2890e050a24fa31200000000000000070a04e92e846c4e36824e24546a4a3385128398a4 (0:Fin 11) <;> decide +kernel

set_option maxRecDepth 4000 in
set_option maxHeartbeats 0 in
theorem portfolio11x4 : ∃ G : SimpleGraph (Fin 11), G.Connected ∧ 42≤G.edgeSet.ncard ∧ ∀ a∈total11 4, G ⊑ (catalogue11 a)ᶜ := by
  apply graph_from_chart catalogue11 (total11 4) 42 158495020108713245283761561610 0x110aa6cdd4580e01053193a083140aa4c4c9412640000000000000008ce0542347acc08394560e535a4076c86b8d1ca242543c66649504 (0:Fin 11) <;> decide +kernel

set_option maxRecDepth 4000 in
set_option maxHeartbeats 0 in
theorem portfolio11x5 : ∃ G : SimpleGraph (Fin 11), G.Connected ∧ 42≤G.edgeSet.ncard ∧ ∀ a∈total11 5, G ⊑ (catalogue11 a)ᶜ := by
  apply graph_from_chart catalogue11 (total11 5) 42 158495020101795716256120479754 0x3b8486a8ab7912000000000000000254e8c941264401260cae7d1215048f59a9381c6029c6c74e505a404521d15b6433c2323d26649504 (0:Fin 11) <;> decide +kernel

set_option maxRecDepth 4000 in
set_option maxHeartbeats 0 in
theorem portfolio11x6 : ∃ G : SimpleGraph (Fin 11), G.Connected ∧ 42≤G.edgeSet.ncard ∧ ∀ a∈total11 6, G ⊑ (catalogue11 a)ᶜ := by
  apply graph_from_chart catalogue11 (total11 6) 42 316912687835989213743856320752 0x42c2d98dc58a5426029034e49440680964fa30091a8e17d171340813b84892e848b5c4181516acf27ce3484928398a4 (0:Fin 11) <;> decide +kernel

set_option maxRecDepth 15000 in
set_option maxHeartbeats 0 in
theorem insufficient11 (I : Finset (Fin 8)) (small : I.card≤6) :
    ∃ f : ∀ _a : I, Fin 11 ↪ Fin 21, let D := ⨅ a : I, (catalogue11 a.val)ᶜ.comap (f a)
      D.Connected ∧ 42 ≤ D.edgeSet.ncard := by
  apply smaller_families catalogue11 total11 (k:=6) _ _ I small
  · intro J bound
    apply small_subset total11 _ J (by omega)
    change ∀ i j : Fin 7, i ≠ j → Disjoint (total11 i)ᶜ (total11 j)ᶜ
    decide +kernel
  · intro j
    fin_cases j <;> first | exact portfolio11x0 | exact portfolio11x1 | exact portfolio11x2 | exact portfolio11x3 | exact portfolio11x4 | exact portfolio11x5 | exact portfolio11x6
end E1182Portfolio
#print axioms E1182Portfolio.insufficient11
