import Intro2
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x100 : ((leaves2.drop 100).take 1).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x101 : ((leaves2.drop 101).take 3).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x104 : ((leaves2.drop 104).take 7).all test2=true := by decide +kernel
end E1182TwelveBlock.Word32
