import Intro11
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice11x14 : ((leaves11.drop 14).take 1).all test11=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice11x15 : ((leaves11.drop 15).take 3).all test11=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice11x18 : ((leaves11.drop 18).take 4).all test11=true := by decide +kernel
end E1182TwelveBlock.Word32
