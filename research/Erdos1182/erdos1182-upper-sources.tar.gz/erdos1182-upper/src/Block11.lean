import TwinRule
import ValidHost2
import WordCut11
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem blocked11 : ¬ (codeGraph 11 pat11.mask) ⊑ (triGraph 21 host2.original)ᶜ := by
  apply null_of_test host2 pat11 hostValid2 (by decide +kernel) (twins_from_types pat11 74066324257876424225694923081633274 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact Word32.miss11
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked11
