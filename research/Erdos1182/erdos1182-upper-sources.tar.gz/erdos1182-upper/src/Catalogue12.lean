import Groups
open SimpleGraph E1182Cover E1182ElevenBlock
namespace E1182Portfolio
def catalogue12 (a : Fin 10) : SimpleGraph (Fin 23) := triGraph 23 E1182Sharp.masks12[a.val]!
instance (a : Fin 10) : DecidableRel (catalogue12 a).Adj := inferInstanceAs (DecidableRel (triGraph 23 E1182Sharp.masks12[a.val]!).Adj)
def total12 (j : Fin 5) : Finset (Fin 10) := Finset.univ.filter (fun a => (([511, 767, 895, 975, 1022] : List Nat)[j.val]!).testBit a.val)

set_option maxRecDepth 4000 in
set_option maxHeartbeats 0 in
theorem portfolio12x0 : ∃ G : SimpleGraph (Fin 12), G.Connected ∧ 50≤G.edgeSet.ncard ∧ ∀ a∈total12 0, G ⊑ (catalogue12 a)ᶜ := by
  apply graph_from_chart catalogue12 (total12 0) 50 1180735762300224933760 0xa34aa1026858dc6a4951480826a2657122a005027b6a5a3131388819be08930f4581c5aa603938f6481858ae664126f58181a41a9ace2f680824198ab56939214962c20 (0:Fin 12) <;> decide +kernel

set_option maxRecDepth 4000 in
set_option maxHeartbeats 0 in
theorem portfolio12x1 : ∃ G : SimpleGraph (Fin 12), G.Connected ∧ 50≤G.edgeSet.ncard ∧ ∀ a∈total12 1, G ⊑ (catalogue12 a)ᶜ := by
  apply graph_from_chart catalogue12 (total12 1) 50 14855280693082744087392616490 0x29a435c28e7b6a800000000000000041040552722a5b110540ad1ec71888092826c2717b9073a6402418d50eae49e4014ec552e0c410202d1e95b59099040abd4b444cd5a928b543404d92 (0:Fin 12) <;> decide +kernel

set_option maxRecDepth 4000 in
set_option maxHeartbeats 0 in
theorem portfolio12x2 : ∃ G : SimpleGraph (Fin 12), G.Connected ∧ 50≤G.edgeSet.ncard ∧ ∀ a∈total12 2, G ⊑ (catalogue12 a)ᶜ := by
  apply graph_from_chart catalogue12 (total12 2) 50 295156924483034464438 0x90ead419f0510a04017328e8d70a06000000000000000501c4306917a502a0a01391317b1c8902a772470634aa382704b2d28b94b201e742c3374183100d3411d58a98f4a16c92ad50d260 (0:Fin 12) <;> decide +kernel

set_option maxRecDepth 4000 in
set_option maxHeartbeats 0 in
theorem portfolio12x3 : ∃ G : SimpleGraph (Fin 12), G.Connected ∧ 50≤G.edgeSet.ncard ∧ ∀ a∈total12 3, G ⊑ (catalogue12 a)ᶜ := by
  apply graph_from_chart catalogue12 (total12 3) 50 4951760378799701888199639082 0xac8668215403da55a0039c2d4734c541002536323a6937a0228baa42a9a000000000000000000000000000000094007b25b35b1ca83001991af4ae88310029c5955350f5a9099c83605594 (0:Fin 12) <;> decide +kernel

set_option maxRecDepth 4000 in
set_option maxHeartbeats 0 in
theorem portfolio12x4 : ∃ G : SimpleGraph (Fin 12), G.Connected ∧ 50≤G.edgeSet.ncard ∧ ∀ a∈total12 4, G ⊑ (catalogue12 a)ᶜ := by
  apply graph_from_chart catalogue12 (total12 4) 50 604831844700893205250230 0x90ccd855e8010aa18110b51cb69a65101b4424a491e63501c2410c17d22b20a018cdd479d2870205a55b24ace3381928d97053669180eb9ba04b31ea100889b1e6546ae000000000000000 (0:Fin 12) <;> decide +kernel

set_option maxRecDepth 15000 in
set_option maxHeartbeats 0 in
theorem insufficient12 (I : Finset (Fin 10)) (small : I.card≤4) :
    ∃ f : ∀ _a : I, Fin 12 ↪ Fin 23, let D := ⨅ a : I, (catalogue12 a.val)ᶜ.comap (f a)
      D.Connected ∧ 50 ≤ D.edgeSet.ncard := by
  apply smaller_families catalogue12 total12 (k:=4) _ _ I small
  · intro J bound
    apply small_subset total12 _ J (by omega)
    change ∀ i j : Fin 5, i ≠ j → Disjoint (total12 i)ᶜ (total12 j)ᶜ
    decide +kernel
  · intro j
    fin_cases j <;> first | exact portfolio12x0 | exact portfolio12x1 | exact portfolio12x2 | exact portfolio12x3 | exact portfolio12x4
end E1182Portfolio
#print axioms E1182Portfolio.insufficient12
