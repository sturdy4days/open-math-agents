import Intro3
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice3x76 : ((leaves3.drop 76).take 1).all test3=true := by decide +kernel
end E1182TwelveBlock.Word32
