import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf10_0_10_11 : failed host0 pat10 (atPath host0 pat10 [11,10,0]) = true := by
  decide +kernel

theorem leaf10_0_10_13 : failed host0 pat10 (atPath host0 pat10 [13,10,0]) = true := by
  decide +kernel

theorem leaf10_0_10_14 : failed host0 pat10 (atPath host0 pat10 [14,10,0]) = true := by
  decide +kernel

theorem leaf10_0_10_17 : failed host0 pat10 (atPath host0 pat10 [17,10,0]) = true := by
  decide +kernel

theorem leaf10_0_10_18 : failed host0 pat10 (atPath host0 pat10 [18,10,0]) = true := by
  decide +kernel

theorem leaf10_0_10_20 : failed host0 pat10 (atPath host0 pat10 [20,10,0]) = true := by
  decide +kernel

theorem leaf10_0_11_12 : failed host0 pat10 (atPath host0 pat10 [12,11,0]) = true := by
  decide +kernel

end E1182ElevenBlock
