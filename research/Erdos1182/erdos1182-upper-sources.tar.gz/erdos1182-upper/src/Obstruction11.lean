import FrontierClose
import Page11x0
import Page11x1
import Page11x2
import Page11x3
import Page11x4
import Page11x5
import Page11x6
import Page11x7
namespace E1182TwelveBlock.Word32
private theorem appendParts11 (offset width : Nat)
    (head : ((leaves11.drop offset).take width).all test11 = true)
    (tail : (leaves11.drop (offset+width)).all test11 = true) :
    (leaves11.drop offset).all test11 = true :=
  prepend_chunk (xs := leaves11) (f := test11) (offset := offset) (width := width) head tail

set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem miss11 : rejects host8 pat11 = false :=
  closeFrontier host8 pat11 p11E p11R h8J h8B h8A h8I h8U h8T
    okH8 okS11 leaves11 branches11
    (appendParts11 0 1 slice11x0 (appendParts11 1 1 slice11x1 (appendParts11 2 1 slice11x2 (appendParts11 3 1 slice11x3 (appendParts11 4 2 slice11x4 (appendParts11 6 1 slice11x6 (appendParts11 7 4 slice11x7 (appendParts11 11 3 slice11x11 (appendParts11 14 1 slice11x14 (appendParts11 15 3 slice11x15 (appendParts11 18 4 slice11x18 (appendParts11 22 1 slice11x22 (appendParts11 23 2 slice11x23 (appendParts11 25 1 slice11x25 (appendParts11 26 4 slice11x26 (appendParts11 30 7 slice11x30 (by decide +kernel))))))))))))))))) (by decide +kernel)
end E1182TwelveBlock.Word32
#print axioms E1182TwelveBlock.Word32.miss11
namespace E1182TwelveBlock
open SimpleGraph E1182Cover
set_option maxHeartbeats 0 in
theorem blocked11 : ¬ (codeGraph 12 pat11.mask) ⊑ (triGraph 23 host8.original)ᶜ := by
  apply null_of_test host8 pat11 hostValid8 (by decide +kernel)
    (twins_from_types pat11 0x2aa000aa0000aa3000a8b00082b0008ab0aa (by decide +kernel)) (by decide +kernel) (by decide +kernel)
  exact Word32.miss11
end E1182TwelveBlock
#print axioms E1182TwelveBlock.blocked11
