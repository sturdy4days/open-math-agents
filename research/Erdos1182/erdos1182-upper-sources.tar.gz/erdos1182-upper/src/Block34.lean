import TwinRule
import ValidHost1
import WordCut34
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem blocked34 : ¬ (codeGraph 11 pat34.mask) ⊑ (triGraph 21 host1.original)ᶜ := by
  apply null_of_test host1 pat34 hostValid1 (by decide +kernel) (twins_from_types pat34 626970271989972519984676199330962922 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact Word32.miss34
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked34
