import TwinRule
import ValidHost1
import WordCut44
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem blocked44 : ¬ (codeGraph 11 pat44.mask) ⊑ (triGraph 21 host1.original)ᶜ := by
  apply null_of_test host1 pat44 hostValid1 (by decide +kernel) (twins_from_types pat44 201201634996559779219032076319841722 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact Word32.miss44
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked44
