import Intro5
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice5x2 : ((leaves5.drop 2).take 3).all test5=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice5x5 : ((leaves5.drop 5).take 6).all test5=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice5x11 : ((leaves5.drop 11).take 1).all test5=true := by decide +kernel
end E1182TwelveBlock.Word32
