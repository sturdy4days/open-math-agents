import Descent
import ValidHost1
namespace E1182ElevenBlock
theorem leaf4_3_5 : failed host1 pat4 (atPath host1 pat4 [5,3]) = true := by
  decide +kernel

theorem leaf4_3_6 : failed host1 pat4 (atPath host1 pat4 [6,3]) = true := by
  decide +kernel

theorem leaf4_3_8 : failed host1 pat4 (atPath host1 pat4 [8,3]) = true := by
  decide +kernel

theorem leaf4_3_9 : failed host1 pat4 (atPath host1 pat4 [9,3]) = true := by
  decide +kernel

theorem leaf4_3_10 : failed host1 pat4 (atPath host1 pat4 [10,3]) = true := by
  decide +kernel

theorem leaf4_3_13 : failed host1 pat4 (atPath host1 pat4 [13,3]) = true := by
  decide +kernel

theorem leaf4_3_14 : failed host1 pat4 (atPath host1 pat4 [14,3]) = true := by
  decide +kernel

theorem leaf4_7_0_0 : failed host1 pat4 (atPath host1 pat4 [0,0,7]) = true := by
  decide +kernel

theorem leaf4_7_0_1 : failed host1 pat4 (atPath host1 pat4 [1,0,7]) = true := by
  decide +kernel

theorem leaf4_7_0_2 : failed host1 pat4 (atPath host1 pat4 [2,0,7]) = true := by
  decide +kernel

end E1182ElevenBlock
