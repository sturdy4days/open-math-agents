import Anchored
import Tables11
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
def rank (h : Host) (i : Fin 21) : Fin 21 := Fin.ofNat 21 h.rank[i.val]!
def move (h : Host) (v i : Fin 21) : Fin 21 := Fin.ofNat 21 ((h.moves[v.val]! >>> (5*i.val)) % 32)
def allowedRoot (h : Host) (v : Fin 21) : Prop := h.root.testBit h.colours[v.val]! = true
instance (h : Host) (v : Fin 21) : Decidable (allowedRoot h v) :=
  inferInstanceAs (Decidable (_ = true))

def domains (h : Host) (p : Pattern) : List (Fin 11 × Nat) :=
  ((List.finRange 11).take p.count).map fun i => (i, if i = 0 then h.root else h.full)

structure HostValid (h : Host) : Prop where
  full : ∀ v : Fin 21, h.full.testBit h.colours[v.val]! = true
  sep : ∀ u v : Fin 21, h.colours[u.val]! ≠ h.colours[v.val]! →
    (h.apart[h.colours[u.val]!]!).testBit h.colours[v.val]! = true
  blue : ∀ u v : Fin 21, (codeGraph 21 h.canonical)ᶜ.Adj u v →
    (h.joined[h.colours[u.val]!]!).testBit h.colours[v.val]! = true
  higher : ∀ u v : Fin 21, u < v → (h.high[h.colours[u.val]!]!).testBit h.colours[v.val]! = true
  moves : ∀ v : Fin 21, Function.Injective (move h v) ∧
    (∀ i j, (codeGraph 21 h.canonical)ᶜ.Adj i j → (codeGraph 21 h.canonical)ᶜ.Adj (move h v i) (move h v j)) ∧
    allowedRoot h (move h v v)
  labels : Function.Injective (rank h) ∧ ∀ i j, (triGraph 21 h.original)ᶜ.Adj i j →
    (codeGraph 21 h.canonical)ᶜ.Adj (rank h i) (rank h j)
def consumeDomains {n : ℕ} (allowed : Fin n → Fin n → ℕ → ℕ) (apart : List ℕ)
    (i : Fin n) (v : ℕ) (remaining : List ℕ) (ds : List (Fin n × ℕ)) :=
  ds.map fun u => (u.1, let mask := u.2 &&& allowed i u.1 v
                        if remaining.contains v then mask else mask &&& apart[v]!)

def capSearch {n : ℕ} (allowed : Fin n → Fin n → ℕ → ℕ) (apart : List ℕ)
    (k : ℕ) (ds : List (Fin n × ℕ)) (supply : List ℕ) : Bool :=
  Nat.rec (motive := fun _ => List (Fin n × ℕ) → List ℕ → Bool) (fun _ _ => true)
    (fun _ rec current available => match current with
      | [] => true
      | (i,domain)::t => domain.bitIndices.any fun v =>
        available.contains v && (let remaining := available.erase v
                                 let next := consumeDomains allowed apart i v remaining t
                                 next.all (fun u => u.2 != 0) && rec next remaining)) k ds supply

def classMask {n : ℕ} (edges twins joined high : List ℕ) (full : ℕ)
    (i j : Fin n) (v : ℕ) : ℕ :=
  let mask := if edges[i.val]!.testBit j.val then joined[v]! else full
  if twins[i.val]! = twins[j.val]! ∧ i < j then mask &&& high[v]! else mask

def rejects (h : Host) (p : Pattern) : Bool :=
  capSearch (classMask p.edges p.tags h.joined h.high h.full) h.apart (domains h p).length
    (domains h p) ((List.finRange 21).map fun x => h.colours[x.val]!)

theorem null_of_test (h : Host) (p : Pattern) (hv : HostValid h)
    (pattern : ∀ i j : Fin 11, p.edges[i.val]!.testBit j.val = true → (codeGraph 11 p.mask).Adj i j)
    (twins : ∀ i j a b : Fin 11, i≠j → a≠b → p.tags[i.val]! = p.tags[a.val]! →
      p.tags[j.val]! = p.tags[b.val]! → (codeGraph 11 p.mask).Adj i j → (codeGraph 11 p.mask).Adj a b)
    (alone : ∀ i : Fin 11, p.tags[i.val]! = p.tags[0]! → i = 0)
    (nd : ((domains h p).map Prod.fst).Nodup)
    (blocked : rejects h p = false) : ¬ (codeGraph 11 p.mask) ⊑ (triGraph 21 h.original)ᶜ := by
  rintro ⟨e⟩
  let chart : Copy (triGraph 21 h.original)ᶜ (codeGraph 21 h.canonical)ᶜ :=
    ⟨⟨rank h, fun {_ _} a => hv.labels.2 _ _ a⟩,hv.labels.1⟩
  have relocate (v : Fin 21) : ∃ a : (codeGraph 21 h.canonical)ᶜ.Copy (codeGraph 21 h.canonical)ᶜ,
      allowedRoot h (a v) := by
    obtain ⟨inj,edges,home⟩ := hv.moves v
    exact ⟨⟨⟨move h v,fun {_ _} q => edges _ _ q⟩,inj⟩,home⟩
  have initial : ∀ u ∈ domains h p, ∀ j : Fin 21,
      (u.1 = 0 → allowedRoot h j) → u.2.testBit h.colours[j.val]! = true := by
    intro u hu j w
    obtain ⟨i,_,rfl⟩ := List.mem_map.mp hu
    by_cases iz : i=0
    · simpa only [if_pos iz,allowedRoot] using w iz
    · simpa only [if_neg iz] using hv.full j
  exact ruledOutFromClasses p.edges p.tags h.colours h.apart h.joined h.high h.full (domains h p)
    0 (allowedRoot h) alone relocate pattern twins hv.full hv.sep hv.blue hv.higher nd initial blocked
    ⟨chart.comp e⟩

end E1182ElevenBlock
#print axioms E1182ElevenBlock.null_of_test
