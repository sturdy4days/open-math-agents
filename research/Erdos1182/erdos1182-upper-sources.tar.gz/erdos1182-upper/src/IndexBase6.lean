import Intro6
namespace E1182TwelveBlock.Word32

/-- Every index proposes a previously certified child. Equality with the full path is checked. -/
def indexedParents (P : Fin 12 → Nat → Nat) (D : Nat → Nat) (root : Node) (goal : Nat)
    (done : Array (List Nat)) : List (List Nat × Nat) → Bool
  | [] => done[goal]? == some []
  | (path,hints)::rest =>
    let n := atPath P D root path
    !n.todo.isEmpty && (choices P D n).all
      (fun a => done[field hints 10 a]? == some (a::path)) &&
      indexedParents P D root goal (done.push path) rest

theorem indexedParents_sound (P : Fin 12 → Nat → Nat) (D : Nat → Nat) (root : Node)
    (goal : Nat) (done : Array (List Nat)) (work : List (List Nat × Nat))
    (proven : ∀ p ∈ done, rejected P D (atPath P D root p))
    (checked : indexedParents P D root goal done work = true) : rejected P D root := by
  induction work generalizing done with
  | nil =>
    have found : done[goal]? = some [] := beq_iff_eq.mp checked
    exact proven [] (Array.mem_iff_getElem?.mpr ⟨goal,found⟩)
  | cons pair rest ih =>
    rcases pair with ⟨path,hints⟩
    simp only [indexedParents,Bool.and_eq_true] at checked
    obtain ⟨⟨nonempty,children⟩,later⟩ := checked
    have here : rejected P D (atPath P D root path) := by
      apply reject_branches P D root path _ (by simpa using nonempty) rfl
      intro a ha
      have found := beq_iff_eq.mp (List.all_eq_true.mp children a ha)
      exact proven (a::path) (Array.mem_iff_getElem?.mpr ⟨_,found⟩)
    apply ih (done.push path) _ later
    intro p hp
    rcases Array.mem_push.mp hp with old|rfl
    · exact proven p old
    · exact here

theorem closeIndexed (h : Host) (p : Pattern) (E R J B A I U T : Nat)
    (host : hostWords h J B A I U T) (src : sourceWords h p E R)
    (leaves : List (List Nat)) (goal : Nat) (work : List (List Nat × Nat))
    (tested : (leaves.drop 0).all (fails (permit E R J B) (field A 384) (initial p I U T)) = true)
    (closed : indexedParents (permit E R J B) (field A 384) (initial p I U T) goal leaves.toArray work = true) :
    rejects h p = false := by
  apply null h p E R J B A I U T host src
  apply indexedParents_sound (permit E R J B) (field A 384) (initial p I U T) goal leaves.toArray work _ closed
  intro q hq
  exact of_decide_eq_true (List.all_eq_true.mp tested q (List.mem_toArray.mp hq))

def indexValid (P : Fin 12 → Nat → Nat) (D : Nat → Nat) (root : Node)
    (done : Array (List Nat)) (path : List Nat) (hints : Nat) : Bool :=
  let n := atPath P D root path
  !n.todo.isEmpty && (choices P D n).all (fun a => done[field hints 10 a]? == some (a::path))

theorem index_cons (P : Fin 12 → Nat → Nat) (D : Nat → Nat) (root : Node) (goal : Nat)
    (done : Array (List Nat)) (path : List Nat) (hints : Nat) (tail : List (List Nat × Nat))
    (head : indexValid P D root done path hints = true)
    (later : indexedParents P D root goal (done.push path) tail = true) :
    indexedParents P D root goal done ((path,hints)::tail) = true := by
  change (indexValid P D root done path hints && indexedParents P D root goal (done.push path) tail) = true
  simp only [Bool.and_eq_true]
  exact ⟨head,later⟩
def indexRow6x0 : List Nat × Nat := ([1,0],0x300b02800024000200000007018050100000c020040000000)
def indexRow6x1 : List Nat × Nat := ([2,0],0x601705800054000500000013048110400003c0e0340000000)
def indexRow6x2 : List Nat × Nat := ([4,0],0x8c22084000800007c000001e0741c06c00068000000000000)
def indexRow6x3 : List Nat × Nat := ([0],0xb42c0ac000a8000a4000002809c2609400091d6065d575000)
def indexRow6x4 : List Nat × Nat := ([0,1],0x3a00000000390e0370d835000340cc000c8310c02f0b80000000)
def indexRow6x5 : List Nat × Nat := ([3,1],0x4600000000451104310841000400fc000f83d0f03b0000000000)
def indexRow6x6 : List Nat × Nat := ([1],0x5200000000511404f1384d0004c12c00128491204776400001d8)
def indexRow6x7 : List Nat × Nat := ([0,2],0x6017c5e174000005c16c5a1640016057158001545414c0000000)
def indexRow6x8 : List Nat × Nat := ([3,2],0x6d1b06b1a800000691a067198001946418c00188610000000000)
def indexRow6x9 : List Nat × Nat := ([4,2],0x791e0771d800000751d0731c8001c4701bc001b8000000000000)
def indexRow6x10 : List Nat × Nat := ([5,2],0x8420c8220400000801fc7e1f4001f07b1e800000000000000000)
def indexRow6x11 : List Nat × Nat := ([2],0x8f2388d230000008b228892200021c8621400779dd77000001db)
def indexRow6x12 : List Nat × Nat := ([0,5],0x2700026c000009a2649825c96000000009525000000932489124000)
def indexRow6x13 : List Nat × Nat := ([1,5],0x2a00029c00000a6294a428ca200000000a1280000009f2789d00000)
def indexRow6x14 : List Nat × Nat := ([5],0x2d0002cc00000b22c4b02bcae00000000ad2b000000ab2a8a9785e0)
def indexRow6x15 : List Nat × Nat := ([1,6],0x304c0000bf2f8bd2f0bb000ba2e4b82dc002d800000002d40000000)
def indexRow6x16 : List Nat × Nat := ([6],0x338cd000cc32cca324c8000c7318c53100030c00000003080078c00)
def indexRow6x17 : List Nat × Nat := ([0,9],0x36cda364d80000035cd6354d400000000d3000d2344d033c00)
def indexRow6x18 : List Nat × Nat := ([2,9],0x39ce6394e40000038ce2384e000000000df000de3740000000)
def indexRow6x19 : List Nat × Nat := ([9],0x3c8f13c0ef000003b8ed3b0eb00000000ea000e93a1e6371e5)
def indexRow6x20 : List Nat × Nat := ([2,11],0x400ff3f8fd3f0fb000fa3e4f8000f73d8f5000f4000f30000000000)
def indexRow6x21 : List Nat × Nat := ([4,11],0x4350c42d0a4250800107419050010440d0200101000000000000000)
def indexRow6x22 : List Nat × Nat := ([8,11],0x4651845d164551400113449110011043c0000000000000000000000)
def indexRow6x23 : List Nat × Nat := ([11],0x49123489214811f0011e4751c0011b469ea0010e001e9001e800000)
def indexRow6x24 : List Nat × Nat := ([1,12],0x4c4004c0004bd2e0012d000004b0004ac004a9294a1274992500000)
def indexRow6x25 : List Nat × Nat := ([12],0x4f8004f4004f13b0013a000004e4004e0004dd364d5344cd327b000)
def indexRow6x26 : List Nat × Nat := ([0,13],0x5314b0014a525480000051d46515440000050d42505404fc00)
def indexRow6x27 : List Nat × Nat := ([1,13],0x565580015755955000005515354951000005414f5394d00000)
def indexRow6x28 : List Nat × Nat := ([2,13],0x595640016358961000005815f5795d000005715b5680000000)
def indexRow6x29 : List Nat × Nat := ([13],0x5c5700016f5b96d000005b16b5a969000005a167599f07bdee)
def indexRow6x30 : List Nat × Nat := ([1,14],0x5fd7e000000017d5f0005ed7a5e400001785dd765d5745cd7200000)
def indexRow6x31 : List Nat × Nat := ([2,14],0x6318b000000018a6240062187618000018561183609816000000000)
def indexRow6x32 : List Nat × Nat := ([3,14],0x661970000000196654006519364800001916418f6398d0000000000)
def indexRow6x33 : List Nat × Nat := ([14],0x691a300000001a2684006819f678000019d6719b669997d1f37c800)
def indexRow6x34 : List Nat × Nat := ([0,17],0x6c5b06bdae0000000000001ad6b1ab6a9a96a1a7001a6001a500000)
def indexRow6x35 : List Nat × Nat := ([2,17],0x6f5bc6edba0000000000001b96e1b76d9b56d1b3001b20000000000)
def indexRow6x36 : List Nat × Nat := ([4,17],0x721c7719c50000000000001c470dc2705c06fdbe000000000000000)
def indexRow6x37 : List Nat × Nat := ([17],0x74dd2745d00000000000001cf739cd731cb729c9001f8001f7001f6)
def indexRow6x38 : List Nat × Nat := ([],0x7e400001f57c5ed7ac0079c00001e478800001df769d7)
def indexStore6x0 : Array (List Nat) := leaves6.toArray
def indexStore6x1 := indexStore6x0.push indexRow6x0.1
def indexStore6x2 := indexStore6x1.push indexRow6x1.1
def indexStore6x3 := indexStore6x2.push indexRow6x2.1
def indexStore6x4 := indexStore6x3.push indexRow6x3.1
def indexStore6x5 := indexStore6x4.push indexRow6x4.1
def indexStore6x6 := indexStore6x5.push indexRow6x5.1
def indexStore6x7 := indexStore6x6.push indexRow6x6.1
def indexStore6x8 := indexStore6x7.push indexRow6x7.1
def indexStore6x9 := indexStore6x8.push indexRow6x8.1
def indexStore6x10 := indexStore6x9.push indexRow6x9.1
def indexStore6x11 := indexStore6x10.push indexRow6x10.1
def indexStore6x12 := indexStore6x11.push indexRow6x11.1
def indexStore6x13 := indexStore6x12.push indexRow6x12.1
def indexStore6x14 := indexStore6x13.push indexRow6x13.1
def indexStore6x15 := indexStore6x14.push indexRow6x14.1
def indexStore6x16 := indexStore6x15.push indexRow6x15.1
def indexStore6x17 := indexStore6x16.push indexRow6x16.1
def indexStore6x18 := indexStore6x17.push indexRow6x17.1
def indexStore6x19 := indexStore6x18.push indexRow6x18.1
def indexStore6x20 := indexStore6x19.push indexRow6x19.1
def indexStore6x21 := indexStore6x20.push indexRow6x20.1
def indexStore6x22 := indexStore6x21.push indexRow6x21.1
def indexStore6x23 := indexStore6x22.push indexRow6x22.1
def indexStore6x24 := indexStore6x23.push indexRow6x23.1
def indexStore6x25 := indexStore6x24.push indexRow6x24.1
def indexStore6x26 := indexStore6x25.push indexRow6x25.1
def indexStore6x27 := indexStore6x26.push indexRow6x26.1
def indexStore6x28 := indexStore6x27.push indexRow6x27.1
def indexStore6x29 := indexStore6x28.push indexRow6x28.1
def indexStore6x30 := indexStore6x29.push indexRow6x29.1
def indexStore6x31 := indexStore6x30.push indexRow6x30.1
def indexStore6x32 := indexStore6x31.push indexRow6x31.1
def indexStore6x33 := indexStore6x32.push indexRow6x32.1
def indexStore6x34 := indexStore6x33.push indexRow6x33.1
def indexStore6x35 := indexStore6x34.push indexRow6x34.1
def indexStore6x36 := indexStore6x35.push indexRow6x35.1
def indexStore6x37 := indexStore6x36.push indexRow6x36.1
def indexStore6x38 := indexStore6x37.push indexRow6x37.1
def indexStore6x39 := indexStore6x38.push indexRow6x38.1
def indexWork6x39 : List (List Nat × Nat) := []
def indexWork6x38 := indexRow6x38 :: indexWork6x39
def indexWork6x37 := indexRow6x37 :: indexWork6x38
def indexWork6x36 := indexRow6x36 :: indexWork6x37
def indexWork6x35 := indexRow6x35 :: indexWork6x36
def indexWork6x34 := indexRow6x34 :: indexWork6x35
def indexWork6x33 := indexRow6x33 :: indexWork6x34
def indexWork6x32 := indexRow6x32 :: indexWork6x33
def indexWork6x31 := indexRow6x31 :: indexWork6x32
def indexWork6x30 := indexRow6x30 :: indexWork6x31
def indexWork6x29 := indexRow6x29 :: indexWork6x30
def indexWork6x28 := indexRow6x28 :: indexWork6x29
def indexWork6x27 := indexRow6x27 :: indexWork6x28
def indexWork6x26 := indexRow6x26 :: indexWork6x27
def indexWork6x25 := indexRow6x25 :: indexWork6x26
def indexWork6x24 := indexRow6x24 :: indexWork6x25
def indexWork6x23 := indexRow6x23 :: indexWork6x24
def indexWork6x22 := indexRow6x22 :: indexWork6x23
def indexWork6x21 := indexRow6x21 :: indexWork6x22
def indexWork6x20 := indexRow6x20 :: indexWork6x21
def indexWork6x19 := indexRow6x19 :: indexWork6x20
def indexWork6x18 := indexRow6x18 :: indexWork6x19
def indexWork6x17 := indexRow6x17 :: indexWork6x18
def indexWork6x16 := indexRow6x16 :: indexWork6x17
def indexWork6x15 := indexRow6x15 :: indexWork6x16
def indexWork6x14 := indexRow6x14 :: indexWork6x15
def indexWork6x13 := indexRow6x13 :: indexWork6x14
def indexWork6x12 := indexRow6x12 :: indexWork6x13
def indexWork6x11 := indexRow6x11 :: indexWork6x12
def indexWork6x10 := indexRow6x10 :: indexWork6x11
def indexWork6x9 := indexRow6x9 :: indexWork6x10
def indexWork6x8 := indexRow6x8 :: indexWork6x9
def indexWork6x7 := indexRow6x7 :: indexWork6x8
def indexWork6x6 := indexRow6x6 :: indexWork6x7
def indexWork6x5 := indexRow6x5 :: indexWork6x6
def indexWork6x4 := indexRow6x4 :: indexWork6x5
def indexWork6x3 := indexRow6x3 :: indexWork6x4
def indexWork6x2 := indexRow6x2 :: indexWork6x3
def indexWork6x1 := indexRow6x1 :: indexWork6x2
def indexWork6x0 := indexRow6x0 :: indexWork6x1
end E1182TwelveBlock.Word32
