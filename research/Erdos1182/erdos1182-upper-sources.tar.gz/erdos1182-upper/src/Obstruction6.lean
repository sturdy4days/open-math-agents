import IndexProof6
import FrontierClose
import Page6x0
import Page6x1
import Page6x2
import Page6x3
import Page6x4
import Page6x5
import Page6x6
import Page6x7
import Page6x8
import Page6x9
import Page6x10
import Page6x11
import Page6x12
import Page6x13
import Page6x14
import Page6x15
import Page6x16
import Page6x17
import Page6x18
import Page6x19
import Page6x20
import Page6x21
import Page6x22
import Page6x23
import Page6x24
import Page6x25
import Page6x26
import Page6x27
import Page6x28
import Page6x29
import Page6x30
import Page6x31
import Page6x32
import Page6x33
import Page6x34
import Page6x35
import Page6x36
import Page6x37
import Page6x38
import Page6x39
import Page6x40
import Page6x41
import Page6x42
import Page6x43
import Page6x44
import Page6x45
import Page6x46
import Page6x47
import Page6x48
import Page6x49
import Page6x50
import Page6x51
import Page6x52
import Page6x53
import Page6x54
namespace E1182TwelveBlock.Word32
private theorem appendParts6 (offset width : Nat)
    (head : ((leaves6.drop offset).take width).all test6 = true)
    (tail : (leaves6.drop (offset+width)).all test6 = true) :
    (leaves6.drop offset).all test6 = true :=
  prepend_chunk (xs := leaves6) (f := test6) (offset := offset) (width := width) head tail

set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem miss6 : rejects host6 pat6 = false :=
  closeIndexed host6 pat6 p6E p6R h6J h6B h6A h6I h6U h6T
    okH6 okS6 leaves6 506 indexWork6x0
    (appendParts6 0 1 slice6x0 (appendParts6 1 3 slice6x1 (appendParts6 4 9 slice6x4 (appendParts6 13 1 slice6x13 (appendParts6 14 1 slice6x14 (appendParts6 15 2 slice6x15 (appendParts6 17 2 slice6x17 (appendParts6 19 6 slice6x19 (appendParts6 25 1 slice6x25 (appendParts6 26 2 slice6x26 (appendParts6 28 3 slice6x28 (appendParts6 31 6 slice6x31 (appendParts6 37 1 slice6x37 (appendParts6 38 2 slice6x38 (appendParts6 40 8 slice6x40 (appendParts6 48 3 slice6x48 (appendParts6 51 9 slice6x51 (appendParts6 60 3 slice6x60 (appendParts6 63 8 slice6x63 (appendParts6 71 1 slice6x71 (appendParts6 72 1 slice6x72 (appendParts6 73 1 slice6x73 (appendParts6 74 3 slice6x74 (appendParts6 77 7 slice6x77 (appendParts6 84 1 slice6x84 (appendParts6 85 1 slice6x85 (appendParts6 86 1 slice6x86 (appendParts6 87 1 slice6x87 (appendParts6 88 3 slice6x88 (appendParts6 91 7 slice6x91 (appendParts6 98 4 slice6x98 (appendParts6 102 9 slice6x102 (appendParts6 111 2 slice6x111 (appendParts6 113 5 slice6x113 (appendParts6 118 5 slice6x118 (appendParts6 123 5 slice6x123 (appendParts6 128 5 slice6x128 (appendParts6 133 1 slice6x133 (appendParts6 134 1 slice6x134 (appendParts6 135 3 slice6x135 (appendParts6 138 8 slice6x138 (appendParts6 146 4 slice6x146 (appendParts6 150 8 slice6x150 (appendParts6 158 2 slice6x158 (appendParts6 160 9 slice6x160 (appendParts6 169 1 slice6x169 (appendParts6 170 1 slice6x170 (appendParts6 171 1 slice6x171 (appendParts6 172 2 slice6x172 (appendParts6 174 8 slice6x174 (appendParts6 182 3 slice6x182 (appendParts6 185 9 slice6x185 (appendParts6 194 1 slice6x194 (appendParts6 195 1 slice6x195 (appendParts6 196 1 slice6x196 (appendParts6 197 2 slice6x197 (appendParts6 199 8 slice6x199 (appendParts6 207 1 slice6x207 (appendParts6 208 1 slice6x208 (appendParts6 209 2 slice6x209 (appendParts6 211 3 slice6x211 (appendParts6 214 6 slice6x214 (appendParts6 220 1 slice6x220 (appendParts6 221 2 slice6x221 (appendParts6 223 3 slice6x223 (appendParts6 226 7 slice6x226 (appendParts6 233 1 slice6x233 (appendParts6 234 3 slice6x234 (appendParts6 237 6 slice6x237 (appendParts6 243 1 slice6x243 (appendParts6 244 1 slice6x244 (appendParts6 245 1 slice6x245 (appendParts6 246 1 slice6x246 (appendParts6 247 2 slice6x247 (appendParts6 249 9 slice6x249 (appendParts6 258 1 slice6x258 (appendParts6 259 3 slice6x259 (appendParts6 262 8 slice6x262 (appendParts6 270 1 slice6x270 (appendParts6 271 1 slice6x271 (appendParts6 272 10 slice6x272 (appendParts6 282 1 slice6x282 (appendParts6 283 1 slice6x283 (appendParts6 284 5 slice6x284 (appendParts6 289 6 slice6x289 (appendParts6 295 3 slice6x295 (appendParts6 298 8 slice6x298 (appendParts6 306 1 slice6x306 (appendParts6 307 1 slice6x307 (appendParts6 308 1 slice6x308 (appendParts6 309 1 slice6x309 (appendParts6 310 3 slice6x310 (appendParts6 313 7 slice6x313 (appendParts6 320 1 slice6x320 (appendParts6 321 1 slice6x321 (appendParts6 322 1 slice6x322 (appendParts6 323 2 slice6x323 (appendParts6 325 8 slice6x325 (appendParts6 333 1 slice6x333 (appendParts6 334 3 slice6x334 (appendParts6 337 9 slice6x337 (appendParts6 346 1 slice6x346 (appendParts6 347 2 slice6x347 (appendParts6 349 2 slice6x349 (appendParts6 351 7 slice6x351 (appendParts6 358 1 slice6x358 (appendParts6 359 1 slice6x359 (appendParts6 360 1 slice6x360 (appendParts6 361 4 slice6x361 (appendParts6 365 6 slice6x365 (appendParts6 371 2 slice6x371 (appendParts6 373 2 slice6x373 (appendParts6 375 9 slice6x375 (appendParts6 384 2 slice6x384 (appendParts6 386 5 slice6x386 (appendParts6 391 7 slice6x391 (appendParts6 398 3 slice6x398 (appendParts6 401 8 slice6x401 (appendParts6 409 1 slice6x409 (appendParts6 410 1 slice6x410 (appendParts6 411 1 slice6x411 (appendParts6 412 3 slice6x412 (appendParts6 415 6 slice6x415 (appendParts6 421 1 slice6x421 (appendParts6 422 2 slice6x422 (appendParts6 424 2 slice6x424 (appendParts6 426 8 slice6x426 (appendParts6 434 1 slice6x434 (appendParts6 435 2 slice6x435 (appendParts6 437 2 slice6x437 (appendParts6 439 8 slice6x439 (appendParts6 447 2 slice6x447 (appendParts6 449 8 slice6x449 (appendParts6 457 1 slice6x457 (appendParts6 458 1 slice6x458 (appendParts6 459 1 slice6x459 (appendParts6 460 8 slice6x460 (by decide +kernel)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) tail6x0
end E1182TwelveBlock.Word32
#print axioms E1182TwelveBlock.Word32.miss6
namespace E1182TwelveBlock
open SimpleGraph E1182Cover
set_option maxHeartbeats 0 in
theorem blocked6 : ¬ (codeGraph 12 pat6.mask) ⊑ (triGraph 23 host6.original)ᶜ := by
  apply null_of_test host6 pat6 hostValid6 (by decide +kernel)
    (twins_from_types pat6 0x2e34410004426a24430000000004e1622 (by decide +kernel)) (by decide +kernel) (by decide +kernel)
  exact Word32.miss6
end E1182TwelveBlock
#print axioms E1182TwelveBlock.blocked6
