import Cut6P0
import Cut6P1
import Cut6P2
import Cut6P3
import Cut6P4
import Cut6P5
import Cut6P6
import Descent
import Descent
import TwinRule
import ValidHost0
namespace E1182ElevenBlock
open SimpleGraph E1182Cover

private theorem leaf6_0_1 : failed host0 pat6 (atPath host0 pat6 [1,0]) = true := by
  apply failed_atPath _ _ _ [3,4,7,8,9,10,11,12,13,14,17,18] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf6_0_1_3
  · exact leaf6_0_1_4
  · exact leaf6_0_1_7
  · exact leaf6_0_1_8
  · exact leaf6_0_1_9
  · exact leaf6_0_1_10
  · exact leaf6_0_1_11
  · exact leaf6_0_1_12
  · exact leaf6_0_1_13
  · exact leaf6_0_1_14
  · exact leaf6_0_1_17
  · exact leaf6_0_1_18

private theorem leaf6_0_3 : failed host0 pat6 (atPath host0 pat6 [3,0]) = true := by
  apply failed_atPath _ _ _ [4,7,8,9,10,11,12,13,14,17,18] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf6_0_3_4
  · exact leaf6_0_3_7
  · exact leaf6_0_3_8
  · exact leaf6_0_3_9
  · exact leaf6_0_3_10
  · exact leaf6_0_3_11
  · exact leaf6_0_3_12
  · exact leaf6_0_3_13
  · exact leaf6_0_3_14
  · exact leaf6_0_3_17
  · exact leaf6_0_3_18

private theorem leaf6_0_4 : failed host0 pat6 (atPath host0 pat6 [4,0]) = true := by
  apply failed_atPath _ _ _ [7,8,9,10,11,12,13,14,17,18] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf6_0_4_7
  · exact leaf6_0_4_8
  · exact leaf6_0_4_9
  · exact leaf6_0_4_10
  · exact leaf6_0_4_11
  · exact leaf6_0_4_12
  · exact leaf6_0_4_13
  · exact leaf6_0_4_14
  · exact leaf6_0_4_17
  · exact leaf6_0_4_18

private theorem leaf6_0_7 : failed host0 pat6 (atPath host0 pat6 [7,0]) = true := by
  apply failed_atPath _ _ _ [8,9,10,11,12,13,14,17,18] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf6_0_7_8
  · exact leaf6_0_7_9
  · exact leaf6_0_7_10
  · exact leaf6_0_7_11
  · exact leaf6_0_7_12
  · exact leaf6_0_7_13
  · exact leaf6_0_7_14
  · exact leaf6_0_7_17
  · exact leaf6_0_7_18

private theorem leaf6_0 : failed host0 pat6 (atPath host0 pat6 [0]) = true := by
  apply failed_atPath _ _ _ [1,3,4,7,8,9,10,11,12,13,14,17,18] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf6_0_1
  · exact leaf6_0_3
  · exact leaf6_0_4
  · exact leaf6_0_7
  · exact leaf6_0_8
  · exact leaf6_0_9
  · exact leaf6_0_10
  · exact leaf6_0_11
  · exact leaf6_0_12
  · exact leaf6_0_13
  · exact leaf6_0_14
  · exact leaf6_0_17
  · exact leaf6_0_18

private theorem leaf6_root : failed host0 pat6 (atPath host0 pat6 []) = true := by
  apply failed_atPath _ _ _ [0] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  subst v
  exact leaf6_0

theorem blocked6 : ¬ (codeGraph 11 pat6.mask) ⊑ (triGraph 21 host0.original)ᶜ := by
  apply null_of_test host0 pat6 hostValid0 (by decide +kernel) (twins_from_types pat6 1298074214634444776896147990137866 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact rejects_of_failed_root _ _ leaf6_root
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked6
