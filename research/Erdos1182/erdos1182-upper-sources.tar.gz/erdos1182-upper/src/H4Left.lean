import Endpoint
import AllPositive
import PositiveBridge
import AllBlocks
namespace E1182Eleven
open SimpleGraph E1182Cover E1182Bits

theorem public_selected_in : ∀ i : Fin 50, E1182ElevenBlock.selectedMasks[i.val]! ∈ extras := by
  decide +kernel

theorem all_blocked : ∀ i : Fin 2297, ∃ m∈extras, ¬ (codeGraph 11 (field l13 121 i.val))ᶜ ⊑ (triGraph 21 m)ᶜ := by
  intro i
  obtain ⟨q,embed⟩ := positive_of_slices allPositive i
  refine ⟨_,public_selected_in q,?_⟩
  intro h
  have bound : q.val < E1182ElevenBlock.patterns.length := q.isLt
  have neq := E1182ElevenBlock.selected_blocked q
  have chart : (E1182ElevenBlock.patterns[q.val]?).getD E1182ElevenBlock.pat0 = patternAt q := by
    rw [List.getElem?_eq_getElem bound]
    rfl
  rw [chart] at neq
  apply neq
  have target : E1182ElevenBlock.triGraph 21 E1182ElevenBlock.selectedMasks[q.val]! =
      triGraph 21 E1182ElevenBlock.selectedMasks[q.val]! := by
    ext x y; rfl
  rw [target]
  exact embed.trans h

theorem h4_eleven :
    let ms : List ℕ := [0x3c03c78079e01ef00ff00f1e007803c03c00781e0f0f01e7bfc0,0x1300c9300ca601898064c034c02980260130130260984c4c9a512,0x14618714a110c3142298116d102a2148904630c2494281d0a4873,0x8c114a884942464b2022a4a428261306320822e4a4ad013060e4,0x2a0350a80582183162129c0f8001d0086405013a94461515060a0,0x320c9a068340d092240b020b03304c45222a22864d0684810665,0x9848e6152078149c905b20421622c0a5011422e4a4ad017060e4,0xb1f00c9911c54838254c9410328059521341a10461915172e0a4]
    let C (a : Fin ms.length) : SimpleGraph (Fin 21) := {
      Adj := fun i j => i≠j ∧ ms[a.val].testBit ((max i j).val.choose 2+(min i j).val)=true
      symm := ⟨fun i j e => ⟨e.1.symm,by simpa only [min_comm j i,max_comm j i] using e.2⟩⟩
      loopless := ⟨fun i e => e.1 rfl⟩ }
    ∀ f : Fin ms.length → Fin 11 ↪ Fin 21, let D := ⨅ a, (C a)ᶜ.comap (f a)
      D.Connected → D.edgeSet.ncard≤41 := by
  intro ms C f D _
  exact fixed_eleven all_blocked f

end E1182Eleven
#print axioms E1182Eleven.h4_eleven
