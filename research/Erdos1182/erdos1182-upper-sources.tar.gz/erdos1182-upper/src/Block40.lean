import TwinRule
import ValidHost6
import WordCut40
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem blocked40 : ¬ (codeGraph 11 pat40.mask) ⊑ (triGraph 21 host6.original)ᶜ := by
  apply null_of_test host6 pat40 hostValid6 (by decide +kernel) (twins_from_types pat40 327114842494109245933559907178899966 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact Word32.miss40
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked40
