import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf26_0_11 : failed host0 pat26 (atPath host0 pat26 [11,0]) = true := by
  decide +kernel

theorem leaf26_0_12 : failed host0 pat26 (atPath host0 pat26 [12,0]) = true := by
  decide +kernel

theorem leaf26_0_13 : failed host0 pat26 (atPath host0 pat26 [13,0]) = true := by
  decide +kernel

theorem leaf26_0_14 : failed host0 pat26 (atPath host0 pat26 [14,0]) = true := by
  decide +kernel

theorem leaf26_0_17 : failed host0 pat26 (atPath host0 pat26 [17,0]) = true := by
  decide +kernel

end E1182ElevenBlock
