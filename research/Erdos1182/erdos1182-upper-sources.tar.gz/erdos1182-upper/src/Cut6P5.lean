import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf6_0_8 : failed host0 pat6 (atPath host0 pat6 [8,0]) = true := by
  decide +kernel

theorem leaf6_0_9 : failed host0 pat6 (atPath host0 pat6 [9,0]) = true := by
  decide +kernel

theorem leaf6_0_10 : failed host0 pat6 (atPath host0 pat6 [10,0]) = true := by
  decide +kernel

end E1182ElevenBlock
