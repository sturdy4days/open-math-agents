import HostChecks8
namespace E1182TwelveBlock.Word32
def p12E : Nat := spreadCells 0xc0efc062450548e444220010888bc4882101
def p12R : Nat := spreadCells 0xffffffffffff7ffffffffffffffbffff7fff
set_option maxHeartbeats 0 in
theorem okS12 : sourceWords host8 pat12 p12E p12R := by
  unfold sourceWords
  decide +kernel
abbrev perm12 := permit p12E p12R h8J h8B
abbrev apart12 := field h8A 384
abbrev start12 := initial pat12 h8I h8U h8T
def leaves12 : List (List Nat) := [[0],[2,1],[4,1],[6,1],[7,1],[8,1],[9,1],[10,1],[11,1],[14,1],[0,3],[0,3,3],[4,3,3],[5,3,3],[6,3,3],[8,3,3],[9,3,3],[12,3,3],[13,3,3],[14,3,3],[4,3],[5,3],[0,6,3],[3,6,3],[5,6,3],[6,6,3],[8,6,3],[9,6,3],[14,6,3],[3,8,3],[4,8,3],[5,8,3],[6,8,3],[8,8,3],[12,8,3],[14,8,3],[9,3],[12,3],[13,3],[14,3],[0,5],[2,5],[3,5],[6,5],[8,5],[10,5],[11,5],[13,5],[14,5],[0,7],[1,7],[2,7],[4,7],[0,7,7],[1,7,7],[2,7,7],[4,7,7],[7,7,7],[9,7,7],[10,7,7],[11,7,7],[12,7,7],[13,7,7],[9,7],[10,7],[11,7],[12,7],[13,7]]
def branches12 : List (List Nat) := [[1],[3,3],[6,3],[8,3],[3],[5],[7,7],[7],[]]
abbrev test12 := fails perm12 apart12 start12
end E1182TwelveBlock.Word32
