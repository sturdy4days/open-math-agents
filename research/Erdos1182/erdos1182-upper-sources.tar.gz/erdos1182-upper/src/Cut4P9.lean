import Descent
import ValidHost1
namespace E1182ElevenBlock
theorem leaf4_7_13 : failed host1 pat4 (atPath host1 pat4 [13,7]) = true := by
  decide +kernel

end E1182ElevenBlock
