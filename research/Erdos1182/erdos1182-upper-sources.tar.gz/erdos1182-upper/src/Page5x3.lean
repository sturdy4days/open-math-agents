import Intro5
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice5x14 : ((leaves5.drop 14).take 2).all test5=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice5x16 : ((leaves5.drop 16).take 4).all test5=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice5x20 : ((leaves5.drop 20).take 3).all test5=true := by decide +kernel
end E1182TwelveBlock.Word32
