import Intro13
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x90 : ((leaves13.drop 90).take 4).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x94 : ((leaves13.drop 94).take 2).all test13=true := by decide +kernel
end E1182TwelveBlock.Word32
