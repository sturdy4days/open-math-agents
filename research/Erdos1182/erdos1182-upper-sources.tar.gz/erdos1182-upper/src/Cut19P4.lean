import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf19_0_7_17 : failed host0 pat19 (atPath host0 pat19 [17,7,0]) = true := by
  decide +kernel

theorem leaf19_0_7_18 : failed host0 pat19 (atPath host0 pat19 [18,7,0]) = true := by
  decide +kernel

theorem leaf19_0_7_20 : failed host0 pat19 (atPath host0 pat19 [20,7,0]) = true := by
  decide +kernel

theorem leaf19_0_8 : failed host0 pat19 (atPath host0 pat19 [8,0]) = true := by
  decide +kernel

theorem leaf19_0_9 : failed host0 pat19 (atPath host0 pat19 [9,0]) = true := by
  decide +kernel

end E1182ElevenBlock
