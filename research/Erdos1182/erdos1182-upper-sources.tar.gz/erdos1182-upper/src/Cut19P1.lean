import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf19_0_3_7 : failed host0 pat19 (atPath host0 pat19 [7,3,0]) = true := by
  decide +kernel

theorem leaf19_0_3_10 : failed host0 pat19 (atPath host0 pat19 [10,3,0]) = true := by
  decide +kernel

theorem leaf19_0_3_11 : failed host0 pat19 (atPath host0 pat19 [11,3,0]) = true := by
  decide +kernel

theorem leaf19_0_3_12 : failed host0 pat19 (atPath host0 pat19 [12,3,0]) = true := by
  decide +kernel

theorem leaf19_0_3_13 : failed host0 pat19 (atPath host0 pat19 [13,3,0]) = true := by
  decide +kernel

theorem leaf19_0_3_14 : failed host0 pat19 (atPath host0 pat19 [14,3,0]) = true := by
  decide +kernel

theorem leaf19_0_3_17 : failed host0 pat19 (atPath host0 pat19 [17,3,0]) = true := by
  decide +kernel

end E1182ElevenBlock
