import HostChecks7
namespace E1182TwelveBlock.Word32
def p10E : Nat := spreadCells 0xf0cc2ca2196008c14172c012ca8ca4012241
def p10R : Nat := spreadCells 0xffffffffffffffffff7ffffffffff7feffff
set_option maxHeartbeats 0 in
theorem okS10 : sourceWords host7 pat10 p10E p10R := by
  unfold sourceWords
  decide +kernel
abbrev perm10 := permit p10E p10R h7J h7B
abbrev apart10 := field h7A 384
abbrev start10 := initial pat10 h7I h7U h7T
def leaves10 : List (List Nat) := [[0,0],[2,0],[3,0],[5,0],[6,0],[1,1],[3,1],[4,1],[6,1],[7,1],[2],[0,5],[2,5],[3,5],[5,5],[7,5],[0,6],[1,6],[3,6],[4,6],[6,6]]
def branches10 : List (List Nat) := [[0],[1],[5],[6],[]]
abbrev test10 := fails perm10 apart10 start10
end E1182TwelveBlock.Word32
