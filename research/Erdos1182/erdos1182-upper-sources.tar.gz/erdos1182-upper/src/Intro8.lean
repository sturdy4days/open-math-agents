import HostChecks7
namespace E1182TwelveBlock.Word32
def p8E : Nat := spreadCells 0x9f75f7229d11c98c68e60d902c8c06c06f01
def p8R : Nat := spreadCells 0xfff7ffffffffffffffffffffffffffffbfff
set_option maxHeartbeats 0 in
theorem okS8 : sourceWords host7 pat8 p8E p8R := by
  unfold sourceWords
  decide +kernel
abbrev perm8 := permit p8E p8R h7J h7B
abbrev apart8 := field h7A 384
abbrev start8 := initial pat8 h7I h7U h7T
def leaves8 : List (List Nat) := [[0,0,0],[2,0,0],[3,0,0],[5,0,0],[6,0,0],[2,0],[3,0],[5,0],[6,0],[1,1,1],[3,1,1],[4,1,1],[6,1,1],[7,1,1],[3,1],[4,1],[6,1],[7,1],[2],[0,5],[2,5],[3,5],[5,5],[7,5],[0,6],[1,1,6],[3,1,6],[4,1,6],[6,1,6],[3,6],[4,6],[6,6]]
def branches8 : List (List Nat) := [[0,0],[0],[1,1],[1],[5],[1,6],[6],[]]
abbrev test8 := fails perm8 apart8 start8
end E1182TwelveBlock.Word32
