import FrontierClose
import Page5x0
import Page5x1
import Page5x2
import Page5x3
import Page5x4
import Page5x5
import Page5x6
import Page5x7
import Page5x8
import Page5x9
import Page5x10
import Page5x11
import Page5x12
namespace E1182TwelveBlock.Word32
private theorem appendParts5 (offset width : Nat)
    (head : ((leaves5.drop offset).take width).all test5 = true)
    (tail : (leaves5.drop (offset+width)).all test5 = true) :
    (leaves5.drop offset).all test5 = true :=
  prepend_chunk (xs := leaves5) (f := test5) (offset := offset) (width := width) head tail

set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem miss5 : rejects host4 pat5 = false :=
  closeFrontier host4 pat5 p5E p5R h4J h4B h4A h4I h4U h4T
    okH4 okS5 leaves5 branches5
    (appendParts5 0 1 slice5x0 (appendParts5 1 1 slice5x1 (appendParts5 2 3 slice5x2 (appendParts5 5 6 slice5x5 (appendParts5 11 1 slice5x11 (appendParts5 12 1 slice5x12 (appendParts5 13 1 slice5x13 (appendParts5 14 2 slice5x14 (appendParts5 16 4 slice5x16 (appendParts5 20 3 slice5x20 (appendParts5 23 1 slice5x23 (appendParts5 24 1 slice5x24 (appendParts5 25 1 slice5x25 (appendParts5 26 1 slice5x26 (appendParts5 27 5 slice5x27 (appendParts5 32 2 slice5x32 (appendParts5 34 1 slice5x34 (appendParts5 35 1 slice5x35 (appendParts5 36 1 slice5x36 (appendParts5 37 2 slice5x37 (appendParts5 39 6 slice5x39 (appendParts5 45 2 slice5x45 (appendParts5 47 7 slice5x47 (appendParts5 54 2 slice5x54 (appendParts5 56 1 slice5x56 (appendParts5 57 2 slice5x57 (appendParts5 59 6 slice5x59 (appendParts5 65 2 slice5x65 (appendParts5 67 3 slice5x67 (appendParts5 70 7 slice5x70 (appendParts5 77 2 slice5x77 (appendParts5 79 6 slice5x79 (appendParts5 85 1 slice5x85 (by decide +kernel)))))))))))))))))))))))))))))))))) (by decide +kernel)
end E1182TwelveBlock.Word32
#print axioms E1182TwelveBlock.Word32.miss5
namespace E1182TwelveBlock
open SimpleGraph E1182Cover
set_option maxHeartbeats 0 in
theorem blocked5 : ¬ (codeGraph 12 pat5.mask) ⊑ (triGraph 23 host4.original)ᶜ := by
  apply null_of_test host4 pat5 hostValid4 (by decide +kernel)
    (twins_from_types pat5 0x1b02b03300003903a (by decide +kernel)) (by decide +kernel) (by decide +kernel)
  exact Word32.miss5
end E1182TwelveBlock
#print axioms E1182TwelveBlock.blocked5
