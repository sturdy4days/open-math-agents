import Submission
import H4Left
import Mathlib.Tactic.FinCases
open SimpleGraph

namespace E1182Eleven

/-- The remaining order-twelve finite statement suffices for the public fourth hypothesis. -/
theorem original_H4_from_twelve (twelve :let n := 12
  let h := 23
  let ms : List ℕ := [0x1f0078f803cf803df007fc01e1f001f003e00f807c003c0781e0f0f01e7bfc0,0x15402ad500aaa8056a8055500b5402aa01aa015405502a82a855154aaab556ad,0x980192600653003130032600698014c004c00980260130130260984c4c9a512,0x914a1386185108a4308c1022c86188168d102a2148904630c2494281d0a4873,0xa0c30e8a50821862a114d022c16819442d102a2148904630c2494281d0a4873,0x6c30c4d0a51091253440c310c81681861d102a2148904630c2494281d0a4873,0x660a992805aa22340c0808a41024c50724808545904048a115126182d64418,0xa1106c0984e4408060650a165e02a01953428300c30140455959a04a01a8204,0x1852522525259494b494925252252594949293252494a4a64a49525929324a65,0x1ac0b4290a509aa0494a14350d81681681d502a2140904620c2496881d0a4873]
  let C (a : Fin ms.length) : SimpleGraph (Fin h) := { Adj := fun i j => i ≠ j ∧ (ms[a.val]).testBit ((max i j).val.choose 2+(min i j).val)=true, symm := ⟨fun i j e => ⟨e.1.symm,by simpa only [min_comm j i,max_comm j i] using e.2⟩⟩, loopless := ⟨fun i e => e.1 rfl⟩ }
  ∀ f : Fin ms.length → Fin n ↪ Fin h, let D := ⨅ a, (C a)ᶜ.comap (f a)
    D.Connected → D.edgeSet.ncard ≤ 49) : OMA.R_Erdos1182_erdos_1182_variants_small_values_R2.H4 := by
  intro t
  fin_cases t
  · exact h4_eleven
  · exact twelve

end E1182Eleven
#print axioms E1182Eleven.original_H4_from_twelve
