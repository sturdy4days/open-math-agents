import HostChecks4
namespace E1182TwelveBlock.Word32
def p3E : Nat := spreadCells 0xfffc20b8eb8eb8e850c20850b8eb8eb8e801
def p3R : Nat := spreadCells 0xfffffffffdffcfffffbfffbfc7fc77c73fff
set_option maxHeartbeats 0 in
theorem okS3 : sourceWords host4 pat3 p3E p3R := by
  unfold sourceWords
  decide +kernel
abbrev perm3 := permit p3E p3R h4J h4B
abbrev apart3 := field h4A 384
abbrev start3 := initial pat3 h4I h4U h4T
def leaves3 : List (List Nat) := [[0],[2,1],[4,1],[6,1],[7,1],[8,1],[10,1],[11,1],[12,1],[13,1],[15,1],[1,2],[2,2],[4,2],[5,2],[7,2],[8,2],[9,2],[11,2],[12,2],[14,2],[15,2],[0,3],[3,3],[4,3],[5,3],[6,3],[8,3],[9,3],[10,3],[13,3],[14,3],[15,3],[1,4],[2,4],[3,4],[4,4],[7,4],[8,4],[9,4],[10,4],[13,4],[14,4],[15,4],[5],[0,6],[1,6],[3,6],[5,6],[6,6],[8,6],[10,6],[11,6],[12,6],[13,6],[15,6],[0,9],[2,9],[3,9],[4,9],[5,9],[7,9],[10,9],[12,9],[14,9],[15,9],[0,10],[1,10],[3,10],[4,10],[6,10],[7,10],[9,10],[12,10],[13,10],[15,10],[13]]
def branches3 : List (List Nat) := [[1],[2],[3],[4],[6],[9],[10],[]]
abbrev test3 := fails perm3 apart3 start3
end E1182TwelveBlock.Word32
