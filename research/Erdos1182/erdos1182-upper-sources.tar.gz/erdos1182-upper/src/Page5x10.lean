import Intro5
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice5x59 : ((leaves5.drop 59).take 6).all test5=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice5x65 : ((leaves5.drop 65).take 2).all test5=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice5x67 : ((leaves5.drop 67).take 3).all test5=true := by decide +kernel
end E1182TwelveBlock.Word32
