import TwinRule
import ValidHost2
import WordCut30
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem blocked30 : ¬ (codeGraph 11 pat30.mask) ⊑ (triGraph 21 host2.original)ᶜ := by
  apply null_of_test host2 pat30 hostValid2 (by decide +kernel) (twins_from_types pat30 324551365587159423838765892716778 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact Word32.miss30
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked30
