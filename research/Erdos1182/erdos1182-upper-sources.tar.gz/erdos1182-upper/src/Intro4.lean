import HostChecks8
namespace E1182TwelveBlock.Word32
def p4E : Nat := spreadCells 0x80f43020f10e08e070460450b88b84b82a01
def p4R : Nat := spreadCells 0xffffff7fffffeffbffffffdffffff7ff3fff
set_option maxHeartbeats 0 in
theorem okS4 : sourceWords host8 pat4 p4E p4R := by
  unfold sourceWords
  decide +kernel
abbrev perm4 := permit p4E p4R h8J h8B
abbrev apart4 := field h8A 384
abbrev start4 := initial pat4 h8I h8U h8T
def leaves4 : List (List Nat) := [[0],[1],[0,3],[3,3],[4,3],[5,3],[6,3],[8,3],[9,3],[12,3],[13,3],[14,3],[5],[0,7],[1,7],[2,7],[4,7],[7,7,7,7],[9,7,7,7],[10,7,7,7],[11,7,7,7],[12,7,7,7],[13,7,7,7],[15,7,7,7],[9,7,7],[10,7,7],[11,7,7],[12,7,7],[13,7,7],[9,7],[10,7],[11,7],[12,7],[13,7]]
def branches4 : List (List Nat) := [[3],[7,7,7],[7,7],[7],[]]
abbrev test4 := fails perm4 apart4 start4
end E1182TwelveBlock.Word32
