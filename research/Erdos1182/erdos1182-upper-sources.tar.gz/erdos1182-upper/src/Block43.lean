import TwinRule
import ValidHost0
import WordCut43
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem blocked43 : ¬ (codeGraph 11 pat43.mask) ⊑ (triGraph 21 host0.original)ᶜ := by
  apply null_of_test host0 pat43 hostValid0 (by decide +kernel) (twins_from_types pat43 988601406216651059961392837942303866 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact Word32.miss43
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked43
