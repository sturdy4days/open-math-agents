import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf16_0_1 : failed host0 pat16 (atPath host0 pat16 [1,0]) = true := by
  decide +kernel

theorem leaf16_0_3_4 : failed host0 pat16 (atPath host0 pat16 [4,3,0]) = true := by
  decide +kernel

theorem leaf16_0_3_7 : failed host0 pat16 (atPath host0 pat16 [7,3,0]) = true := by
  decide +kernel

theorem leaf16_0_3_10 : failed host0 pat16 (atPath host0 pat16 [10,3,0]) = true := by
  decide +kernel

theorem leaf16_0_3_11 : failed host0 pat16 (atPath host0 pat16 [11,3,0]) = true := by
  decide +kernel

theorem leaf16_0_3_12 : failed host0 pat16 (atPath host0 pat16 [12,3,0]) = true := by
  decide +kernel

theorem leaf16_0_3_13 : failed host0 pat16 (atPath host0 pat16 [13,3,0]) = true := by
  decide +kernel

end E1182ElevenBlock
