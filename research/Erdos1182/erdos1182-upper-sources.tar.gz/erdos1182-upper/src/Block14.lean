import TwinRule
import ValidHost1
import WordCut14
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem blocked14 : ¬ (codeGraph 11 pat14.mask) ⊑ (triGraph 21 host1.original)ᶜ := by
  apply null_of_test host1 pat14 hostValid1 (by decide +kernel) (twins_from_types pat14 1084547050259316397255007320903077738 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact Word32.miss14
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked14
