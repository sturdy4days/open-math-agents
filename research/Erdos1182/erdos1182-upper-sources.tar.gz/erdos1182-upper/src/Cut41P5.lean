import Descent
import ValidHost1
namespace E1182ElevenBlock
theorem leaf41_7_2 : failed host1 pat41 (atPath host1 pat41 [2,7]) = true := by
  decide +kernel

theorem leaf41_7_4 : failed host1 pat41 (atPath host1 pat41 [4,7]) = true := by
  decide +kernel

theorem leaf41_7_9 : failed host1 pat41 (atPath host1 pat41 [9,7]) = true := by
  decide +kernel

theorem leaf41_7_10 : failed host1 pat41 (atPath host1 pat41 [10,7]) = true := by
  decide +kernel

theorem leaf41_7_11 : failed host1 pat41 (atPath host1 pat41 [11,7]) = true := by
  decide +kernel

theorem leaf41_7_13 : failed host1 pat41 (atPath host1 pat41 [13,7]) = true := by
  decide +kernel

end E1182ElevenBlock
