import Intro12
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice12x24 : ((leaves12.drop 24).take 1).all test12=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice12x25 : ((leaves12.drop 25).take 2).all test12=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice12x27 : ((leaves12.drop 27).take 4).all test12=true := by decide +kernel
end E1182TwelveBlock.Word32
