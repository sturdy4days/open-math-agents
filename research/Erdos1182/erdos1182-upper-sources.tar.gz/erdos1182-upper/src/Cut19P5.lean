import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf19_0_10_11 : failed host0 pat19 (atPath host0 pat19 [11,10,0]) = true := by
  decide +kernel

theorem leaf19_0_10_13 : failed host0 pat19 (atPath host0 pat19 [13,10,0]) = true := by
  decide +kernel

theorem leaf19_0_10_14 : failed host0 pat19 (atPath host0 pat19 [14,10,0]) = true := by
  decide +kernel

theorem leaf19_0_10_17 : failed host0 pat19 (atPath host0 pat19 [17,10,0]) = true := by
  decide +kernel

theorem leaf19_0_10_18 : failed host0 pat19 (atPath host0 pat19 [18,10,0]) = true := by
  decide +kernel

theorem leaf19_0_10_20 : failed host0 pat19 (atPath host0 pat19 [20,10,0]) = true := by
  decide +kernel

end E1182ElevenBlock
