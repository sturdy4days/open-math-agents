import Intro3
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice3x25 : ((leaves3.drop 25).take 3).all test3=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice3x28 : ((leaves3.drop 28).take 5).all test3=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice3x33 : ((leaves3.drop 33).take 1).all test3=true := by decide +kernel
end E1182TwelveBlock.Word32
