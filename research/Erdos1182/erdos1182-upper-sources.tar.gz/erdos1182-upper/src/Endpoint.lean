import GlueTen
import FirstEleven
import ClassAll
namespace E1182Eleven
open SimpleGraph E1182Cover E1182Bits

def triGraph (h mask : ℕ) : SimpleGraph (Fin h) where
  Adj i j := i≠j ∧ mask.testBit ((max i j).val.choose 2+(min i j).val)=true
  symm := ⟨fun i j e => ⟨e.1.symm,by simpa only [min_comm j i,max_comm j i] using e.2⟩⟩
  loopless := ⟨fun i e => e.1 rfl⟩

instance (h mask : Nat) : DecidableRel (triGraph h mask).Adj :=
  fun _ _ => inferInstanceAs (Decidable (_≠_ ∧ _=true))

def masks : List Nat := [0x3c03c78079e01ef00ff00f1e007803c03c00781e0f0f01e7bfc0,0x1300c9300ca601898064c034c02980260130130260984c4c9a512,0x14618714a110c3142298116d102a2148904630c2494281d0a4873,0x8c114a884942464b2022a4a428261306320822e4a4ad013060e4,0x2a0350a80582183162129c0f8001d0086405013a94461515060a0,0x320c9a068340d092240b020b03304c45222a22864d0684810665,0x9848e6152078149c905b20421622c0a5011422e4a4ad017060e4,0xb1f00c9911c54838254c9410328059521341a10461915172e0a4]
def extras : List Nat := [0x1300c9300ca601898064c034c02980260130130260984c4c9a512,0x14618714a110c3142298116d102a2148904630c2494281d0a4873,0x8c114a884942464b2022a4a428261306320822e4a4ad013060e4,0x2a0350a80582183162129c0f8001d0086405013a94461515060a0,0x320c9a068340d092240b020b03304c45222a22864d0684810665,0x9848e6152078149c905b20421622c0a5011422e4a4ad017060e4,0xb1f00c9911c54838254c9410328059521341a10461915172e0a4]

theorem first_matches : codeGraph 21 135609609600247606128381683893665301321939630946951377255594972053592485320532370282964939986463293680 = triGraph 21 0x3c03c78079e01ef00ff00f1e007803c03c00781e0f0f01e7bfc0 := by
  ext i j
  exact (show ∀ i j : Fin 21, (codeGraph 21 135609609600247606128381683893665301321939630946951377255594972053592485320532370282964939986463293680).Adj i j ↔ (triGraph 21 0x3c03c78079e01ef00ff00f1e007803c03c00781e0f0f01e7bfc0).Adj i j by decide +kernel) i j

theorem red_card {G : SimpleGraph (Fin 11)} (h : G.edgeSet.ncard=42) :
    Gᶜ.edgeSet.ncard=13 := by
  classical
  have dis : Disjoint G.edgeSet Gᶜ.edgeSet := disjoint_edgeSet.mpr disjoint_compl_right
  have edge := Set.ncard_union_eq dis (Set.toFinite _) (Set.toFinite _)
  have topSize : (⊤ : SimpleGraph (Fin 11)).edgeSet.ncard = 55 := by
    calc
      _ = (⊤ : SimpleGraph (Fin 11)).edgeFinset.card := Set.ncard_eq_toFinset_card' _
      _ = (Fintype.card (Fin 11)).choose 2 := card_edgeFinset_top_eq_card_choose_two
      _ = 55 := by decide
  rw [←edgeSet_sup,sup_compl_eq_top,topSize] at edge
  omega

theorem no_common
    (blocked : ∀ i : Fin 2297, ∃ m∈extras, ¬ (codeGraph 11 (field l13 121 i.val))ᶜ ⊑ (triGraph 21 m)ᶜ)
    (G : SimpleGraph (Fin 11)) (hG : G.edgeSet.ncard=42) :
    ∃ m∈masks, ¬ G ⊑ (triGraph 21 m)ᶜ := by
  classical
  by_contra! h
  obtain ⟨f⟩ := h 0x3c03c78079e01ef00ff00f1e007803c03c00781e0f0f01e7bfc0 (List.mem_cons_self)
  have hr := red_card hG
  have pull : ∀ i j, (codeGraph 21 135609609600247606128381683893665301321939630946951377255594972053592485320532370282964939986463293680).Adj (f i) (f j) → Gᶜ.Adj i j := by
    rw [first_matches]
    intro i j edge
    exact ⟨fun he => edge.ne (congrArg f he),fun bad => (f.toHom.map_rel' bad).2 edge⟩
  obtain ⟨i,⟨e⟩⟩ := classify hr (from_first_host_eleven Gᶜ hr f.toEmbedding pull)
  obtain ⟨m,hm,notIn⟩ := blocked i
  have toG : (codeGraph 11 (field l13 121 i.val))ᶜ ⊑ G := by
    simpa using (SimpleGraph.Embedding.complEquiv e.toEmbedding).isContained
  exact notIn (toG.trans (h m (List.mem_cons_of_mem 0x3c03c78079e01ef00ff00f1e007803c03c00781e0f0f01e7bfc0 hm)))

theorem fixed_eleven
    (blocked : ∀ i : Fin 2297, ∃ m∈extras, ¬ (codeGraph 11 (field l13 121 i.val))ᶜ ⊑ (triGraph 21 m)ᶜ) :
    let ms := [0x3c03c78079e01ef00ff00f1e007803c03c00781e0f0f01e7bfc0,0x1300c9300ca601898064c034c02980260130130260984c4c9a512,0x14618714a110c3142298116d102a2148904630c2494281d0a4873,0x8c114a884942464b2022a4a428261306320822e4a4ad013060e4,0x2a0350a80582183162129c0f8001d0086405013a94461515060a0,0x320c9a068340d092240b020b03304c45222a22864d0684810665,0x9848e6152078149c905b20421622c0a5011422e4a4ad017060e4,0xb1f00c9911c54838254c9410328059521341a10461915172e0a4]
    let C (a : Fin ms.length) : SimpleGraph (Fin 21) := triGraph 21 ms[a.val]
    ∀ f : Fin ms.length → Fin 11 ↪ Fin 21, (⨅ a, (C a)ᶜ.comap (f a)).edgeSet.ncard ≤ 41 := by
  classical
  intro _ms _C f
  let D := ⨅ a : Fin masks.length, (triGraph 21 (masks[a.val]))ᶜ.comap (f a)
  change D.edgeSet.ncard ≤ 41
  by_contra! big
  obtain ⟨G,sub,sz⟩ := trim_edges D (q:=42) (by omega)
  obtain ⟨m,hm,notIn⟩ := no_common blocked G sz
  obtain ⟨i,hi,rfl⟩ := List.getElem_of_mem hm
  let a : Fin masks.length := ⟨i,hi⟩
  exact notIn (isContained_iff_exists_le_comap.mpr ⟨f a,sub.trans (iInf_le _ a)⟩)

end E1182Eleven
#print axioms E1182Eleven.fixed_eleven
