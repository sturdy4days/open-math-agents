import Descent
import ValidHost1
namespace E1182ElevenBlock
theorem leaf41_0_0_3 : failed host1 pat41 (atPath host1 pat41 [3,0,0]) = true := by
  decide +kernel

theorem leaf41_0_0_5 : failed host1 pat41 (atPath host1 pat41 [5,0,0]) = true := by
  decide +kernel

theorem leaf41_0_0_6 : failed host1 pat41 (atPath host1 pat41 [6,0,0]) = true := by
  decide +kernel

theorem leaf41_0_0_7 : failed host1 pat41 (atPath host1 pat41 [7,0,0]) = true := by
  decide +kernel

theorem leaf41_0_0_9 : failed host1 pat41 (atPath host1 pat41 [9,0,0]) = true := by
  decide +kernel

theorem leaf41_0_0_10 : failed host1 pat41 (atPath host1 pat41 [10,0,0]) = true := by
  decide +kernel

theorem leaf41_0_0_11 : failed host1 pat41 (atPath host1 pat41 [11,0,0]) = true := by
  decide +kernel

theorem leaf41_0_0_13 : failed host1 pat41 (atPath host1 pat41 [13,0,0]) = true := by
  decide +kernel

end E1182ElevenBlock
