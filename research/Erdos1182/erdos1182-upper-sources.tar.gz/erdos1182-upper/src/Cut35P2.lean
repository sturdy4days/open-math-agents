import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf35_0_7_10 : failed host0 pat35 (atPath host0 pat35 [10,7,0]) = true := by
  decide +kernel

theorem leaf35_0_7_11 : failed host0 pat35 (atPath host0 pat35 [11,7,0]) = true := by
  decide +kernel

theorem leaf35_0_7_14 : failed host0 pat35 (atPath host0 pat35 [14,7,0]) = true := by
  decide +kernel

theorem leaf35_0_7_17 : failed host0 pat35 (atPath host0 pat35 [17,7,0]) = true := by
  decide +kernel

theorem leaf35_0_7_18 : failed host0 pat35 (atPath host0 pat35 [18,7,0]) = true := by
  decide +kernel

theorem leaf35_0_7_20 : failed host0 pat35 (atPath host0 pat35 [20,7,0]) = true := by
  decide +kernel

theorem leaf35_0_8 : failed host0 pat35 (atPath host0 pat35 [8,0]) = true := by
  decide +kernel

theorem leaf35_0_9 : failed host0 pat35 (atPath host0 pat35 [9,0]) = true := by
  decide +kernel

end E1182ElevenBlock
