import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf45_0_1 : failed host0 pat45 (atPath host0 pat45 [1,0]) = true := by
  decide +kernel

theorem leaf45_0_3_4 : failed host0 pat45 (atPath host0 pat45 [4,3,0]) = true := by
  decide +kernel

theorem leaf45_0_3_7 : failed host0 pat45 (atPath host0 pat45 [7,3,0]) = true := by
  decide +kernel

theorem leaf45_0_3_10 : failed host0 pat45 (atPath host0 pat45 [10,3,0]) = true := by
  decide +kernel

theorem leaf45_0_3_11 : failed host0 pat45 (atPath host0 pat45 [11,3,0]) = true := by
  decide +kernel

theorem leaf45_0_3_12 : failed host0 pat45 (atPath host0 pat45 [12,3,0]) = true := by
  decide +kernel

theorem leaf45_0_3_13 : failed host0 pat45 (atPath host0 pat45 [13,3,0]) = true := by
  decide +kernel

end E1182ElevenBlock
