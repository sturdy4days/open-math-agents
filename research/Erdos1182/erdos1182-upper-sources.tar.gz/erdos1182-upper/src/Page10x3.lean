import Intro10
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice10x12 : ((leaves10.drop 12).take 4).all test10=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice10x16 : ((leaves10.drop 16).take 1).all test10=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice10x17 : ((leaves10.drop 17).take 1).all test10=true := by decide +kernel
end E1182TwelveBlock.Word32
