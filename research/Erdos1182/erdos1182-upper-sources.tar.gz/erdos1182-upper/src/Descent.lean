import HostRule
namespace E1182ElevenBlock

abbrev SearchState := List (Fin 11 × ℕ) × List ℕ

def nextState (h : Host) (p : Pattern) (s : SearchState) (v : ℕ) : SearchState :=
  match s.1 with
  | [] => ([],s.2)
  | (i,_)::ds =>
    let avail := s.2.erase v
    (consumeDomains (classMask p.edges p.tags h.joined h.high h.full) h.apart i v avail ds,avail)

def choices (h : Host) (p : Pattern) (s : SearchState) : List ℕ :=
  match s.1 with
  | [] => []
  | (_,domain)::_ => domain.bitIndices.filter fun v =>
    s.2.contains v && (nextState h p s v).1.all (fun u => u.2 != 0)

def failed (h : Host) (p : Pattern) (s : SearchState) : Bool :=
  !(capSearch (classMask p.edges p.tags h.joined h.high h.full) h.apart s.1.length s.1 s.2)

def atPath (h : Host) (p : Pattern) : List ℕ → SearchState
  | [] => (domains h p,(List.finRange 21).map fun x => h.colours[x.val]!)
  | v::t => nextState h p (atPath h p t) v

theorem negate_true (b : Bool) : (!b) = true ↔ b = false := by cases b <;> decide

theorem failed_of_choices (h : Host) (p : Pattern) (s : SearchState) (ne : s.1≠[])
    (children : ∀ v ∈ choices h p s, failed h p (nextState h p s v) = true) :
    failed h p s = true := by
  rcases s with ⟨ds,supply⟩
  rcases ds with _ | ⟨⟨i,dom⟩,t⟩
  · exact (ne rfl).elim
  · let allow := classMask (n:=11) p.edges p.tags h.joined h.high h.full
    change (! (dom.bitIndices.any _)) = true
    apply (negate_true _).mpr
    apply List.any_eq_false.mpr
    intro v hv
    let remv := supply.erase v
    let ds' := consumeDomains allow h.apart i v remv t
    apply Bool.eq_false_iff.mp
    change (supply.contains v && (ds'.all (fun u => u.2 != 0) && capSearch allow h.apart t.length ds' remv)) = false
    by_cases vg : supply.contains v = true
    · by_cases live : ds'.all (fun u => u.2 != 0) = true
      · have choice : v ∈ choices h p ((i,dom)::t,supply) := by
          apply List.mem_filter.mpr
          refine ⟨hv,?_⟩
          change (supply.contains v && ds'.all (fun u => u.2 != 0)) = true
          rw [vg,live]
          rfl
        have hx := children v choice
        change (!(capSearch allow h.apart ds'.length ds' remv))=true at hx
        have len : ds'.length=t.length := List.length_map _
        rw [len,negate_true] at hx
        rw [vg,live,hx]
        rfl
      · rw [Bool.eq_false_iff.mpr live, Bool.false_and, Bool.and_false]
    · rw [Bool.eq_false_iff.mpr vg, Bool.false_and]

theorem failed_atPath (h : Host) (p : Pattern) (path roots : List ℕ)
    (ne : (atPath h p path).1≠[]) (complete : choices h p (atPath h p path) = roots)
    (children : ∀ v ∈ roots, failed h p (atPath h p (v::path)) = true) :
    failed h p (atPath h p path) = true := by
  apply failed_of_choices h p _ ne
  intro v hv
  exact children v (complete ▸ hv)

theorem rejects_of_failed_root (h : Host) (p : Pattern) (x : failed h p (atPath h p []) = true) :
    rejects h p = false := by simpa only [failed,atPath,negate_true,rejects] using x

end E1182ElevenBlock
#print axioms E1182ElevenBlock.failed_atPath
