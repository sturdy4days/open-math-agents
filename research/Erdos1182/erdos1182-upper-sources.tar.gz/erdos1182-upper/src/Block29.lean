import TwinRule
import ValidHost1
import WordCut29
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem blocked29 : ¬ (codeGraph 11 pat29.mask) ⊑ (triGraph 21 host1.original)ᶜ := by
  apply null_of_test host1 pat29 hostValid1 (by decide +kernel) (twins_from_types pat29 284597936762153173758786009988980218 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact Word32.miss29
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked29
