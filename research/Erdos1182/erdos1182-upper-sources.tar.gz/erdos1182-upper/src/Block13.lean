import TwinRule
import ValidHost1
import WordCut13
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem blocked13 : ¬ (codeGraph 11 pat13.mask) ⊑ (triGraph 21 host1.original)ᶜ := by
  apply null_of_test host1 pat13 hostValid1 (by decide +kernel) (twins_from_types pat13 89775854572471142904750977917317086 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact Word32.miss13
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked13
