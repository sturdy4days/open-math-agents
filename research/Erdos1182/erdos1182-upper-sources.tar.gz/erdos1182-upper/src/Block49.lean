import TwinRule
import ValidHost2
import WordCut49
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem blocked49 : ¬ (codeGraph 11 pat49.mask) ⊑ (triGraph 21 host2.original)ᶜ := by
  apply null_of_test host2 pat49 hostValid2 (by decide +kernel) (twins_from_types pat49 241441871903880584910539682596444666 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact Word32.miss49
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked49
