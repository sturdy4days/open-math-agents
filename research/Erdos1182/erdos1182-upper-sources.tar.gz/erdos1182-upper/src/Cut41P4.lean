import Descent
import ValidHost1
namespace E1182ElevenBlock
theorem leaf41_3_9 : failed host1 pat41 (atPath host1 pat41 [9,3]) = true := by
  decide +kernel

theorem leaf41_3_10 : failed host1 pat41 (atPath host1 pat41 [10,3]) = true := by
  decide +kernel

theorem leaf41_3_13 : failed host1 pat41 (atPath host1 pat41 [13,3]) = true := by
  decide +kernel

theorem leaf41_7_0 : failed host1 pat41 (atPath host1 pat41 [0,7]) = true := by
  decide +kernel

theorem leaf41_7_1 : failed host1 pat41 (atPath host1 pat41 [1,7]) = true := by
  decide +kernel

end E1182ElevenBlock
