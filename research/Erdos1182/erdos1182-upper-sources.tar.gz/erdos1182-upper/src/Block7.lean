import Cut7P0
import Cut7P1
import Cut7P2
import Cut7P3
import Cut7P4
import Cut7P5
import Cut7P6
import Cut7P7
import Cut7P8
import Descent
import Descent
import TwinRule
import ValidHost3
namespace E1182ElevenBlock
open SimpleGraph E1182Cover

private theorem leaf7_0 : failed host3 pat7 (atPath host3 pat7 [0]) = true := by
  apply failed_atPath _ _ _ [1,2,3,4,5,6,7,9,10,12,14,15,16] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf7_0_1
  · exact leaf7_0_2
  · exact leaf7_0_3
  · exact leaf7_0_4
  · exact leaf7_0_5
  · exact leaf7_0_6
  · exact leaf7_0_7
  · exact leaf7_0_9
  · exact leaf7_0_10
  · exact leaf7_0_12
  · exact leaf7_0_14
  · exact leaf7_0_15
  · exact leaf7_0_16

private theorem leaf7_1 : failed host3 pat7 (atPath host3 pat7 [1]) = true := by
  apply failed_atPath _ _ _ [0,2,3,5,6,8,12,13,14,15,16,17,18] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf7_1_0
  · exact leaf7_1_2
  · exact leaf7_1_3
  · exact leaf7_1_5
  · exact leaf7_1_6
  · exact leaf7_1_8
  · exact leaf7_1_12
  · exact leaf7_1_13
  · exact leaf7_1_14
  · exact leaf7_1_15
  · exact leaf7_1_16
  · exact leaf7_1_17
  · exact leaf7_1_18

private theorem leaf7_16_0 : failed host3 pat7 (atPath host3 pat7 [0,16]) = true := by
  apply failed_atPath _ _ _ [1,2,3,4,5,9,10,12,14] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf7_16_0_1
  · exact leaf7_16_0_2
  · exact leaf7_16_0_3
  · exact leaf7_16_0_4
  · exact leaf7_16_0_5
  · exact leaf7_16_0_9
  · exact leaf7_16_0_10
  · exact leaf7_16_0_12
  · exact leaf7_16_0_14

private theorem leaf7_16 : failed host3 pat7 (atPath host3 pat7 [16]) = true := by
  apply failed_atPath _ _ _ [0,1,2,3,4,5,9,10,12,14,15,18] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf7_16_0
  · exact leaf7_16_1
  · exact leaf7_16_2
  · exact leaf7_16_3
  · exact leaf7_16_4
  · exact leaf7_16_5
  · exact leaf7_16_9
  · exact leaf7_16_10
  · exact leaf7_16_12
  · exact leaf7_16_14
  · exact leaf7_16_15
  · exact leaf7_16_18

private theorem leaf7_18 : failed host3 pat7 (atPath host3 pat7 [18]) = true := by
  apply failed_atPath _ _ _ [1,2,3,4,5,8,9,10,11,13,14,15,16,17] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf7_18_1
  · exact leaf7_18_2
  · exact leaf7_18_3
  · exact leaf7_18_4
  · exact leaf7_18_5
  · exact leaf7_18_8
  · exact leaf7_18_9
  · exact leaf7_18_10
  · exact leaf7_18_11
  · exact leaf7_18_13
  · exact leaf7_18_14
  · exact leaf7_18_15
  · exact leaf7_18_16
  · exact leaf7_18_17

private theorem leaf7_root : failed host3 pat7 (atPath host3 pat7 []) = true := by
  apply failed_atPath _ _ _ [0,1,16,18] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl
  · exact leaf7_0
  · exact leaf7_1
  · exact leaf7_16
  · exact leaf7_18

theorem blocked7 : ¬ (codeGraph 11 pat7.mask) ⊑ (triGraph 21 host3.original)ᶜ := by
  apply null_of_test host3 pat7 hostValid3 (by decide +kernel) (twins_from_types pat7 2720083096437492015208466 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact rejects_of_failed_root _ _ leaf7_root
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked7
