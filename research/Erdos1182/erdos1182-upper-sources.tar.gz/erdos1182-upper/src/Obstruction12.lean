import FrontierClose
import Page12x0
import Page12x1
import Page12x2
import Page12x3
import Page12x4
import Page12x5
import Page12x6
import Page12x7
import Page12x8
import Page12x9
import Page12x10
import Page12x11
import Page12x12
namespace E1182TwelveBlock.Word32
private theorem appendParts12 (offset width : Nat)
    (head : ((leaves12.drop offset).take width).all test12 = true)
    (tail : (leaves12.drop (offset+width)).all test12 = true) :
    (leaves12.drop offset).all test12 = true :=
  prepend_chunk (xs := leaves12) (f := test12) (offset := offset) (width := width) head tail

set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem miss12 : rejects host8 pat12 = false :=
  closeFrontier host8 pat12 p12E p12R h8J h8B h8A h8I h8U h8T
    okH8 okS12 leaves12 branches12
    (appendParts12 0 1 slice12x0 (appendParts12 1 3 slice12x1 (appendParts12 4 2 slice12x4 (appendParts12 6 7 slice12x6 (appendParts12 13 1 slice12x13 (appendParts12 14 1 slice12x14 (appendParts12 15 5 slice12x15 (appendParts12 20 1 slice12x20 (appendParts12 21 1 slice12x21 (appendParts12 22 2 slice12x22 (appendParts12 24 1 slice12x24 (appendParts12 25 2 slice12x25 (appendParts12 27 4 slice12x27 (appendParts12 31 3 slice12x31 (appendParts12 34 5 slice12x34 (appendParts12 39 3 slice12x39 (appendParts12 42 1 slice12x42 (appendParts12 43 1 slice12x43 (appendParts12 44 4 slice12x44 (appendParts12 48 1 slice12x48 (appendParts12 49 1 slice12x49 (appendParts12 50 1 slice12x50 (appendParts12 51 1 slice12x51 (appendParts12 52 1 slice12x52 (appendParts12 53 1 slice12x53 (appendParts12 54 1 slice12x54 (appendParts12 55 1 slice12x55 (appendParts12 56 1 slice12x56 (appendParts12 57 1 slice12x57 (appendParts12 58 3 slice12x58 (appendParts12 61 3 slice12x61 (appendParts12 64 4 slice12x64 (by decide +kernel))))))))))))))))))))))))))))))))) (by decide +kernel)
end E1182TwelveBlock.Word32
#print axioms E1182TwelveBlock.Word32.miss12
namespace E1182TwelveBlock
open SimpleGraph E1182Cover
set_option maxHeartbeats 0 in
theorem blocked12 : ¬ (codeGraph 12 pat12.mask) ⊑ (triGraph 23 host8.original)ᶜ := by
  apply null_of_test host8 pat12 hostValid8 (by decide +kernel)
    (twins_from_types pat12 0x1d32f23f13b31d73e70000373772f6 (by decide +kernel)) (by decide +kernel) (by decide +kernel)
  exact Word32.miss12
end E1182TwelveBlock
#print axioms E1182TwelveBlock.blocked12
