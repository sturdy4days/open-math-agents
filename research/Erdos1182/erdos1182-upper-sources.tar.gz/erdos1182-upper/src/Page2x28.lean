import Intro2
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x208 : ((leaves2.drop 208).take 1).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x209 : ((leaves2.drop 209).take 1).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x210 : ((leaves2.drop 210).take 1).all test2=true := by decide +kernel
end E1182TwelveBlock.Word32
