import FrontierClose
import Page7x0
import Page7x1
import Page7x2
import Page7x3
import Page7x4
import Page7x5
namespace E1182TwelveBlock.Word32
private theorem appendParts7 (offset width : Nat)
    (head : ((leaves7.drop offset).take width).all test7 = true)
    (tail : (leaves7.drop (offset+width)).all test7 = true) :
    (leaves7.drop offset).all test7 = true :=
  prepend_chunk (xs := leaves7) (f := test7) (offset := offset) (width := width) head tail

set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem miss7 : rejects host8 pat7 = false :=
  closeFrontier host8 pat7 p7E p7R h8J h8B h8A h8I h8U h8T
    okH8 okS7 leaves7 branches7
    (appendParts7 0 1 slice7x0 (appendParts7 1 1 slice7x1 (appendParts7 2 1 slice7x2 (appendParts7 3 1 slice7x3 (appendParts7 4 2 slice7x4 (appendParts7 6 1 slice7x6 (appendParts7 7 5 slice7x7 (appendParts7 12 1 slice7x12 (appendParts7 13 1 slice7x13 (appendParts7 14 1 slice7x14 (appendParts7 15 1 slice7x15 (appendParts7 16 1 slice7x16 (appendParts7 17 1 slice7x17 (appendParts7 18 10 slice7x18 (by decide +kernel))))))))))))))) (by decide +kernel)
end E1182TwelveBlock.Word32
#print axioms E1182TwelveBlock.Word32.miss7
namespace E1182TwelveBlock
open SimpleGraph E1182Cover
set_option maxHeartbeats 0 in
theorem blocked7 : ¬ (codeGraph 12 pat7.mask) ⊑ (triGraph 23 host8.original)ᶜ := by
  apply null_of_test host8 pat7 hostValid8 (by decide +kernel)
    (twins_from_types pat7 0x691a92cd0000ed1293000ec30000004538d2 (by decide +kernel)) (by decide +kernel) (by decide +kernel)
  exact Word32.miss7
end E1182TwelveBlock
#print axioms E1182TwelveBlock.blocked7
