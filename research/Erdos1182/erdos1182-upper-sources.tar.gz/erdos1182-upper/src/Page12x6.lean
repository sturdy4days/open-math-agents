import Intro12
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice12x42 : ((leaves12.drop 42).take 1).all test12=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice12x43 : ((leaves12.drop 43).take 1).all test12=true := by decide +kernel
end E1182TwelveBlock.Word32
