import Descent
import ValidHost3
namespace E1182ElevenBlock
theorem leaf7_16_0_1 : failed host3 pat7 (atPath host3 pat7 [1,0,16]) = true := by
  decide +kernel

theorem leaf7_16_0_2 : failed host3 pat7 (atPath host3 pat7 [2,0,16]) = true := by
  decide +kernel

theorem leaf7_16_0_3 : failed host3 pat7 (atPath host3 pat7 [3,0,16]) = true := by
  decide +kernel

theorem leaf7_16_0_4 : failed host3 pat7 (atPath host3 pat7 [4,0,16]) = true := by
  decide +kernel

theorem leaf7_16_0_5 : failed host3 pat7 (atPath host3 pat7 [5,0,16]) = true := by
  decide +kernel

theorem leaf7_16_0_9 : failed host3 pat7 (atPath host3 pat7 [9,0,16]) = true := by
  decide +kernel

theorem leaf7_16_0_10 : failed host3 pat7 (atPath host3 pat7 [10,0,16]) = true := by
  decide +kernel

theorem leaf7_16_0_12 : failed host3 pat7 (atPath host3 pat7 [12,0,16]) = true := by
  decide +kernel

theorem leaf7_16_0_14 : failed host3 pat7 (atPath host3 pat7 [14,0,16]) = true := by
  decide +kernel

theorem leaf7_16_1 : failed host3 pat7 (atPath host3 pat7 [1,16]) = true := by
  decide +kernel

end E1182ElevenBlock
