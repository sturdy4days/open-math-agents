import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf45_0_11 : failed host0 pat45 (atPath host0 pat45 [11,0]) = true := by
  decide +kernel

theorem leaf45_0_12 : failed host0 pat45 (atPath host0 pat45 [12,0]) = true := by
  decide +kernel

theorem leaf45_0_13 : failed host0 pat45 (atPath host0 pat45 [13,0]) = true := by
  decide +kernel

theorem leaf45_0_14 : failed host0 pat45 (atPath host0 pat45 [14,0]) = true := by
  decide +kernel

theorem leaf45_0_17 : failed host0 pat45 (atPath host0 pat45 [17,0]) = true := by
  decide +kernel

end E1182ElevenBlock
