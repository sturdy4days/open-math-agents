import BlockCore
namespace E1182TwelveBlock.Word32

theorem closeFrontier (h : Host) (p : Pattern) (E R J B A I U T : Nat)
    (host : hostWords h J B A I U T) (src : sourceWords h p E R)
    (leaves branches : List (List Nat))
    (tested : (leaves.drop 0).all (fails (permit E R J B) (field A 384) (initial p I U T)) = true)
    (closed : collectParents (permit E R J B) (field A 384) (initial p I U T) leaves branches = true) :
    rejects h p = false :=
  null h p E R J B A I U T host src (certified_frontier _ _ _ leaves branches tested closed)

end E1182TwelveBlock.Word32
