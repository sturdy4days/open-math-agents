import ArticleEleven
import Joint

/-! Upper bounds on the largest edge counts of triangle-good graphs of orders eleven and twelve. -/

namespace E1182Complete

theorem upper_twelve : Erdos1182.f 12 ≤ 49 := by
  obtain ⟨r,C,tri,cap⟩ := OMA.R_Erdos1182_erdos_1182_variants_small_values_R2.explicit_hosts fixed_hosts 1
  exact upper_of_hosts (by decide) C tri cap

theorem upper_pair : Erdos1182.f 11 ≤ 41 ∧ Erdos1182.f 12 ≤ 49 := ⟨upper_eleven,upper_twelve⟩

theorem small_values_of_remaining
    (a : OMA.R_Erdos1182_erdos_1182_variants_small_values_R2.H1)
    (b : OMA.R_Erdos1182_erdos_1182_variants_small_values_R2.H2)
    (c : OMA.R_Erdos1182_erdos_1182_variants_small_values_R2.H3) :
    type_of% @Erdos1182.erdos_1182.variants.small_values :=
  OMA.R_Erdos1182_erdos_1182_variants_small_values_R2.main a b c fixed_hosts

end E1182Complete
#print axioms E1182Complete.upper_pair
#print axioms E1182Complete.small_values_of_remaining
