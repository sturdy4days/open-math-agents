import TwinRule
import ValidHost1
import WordCut46
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem blocked46 : ¬ (codeGraph 11 pat46.mask) ⊑ (triGraph 21 host1.original)ᶜ := by
  apply null_of_test host1 pat46 hostValid1 (by decide +kernel) (twins_from_types pat46 312684909127067057261199460203518 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact Word32.miss46
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked46
