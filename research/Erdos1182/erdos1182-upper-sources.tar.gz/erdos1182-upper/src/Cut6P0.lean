import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf6_0_1_3 : failed host0 pat6 (atPath host0 pat6 [3,1,0]) = true := by
  decide +kernel

theorem leaf6_0_1_4 : failed host0 pat6 (atPath host0 pat6 [4,1,0]) = true := by
  decide +kernel

theorem leaf6_0_1_7 : failed host0 pat6 (atPath host0 pat6 [7,1,0]) = true := by
  decide +kernel

theorem leaf6_0_1_8 : failed host0 pat6 (atPath host0 pat6 [8,1,0]) = true := by
  decide +kernel

theorem leaf6_0_1_9 : failed host0 pat6 (atPath host0 pat6 [9,1,0]) = true := by
  decide +kernel

end E1182ElevenBlock
