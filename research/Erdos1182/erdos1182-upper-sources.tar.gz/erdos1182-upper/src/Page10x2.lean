import Intro10
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice10x8 : ((leaves10.drop 8).take 2).all test10=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice10x10 : ((leaves10.drop 10).take 1).all test10=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice10x11 : ((leaves10.drop 11).take 1).all test10=true := by decide +kernel
end E1182TwelveBlock.Word32
