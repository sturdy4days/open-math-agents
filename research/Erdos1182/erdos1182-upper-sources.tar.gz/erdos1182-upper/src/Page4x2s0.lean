import Intro4
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice4x6 : ((leaves4.drop 6).take 1).all test4=true := by decide +kernel
end E1182TwelveBlock.Word32
