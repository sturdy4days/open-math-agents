import Intro5
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice5x12 : ((leaves5.drop 12).take 1).all test5=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice5x13 : ((leaves5.drop 13).take 1).all test5=true := by decide +kernel
end E1182TwelveBlock.Word32
