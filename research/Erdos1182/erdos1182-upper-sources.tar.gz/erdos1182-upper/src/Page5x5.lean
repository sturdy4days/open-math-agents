import Intro5
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice5x26 : ((leaves5.drop 26).take 1).all test5=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice5x27 : ((leaves5.drop 27).take 5).all test5=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice5x32 : ((leaves5.drop 32).take 2).all test5=true := by decide +kernel
end E1182TwelveBlock.Word32
