import ProfileTwelve
import Mathlib.Tactic.FinCases
import Mathlib.Algebra.BigOperators.Fin
open SimpleGraph

namespace E1182Cover.Twelve

private def seedMasks : List ℕ := [508028,511874,2013757560,18738424009021844676149310,4161765624,18738424009020744896020528,74294540672716477532429352960,18742925023579729721098256]

private def HasSeed (k : Fin 5 → ℕ) : Prop :=
  ∃ m ∈ seedMasks, ∃ e : Fin 12 ↪ Slots k, ∀ i j, (codeGraph 12 m).Adj i j →
    classAdj (e i).1 (e j).1

private def sparseProfiles : List (Fin 5 → ℕ) := [
  seedSizes 0 1 5 1 5,
  seedSizes 0 2 5 0 5,
  seedSizes 0 3 4 0 5,
  seedSizes 0 3 5 0 4,
  seedSizes 0 4 0 3 5,
  seedSizes 0 4 0 4 4,
  seedSizes 0 4 0 5 3,
  seedSizes 0 4 1 2 5,
  seedSizes 0 4 2 1 5,
  seedSizes 0 4 3 0 5,
  seedSizes 0 4 4 0 4,
  seedSizes 1 0 5 1 5,
  seedSizes 1 1 5 0 5,
  seedSizes 1 2 4 0 5,
  seedSizes 1 2 5 0 4,
  seedSizes 1 4 0 5 2,
  seedSizes 2 0 5 0 5,
  seedSizes 2 1 4 0 5,
  seedSizes 2 1 5 0 4,
  seedSizes 2 4 0 5 1,
  seedSizes 3 0 4 0 5,
  seedSizes 3 0 5 0 4,
  seedSizes 3 4 0 5 0,
  seedSizes 4 0 3 5 0,
  seedSizes 4 0 4 0 4,
  seedSizes 4 0 4 4 0,
  seedSizes 4 0 5 0 3,
  seedSizes 4 0 5 1 2,
  seedSizes 4 0 5 2 1,
  seedSizes 4 0 5 3 0,
  seedSizes 4 1 2 5 0,
  seedSizes 4 2 1 5 0,
  seedSizes 4 3 0 5 0,
  seedSizes 4 4 0 4 0]

set_option maxRecDepth 10000 in
set_option maxHeartbeats 2500000 in
private theorem count_cases :
    ∀ (a b : Fin 5) (c d e : Fin 6), a.val+b.val+c.val+d.val+e.val = 12 →
    a.val*b.val+b.val*c.val+c.val*d.val+d.val*e.val+e.val*a.val ≤ 16 →
    seedSizes a.val b.val c.val d.val e.val ∈ sparseProfiles := by
  intro a b
  fin_cases a <;> fin_cases b <;> decide

set_option maxRecDepth 10000 in
private theorem profile_0 : HasSeed (seedSizes 0 1 5 1 5) := by
  let push : Fin 12 → Slots (seedSizes 0 1 5 1 5) := ![
    ⟨1, ⟨0, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨2, ⟨3, by decide⟩⟩, ⟨2, ⟨4, by decide⟩⟩, ⟨3, ⟨0, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩, ⟨4, ⟨4, by decide⟩⟩]
  exact ⟨18738424009021844676149310, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_1 : HasSeed (seedSizes 0 2 5 0 5) := by
  let push : Fin 12 → Slots (seedSizes 0 2 5 0 5) := ![
    ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨2, ⟨3, by decide⟩⟩, ⟨2, ⟨4, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩, ⟨4, ⟨4, by decide⟩⟩]
  exact ⟨508028, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_2 : HasSeed (seedSizes 0 3 4 0 5) := by
  let push : Fin 12 → Slots (seedSizes 0 3 4 0 5) := ![
    ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨1, ⟨2, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨2, ⟨3, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩, ⟨4, ⟨4, by decide⟩⟩]
  exact ⟨2013757560, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_3 : HasSeed (seedSizes 0 3 5 0 4) := by
  let push : Fin 12 → Slots (seedSizes 0 3 5 0 4) := ![
    ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨1, ⟨2, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨2, ⟨3, by decide⟩⟩, ⟨2, ⟨4, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩]
  exact ⟨4161765624, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_4 : HasSeed (seedSizes 0 4 0 3 5) := by
  let push : Fin 12 → Slots (seedSizes 0 4 0 3 5) := ![
    ⟨3, ⟨0, by decide⟩⟩, ⟨3, ⟨1, by decide⟩⟩, ⟨3, ⟨2, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩, ⟨4, ⟨4, by decide⟩⟩, ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨1, ⟨2, by decide⟩⟩, ⟨1, ⟨3, by decide⟩⟩]
  exact ⟨4161765624, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_5 : HasSeed (seedSizes 0 4 0 4 4) := by
  let push : Fin 12 → Slots (seedSizes 0 4 0 4 4) := ![
    ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨1, ⟨2, by decide⟩⟩, ⟨1, ⟨3, by decide⟩⟩, ⟨3, ⟨0, by decide⟩⟩, ⟨3, ⟨1, by decide⟩⟩, ⟨3, ⟨2, by decide⟩⟩, ⟨3, ⟨3, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩]
  exact ⟨74294540672716477532429352960, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_6 : HasSeed (seedSizes 0 4 0 5 3) := by
  let push : Fin 12 → Slots (seedSizes 0 4 0 5 3) := ![
    ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨3, ⟨0, by decide⟩⟩, ⟨3, ⟨1, by decide⟩⟩, ⟨3, ⟨2, by decide⟩⟩, ⟨3, ⟨3, by decide⟩⟩, ⟨3, ⟨4, by decide⟩⟩, ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨1, ⟨2, by decide⟩⟩, ⟨1, ⟨3, by decide⟩⟩]
  exact ⟨4161765624, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_7 : HasSeed (seedSizes 0 4 1 2 5) := by
  let push : Fin 12 → Slots (seedSizes 0 4 1 2 5) := ![
    ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨1, ⟨2, by decide⟩⟩, ⟨1, ⟨3, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨3, ⟨0, by decide⟩⟩, ⟨3, ⟨1, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩, ⟨4, ⟨4, by decide⟩⟩]
  exact ⟨18742925023579729721098256, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_8 : HasSeed (seedSizes 0 4 2 1 5) := by
  let push : Fin 12 → Slots (seedSizes 0 4 2 1 5) := ![
    ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨1, ⟨2, by decide⟩⟩, ⟨1, ⟨3, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨3, ⟨0, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩, ⟨4, ⟨4, by decide⟩⟩]
  exact ⟨18738424009020744896020528, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_9 : HasSeed (seedSizes 0 4 3 0 5) := by
  let push : Fin 12 → Slots (seedSizes 0 4 3 0 5) := ![
    ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨1, ⟨2, by decide⟩⟩, ⟨1, ⟨3, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩, ⟨4, ⟨4, by decide⟩⟩]
  exact ⟨2013757560, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_10 : HasSeed (seedSizes 0 4 4 0 4) := by
  let push : Fin 12 → Slots (seedSizes 0 4 4 0 4) := ![
    ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩, ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨1, ⟨2, by decide⟩⟩, ⟨1, ⟨3, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨2, ⟨3, by decide⟩⟩]
  exact ⟨74294540672716477532429352960, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_11 : HasSeed (seedSizes 1 0 5 1 5) := by
  let push : Fin 12 → Slots (seedSizes 1 0 5 1 5) := ![
    ⟨0, ⟨0, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩, ⟨4, ⟨4, by decide⟩⟩, ⟨3, ⟨0, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨2, ⟨3, by decide⟩⟩, ⟨2, ⟨4, by decide⟩⟩]
  exact ⟨18738424009021844676149310, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_12 : HasSeed (seedSizes 1 1 5 0 5) := by
  let push : Fin 12 → Slots (seedSizes 1 1 5 0 5) := ![
    ⟨0, ⟨0, by decide⟩⟩, ⟨1, ⟨0, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨2, ⟨3, by decide⟩⟩, ⟨2, ⟨4, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩, ⟨4, ⟨4, by decide⟩⟩]
  exact ⟨511874, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_13 : HasSeed (seedSizes 1 2 4 0 5) := by
  let push : Fin 12 → Slots (seedSizes 1 2 4 0 5) := ![
    ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨2, ⟨3, by decide⟩⟩, ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨0, ⟨0, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩, ⟨4, ⟨4, by decide⟩⟩]
  exact ⟨18738424009020744896020528, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_14 : HasSeed (seedSizes 1 2 5 0 4) := by
  let push : Fin 12 → Slots (seedSizes 1 2 5 0 4) := ![
    ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩, ⟨0, ⟨0, by decide⟩⟩, ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨2, ⟨3, by decide⟩⟩, ⟨2, ⟨4, by decide⟩⟩]
  exact ⟨18742925023579729721098256, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_15 : HasSeed (seedSizes 1 4 0 5 2) := by
  let push : Fin 12 → Slots (seedSizes 1 4 0 5 2) := ![
    ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨1, ⟨2, by decide⟩⟩, ⟨1, ⟨3, by decide⟩⟩, ⟨0, ⟨0, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨3, ⟨0, by decide⟩⟩, ⟨3, ⟨1, by decide⟩⟩, ⟨3, ⟨2, by decide⟩⟩, ⟨3, ⟨3, by decide⟩⟩, ⟨3, ⟨4, by decide⟩⟩]
  exact ⟨18742925023579729721098256, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_16 : HasSeed (seedSizes 2 0 5 0 5) := by
  let push : Fin 12 → Slots (seedSizes 2 0 5 0 5) := ![
    ⟨0, ⟨0, by decide⟩⟩, ⟨0, ⟨1, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩, ⟨4, ⟨4, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨2, ⟨3, by decide⟩⟩, ⟨2, ⟨4, by decide⟩⟩]
  exact ⟨508028, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_17 : HasSeed (seedSizes 2 1 4 0 5) := by
  let push : Fin 12 → Slots (seedSizes 2 1 4 0 5) := ![
    ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨2, ⟨3, by decide⟩⟩, ⟨1, ⟨0, by decide⟩⟩, ⟨0, ⟨0, by decide⟩⟩, ⟨0, ⟨1, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩, ⟨4, ⟨4, by decide⟩⟩]
  exact ⟨18742925023579729721098256, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_18 : HasSeed (seedSizes 2 1 5 0 4) := by
  let push : Fin 12 → Slots (seedSizes 2 1 5 0 4) := ![
    ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩, ⟨0, ⟨0, by decide⟩⟩, ⟨0, ⟨1, by decide⟩⟩, ⟨1, ⟨0, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨2, ⟨3, by decide⟩⟩, ⟨2, ⟨4, by decide⟩⟩]
  exact ⟨18738424009020744896020528, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_19 : HasSeed (seedSizes 2 4 0 5 1) := by
  let push : Fin 12 → Slots (seedSizes 2 4 0 5 1) := ![
    ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨1, ⟨2, by decide⟩⟩, ⟨1, ⟨3, by decide⟩⟩, ⟨0, ⟨0, by decide⟩⟩, ⟨0, ⟨1, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨3, ⟨0, by decide⟩⟩, ⟨3, ⟨1, by decide⟩⟩, ⟨3, ⟨2, by decide⟩⟩, ⟨3, ⟨3, by decide⟩⟩, ⟨3, ⟨4, by decide⟩⟩]
  exact ⟨18738424009020744896020528, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_20 : HasSeed (seedSizes 3 0 4 0 5) := by
  let push : Fin 12 → Slots (seedSizes 3 0 4 0 5) := ![
    ⟨0, ⟨0, by decide⟩⟩, ⟨0, ⟨1, by decide⟩⟩, ⟨0, ⟨2, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩, ⟨4, ⟨4, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨2, ⟨3, by decide⟩⟩]
  exact ⟨4161765624, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_21 : HasSeed (seedSizes 3 0 5 0 4) := by
  let push : Fin 12 → Slots (seedSizes 3 0 5 0 4) := ![
    ⟨0, ⟨0, by decide⟩⟩, ⟨0, ⟨1, by decide⟩⟩, ⟨0, ⟨2, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨2, ⟨3, by decide⟩⟩, ⟨2, ⟨4, by decide⟩⟩]
  exact ⟨2013757560, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_22 : HasSeed (seedSizes 3 4 0 5 0) := by
  let push : Fin 12 → Slots (seedSizes 3 4 0 5 0) := ![
    ⟨0, ⟨0, by decide⟩⟩, ⟨0, ⟨1, by decide⟩⟩, ⟨0, ⟨2, by decide⟩⟩, ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨1, ⟨2, by decide⟩⟩, ⟨1, ⟨3, by decide⟩⟩, ⟨3, ⟨0, by decide⟩⟩, ⟨3, ⟨1, by decide⟩⟩, ⟨3, ⟨2, by decide⟩⟩, ⟨3, ⟨3, by decide⟩⟩, ⟨3, ⟨4, by decide⟩⟩]
  exact ⟨2013757560, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_23 : HasSeed (seedSizes 4 0 3 5 0) := by
  let push : Fin 12 → Slots (seedSizes 4 0 3 5 0) := ![
    ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨3, ⟨0, by decide⟩⟩, ⟨3, ⟨1, by decide⟩⟩, ⟨3, ⟨2, by decide⟩⟩, ⟨3, ⟨3, by decide⟩⟩, ⟨3, ⟨4, by decide⟩⟩, ⟨0, ⟨0, by decide⟩⟩, ⟨0, ⟨1, by decide⟩⟩, ⟨0, ⟨2, by decide⟩⟩, ⟨0, ⟨3, by decide⟩⟩]
  exact ⟨4161765624, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_24 : HasSeed (seedSizes 4 0 4 0 4) := by
  let push : Fin 12 → Slots (seedSizes 4 0 4 0 4) := ![
    ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨2, ⟨3, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨4, ⟨3, by decide⟩⟩, ⟨0, ⟨0, by decide⟩⟩, ⟨0, ⟨1, by decide⟩⟩, ⟨0, ⟨2, by decide⟩⟩, ⟨0, ⟨3, by decide⟩⟩]
  exact ⟨74294540672716477532429352960, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_25 : HasSeed (seedSizes 4 0 4 4 0) := by
  let push : Fin 12 → Slots (seedSizes 4 0 4 4 0) := ![
    ⟨0, ⟨0, by decide⟩⟩, ⟨0, ⟨1, by decide⟩⟩, ⟨0, ⟨2, by decide⟩⟩, ⟨0, ⟨3, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨2, ⟨3, by decide⟩⟩, ⟨3, ⟨0, by decide⟩⟩, ⟨3, ⟨1, by decide⟩⟩, ⟨3, ⟨2, by decide⟩⟩, ⟨3, ⟨3, by decide⟩⟩]
  exact ⟨74294540672716477532429352960, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_26 : HasSeed (seedSizes 4 0 5 0 3) := by
  let push : Fin 12 → Slots (seedSizes 4 0 5 0 3) := ![
    ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨4, ⟨2, by decide⟩⟩, ⟨0, ⟨0, by decide⟩⟩, ⟨0, ⟨1, by decide⟩⟩, ⟨0, ⟨2, by decide⟩⟩, ⟨0, ⟨3, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨2, ⟨3, by decide⟩⟩, ⟨2, ⟨4, by decide⟩⟩]
  exact ⟨2013757560, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_27 : HasSeed (seedSizes 4 0 5 1 2) := by
  let push : Fin 12 → Slots (seedSizes 4 0 5 1 2) := ![
    ⟨0, ⟨0, by decide⟩⟩, ⟨0, ⟨1, by decide⟩⟩, ⟨0, ⟨2, by decide⟩⟩, ⟨0, ⟨3, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨4, ⟨1, by decide⟩⟩, ⟨3, ⟨0, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨2, ⟨3, by decide⟩⟩, ⟨2, ⟨4, by decide⟩⟩]
  exact ⟨18738424009020744896020528, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_28 : HasSeed (seedSizes 4 0 5 2 1) := by
  let push : Fin 12 → Slots (seedSizes 4 0 5 2 1) := ![
    ⟨0, ⟨0, by decide⟩⟩, ⟨0, ⟨1, by decide⟩⟩, ⟨0, ⟨2, by decide⟩⟩, ⟨0, ⟨3, by decide⟩⟩, ⟨4, ⟨0, by decide⟩⟩, ⟨3, ⟨0, by decide⟩⟩, ⟨3, ⟨1, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨2, ⟨3, by decide⟩⟩, ⟨2, ⟨4, by decide⟩⟩]
  exact ⟨18742925023579729721098256, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_29 : HasSeed (seedSizes 4 0 5 3 0) := by
  let push : Fin 12 → Slots (seedSizes 4 0 5 3 0) := ![
    ⟨3, ⟨0, by decide⟩⟩, ⟨3, ⟨1, by decide⟩⟩, ⟨3, ⟨2, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨2, ⟨2, by decide⟩⟩, ⟨2, ⟨3, by decide⟩⟩, ⟨2, ⟨4, by decide⟩⟩, ⟨0, ⟨0, by decide⟩⟩, ⟨0, ⟨1, by decide⟩⟩, ⟨0, ⟨2, by decide⟩⟩, ⟨0, ⟨3, by decide⟩⟩]
  exact ⟨4161765624, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_30 : HasSeed (seedSizes 4 1 2 5 0) := by
  let push : Fin 12 → Slots (seedSizes 4 1 2 5 0) := ![
    ⟨0, ⟨0, by decide⟩⟩, ⟨0, ⟨1, by decide⟩⟩, ⟨0, ⟨2, by decide⟩⟩, ⟨0, ⟨3, by decide⟩⟩, ⟨1, ⟨0, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨2, ⟨1, by decide⟩⟩, ⟨3, ⟨0, by decide⟩⟩, ⟨3, ⟨1, by decide⟩⟩, ⟨3, ⟨2, by decide⟩⟩, ⟨3, ⟨3, by decide⟩⟩, ⟨3, ⟨4, by decide⟩⟩]
  exact ⟨18742925023579729721098256, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_31 : HasSeed (seedSizes 4 2 1 5 0) := by
  let push : Fin 12 → Slots (seedSizes 4 2 1 5 0) := ![
    ⟨0, ⟨0, by decide⟩⟩, ⟨0, ⟨1, by decide⟩⟩, ⟨0, ⟨2, by decide⟩⟩, ⟨0, ⟨3, by decide⟩⟩, ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨2, ⟨0, by decide⟩⟩, ⟨3, ⟨0, by decide⟩⟩, ⟨3, ⟨1, by decide⟩⟩, ⟨3, ⟨2, by decide⟩⟩, ⟨3, ⟨3, by decide⟩⟩, ⟨3, ⟨4, by decide⟩⟩]
  exact ⟨18738424009020744896020528, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_32 : HasSeed (seedSizes 4 3 0 5 0) := by
  let push : Fin 12 → Slots (seedSizes 4 3 0 5 0) := ![
    ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨1, ⟨2, by decide⟩⟩, ⟨0, ⟨0, by decide⟩⟩, ⟨0, ⟨1, by decide⟩⟩, ⟨0, ⟨2, by decide⟩⟩, ⟨0, ⟨3, by decide⟩⟩, ⟨3, ⟨0, by decide⟩⟩, ⟨3, ⟨1, by decide⟩⟩, ⟨3, ⟨2, by decide⟩⟩, ⟨3, ⟨3, by decide⟩⟩, ⟨3, ⟨4, by decide⟩⟩]
  exact ⟨2013757560, by decide, ⟨push, by decide⟩, by decide⟩

set_option maxRecDepth 10000 in
private theorem profile_33 : HasSeed (seedSizes 4 4 0 4 0) := by
  let push : Fin 12 → Slots (seedSizes 4 4 0 4 0) := ![
    ⟨3, ⟨0, by decide⟩⟩, ⟨3, ⟨1, by decide⟩⟩, ⟨3, ⟨2, by decide⟩⟩, ⟨3, ⟨3, by decide⟩⟩, ⟨0, ⟨0, by decide⟩⟩, ⟨0, ⟨1, by decide⟩⟩, ⟨0, ⟨2, by decide⟩⟩, ⟨0, ⟨3, by decide⟩⟩, ⟨1, ⟨0, by decide⟩⟩, ⟨1, ⟨1, by decide⟩⟩, ⟨1, ⟨2, by decide⟩⟩, ⟨1, ⟨3, by decide⟩⟩]
  exact ⟨74294540672716477532429352960, by decide, ⟨push, by decide⟩, by decide⟩

private theorem profile_has_seed (k : Fin 5 → ℕ)
    (cap : ∀ i, k i ≤ seedSizes 4 4 5 5 5 i)
    (total : ∑ i, k i = 12) (edge : ∑ i, k i * k (classNext i) ≤ 16) : HasSeed k := by
  let a : Fin 5 := ⟨k 0, Nat.lt_succ_of_le (cap 0)⟩
  let b : Fin 5 := ⟨k 1, Nat.lt_succ_of_le (cap 1)⟩
  let c : Fin 6 := ⟨k 2, Nat.lt_succ_of_le (cap 2)⟩
  let d : Fin 6 := ⟨k 3, Nat.lt_succ_of_le (cap 3)⟩
  let e : Fin 6 := ⟨k 4, Nat.lt_succ_of_le (cap 4)⟩
  have members := count_cases a b c d e
  have ht : a.val+b.val+c.val+d.val+e.val = 12 := by
    simpa [a,b,c,d,e, Fin.sum_univ_succ, add_assoc] using total
  have he : a.val*b.val+b.val*c.val+c.val*d.val+d.val*e.val+e.val*a.val ≤ 16 := by
    simpa [a,b,c,d,e, Fin.sum_univ_succ, classNext, add_assoc] using edge
  have ks : seedSizes a.val b.val c.val d.val e.val = k := by
    funext i
    fin_cases i <;> rfl
  have hm := ks ▸ members ht he
  simp only [sparseProfiles, List.mem_cons, List.not_mem_nil, or_false] at hm
  rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact profile_0
  · exact profile_1
  · exact profile_2
  · exact profile_3
  · exact profile_4
  · exact profile_5
  · exact profile_6
  · exact profile_7
  · exact profile_8
  · exact profile_9
  · exact profile_10
  · exact profile_11
  · exact profile_12
  · exact profile_13
  · exact profile_14
  · exact profile_15
  · exact profile_16
  · exact profile_17
  · exact profile_18
  · exact profile_19
  · exact profile_20
  · exact profile_21
  · exact profile_22
  · exact profile_23
  · exact profile_24
  · exact profile_25
  · exact profile_26
  · exact profile_27
  · exact profile_28
  · exact profile_29
  · exact profile_30
  · exact profile_31
  · exact profile_32
  · exact profile_33

theorem _root_.E1182Cover.from_first_host_twelve (D : SimpleGraph (Fin 12)) (edge : D.edgeSet.ncard = 16)
    (f : Fin 12 ↪ Fin 23)
    (copy : ∀ i j, (codeGraph 23 40985474950844763926564131426557755203912057542345515927787833703577696920095796140223645013612874172055202285572651784863984).Adj (f i) (f j) → D.Adj i j) :
    ∃ m ∈ [508028,511874,2013757560,18738424009021844676149310,4161765624,18738424009020744896020528,74294540672716477532429352960,18742925023579729721098256], codeGraph 12 m ⊑ D := by
  obtain ⟨k,u,cap,total,bound,adj⟩ := first_host_slots D f copy
  obtain ⟨m,hm,p,hp⟩ := profile_has_seed k cap total (edge ▸ bound)
  exact ⟨m, hm, ⟨⟨⟨u ∘ p, fun h => adj _ _ (hp _ _ h)⟩, u.injective.comp p.injective⟩⟩⟩

#print axioms E1182Cover.from_first_host_twelve

end E1182Cover.Twelve
