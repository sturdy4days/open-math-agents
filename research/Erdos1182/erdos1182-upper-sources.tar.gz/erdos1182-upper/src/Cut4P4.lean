import Descent
import ValidHost1
namespace E1182ElevenBlock
theorem leaf4_2_4 : failed host1 pat4 (atPath host1 pat4 [4,2]) = true := by
  decide +kernel

theorem leaf4_2_5 : failed host1 pat4 (atPath host1 pat4 [5,2]) = true := by
  decide +kernel

theorem leaf4_2_7 : failed host1 pat4 (atPath host1 pat4 [7,2]) = true := by
  decide +kernel

theorem leaf4_2_8 : failed host1 pat4 (atPath host1 pat4 [8,2]) = true := by
  decide +kernel

theorem leaf4_2_9 : failed host1 pat4 (atPath host1 pat4 [9,2]) = true := by
  decide +kernel

theorem leaf4_2_11 : failed host1 pat4 (atPath host1 pat4 [11,2]) = true := by
  decide +kernel

theorem leaf4_2_12 : failed host1 pat4 (atPath host1 pat4 [12,2]) = true := by
  decide +kernel

theorem leaf4_2_14 : failed host1 pat4 (atPath host1 pat4 [14,2]) = true := by
  decide +kernel

end E1182ElevenBlock
