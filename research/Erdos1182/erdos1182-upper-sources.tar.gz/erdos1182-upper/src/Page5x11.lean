import Intro5
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice5x70 : ((leaves5.drop 70).take 7).all test5=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice5x77 : ((leaves5.drop 77).take 2).all test5=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice5x79 : ((leaves5.drop 79).take 6).all test5=true := by decide +kernel
end E1182TwelveBlock.Word32
