import Intro3
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice3x13 : ((leaves3.drop 13).take 1).all test3=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice3x14 : ((leaves3.drop 14).take 3).all test3=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice3x17 : ((leaves3.drop 17).take 6).all test3=true := by decide +kernel
end E1182TwelveBlock.Word32
