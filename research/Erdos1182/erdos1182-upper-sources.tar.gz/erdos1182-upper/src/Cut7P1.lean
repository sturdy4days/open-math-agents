import Descent
import ValidHost3
namespace E1182ElevenBlock
theorem leaf7_0_5 : failed host3 pat7 (atPath host3 pat7 [5,0]) = true := by
  decide +kernel

theorem leaf7_0_6 : failed host3 pat7 (atPath host3 pat7 [6,0]) = true := by
  decide +kernel

theorem leaf7_0_7 : failed host3 pat7 (atPath host3 pat7 [7,0]) = true := by
  decide +kernel

theorem leaf7_0_9 : failed host3 pat7 (atPath host3 pat7 [9,0]) = true := by
  decide +kernel

theorem leaf7_0_10 : failed host3 pat7 (atPath host3 pat7 [10,0]) = true := by
  decide +kernel

theorem leaf7_0_12 : failed host3 pat7 (atPath host3 pat7 [12,0]) = true := by
  decide +kernel

theorem leaf7_0_14 : failed host3 pat7 (atPath host3 pat7 [14,0]) = true := by
  decide +kernel

theorem leaf7_0_15 : failed host3 pat7 (atPath host3 pat7 [15,0]) = true := by
  decide +kernel

theorem leaf7_0_16 : failed host3 pat7 (atPath host3 pat7 [16,0]) = true := by
  decide +kernel

end E1182ElevenBlock
