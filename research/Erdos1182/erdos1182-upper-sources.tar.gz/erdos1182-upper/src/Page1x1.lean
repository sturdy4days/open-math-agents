import Intro1
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice1x5 : ((leaves1.drop 5).take 1).all test1=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice1x6 : ((leaves1.drop 6).take 1).all test1=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice1x7 : ((leaves1.drop 7).take 1).all test1=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice1x8 : ((leaves1.drop 8).take 1).all test1=true := by decide +kernel
end E1182TwelveBlock.Word32
