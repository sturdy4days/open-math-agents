import FrontierClose
import Page9x0
import Page9x1
import Page9x2
import Page9x3
import Page9x4
import Page9x5
import Page9x6
import Page9x7
import Page9x8
import Page9x9
namespace E1182TwelveBlock.Word32
private theorem appendParts9 (offset width : Nat)
    (head : ((leaves9.drop offset).take width).all test9 = true)
    (tail : (leaves9.drop (offset+width)).all test9 = true) :
    (leaves9.drop offset).all test9 = true :=
  prepend_chunk (xs := leaves9) (f := test9) (offset := offset) (width := width) head tail

set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem miss9 : rejects host6 pat9 = false :=
  closeFrontier host6 pat9 p9E p9R h6J h6B h6A h6I h6U h6T
    okH6 okS9 leaves9 branches9
    (appendParts9 0 2 slice9x0 (appendParts9 2 6 slice9x2 (appendParts9 8 7 slice9x8 (appendParts9 15 11 slice9x15 (appendParts9 26 2 slice9x26 (appendParts9 28 4 slice9x28 (appendParts9 32 9 slice9x32 (appendParts9 41 3 slice9x41 (appendParts9 44 10 slice9x44 (appendParts9 54 3 slice9x54 (appendParts9 57 10 slice9x57 (appendParts9 67 2 slice9x67 (appendParts9 69 5 slice9x69 (appendParts9 74 7 slice9x74 (appendParts9 81 3 slice9x81 (appendParts9 84 11 slice9x84 (appendParts9 95 4 slice9x95 (appendParts9 99 9 slice9x99 (appendParts9 108 2 slice9x108 (appendParts9 110 5 slice9x110 (appendParts9 115 8 slice9x115 (appendParts9 123 3 slice9x123 (appendParts9 126 10 slice9x126 (appendParts9 136 2 slice9x136 (appendParts9 138 7 slice9x138 (appendParts9 145 4 slice9x145 (by decide +kernel))))))))))))))))))))))))))) (by decide +kernel)
end E1182TwelveBlock.Word32
#print axioms E1182TwelveBlock.Word32.miss9
namespace E1182TwelveBlock
open SimpleGraph E1182Cover
set_option maxHeartbeats 0 in
theorem blocked9 : ¬ (codeGraph 12 pat9.mask) ⊑ (triGraph 23 host6.original)ᶜ := by
  apply null_of_test host6 pat9 hostValid6 (by decide +kernel)
    (twins_from_types pat9 0x1011000000000000202000000013602 (by decide +kernel)) (by decide +kernel) (by decide +kernel)
  exact Word32.miss9
end E1182TwelveBlock
#print axioms E1182TwelveBlock.blocked9
