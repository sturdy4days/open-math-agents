import Block0
import Block1
import Block2
import Block3
import Block4
import Block5
import Block6
import Block7
import Block8
import Block9
import Block10
import Block11
import Block12
import Block13
import Block14
import Block15
import Block16
import Block17
import Block18
import Block19
import Block20
import Block21
import Block22
import Block23
import Block24
import Block25
import Block26
import Block27
import Block28
import Block29
import Block30
import Block31
import Block32
import Block33
import Block34
import Block35
import Block36
import Block37
import Block38
import Block39
import Block40
import Block41
import Block42
import Block43
import Block44
import Block45
import Block46
import Block47
import Block48
import Block49
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem selected_blocked (i : Fin 50) :
    ¬ (codeGraph 11 ((patterns[i.val]?).getD pat0).mask) ⊑
      (triGraph 21 (selectedMasks[i.val]!))ᶜ := by
  fin_cases i
  · exact blocked0
  · exact blocked1
  · exact blocked2
  · exact blocked3
  · exact blocked4
  · exact blocked5
  · exact blocked6
  · exact blocked7
  · exact blocked8
  · exact blocked9
  · exact blocked10
  · exact blocked11
  · exact blocked12
  · exact blocked13
  · exact blocked14
  · exact blocked15
  · exact blocked16
  · exact blocked17
  · exact blocked18
  · exact blocked19
  · exact blocked20
  · exact blocked21
  · exact blocked22
  · exact blocked23
  · exact blocked24
  · exact blocked25
  · exact blocked26
  · exact blocked27
  · exact blocked28
  · exact blocked29
  · exact blocked30
  · exact blocked31
  · exact blocked32
  · exact blocked33
  · exact blocked34
  · exact blocked35
  · exact blocked36
  · exact blocked37
  · exact blocked38
  · exact blocked39
  · exact blocked40
  · exact blocked41
  · exact blocked42
  · exact blocked43
  · exact blocked44
  · exact blocked45
  · exact blocked46
  · exact blocked47
  · exact blocked48
  · exact blocked49
end E1182ElevenBlock
#print axioms E1182ElevenBlock.selected_blocked
