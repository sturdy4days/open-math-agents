import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf22_0_10 : failed host0 pat22 (atPath host0 pat22 [10,0]) = true := by
  decide +kernel

theorem leaf22_0_11 : failed host0 pat22 (atPath host0 pat22 [11,0]) = true := by
  decide +kernel

theorem leaf22_0_12 : failed host0 pat22 (atPath host0 pat22 [12,0]) = true := by
  decide +kernel

end E1182ElevenBlock
