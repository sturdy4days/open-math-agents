import Intro10
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice10x5 : ((leaves10.drop 5).take 1).all test10=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice10x6 : ((leaves10.drop 6).take 1).all test10=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice10x7 : ((leaves10.drop 7).take 1).all test10=true := by decide +kernel
end E1182TwelveBlock.Word32
