import ClassStructure
import VerifiedRows
namespace E1182Eleven
open SimpleGraph E1182Cover E1182Bits
theorem classify {D : SimpleGraph (Fin 11)} (hD : D.edgeSet.ncard=13)
    (start : ∃ m ∈ [122940, 234995768, 71516036182736633856, 71481696373084028944, 503562360, 71481696510590124062, 71481696510556553240], codeGraph 11 m ⊑ D) :
    ∃ i : Fin 2297, Nonempty (codeGraph 11 (field l13 121 i.val) ≃g D) :=
  classify_given c8 c9 c10 c11 c12 hD start
end E1182Eleven
#print axioms E1182Eleven.classify
