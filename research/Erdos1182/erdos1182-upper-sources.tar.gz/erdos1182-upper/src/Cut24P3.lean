import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf24_0_7_3 : failed host0 pat24 (atPath host0 pat24 [3,7,0]) = true := by
  decide +kernel

theorem leaf24_0_7_4 : failed host0 pat24 (atPath host0 pat24 [4,7,0]) = true := by
  decide +kernel

theorem leaf24_0_7_8 : failed host0 pat24 (atPath host0 pat24 [8,7,0]) = true := by
  decide +kernel

theorem leaf24_0_7_10 : failed host0 pat24 (atPath host0 pat24 [10,7,0]) = true := by
  decide +kernel

theorem leaf24_0_7_11 : failed host0 pat24 (atPath host0 pat24 [11,7,0]) = true := by
  decide +kernel

theorem leaf24_0_7_14 : failed host0 pat24 (atPath host0 pat24 [14,7,0]) = true := by
  decide +kernel

theorem leaf24_0_7_17 : failed host0 pat24 (atPath host0 pat24 [17,7,0]) = true := by
  decide +kernel

theorem leaf24_0_8_1 : failed host0 pat24 (atPath host0 pat24 [1,8,0]) = true := by
  decide +kernel

end E1182ElevenBlock
