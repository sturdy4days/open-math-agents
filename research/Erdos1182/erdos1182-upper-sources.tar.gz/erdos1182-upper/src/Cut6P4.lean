import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf6_0_7_9 : failed host0 pat6 (atPath host0 pat6 [9,7,0]) = true := by
  decide +kernel

theorem leaf6_0_7_10 : failed host0 pat6 (atPath host0 pat6 [10,7,0]) = true := by
  decide +kernel

theorem leaf6_0_7_11 : failed host0 pat6 (atPath host0 pat6 [11,7,0]) = true := by
  decide +kernel

theorem leaf6_0_7_12 : failed host0 pat6 (atPath host0 pat6 [12,7,0]) = true := by
  decide +kernel

theorem leaf6_0_7_13 : failed host0 pat6 (atPath host0 pat6 [13,7,0]) = true := by
  decide +kernel

theorem leaf6_0_7_14 : failed host0 pat6 (atPath host0 pat6 [14,7,0]) = true := by
  decide +kernel

theorem leaf6_0_7_17 : failed host0 pat6 (atPath host0 pat6 [17,7,0]) = true := by
  decide +kernel

theorem leaf6_0_7_18 : failed host0 pat6 (atPath host0 pat6 [18,7,0]) = true := by
  decide +kernel

end E1182ElevenBlock
