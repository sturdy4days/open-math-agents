import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf24_0_8_4 : failed host0 pat24 (atPath host0 pat24 [4,8,0]) = true := by
  decide +kernel

theorem leaf24_0_8_7 : failed host0 pat24 (atPath host0 pat24 [7,8,0]) = true := by
  decide +kernel

theorem leaf24_0_8_9 : failed host0 pat24 (atPath host0 pat24 [9,8,0]) = true := by
  decide +kernel

theorem leaf24_0_8_11 : failed host0 pat24 (atPath host0 pat24 [11,8,0]) = true := by
  decide +kernel

theorem leaf24_0_8_12 : failed host0 pat24 (atPath host0 pat24 [12,8,0]) = true := by
  decide +kernel

theorem leaf24_0_8_17 : failed host0 pat24 (atPath host0 pat24 [17,8,0]) = true := by
  decide +kernel

theorem leaf24_0_9 : failed host0 pat24 (atPath host0 pat24 [9,0]) = true := by
  decide +kernel

end E1182ElevenBlock
