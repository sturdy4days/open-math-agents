import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf45_0_3_14 : failed host0 pat45 (atPath host0 pat45 [14,3,0]) = true := by
  decide +kernel

theorem leaf45_0_3_17 : failed host0 pat45 (atPath host0 pat45 [17,3,0]) = true := by
  decide +kernel

theorem leaf45_0_3_20 : failed host0 pat45 (atPath host0 pat45 [20,3,0]) = true := by
  decide +kernel

theorem leaf45_0_4_7 : failed host0 pat45 (atPath host0 pat45 [7,4,0]) = true := by
  decide +kernel

theorem leaf45_0_4_8 : failed host0 pat45 (atPath host0 pat45 [8,4,0]) = true := by
  decide +kernel

theorem leaf45_0_4_11 : failed host0 pat45 (atPath host0 pat45 [11,4,0]) = true := by
  decide +kernel

theorem leaf45_0_4_12 : failed host0 pat45 (atPath host0 pat45 [12,4,0]) = true := by
  decide +kernel

theorem leaf45_0_4_13 : failed host0 pat45 (atPath host0 pat45 [13,4,0]) = true := by
  decide +kernel

theorem leaf45_0_4_14 : failed host0 pat45 (atPath host0 pat45 [14,4,0]) = true := by
  decide +kernel

theorem leaf45_0_4_17 : failed host0 pat45 (atPath host0 pat45 [17,4,0]) = true := by
  decide +kernel

end E1182ElevenBlock
