import Intro13
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x43 : ((leaves13.drop 43).take 2).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x45 : ((leaves13.drop 45).take 2).all test13=true := by decide +kernel
end E1182TwelveBlock.Word32
