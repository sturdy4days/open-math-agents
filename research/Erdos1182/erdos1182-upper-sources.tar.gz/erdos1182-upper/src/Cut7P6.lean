import Descent
import ValidHost3
namespace E1182ElevenBlock
theorem leaf7_18_1 : failed host3 pat7 (atPath host3 pat7 [1,18]) = true := by
  decide +kernel

theorem leaf7_18_2 : failed host3 pat7 (atPath host3 pat7 [2,18]) = true := by
  decide +kernel

theorem leaf7_18_3 : failed host3 pat7 (atPath host3 pat7 [3,18]) = true := by
  decide +kernel

end E1182ElevenBlock
