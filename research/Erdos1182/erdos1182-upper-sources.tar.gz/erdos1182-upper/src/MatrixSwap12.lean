import Exchange12
namespace E1182BitsTwelve

def partner (mask d k : Nat) :=
  if mask.testBit k then d+k else if d≤k ∧ mask.testBit (k-d) then k-d else k

def apart (mask d k : Nat) : Prop :=
  mask.testBit k = true → d ≤ k → mask.testBit (k-d) = false

instance (m d k : Nat) : Decidable (apart m d k) := by unfold apart; infer_instance

theorem exchange_at (x mask d k : Nat) (good : apart mask d k) :
    (exchange x mask d).testBit k = x.testBit (partner mask d k) := by
  rw [testBit_exchange x mask d k good]
  unfold partner
  by_cases lo : mask.testBit k = true
  · simp [lo]
  · by_cases hi : d≤k ∧ mask.testBit (k-d)=true <;> simp [lo,hi]

def addr (i j : Fin 12) := 12*i.val+j.val
def swapI (a b i : Fin 12) := if i=a then b else if i=b then a else i

def rowM (a : Fin 12) := 4095 <<< (12*a.val)
def colM (a : Fin 12) := 5445847423328601499764522166702896582657 <<< a.val

def swapFull (w : Nat) (a b : Fin 12) :=
  let d := b.val-a.val
  exchange (exchange w (colM a) d) (rowM a) (12*d)

def layout (a b i j : Fin 12) : Prop :=
  let d := b.val-a.val
  let k := addr i j
  let k' := addr (swapI a b i) j
  apart (rowM a) (12*d) k ∧ partner (rowM a) (12*d) k = k' ∧
    apart (colM a) d k' ∧ partner (colM a) d k' = addr (swapI a b i) (swapI a b j)

instance (a b i j : Fin 12) : Decidable (layout a b i j) := by unfold layout; infer_instance

theorem row_bit (a : Fin 12) (k : Nat) :
    (rowM a).testBit k = decide (12*a.val ≤ k ∧ k < 12*a.val+12) := by
  unfold rowM
  rw [Nat.testBit_shiftLeft, show 4095 = 2^12-1 by decide, Nat.testBit_two_pow_sub_one]
  rw [Bool.eq_iff_iff]
  simp only [Bool.and_eq_true, decide_eq_true_eq]
  omega

theorem col_zero : ∀ i : Fin 144,
    (5445847423328601499764522166702896582657 : Nat).testBit i.val = decide (i.val%12 = 0) := by
  decide +kernel

theorem col_bit (a : Fin 12) (k : Nat) (hk : k < 144) :
    (colM a).testBit k = decide (k % 12 = a.val) := by
  unfold colM
  rw [Nat.testBit_shiftLeft, col_zero ⟨k-a.val,by omega⟩]
  rw [Bool.eq_iff_iff]
  simp only [Bool.and_eq_true, decide_eq_true_eq]
  omega

theorem row_layout (a b i j : Fin 12) (h : a < b) :
    apart (rowM a) (12*(b.val-a.val)) (addr i j) ∧
      partner (rowM a) (12*(b.val-a.val)) (addr i j) = addr (swapI a b i) j := by
  unfold apart partner addr swapI
  simp only [row_bit, decide_eq_true_eq, decide_eq_false_iff_not, Fin.ext_iff]
  simp only [Fin.lt_def] at h
  have hh : 12*(b.val-a.val) = 12*b.val-12*a.val := Nat.mul_sub _ _ _
  rw [hh]
  constructor
  · omega
  · (repeat' split) <;> omega

theorem col_layout (a b i j : Fin 12) (h : a < b) :
    apart (colM a) (b.val-a.val) (addr i j) ∧
      partner (colM a) (b.val-a.val) (addr i j) = addr i (swapI a b j) := by
  unfold apart partner addr swapI
  rw [col_bit a (12*i.val+j.val) (by omega), col_bit a (12*i.val+j.val-(b.val-a.val)) (by omega)]
  simp only [ decide_eq_true_eq, decide_eq_false_iff_not, Fin.ext_iff]
  simp only [Fin.lt_def] at h
  constructor
  · omega
  · (repeat' split) <;> omega

theorem layout_ok (a b i j : Fin 12) (h : a<b) : layout a b i j := by
  have ⟨r,s⟩ := row_layout a b i j h
  exact ⟨r,s,col_layout a b (swapI a b i) j h⟩

theorem swapFull_at (w : Nat) {a b : Fin 12} (lt : a<b) (i j : Fin 12) :
    (swapFull w a b).testBit (addr i j) = w.testBit (addr (swapI a b i) (swapI a b j)) := by
  obtain ⟨hr,er,hc,ec⟩ := layout_ok a b i j lt
  rw [swapFull,exchange_at _ _ _ _ hr,er,exchange_at _ _ _ _ hc,ec]

end E1182BitsTwelve
#print axioms E1182BitsTwelve.swapFull_at
