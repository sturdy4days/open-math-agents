import TwinRule
import ValidHost0
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
set_option maxRecDepth 30000 in
set_option maxHeartbeats 7000000 in
theorem blocked2 : ¬ (codeGraph 11 pat2.mask) ⊑ (triGraph 21 host0.original)ᶜ := by
  apply null_of_test host0 pat2 hostValid0 (by decide +kernel) (twins_from_types pat2 82397371221795364664479073769506 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  decide +kernel
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked2
