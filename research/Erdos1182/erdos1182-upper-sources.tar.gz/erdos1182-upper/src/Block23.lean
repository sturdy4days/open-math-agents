import TwinRule
import ValidHost2
import WordCut23
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem blocked23 : ¬ (codeGraph 11 pat23.mask) ⊑ (triGraph 21 host2.original)ᶜ := by
  apply null_of_test host2 pat23 hostValid2 (by decide +kernel) (twins_from_types pat23 184030363009490330053592135715050 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact Word32.miss23
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked23
