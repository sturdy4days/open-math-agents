import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf22_0_7_10 : failed host0 pat22 (atPath host0 pat22 [10,7,0]) = true := by
  decide +kernel

theorem leaf22_0_7_11 : failed host0 pat22 (atPath host0 pat22 [11,7,0]) = true := by
  decide +kernel

theorem leaf22_0_7_14 : failed host0 pat22 (atPath host0 pat22 [14,7,0]) = true := by
  decide +kernel

theorem leaf22_0_7_17 : failed host0 pat22 (atPath host0 pat22 [17,7,0]) = true := by
  decide +kernel

theorem leaf22_0_7_18 : failed host0 pat22 (atPath host0 pat22 [18,7,0]) = true := by
  decide +kernel

theorem leaf22_0_7_20 : failed host0 pat22 (atPath host0 pat22 [20,7,0]) = true := by
  decide +kernel

theorem leaf22_0_8 : failed host0 pat22 (atPath host0 pat22 [8,0]) = true := by
  decide +kernel

theorem leaf22_0_9 : failed host0 pat22 (atPath host0 pat22 [9,0]) = true := by
  decide +kernel

end E1182ElevenBlock
