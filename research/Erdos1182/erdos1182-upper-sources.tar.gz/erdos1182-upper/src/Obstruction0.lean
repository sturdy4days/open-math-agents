import Page0x0
import Page0x1
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem miss0 : rejects host6 pat0=false := by
  apply null _ _ _ _ _ _ _ _ _ _ okH6 okS0
  apply certified_frontier perm0 apart0 start0 leaves0 branches0
  · exact (prepend_chunk slice0x0 (prepend_chunk slice0x2 (prepend_chunk slice0x4 (prepend_chunk slice0x6 (prepend_chunk slice0x8 (prepend_chunk slice0x10 (by decide +kernel)))))))
  · decide +kernel
end E1182TwelveBlock.Word32
#print axioms E1182TwelveBlock.Word32.miss0
namespace E1182TwelveBlock
open SimpleGraph E1182Cover
set_option maxHeartbeats 0 in
theorem blocked0 : ¬ (codeGraph 12 pat0.mask) ⊑ (triGraph 23 host6.original)ᶜ := by
  apply null_of_test host6 pat0 hostValid6 (by decide +kernel)
    (twins_from_types pat0 0x2000000000000043002 (by decide +kernel)) (by decide +kernel) (by decide +kernel)
  exact Word32.miss0
end E1182TwelveBlock
#print axioms E1182TwelveBlock.blocked0
