import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf35_0_10 : failed host0 pat35 (atPath host0 pat35 [10,0]) = true := by
  decide +kernel

theorem leaf35_0_11 : failed host0 pat35 (atPath host0 pat35 [11,0]) = true := by
  decide +kernel

theorem leaf35_0_12 : failed host0 pat35 (atPath host0 pat35 [12,0]) = true := by
  decide +kernel

end E1182ElevenBlock
