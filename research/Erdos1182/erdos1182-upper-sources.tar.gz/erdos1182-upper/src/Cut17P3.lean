import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf17_0_10 : failed host0 pat17 (atPath host0 pat17 [10,0]) = true := by
  decide +kernel

theorem leaf17_0_11 : failed host0 pat17 (atPath host0 pat17 [11,0]) = true := by
  decide +kernel

theorem leaf17_0_12 : failed host0 pat17 (atPath host0 pat17 [12,0]) = true := by
  decide +kernel

theorem leaf17_0_13 : failed host0 pat17 (atPath host0 pat17 [13,0]) = true := by
  decide +kernel

end E1182ElevenBlock
