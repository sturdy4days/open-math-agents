import Intro2
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x141 : ((leaves2.drop 141).take 4).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x145 : ((leaves2.drop 145).take 5).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x150 : ((leaves2.drop 150).take 1).all test2=true := by decide +kernel
end E1182TwelveBlock.Word32
