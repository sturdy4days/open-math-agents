import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf17_0_7_10 : failed host0 pat17 (atPath host0 pat17 [10,7,0]) = true := by
  decide +kernel

theorem leaf17_0_7_11 : failed host0 pat17 (atPath host0 pat17 [11,7,0]) = true := by
  decide +kernel

theorem leaf17_0_7_14 : failed host0 pat17 (atPath host0 pat17 [14,7,0]) = true := by
  decide +kernel

theorem leaf17_0_7_17 : failed host0 pat17 (atPath host0 pat17 [17,7,0]) = true := by
  decide +kernel

theorem leaf17_0_7_18 : failed host0 pat17 (atPath host0 pat17 [18,7,0]) = true := by
  decide +kernel

theorem leaf17_0_7_20 : failed host0 pat17 (atPath host0 pat17 [20,7,0]) = true := by
  decide +kernel

theorem leaf17_0_8 : failed host0 pat17 (atPath host0 pat17 [8,0]) = true := by
  decide +kernel

theorem leaf17_0_9 : failed host0 pat17 (atPath host0 pat17 [9,0]) = true := by
  decide +kernel

end E1182ElevenBlock
