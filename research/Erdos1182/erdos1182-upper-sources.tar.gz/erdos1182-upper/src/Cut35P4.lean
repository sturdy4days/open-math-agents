import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf35_0_13 : failed host0 pat35 (atPath host0 pat35 [13,0]) = true := by
  decide +kernel

theorem leaf35_0_14 : failed host0 pat35 (atPath host0 pat35 [14,0]) = true := by
  decide +kernel

theorem leaf35_0_17 : failed host0 pat35 (atPath host0 pat35 [17,0]) = true := by
  decide +kernel

end E1182ElevenBlock
