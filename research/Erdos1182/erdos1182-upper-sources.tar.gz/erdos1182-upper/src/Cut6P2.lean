import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf6_0_3_8 : failed host0 pat6 (atPath host0 pat6 [8,3,0]) = true := by
  decide +kernel

theorem leaf6_0_3_9 : failed host0 pat6 (atPath host0 pat6 [9,3,0]) = true := by
  decide +kernel

theorem leaf6_0_3_10 : failed host0 pat6 (atPath host0 pat6 [10,3,0]) = true := by
  decide +kernel

theorem leaf6_0_3_11 : failed host0 pat6 (atPath host0 pat6 [11,3,0]) = true := by
  decide +kernel

theorem leaf6_0_3_12 : failed host0 pat6 (atPath host0 pat6 [12,3,0]) = true := by
  decide +kernel

theorem leaf6_0_3_13 : failed host0 pat6 (atPath host0 pat6 [13,3,0]) = true := by
  decide +kernel

theorem leaf6_0_3_14 : failed host0 pat6 (atPath host0 pat6 [14,3,0]) = true := by
  decide +kernel

theorem leaf6_0_3_17 : failed host0 pat6 (atPath host0 pat6 [17,3,0]) = true := by
  decide +kernel

theorem leaf6_0_3_18 : failed host0 pat6 (atPath host0 pat6 [18,3,0]) = true := by
  decide +kernel

theorem leaf6_0_4_7 : failed host0 pat6 (atPath host0 pat6 [7,4,0]) = true := by
  decide +kernel

end E1182ElevenBlock
