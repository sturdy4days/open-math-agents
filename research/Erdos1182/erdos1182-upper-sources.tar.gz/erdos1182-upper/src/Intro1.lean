import HostChecks6
namespace E1182TwelveBlock.Word32
def p1E : Nat := spreadCells 0xffffffffff5eea1f40ea1f10f08f04f02ea1
def p1R : Nat := spreadCells 0xfff7ff3ffffffffffff7ffbffaffa7fa3fff
set_option maxHeartbeats 0 in
theorem okS1 : sourceWords host6 pat1 p1E p1R := by
  unfold sourceWords
  decide +kernel
abbrev perm1 := permit p1E p1R h6J h6B
abbrev apart1 := field h6A 384
abbrev start1 := initial pat1 h6I h6U h6T
def leaves1 : List (List Nat) := [[0],[1],[2],[5],[6],[9],[11],[12],[13],[14],[17]]
def branches1 : List (List Nat) := [[]]
abbrev test1 := fails perm1 apart1 start1
end E1182TwelveBlock.Word32
