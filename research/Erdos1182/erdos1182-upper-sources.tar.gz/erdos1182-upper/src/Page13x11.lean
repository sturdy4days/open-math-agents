import Intro13
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x61 : ((leaves13.drop 61).take 6).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x67 : ((leaves13.drop 67).take 2).all test13=true := by decide +kernel
end E1182TwelveBlock.Word32
