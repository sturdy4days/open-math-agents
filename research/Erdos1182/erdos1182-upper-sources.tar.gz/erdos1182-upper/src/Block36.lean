import TwinRule
import ValidHost3
import WordCut36
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem blocked36 : ¬ (codeGraph 11 pat36.mask) ⊑ (triGraph 21 host3.original)ᶜ := by
  apply null_of_test host3 pat36 hostValid3 (by decide +kernel) (twins_from_types pat36 158473438425510728040418730338147066 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact Word32.miss36
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked36
