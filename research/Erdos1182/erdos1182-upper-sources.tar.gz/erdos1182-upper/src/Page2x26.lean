import Intro2
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x192 : ((leaves2.drop 192).take 3).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x195 : ((leaves2.drop 195).take 5).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x200 : ((leaves2.drop 200).take 6).all test2=true := by decide +kernel
end E1182TwelveBlock.Word32
