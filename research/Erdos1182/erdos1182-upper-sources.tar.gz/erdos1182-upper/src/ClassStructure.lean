import StartCases
namespace E1182Eleven
open SimpleGraph E1182Cover E1182Bits
theorem classify_given
    (q8 : rows l8 l9 6 scripts r8 0 1)
    (q9 : rows l9 l10 28 scripts r9 0 6)
    (q10 : rows l10 l11 127 scripts r10 0 28)
    (q11 : rows l11 l12 549 scripts r11 0 127)
    (q12 : rows l12 l13 2297 scripts r12 0 549)
    {D : SimpleGraph (Fin 11)} (hD : D.edgeSet.ncard=13)
    (start : ∃ m ∈ [122940, 234995768, 71516036182736633856, 71481696373084028944, 503562360, 71481696510590124062, 71481696510556553240], codeGraph 11 m ⊑ D) :
    ∃ i : Fin 2297, Nonempty (codeGraph 11 (field l13 121 i.val) ≃g D) := by
  have a8 (s : reached D l8 1 8) : reached D l9 6 9 :=
    next_layer s (by omega) q8
  have a9 (s : reached D l9 6 9) : reached D l10 28 10 :=
    next_layer s (by omega) q9
  have a10 (s : reached D l10 28 10) : reached D l11 127 11 :=
    next_layer s (by omega) q10
  have a11 (s : reached D l11 127 11) : reached D l12 549 12 :=
    next_layer s (by omega) q11
  have a12 (s : reached D l12 549 12) : reached D l13 2297 13 :=
    next_layer s (by omega) q12
  obtain ⟨m,hm,sub⟩ := start
  have finish : reached D l13 2297 13 := by
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact (a12 (a11 (a10 (a9 (a8 (start_at (by decide) seed0 sub))))))
    · exact (a12 (a11 (a10 (a9 (start_at (by decide) seed1 sub)))))
    · exact (a12 (a11 (a10 (start_at (by decide) seed2 sub))))
    · exact (a12 (a11 (a10 (start_at (by decide) seed3 sub))))
    · exact (a12 (start_at (by decide) seed4 sub))
    · exact (start_at (by decide) seed5 sub)
    · exact (start_at (by decide) seed6 sub)
  obtain ⟨i,hi,_,sz,emb⟩ := finish
  exact ⟨⟨i,hi⟩,exact_copy emb (sz.trans hD.symm)⟩
end E1182Eleven
#print axioms E1182Eleven.classify_given
