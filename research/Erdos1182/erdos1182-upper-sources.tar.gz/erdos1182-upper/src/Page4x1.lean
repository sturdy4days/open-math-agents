import Intro4
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice4x3 : ((leaves4.drop 3).take 1).all test4=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice4x4 : ((leaves4.drop 4).take 2).all test4=true := by decide +kernel
end E1182TwelveBlock.Word32
