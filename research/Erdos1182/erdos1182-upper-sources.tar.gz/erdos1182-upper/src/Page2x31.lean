import Intro2
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x221 : ((leaves2.drop 221).take 1).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x222 : ((leaves2.drop 222).take 1).all test2=true := by decide +kernel
end E1182TwelveBlock.Word32
