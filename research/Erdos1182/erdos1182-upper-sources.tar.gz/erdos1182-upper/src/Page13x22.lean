import Intro13
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x125 : ((leaves13.drop 125).take 1).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x126 : ((leaves13.drop 126).take 1).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x127 : ((leaves13.drop 127).take 1).all test13=true := by decide +kernel
end E1182TwelveBlock.Word32
