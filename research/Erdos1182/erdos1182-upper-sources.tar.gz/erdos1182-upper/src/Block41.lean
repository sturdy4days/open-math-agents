import Cut41P0
import Cut41P1
import Cut41P2
import Cut41P3
import Cut41P4
import Cut41P5
import Descent
import Descent
import TwinRule
import ValidHost1
namespace E1182ElevenBlock
open SimpleGraph E1182Cover

private theorem leaf41_0_0 : failed host1 pat41 (atPath host1 pat41 [0,0]) = true := by
  apply failed_atPath _ _ _ [3,5,6,7,9,10,11,13] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf41_0_0_3
  · exact leaf41_0_0_5
  · exact leaf41_0_0_6
  · exact leaf41_0_0_7
  · exact leaf41_0_0_9
  · exact leaf41_0_0_10
  · exact leaf41_0_0_11
  · exact leaf41_0_0_13

private theorem leaf41_0 : failed host1 pat41 (atPath host1 pat41 [0]) = true := by
  apply failed_atPath _ _ _ [0,3,5,6,7,9,10,11,13] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf41_0_0
  · exact leaf41_0_3
  · exact leaf41_0_5
  · exact leaf41_0_6
  · exact leaf41_0_7
  · exact leaf41_0_9
  · exact leaf41_0_10
  · exact leaf41_0_11
  · exact leaf41_0_13

private theorem leaf41_2 : failed host1 pat41 (atPath host1 pat41 [2]) = true := by
  apply failed_atPath _ _ _ [1,4,5,7,8,9,11,12] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf41_2_1
  · exact leaf41_2_4
  · exact leaf41_2_5
  · exact leaf41_2_7
  · exact leaf41_2_8
  · exact leaf41_2_9
  · exact leaf41_2_11
  · exact leaf41_2_12

private theorem leaf41_3 : failed host1 pat41 (atPath host1 pat41 [3]) = true := by
  apply failed_atPath _ _ _ [0,4,5,6,8,9,10,13] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf41_3_0
  · exact leaf41_3_4
  · exact leaf41_3_5
  · exact leaf41_3_6
  · exact leaf41_3_8
  · exact leaf41_3_9
  · exact leaf41_3_10
  · exact leaf41_3_13

private theorem leaf41_7 : failed host1 pat41 (atPath host1 pat41 [7]) = true := by
  apply failed_atPath _ _ _ [0,1,2,4,9,10,11,13] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf41_7_0
  · exact leaf41_7_1
  · exact leaf41_7_2
  · exact leaf41_7_4
  · exact leaf41_7_9
  · exact leaf41_7_10
  · exact leaf41_7_11
  · exact leaf41_7_13

private theorem leaf41_root : failed host1 pat41 (atPath host1 pat41 []) = true := by
  apply failed_atPath _ _ _ [0,2,3,7] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl
  · exact leaf41_0
  · exact leaf41_2
  · exact leaf41_3
  · exact leaf41_7

theorem blocked41 : ¬ (codeGraph 11 pat41.mask) ⊑ (triGraph 21 host1.original)ᶜ := by
  apply null_of_test host1 pat41 hostValid1 (by decide +kernel) (twins_from_types pat41 215159286354756972763011607927666 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact rejects_of_failed_root _ _ leaf41_root
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked41
