import Intro11
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice11x30 : ((leaves11.drop 30).take 7).all test11=true := by decide +kernel
end E1182TwelveBlock.Word32
