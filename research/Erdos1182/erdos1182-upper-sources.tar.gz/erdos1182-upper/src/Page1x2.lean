import Intro1
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice1x9 : ((leaves1.drop 9).take 1).all test1=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice1x10 : ((leaves1.drop 10).take 1).all test1=true := by decide +kernel
end E1182TwelveBlock.Word32
