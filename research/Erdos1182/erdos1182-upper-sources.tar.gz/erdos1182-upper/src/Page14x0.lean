import Intro14
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice14x0 : ((leaves14.drop 0).take 1).all test14=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice14x1 : ((leaves14.drop 1).take 1).all test14=true := by decide +kernel
end E1182TwelveBlock.Word32
