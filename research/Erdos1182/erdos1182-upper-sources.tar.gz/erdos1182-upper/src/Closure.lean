import CodeGraph
import Mathlib.Data.Set.Card
open SimpleGraph
namespace E1182Cover

/-- Pull back to the source coordinates of a spanning copy. -/
theorem pullback_size {n : ℕ} (D : SimpleGraph (Fin n)) (b : Fin n ≃ Fin n) :
    (D.comap b).edgeSet.ncard = D.edgeSet.ncard := by
  exact Nat.card_congr (SimpleGraph.Iso.comap b D).mapEdgeSet

theorem strict_edge {n : ℕ} {A D : SimpleGraph (Fin n)} (sub : A ⊑ D)
    (hsize : A.edgeSet.ncard < D.edgeSet.ncard) :
    ∃ (f : A.Copy D) (i j : Fin n), i < j ∧ ¬ A.Adj i j ∧ D.Adj (f i) (f j) := by
  obtain ⟨f⟩ := sub
  let b : Fin n ≃ Fin n := Equiv.ofBijective f f.injective.bijective_of_finite
  have need : ∃ i j, ¬ A.Adj i j ∧ D.Adj (f i) (f j) := by
    by_contra! h
    have eq : A = D.comap b := by
      ext i j
      exact ⟨f.toHom.map_rel',fun hd => Classical.byContradiction (fun no => h i j no hd)⟩
    have := pullback_size D b
    rw [←eq] at this
    omega
  obtain ⟨i,j,hn,hy⟩ := need
  by_cases lt : i < j
  · exact ⟨f,i,j,lt,hn,hy⟩
  · exact ⟨f,j,i,lt_of_le_of_ne (le_of_not_gt lt) (fun h => hy.ne (congrArg f h.symm)),
      fun h => hn h.symm,hy.symm⟩

def pos10 (w : ℕ) (i : Fin 10) : Fin 10 :=
  ⟨((w >>> (4*i.val)) % 16) % 10,Nat.mod_lt _ (by decide)⟩

def rowEntry (r : ℕ) (i j : Fin 10) : ℕ := (r >>> (48*(10*i.val+j.val))) % 2^48

def validEntry (s : ℕ) (targets : List ℕ) (r : ℕ) (i j : Fin 10) : Prop :=
  let w := rowEntry r i j
  let k := w >>> 40
  let p := pos10 w
  k < targets.length ∧ (∀ u v : Fin 10, p u = p v → u=v) ∧
    ∀ u v : Fin 10, (codeGraph 10 (targets[k]!)).Adj u v →
      (codeGraph 10 s).Adj (p u) (p v) ∨ (p u=i ∧ p v=j) ∨ (p u=j ∧ p v=i)

instance (s : ℕ) (targets : List ℕ) (r : ℕ) (i j : Fin 10) :
    Decidable (validEntry s targets r i j) := by unfold validEntry; infer_instance

def rowValid (s : ℕ) (targets : List ℕ) (r : ℕ) : Prop :=
  ∀ i j : Fin 10, i < j → ¬ (codeGraph 10 s).Adj i j → validEntry s targets r i j

instance (s : ℕ) (targets : List ℕ) (r : ℕ) : Decidable (rowValid s targets r) := by
  unfold rowValid; infer_instance

theorem advance {s r : ℕ} {targets : List ℕ} {D : SimpleGraph (Fin 10)}
    (hsub : codeGraph 10 s ⊑ D) (small : (codeGraph 10 s).edgeSet.ncard < D.edgeSet.ncard)
    (table : rowValid s targets r) : ∃ t ∈ targets, codeGraph 10 t ⊑ D := by
  obtain ⟨f,i,j,lt,no,yes⟩ := strict_edge hsub small
  obtain ⟨bound,inj,edges⟩ := table i j lt no
  let w := rowEntry r i j
  let k := w >>> 40
  let p := pos10 w
  have goodmem : targets[k]! ∈ targets := by
    rw [getElem!_pos targets k bound]
    exact List.getElem_mem _
  refine ⟨_,goodmem,⟨⟨⟨fun a => f (p a),?_⟩,f.injective.comp inj⟩⟩⟩
  intro u v huv
  rcases edges u v huv with hh | ⟨he,hf⟩ | ⟨he,hf⟩
  · exact f.toHom.map_rel' hh
  · change D.Adj (f (pos10 w u)) (f (pos10 w v))
    simpa only [show pos10 w u=i from he,show pos10 w v=j from hf] using yes
  · change D.Adj (f (pos10 w u)) (f (pos10 w v))
    simpa only [show pos10 w u=j from he,show pos10 w v=i from hf] using yes.symm

theorem exact_copy {n : ℕ} {A D : SimpleGraph (Fin n)} (sub : A ⊑ D)
    (size : A.edgeSet.ncard = D.edgeSet.ncard) : Nonempty (A ≃g D) := by
  obtain ⟨f⟩ := sub
  let b : Fin n ≃ Fin n := Equiv.ofBijective f f.injective.bijective_of_finite
  have le : A ≤ D.comap b := fun _ _ h => f.toHom.map_rel' h
  have sie := pullback_size D b
  have eq : A = D.comap b := by
    apply le_antisymm le
    by_contra hn
    have hlt : A < D.comap b := lt_of_le_not_ge le hn
    have := Set.ncard_lt_ncard (SimpleGraph.edgeSet_strict_mono hlt)
    omega
  exact ⟨eq ▸ SimpleGraph.Iso.comap b D⟩

end E1182Cover
#print axioms E1182Cover.advance
#print axioms E1182Cover.exact_copy
