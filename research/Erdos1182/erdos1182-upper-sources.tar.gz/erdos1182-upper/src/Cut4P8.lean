import Descent
import ValidHost1
namespace E1182ElevenBlock
theorem leaf4_7_1_10 : failed host1 pat4 (atPath host1 pat4 [10,1,7]) = true := by
  decide +kernel

theorem leaf4_7_1_11 : failed host1 pat4 (atPath host1 pat4 [11,1,7]) = true := by
  decide +kernel

theorem leaf4_7_1_12 : failed host1 pat4 (atPath host1 pat4 [12,1,7]) = true := by
  decide +kernel

theorem leaf4_7_1_13 : failed host1 pat4 (atPath host1 pat4 [13,1,7]) = true := by
  decide +kernel

theorem leaf4_7_2 : failed host1 pat4 (atPath host1 pat4 [2,7]) = true := by
  decide +kernel

theorem leaf4_7_4 : failed host1 pat4 (atPath host1 pat4 [4,7]) = true := by
  decide +kernel

theorem leaf4_7_9 : failed host1 pat4 (atPath host1 pat4 [9,7]) = true := by
  decide +kernel

theorem leaf4_7_10 : failed host1 pat4 (atPath host1 pat4 [10,7]) = true := by
  decide +kernel

theorem leaf4_7_11 : failed host1 pat4 (atPath host1 pat4 [11,7]) = true := by
  decide +kernel

theorem leaf4_7_12 : failed host1 pat4 (atPath host1 pat4 [12,7]) = true := by
  decide +kernel

end E1182ElevenBlock
