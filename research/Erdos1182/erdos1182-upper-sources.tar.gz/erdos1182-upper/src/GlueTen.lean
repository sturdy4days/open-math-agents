import FirstHost
import ClosureData
import Mathlib.Combinatorics.SimpleGraph.Clique
import Mathlib.Combinatorics.SimpleGraph.Connectivity.Connected
open SimpleGraph Finset
namespace E1182Cover

def extraMasks : List ℕ := [4479493756337828422381768076222663975448198329188301774237696156955172576037144452142741750559459805632,12815938511828812536218087847244909534200620914327746814503801336510447893155006986723115497757970,12815930363669365891600092140750539518217499177757377408917144300401324135455101653909173508030514]
def seedMask : ℕ := 58280177927389562003304118167894045837298871419233698940907216524622014388169689497720
def hostMasks : List ℕ := seedMask :: extraMasks

theorem host_triangle_free : ∀ m ∈ hostMasks, (codeGraph 19 m).CliqueFree 3 := by
  have raw : ∀ a : Fin hostMasks.length, ∀ i j k : Fin 19,
      (codeGraph 19 hostMasks[a.val]).Adj i j → (codeGraph 19 hostMasks[a.val]).Adj i k →
      ¬ (codeGraph 19 hostMasks[a.val]).Adj j k := by decide +kernel
  intro m hm S hS
  obtain ⟨a,ha,rfl⟩ := List.getElem_of_mem hm
  obtain ⟨i,j,k,hij,hik,hjk,_⟩ := SimpleGraph.is3Clique_iff.mp hS
  exact raw ⟨a,ha⟩ i j k hij hik hjk

/-- Remove edges to attain the specified size, retaining every vertex. -/
theorem trim_edges {n q : ℕ} (G : SimpleGraph (Fin n)) (count : q ≤ G.edgeSet.ncard) :
    ∃ B : SimpleGraph (Fin n), B ≤ G ∧ B.edgeSet.ncard = q := by
  classical
  rw [Set.ncard_eq_toFinset_card'] at count
  obtain ⟨W,sub,hw⟩ := Finset.exists_subset_card_eq count
  let B := fromEdgeSet (W : Set (Sym2 (Fin n)))
  have inG : (W : Set (Sym2 (Fin n))) ⊆ G.edgeSet := fun e he => by
    have := sub he
    simpa using this
  have eq : B.edgeSet = (W : Set (Sym2 (Fin n))) := by
    rw [show B.edgeSet = _ from edgeSet_fromEdgeSet _]
    ext e
    exact ⟨And.left,fun he => ⟨he,G.not_isDiag_of_mem_edgeSet (inG he)⟩⟩
  exact ⟨B,edgeSet_subset_edgeSet.mp (eq ▸ inG),by simpa [eq] using hw⟩

theorem red_size (G : SimpleGraph (Fin 10)) (size : G.edgeSet.ncard = 34) :
    Gᶜ.edgeSet.ncard = 11 := by
  classical
  have dis : Disjoint G.edgeSet Gᶜ.edgeSet := disjoint_edgeSet.mpr disjoint_compl_right
  have edge := Set.ncard_union_eq dis (Set.toFinite _) (Set.toFinite _)
  have topSize : (⊤ : SimpleGraph (Fin 10)).edgeSet.ncard = 45 := by
    calc
      _ = (⊤ : SimpleGraph (Fin 10)).edgeFinset.card := Set.ncard_eq_toFinset_card' _
      _ = (Fintype.card (Fin 10)).choose 2 := card_edgeFinset_top_eq_card_choose_two
      _ = 45 := by decide
  rw [←edgeSet_sup,sup_compl_eq_top,topSize] at edge
  omega

theorem ten_obstruction_of_classification
    (classify : ∀ D : SimpleGraph (Fin 10), D.edgeSet.ncard = 11 →
      (∃ e ∈ [61500,58777656,1080899112137670672], codeGraph 10 e ⊑ D) →
      ∃ e ∈ layer11, Nonempty (codeGraph 10 e ≃g D))
    (blocked : ∀ e ∈ layer11, ∃ m ∈ extraMasks, ¬ (codeGraph 10 e)ᶜ ⊑ (codeGraph 19 m)ᶜ)
    (G : SimpleGraph (Fin 10)) (edge : G.edgeSet.ncard = 34) :
    ∃ m ∈ hostMasks, ¬ G ⊑ (codeGraph 19 m)ᶜ := by
  classical
  by_contra! h
  obtain ⟨f⟩ := h seedMask List.mem_cons_self
  have hred := red_size G edge
  have pull : ∀ i j, (codeGraph 19 seedMask).Adj (f i) (f j) → Gᶜ.Adj i j := by
    intro i j hr
    refine ⟨fun heq => hr.ne (congrArg f heq),fun hg => ?_⟩
    exact (f.toHom.map_rel' hg).2 hr
  obtain ⟨e,he,⟨iso⟩⟩ := classify Gᶜ hred (from_first_host Gᶜ hred f.toEmbedding pull)
  obtain ⟨m,hm,forbid⟩ := blocked e he
  have lift : (codeGraph 10 e)ᶜ ⊑ G := by
    let emb := SimpleGraph.Embedding.complEquiv iso.toEmbedding
    simpa using emb.isContained
  exact forbid (lift.trans (h m (List.mem_cons_of_mem seedMask hm)))

theorem ten_common_of_obstruction
    (obs : ∀ G : SimpleGraph (Fin 10), G.edgeSet.ncard = 34 →
      ∃ m ∈ hostMasks, ¬ G ⊑ (codeGraph 19 m)ᶜ) :
    ∃ (r : ℕ) (masks : Fin r → ℕ),
      (∀ a, (codeGraph 19 (masks a)).CliqueFree 3) ∧
      ∀ f : Fin r → Fin 10 ↪ Fin 19,
        (⨅ a, (codeGraph 19 (masks a))ᶜ.comap (f a)).edgeSet.ncard ≤ 33 := by
  classical
  refine ⟨hostMasks.length, (fun a => hostMasks[a.val]), fun a => host_triangle_free _ (List.getElem_mem _), ?_⟩
  intro f
  let D := ⨅ (a : Fin hostMasks.length), (codeGraph 19 hostMasks[a.val])ᶜ.comap (f a)
  change D.edgeSet.ncard ≤ 33
  by_contra! gt
  obtain ⟨G,sub,edge⟩ := trim_edges D (q:=34) (by omega)
  obtain ⟨m,hm,no⟩ := obs G edge
  obtain ⟨i,hi,rfl⟩ := List.getElem_of_mem hm
  let a : Fin hostMasks.length := ⟨i,hi⟩
  exact no (isContained_iff_exists_le_comap.mpr ⟨f a,sub.trans (iInf_le _ a)⟩)

end E1182Cover
#print axioms E1182Cover.ten_common_of_obstruction
