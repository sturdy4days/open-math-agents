import Page1x0
import Page1x1
import Page1x2
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem miss1 : rejects host6 pat1=false := by
  apply null _ _ _ _ _ _ _ _ _ _ okH6 okS1
  apply certified_frontier perm1 apart1 start1 leaves1 branches1
  · exact (prepend_chunk slice1x0 (prepend_chunk slice1x2 (prepend_chunk slice1x3 (prepend_chunk slice1x5 (prepend_chunk slice1x6 (prepend_chunk slice1x7 (prepend_chunk slice1x8 (prepend_chunk slice1x9 (prepend_chunk slice1x10 (by decide +kernel))))))))))
  · decide +kernel
end E1182TwelveBlock.Word32
#print axioms E1182TwelveBlock.Word32.miss1
namespace E1182TwelveBlock
open SimpleGraph E1182Cover
set_option maxHeartbeats 0 in
theorem blocked1 : ¬ (codeGraph 12 pat1.mask) ⊑ (triGraph 23 host6.original)ᶜ := by
  apply null_of_test host6 pat1 hostValid6 (by decide +kernel)
    (twins_from_types pat1 0x21000000102000000000023102 (by decide +kernel)) (by decide +kernel) (by decide +kernel)
  exact Word32.miss1
end E1182TwelveBlock
#print axioms E1182TwelveBlock.blocked1
