import Permutation12
namespace E1182Twelve
def field (w width i : Nat) := (w >>> (width*i)) % 2^width

end E1182Twelve
