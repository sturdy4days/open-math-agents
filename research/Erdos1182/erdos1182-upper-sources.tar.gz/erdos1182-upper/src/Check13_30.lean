import RowChecks12
namespace E1182Twelve
set_option maxHeartbeats 0 in
set_option maxRecDepth 4000 in
theorem r13_30 : rows l13 l14 163 b13 o13 z13 30 10 := by decide +kernel
end E1182Twelve
