import RowChecks12
namespace E1182Twelve
set_option maxHeartbeats 0 in
set_option maxRecDepth 4000 in
theorem r12_10 : rows l12 l13 43 b12 o12 z12 10 3 := by decide +kernel
end E1182Twelve
