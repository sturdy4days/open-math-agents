import TwinRule
import ValidHost1
import WordCut9
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem blocked9 : ¬ (codeGraph 11 pat9.mask) ⊑ (triGraph 21 host1.original)ᶜ := by
  apply null_of_test host1 pat9 hostValid1 (by decide +kernel) (twins_from_types pat9 107750948156561604812901499978899322 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact Word32.miss9
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked9
