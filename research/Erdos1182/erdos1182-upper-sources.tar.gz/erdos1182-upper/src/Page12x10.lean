import Intro12
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice12x54 : ((leaves12.drop 54).take 1).all test12=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice12x55 : ((leaves12.drop 55).take 1).all test12=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice12x56 : ((leaves12.drop 56).take 1).all test12=true := by decide +kernel
end E1182TwelveBlock.Word32
