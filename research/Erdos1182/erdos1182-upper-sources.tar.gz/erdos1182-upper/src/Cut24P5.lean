import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf24_0_10 : failed host0 pat24 (atPath host0 pat24 [10,0]) = true := by
  decide +kernel

theorem leaf24_0_11_1 : failed host0 pat24 (atPath host0 pat24 [1,11,0]) = true := by
  decide +kernel

theorem leaf24_0_11_3 : failed host0 pat24 (atPath host0 pat24 [3,11,0]) = true := by
  decide +kernel

theorem leaf24_0_11_4 : failed host0 pat24 (atPath host0 pat24 [4,11,0]) = true := by
  decide +kernel

end E1182ElevenBlock
