import Cut24P0
import Cut24P1
import Cut24P2
import Cut24P3
import Cut24P4
import Cut24P5
import Cut24P6
import Cut24P7
import Descent
import Descent
import TwinRule
import ValidHost0
namespace E1182ElevenBlock
open SimpleGraph E1182Cover

private theorem leaf24_0_1 : failed host0 pat24 (atPath host0 pat24 [1,0]) = true := by
  apply failed_atPath _ _ _ [4,8,9,10,11,12,13,14] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf24_0_1_4
  · exact leaf24_0_1_8
  · exact leaf24_0_1_9
  · exact leaf24_0_1_10
  · exact leaf24_0_1_11
  · exact leaf24_0_1_12
  · exact leaf24_0_1_13
  · exact leaf24_0_1_14

private theorem leaf24_0_3 : failed host0 pat24 (atPath host0 pat24 [3,0]) = true := by
  apply failed_atPath _ _ _ [4,7,10,11,12,13,14,17] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf24_0_3_4
  · exact leaf24_0_3_7
  · exact leaf24_0_3_10
  · exact leaf24_0_3_11
  · exact leaf24_0_3_12
  · exact leaf24_0_3_13
  · exact leaf24_0_3_14
  · exact leaf24_0_3_17

private theorem leaf24_0_4 : failed host0 pat24 (atPath host0 pat24 [4,0]) = true := by
  apply failed_atPath _ _ _ [1,3,7,8,11,12,13,14,17] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf24_0_4_1
  · exact leaf24_0_4_3
  · exact leaf24_0_4_7
  · exact leaf24_0_4_8
  · exact leaf24_0_4_11
  · exact leaf24_0_4_12
  · exact leaf24_0_4_13
  · exact leaf24_0_4_14
  · exact leaf24_0_4_17

private theorem leaf24_0_7 : failed host0 pat24 (atPath host0 pat24 [7,0]) = true := by
  apply failed_atPath _ _ _ [3,4,8,10,11,14,17] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf24_0_7_3
  · exact leaf24_0_7_4
  · exact leaf24_0_7_8
  · exact leaf24_0_7_10
  · exact leaf24_0_7_11
  · exact leaf24_0_7_14
  · exact leaf24_0_7_17

private theorem leaf24_0_8 : failed host0 pat24 (atPath host0 pat24 [8,0]) = true := by
  apply failed_atPath _ _ _ [1,4,7,9,11,12,17] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf24_0_8_1
  · exact leaf24_0_8_4
  · exact leaf24_0_8_7
  · exact leaf24_0_8_9
  · exact leaf24_0_8_11
  · exact leaf24_0_8_12
  · exact leaf24_0_8_17

private theorem leaf24_0_11 : failed host0 pat24 (atPath host0 pat24 [11,0]) = true := by
  apply failed_atPath _ _ _ [1,3,4,7,8,10,12,14] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf24_0_11_1
  · exact leaf24_0_11_3
  · exact leaf24_0_11_4
  · exact leaf24_0_11_7
  · exact leaf24_0_11_8
  · exact leaf24_0_11_10
  · exact leaf24_0_11_12
  · exact leaf24_0_11_14

private theorem leaf24_0_14 : failed host0 pat24 (atPath host0 pat24 [14,0]) = true := by
  apply failed_atPath _ _ _ [1,3,4,7,10,11,13,17] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf24_0_14_1
  · exact leaf24_0_14_3
  · exact leaf24_0_14_4
  · exact leaf24_0_14_7
  · exact leaf24_0_14_10
  · exact leaf24_0_14_11
  · exact leaf24_0_14_13
  · exact leaf24_0_14_17

private theorem leaf24_0 : failed host0 pat24 (atPath host0 pat24 [0]) = true := by
  apply failed_atPath _ _ _ [1,3,4,7,8,9,10,11,12,13,14,17,18] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf24_0_1
  · exact leaf24_0_3
  · exact leaf24_0_4
  · exact leaf24_0_7
  · exact leaf24_0_8
  · exact leaf24_0_9
  · exact leaf24_0_10
  · exact leaf24_0_11
  · exact leaf24_0_12
  · exact leaf24_0_13
  · exact leaf24_0_14
  · exact leaf24_0_17
  · exact leaf24_0_18

private theorem leaf24_root : failed host0 pat24 (atPath host0 pat24 []) = true := by
  apply failed_atPath _ _ _ [0] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  subst v
  exact leaf24_0

theorem blocked24 : ¬ (codeGraph 11 pat24.mask) ⊑ (triGraph 21 host0.original)ᶜ := by
  apply null_of_test host0 pat24 hostValid0 (by decide +kernel) (twins_from_types pat24 60398874067811969248114026838 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact rejects_of_failed_root _ _ leaf24_root
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked24
