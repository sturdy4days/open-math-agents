import Descent
import TwinRule
import ValidHost0
namespace E1182ElevenBlock
open SimpleGraph E1182Cover

private theorem leaf5_0_1 : failed host0 pat5 (atPath host0 pat5 [1,0]) = true := by
  decide +kernel

private theorem leaf5_0_3 : failed host0 pat5 (atPath host0 pat5 [3,0]) = true := by
  decide +kernel

private theorem leaf5_0_4 : failed host0 pat5 (atPath host0 pat5 [4,0]) = true := by
  decide +kernel

private theorem leaf5_0_7 : failed host0 pat5 (atPath host0 pat5 [7,0]) = true := by
  decide +kernel

private theorem leaf5_0_8 : failed host0 pat5 (atPath host0 pat5 [8,0]) = true := by
  decide +kernel

private theorem leaf5_0_9 : failed host0 pat5 (atPath host0 pat5 [9,0]) = true := by
  decide +kernel

private theorem leaf5_0_10 : failed host0 pat5 (atPath host0 pat5 [10,0]) = true := by
  decide +kernel

private theorem leaf5_0_11 : failed host0 pat5 (atPath host0 pat5 [11,0]) = true := by
  decide +kernel

private theorem leaf5_0_12 : failed host0 pat5 (atPath host0 pat5 [12,0]) = true := by
  decide +kernel

private theorem leaf5_0_13 : failed host0 pat5 (atPath host0 pat5 [13,0]) = true := by
  decide +kernel

private theorem leaf5_0_14 : failed host0 pat5 (atPath host0 pat5 [14,0]) = true := by
  decide +kernel

private theorem leaf5_0_17 : failed host0 pat5 (atPath host0 pat5 [17,0]) = true := by
  decide +kernel

private theorem leaf5_0 : failed host0 pat5 (atPath host0 pat5 [0]) = true := by
  apply failed_atPath _ _ _ [1,3,4,7,8,9,10,11,12,13,14,17] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf5_0_1
  · exact leaf5_0_3
  · exact leaf5_0_4
  · exact leaf5_0_7
  · exact leaf5_0_8
  · exact leaf5_0_9
  · exact leaf5_0_10
  · exact leaf5_0_11
  · exact leaf5_0_12
  · exact leaf5_0_13
  · exact leaf5_0_14
  · exact leaf5_0_17

private theorem leaf5_root : failed host0 pat5 (atPath host0 pat5 []) = true := by
  apply failed_atPath _ _ _ [0] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  subst v
  exact leaf5_0

theorem blocked5 : ¬ (codeGraph 11 pat5.mask) ⊑ (triGraph 21 host0.original)ᶜ := by
  apply null_of_test host0 pat5 hostValid0 (by decide +kernel) (twins_from_types pat5 72057594037999618 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact rejects_of_failed_root _ _ leaf5_root
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked5
