import FrontierClose
import Page4x0
import Page4x1
import Page4x2
import Page4x3
import Page4x4
import Page4x5
namespace E1182TwelveBlock.Word32
private theorem appendParts4 (offset width : Nat)
    (head : ((leaves4.drop offset).take width).all test4 = true)
    (tail : (leaves4.drop (offset+width)).all test4 = true) :
    (leaves4.drop offset).all test4 = true :=
  prepend_chunk (xs := leaves4) (f := test4) (offset := offset) (width := width) head tail

set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem miss4 : rejects host8 pat4 = false :=
  closeFrontier host8 pat4 p4E p4R h8J h8B h8A h8I h8U h8T
    okH8 okS4 leaves4 branches4
    (appendParts4 0 1 slice4x0 (appendParts4 1 1 slice4x1 (appendParts4 2 1 slice4x2 (appendParts4 3 1 slice4x3 (appendParts4 4 2 slice4x4 (appendParts4 6 1 slice4x6 (appendParts4 7 5 slice4x7 (appendParts4 12 1 slice4x12 (appendParts4 13 1 slice4x13 (appendParts4 14 1 slice4x14 (appendParts4 15 1 slice4x15 (appendParts4 16 2 slice4x16 (appendParts4 18 5 slice4x18 (appendParts4 23 11 slice4x23 (by decide +kernel))))))))))))))) (by decide +kernel)
end E1182TwelveBlock.Word32
#print axioms E1182TwelveBlock.Word32.miss4
namespace E1182TwelveBlock
open SimpleGraph E1182Cover
set_option maxHeartbeats 0 in
theorem blocked4 : ¬ (codeGraph 12 pat4.mask) ⊑ (triGraph 23 host8.original)ᶜ := by
  apply null_of_test host8 pat4 hostValid8 (by decide +kernel)
    (twins_from_types pat4 0x2d00002d12c30002930000000530d2 (by decide +kernel)) (by decide +kernel) (by decide +kernel)
  exact Word32.miss4
end E1182TwelveBlock
#print axioms E1182TwelveBlock.blocked4
