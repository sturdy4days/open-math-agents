import Check11_0
namespace E1182Twelve
theorem layer11 : rows l11 l12 13 b11 o11 z11 0 4 := r11_0
end E1182Twelve
