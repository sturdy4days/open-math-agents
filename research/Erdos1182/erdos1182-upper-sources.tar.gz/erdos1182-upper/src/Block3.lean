import Descent
import TwinRule
import ValidHost1
namespace E1182ElevenBlock
open SimpleGraph E1182Cover

private theorem leaf3_0_0 : failed host1 pat3 (atPath host1 pat3 [0,0]) = true := by
  decide +kernel

private theorem leaf3_0_3 : failed host1 pat3 (atPath host1 pat3 [3,0]) = true := by
  decide +kernel

private theorem leaf3_0_5 : failed host1 pat3 (atPath host1 pat3 [5,0]) = true := by
  decide +kernel

private theorem leaf3_0_6 : failed host1 pat3 (atPath host1 pat3 [6,0]) = true := by
  decide +kernel

private theorem leaf3_0_7 : failed host1 pat3 (atPath host1 pat3 [7,0]) = true := by
  decide +kernel

private theorem leaf3_0_9 : failed host1 pat3 (atPath host1 pat3 [9,0]) = true := by
  decide +kernel

private theorem leaf3_0_10 : failed host1 pat3 (atPath host1 pat3 [10,0]) = true := by
  decide +kernel

private theorem leaf3_0_11 : failed host1 pat3 (atPath host1 pat3 [11,0]) = true := by
  decide +kernel

private theorem leaf3_0_13 : failed host1 pat3 (atPath host1 pat3 [13,0]) = true := by
  decide +kernel

private theorem leaf3_0 : failed host1 pat3 (atPath host1 pat3 [0]) = true := by
  apply failed_atPath _ _ _ [0,3,5,6,7,9,10,11,13] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf3_0_0
  · exact leaf3_0_3
  · exact leaf3_0_5
  · exact leaf3_0_6
  · exact leaf3_0_7
  · exact leaf3_0_9
  · exact leaf3_0_10
  · exact leaf3_0_11
  · exact leaf3_0_13

private theorem leaf3_2_1 : failed host1 pat3 (atPath host1 pat3 [1,2]) = true := by
  decide +kernel

private theorem leaf3_2_4 : failed host1 pat3 (atPath host1 pat3 [4,2]) = true := by
  decide +kernel

private theorem leaf3_2_5 : failed host1 pat3 (atPath host1 pat3 [5,2]) = true := by
  decide +kernel

private theorem leaf3_2_7 : failed host1 pat3 (atPath host1 pat3 [7,2]) = true := by
  decide +kernel

private theorem leaf3_2_8 : failed host1 pat3 (atPath host1 pat3 [8,2]) = true := by
  decide +kernel

private theorem leaf3_2_9 : failed host1 pat3 (atPath host1 pat3 [9,2]) = true := by
  decide +kernel

private theorem leaf3_2_11 : failed host1 pat3 (atPath host1 pat3 [11,2]) = true := by
  decide +kernel

private theorem leaf3_2_12 : failed host1 pat3 (atPath host1 pat3 [12,2]) = true := by
  decide +kernel

private theorem leaf3_2 : failed host1 pat3 (atPath host1 pat3 [2]) = true := by
  apply failed_atPath _ _ _ [1,4,5,7,8,9,11,12] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf3_2_1
  · exact leaf3_2_4
  · exact leaf3_2_5
  · exact leaf3_2_7
  · exact leaf3_2_8
  · exact leaf3_2_9
  · exact leaf3_2_11
  · exact leaf3_2_12

private theorem leaf3_3 : failed host1 pat3 (atPath host1 pat3 [3]) = true := by
  decide +kernel

private theorem leaf3_7_0 : failed host1 pat3 (atPath host1 pat3 [0,7]) = true := by
  decide +kernel

private theorem leaf3_7_1 : failed host1 pat3 (atPath host1 pat3 [1,7]) = true := by
  decide +kernel

private theorem leaf3_7_2 : failed host1 pat3 (atPath host1 pat3 [2,7]) = true := by
  decide +kernel

private theorem leaf3_7_4 : failed host1 pat3 (atPath host1 pat3 [4,7]) = true := by
  decide +kernel

private theorem leaf3_7_9 : failed host1 pat3 (atPath host1 pat3 [9,7]) = true := by
  decide +kernel

private theorem leaf3_7_10 : failed host1 pat3 (atPath host1 pat3 [10,7]) = true := by
  decide +kernel

private theorem leaf3_7_11 : failed host1 pat3 (atPath host1 pat3 [11,7]) = true := by
  decide +kernel

private theorem leaf3_7_13 : failed host1 pat3 (atPath host1 pat3 [13,7]) = true := by
  decide +kernel

private theorem leaf3_7 : failed host1 pat3 (atPath host1 pat3 [7]) = true := by
  apply failed_atPath _ _ _ [0,1,2,4,9,10,11,13] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf3_7_0
  · exact leaf3_7_1
  · exact leaf3_7_2
  · exact leaf3_7_4
  · exact leaf3_7_9
  · exact leaf3_7_10
  · exact leaf3_7_11
  · exact leaf3_7_13

private theorem leaf3_root : failed host1 pat3 (atPath host1 pat3 []) = true := by
  apply failed_atPath _ _ _ [0,2,3,7] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl
  · exact leaf3_0
  · exact leaf3_2
  · exact leaf3_3
  · exact leaf3_7

theorem blocked3 : ¬ (codeGraph 11 pat3.mask) ⊑ (triGraph 21 host1.original)ᶜ := by
  apply null_of_test host1 pat3 hostValid1 (by decide +kernel) (twins_from_types pat3 2720083781547585329010738 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact rejects_of_failed_root _ _ leaf3_root
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked3
