import Intro11
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice11x1 : ((leaves11.drop 1).take 1).all test11=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice11x2 : ((leaves11.drop 2).take 1).all test11=true := by decide +kernel
end E1182TwelveBlock.Word32
