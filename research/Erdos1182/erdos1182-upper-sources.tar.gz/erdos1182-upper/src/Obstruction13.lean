import FrontierClose
import Page13x0
import Page13x1
import Page13x2
import Page13x3
import Page13x4
import Page13x5
import Page13x6
import Page13x7
import Page13x8
import Page13x9
import Page13x10
import Page13x11
import Page13x12
import Page13x13
import Page13x14
import Page13x15
import Page13x16
import Page13x17
import Page13x18
import Page13x19
import Page13x20
import Page13x21
import Page13x22
import Page13x23
import Page13x24
import Page13x25
namespace E1182TwelveBlock.Word32
private theorem appendParts13 (offset width : Nat)
    (head : ((leaves13.drop offset).take width).all test13 = true)
    (tail : (leaves13.drop (offset+width)).all test13 = true) :
    (leaves13.drop offset).all test13 = true :=
  prepend_chunk (xs := leaves13) (f := test13) (offset := offset) (width := width) head tail

set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem miss13 : rejects host6 pat13 = false :=
  closeFrontier host6 pat13 p13E p13R h6J h6B h6A h6I h6U h6T
    okH6 okS13 leaves13 branches13
    (appendParts13 0 1 slice13x0 (appendParts13 1 1 slice13x1 (appendParts13 2 1 slice13x2 (appendParts13 3 2 slice13x3 (appendParts13 5 2 slice13x5 (appendParts13 7 2 slice13x7 (appendParts13 9 4 slice13x9 (appendParts13 13 1 slice13x13 (appendParts13 14 1 slice13x14 (appendParts13 15 2 slice13x15 (appendParts13 17 3 slice13x17 (appendParts13 20 4 slice13x20 (appendParts13 24 2 slice13x24 (appendParts13 26 1 slice13x26 (appendParts13 27 1 slice13x27 (appendParts13 28 1 slice13x28 (appendParts13 29 2 slice13x29 (appendParts13 31 1 slice13x31 (appendParts13 32 1 slice13x32 (appendParts13 33 2 slice13x33 (appendParts13 35 4 slice13x35 (appendParts13 39 2 slice13x39 (appendParts13 41 1 slice13x41 (appendParts13 42 1 slice13x42 (appendParts13 43 2 slice13x43 (appendParts13 45 2 slice13x45 (appendParts13 47 3 slice13x47 (appendParts13 50 5 slice13x50 (appendParts13 55 3 slice13x55 (appendParts13 58 3 slice13x58 (appendParts13 61 6 slice13x61 (appendParts13 67 2 slice13x67 (appendParts13 69 2 slice13x69 (appendParts13 71 2 slice13x71 (appendParts13 73 1 slice13x73 (appendParts13 74 2 slice13x74 (appendParts13 76 4 slice13x76 (appendParts13 80 1 slice13x80 (appendParts13 81 1 slice13x81 (appendParts13 82 1 slice13x82 (appendParts13 83 1 slice13x83 (appendParts13 84 1 slice13x84 (appendParts13 85 2 slice13x85 (appendParts13 87 3 slice13x87 (appendParts13 90 4 slice13x90 (appendParts13 94 2 slice13x94 (appendParts13 96 2 slice13x96 (appendParts13 98 2 slice13x98 (appendParts13 100 3 slice13x100 (appendParts13 103 5 slice13x103 (appendParts13 108 1 slice13x108 (appendParts13 109 1 slice13x109 (appendParts13 110 1 slice13x110 (appendParts13 111 1 slice13x111 (appendParts13 112 2 slice13x112 (appendParts13 114 1 slice13x114 (appendParts13 115 1 slice13x115 (appendParts13 116 3 slice13x116 (appendParts13 119 3 slice13x119 (appendParts13 122 1 slice13x122 (appendParts13 123 1 slice13x123 (appendParts13 124 1 slice13x124 (appendParts13 125 1 slice13x125 (appendParts13 126 1 slice13x126 (appendParts13 127 1 slice13x127 (appendParts13 128 2 slice13x128 (appendParts13 130 3 slice13x130 (appendParts13 133 3 slice13x133 (appendParts13 136 1 slice13x136 (appendParts13 137 1 slice13x137 (appendParts13 138 1 slice13x138 (appendParts13 139 2 slice13x139 (appendParts13 141 1 slice13x141 (appendParts13 142 2 slice13x142 (appendParts13 144 3 slice13x144 (appendParts13 147 2 slice13x147 (by decide +kernel))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) (by decide +kernel)
end E1182TwelveBlock.Word32
#print axioms E1182TwelveBlock.Word32.miss13
namespace E1182TwelveBlock
open SimpleGraph E1182Cover
set_option maxHeartbeats 0 in
theorem blocked13 : ¬ (codeGraph 12 pat13.mask) ⊑ (triGraph 23 host6.original)ᶜ := by
  apply null_of_test host6 pat13 hostValid6 (by decide +kernel)
    (twins_from_types pat13 0x6e2a43c420eb923f239cb00012b000feb5ea (by decide +kernel)) (by decide +kernel) (by decide +kernel)
  exact Word32.miss13
end E1182TwelveBlock
#print axioms E1182TwelveBlock.blocked13
