import Closure
import Rows
import Symmetry
import Mathlib.Combinatorics.SimpleGraph.Operations
open SimpleGraph E1182Bits E1182Cover
namespace E1182Eleven

theorem symmetric_adj {w : Nat} (hw : symmetric w) (i j : Fin 11) :
    (codeGraph 11 w).Adj i j ↔ i≠j ∧ neighbors w i j := by
  change (i≠j ∧ w.testBit (min i.val j.val*11+max i.val j.val)=true) ↔ _
  unfold neighbors
  by_cases h : i.val≤j.val
  · simp only [min_eq_left h,max_eq_right h,hw j i,Bool.or_self]
    simp only [addr,Nat.mul_comm 11]
  · have h' := Nat.le_of_lt (Nat.lt_of_not_ge h)
    simp only [min_eq_right h',max_eq_left h',hw i j,Bool.or_self]
    simp only [addr,Nat.mul_comm 11]

theorem added_graph {w : Nat} (hw : symmetric w) (a b : Fin 11) :
    codeGraph 11 (insertPair w a b) = codeGraph 11 w ⊔ SimpleGraph.edge a b := by
  ext i j
  rw [symmetric_adj (symmetric_insert hw a b),neighbors_insert_iff,SimpleGraph.sup_adj,
    symmetric_adj hw,SimpleGraph.edge_adj]
  tauto

theorem added_count {w : Nat} (hw : symmetric w) {a b : Fin 11} (lt : a<b)
    (no : ¬ (codeGraph 11 w).Adj a b) :
    (codeGraph 11 (insertPair w a b)).edgeSet.ncard = (codeGraph 11 w).edgeSet.ncard+1 := by
  rw [added_graph hw,edgeSet_sup,edgeSet_edge_of_ne (ne_of_lt lt),Set.union_singleton,
    Set.ncard_insert_of_notMem]
  exact no

theorem relabel_graph (k s : Nat) {w : Nat} (hw : symmetric w) :
    Nonempty (codeGraph 11 (relabel k w s) ≃g codeGraph 11 w) := by
  let e := Equiv.ofBijective (labelMap k s) (labelMap_inj k s).bijective_of_finite
  have eq : codeGraph 11 (relabel k w s) = (codeGraph 11 w).comap e := by
    ext i j
    change (codeGraph 11 (relabel k w s)).Adj i j ↔ (codeGraph 11 w).Adj (labelMap k s i) (labelMap k s j)
    rw [symmetric_adj (symmetric_relabel k s hw),symmetric_adj hw]
    simp only [neighbors,relabel_at,ne_eq,(labelMap_inj k s).eq_iff]
  exact ⟨eq ▸ SimpleGraph.Iso.comap e (codeGraph 11 w)⟩

/-- The number of red edges and symmetry propagate from the chosen seed, making
    separate cardinality computations for all 2,297 terminal matrices unnecessary. -/
def reached (D : SimpleGraph (Fin 11)) (table count size : Nat) : Prop :=
  ∃ t < count, let w := field table 121 t
    symmetric w ∧ (codeGraph 11 w).edgeSet.ncard=size ∧ codeGraph 11 w ⊑ D

theorem next_layer {D : SimpleGraph (Fin 11)} {ss ts num next size scripts recs : Nat}
    (h : reached D ss num size) (more : size < D.edgeSet.ncard)
    (checked : rows ss ts next scripts recs 0 num) : reached D ts next (size+1) := by
  obtain ⟨i,hi,hs,hcard,sub⟩ := h
  let m := field ss 121 i
  have hsize : (codeGraph 11 m).edgeSet.ncard < D.edgeSet.ncard := hcard.trans_lt more
  obtain ⟨f,a,b,lt,no,yes⟩ := strict_edge sub hsize
  have valid : rowOK m ts next scripts (field recs 1210 i) := by
    simpa only [rows,verifyRow,Nat.zero_add] using checked ⟨i,hi⟩
  have notNeighbor : ¬ neighbors m a b := fun hy => no ((symmetric_adj hs a b).mpr ⟨ne_of_lt lt,hy⟩)
  obtain ⟨bound,step⟩ := valid a b lt notNeighbor
  refine ⟨_, bound, ?_⟩
  rw [←step]
  let add := codeGraph 11 (insertPair m a b)
  have into : add ⊑ D := by
    refine ⟨⟨⟨f,?_⟩,f.injective⟩⟩
    intro x y xy
    change (codeGraph 11 (insertPair (field ss 121 i) a b)).Adj x y at xy
    rw [added_graph hs,SimpleGraph.sup_adj,SimpleGraph.edge_adj] at xy
    rcases xy with present | ⟨(⟨rfl,rfl⟩|⟨rfl,rfl⟩),_⟩
    · exact f.toHom.map_rel' present
    · exact yes
    · exact yes.symm
  let script := field scripts 80 ((witness (field recs 1210 i) a b) >>> 12)
  obtain ⟨e⟩ := relabel_graph 10 script (symmetric_insert hs a b)
  exact ⟨symmetric_relabel _ _ (symmetric_insert hs a b),
    (Nat.card_congr e.mapEdgeSet).trans ((added_count hs lt no).trans (congrArg (·+1) hcard)),
    e.isContained.trans into⟩

end E1182Eleven
#print axioms E1182Eleven.next_layer
