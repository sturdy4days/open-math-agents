import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf19_0_4_18 : failed host0 pat19 (atPath host0 pat19 [18,4,0]) = true := by
  decide +kernel

theorem leaf19_0_7_8 : failed host0 pat19 (atPath host0 pat19 [8,7,0]) = true := by
  decide +kernel

theorem leaf19_0_7_10 : failed host0 pat19 (atPath host0 pat19 [10,7,0]) = true := by
  decide +kernel

theorem leaf19_0_7_11 : failed host0 pat19 (atPath host0 pat19 [11,7,0]) = true := by
  decide +kernel

theorem leaf19_0_7_14 : failed host0 pat19 (atPath host0 pat19 [14,7,0]) = true := by
  decide +kernel

end E1182ElevenBlock
