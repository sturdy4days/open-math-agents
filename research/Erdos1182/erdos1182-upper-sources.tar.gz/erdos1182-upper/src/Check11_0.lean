import RowChecks12
namespace E1182Twelve
set_option maxHeartbeats 0 in
set_option maxRecDepth 4000 in
theorem r11_0 : rows l11 l12 13 b11 o11 z11 0 4 := by decide +kernel
end E1182Twelve
