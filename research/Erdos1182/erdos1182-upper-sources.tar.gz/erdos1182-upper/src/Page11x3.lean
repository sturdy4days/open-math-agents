import Intro11
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice11x6 : ((leaves11.drop 6).take 1).all test11=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice11x7 : ((leaves11.drop 7).take 4).all test11=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice11x11 : ((leaves11.drop 11).take 3).all test11=true := by decide +kernel
end E1182TwelveBlock.Word32
