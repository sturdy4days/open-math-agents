import TwinRule
import ValidHost0
import WordCut21
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem blocked21 : ¬ (codeGraph 11 pat21.mask) ⊑ (triGraph 21 host0.original)ᶜ := by
  apply null_of_test host0 pat21 hostValid0 (by decide +kernel) (twins_from_types pat21 760044002728322084162292599485582378 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact Word32.miss21
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked21
