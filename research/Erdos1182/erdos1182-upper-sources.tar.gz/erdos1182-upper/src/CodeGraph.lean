import Mathlib.Combinatorics.SimpleGraph.Copy
import Mathlib.Combinatorics.SimpleGraph.Finite
import Mathlib.Tactic.Push

namespace E1182Cover

def codeGraph (n mask : ℕ) : SimpleGraph (Fin n) where
  Adj x y := x ≠ y ∧ mask.testBit (min x.val y.val*n + max x.val y.val) = true
  symm := ⟨fun x y h => ⟨h.1.symm, by simpa only [min_comm y.val, max_comm y.val] using h.2⟩⟩
  loopless := ⟨fun x h => h.1 rfl⟩

instance (n mask : ℕ) : DecidableRel (codeGraph n mask).Adj :=
  fun _ _ => inferInstanceAs (Decidable (_ ≠ _ ∧ _ = true))

end E1182Cover
