import HostChecks8
namespace E1182TwelveBlock.Word32
def p11E : Nat := spreadCells 0x80141f21f118098060060790788604602e01
def p11R : Nat := spreadCells 0xffffffbfffffeffffffbfffffeffffffbfff
set_option maxHeartbeats 0 in
theorem okS11 : sourceWords host8 pat11 p11E p11R := by
  unfold sourceWords
  decide +kernel
abbrev perm11 := permit p11E p11R h8J h8B
abbrev apart11 := field h8A 384
abbrev start11 := initial pat11 h8I h8U h8T
def leaves11 : List (List Nat) := [[0],[1],[0,3],[3,3],[4,3],[5,3],[6,3],[8,3],[9,3],[12,3],[13,3],[14,3],[0,5],[2,5],[3,5],[6,5],[8,5],[10,5],[11,5],[13,5],[14,5],[0,7],[1,7],[2,7],[4,7],[7,7,7],[9,7,7],[10,7,7],[11,7,7],[12,7,7],[13,7,7],[15,7,7],[9,7],[10,7],[11,7],[12,7],[13,7]]
def branches11 : List (List Nat) := [[3],[5],[7,7],[7],[]]
abbrev test11 := fails perm11 apart11 start11
end E1182TwelveBlock.Word32
