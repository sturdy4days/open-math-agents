import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf6_0_4_8 : failed host0 pat6 (atPath host0 pat6 [8,4,0]) = true := by
  decide +kernel

theorem leaf6_0_4_9 : failed host0 pat6 (atPath host0 pat6 [9,4,0]) = true := by
  decide +kernel

theorem leaf6_0_4_10 : failed host0 pat6 (atPath host0 pat6 [10,4,0]) = true := by
  decide +kernel

theorem leaf6_0_4_11 : failed host0 pat6 (atPath host0 pat6 [11,4,0]) = true := by
  decide +kernel

theorem leaf6_0_4_12 : failed host0 pat6 (atPath host0 pat6 [12,4,0]) = true := by
  decide +kernel

theorem leaf6_0_4_13 : failed host0 pat6 (atPath host0 pat6 [13,4,0]) = true := by
  decide +kernel

theorem leaf6_0_4_14 : failed host0 pat6 (atPath host0 pat6 [14,4,0]) = true := by
  decide +kernel

theorem leaf6_0_4_17 : failed host0 pat6 (atPath host0 pat6 [17,4,0]) = true := by
  decide +kernel

theorem leaf6_0_4_18 : failed host0 pat6 (atPath host0 pat6 [18,4,0]) = true := by
  decide +kernel

theorem leaf6_0_7_8 : failed host0 pat6 (atPath host0 pat6 [8,7,0]) = true := by
  decide +kernel

end E1182ElevenBlock
