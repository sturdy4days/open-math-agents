import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf6_0_1_10 : failed host0 pat6 (atPath host0 pat6 [10,1,0]) = true := by
  decide +kernel

theorem leaf6_0_1_11 : failed host0 pat6 (atPath host0 pat6 [11,1,0]) = true := by
  decide +kernel

theorem leaf6_0_1_12 : failed host0 pat6 (atPath host0 pat6 [12,1,0]) = true := by
  decide +kernel

theorem leaf6_0_1_13 : failed host0 pat6 (atPath host0 pat6 [13,1,0]) = true := by
  decide +kernel

theorem leaf6_0_1_14 : failed host0 pat6 (atPath host0 pat6 [14,1,0]) = true := by
  decide +kernel

theorem leaf6_0_1_17 : failed host0 pat6 (atPath host0 pat6 [17,1,0]) = true := by
  decide +kernel

theorem leaf6_0_1_18 : failed host0 pat6 (atPath host0 pat6 [18,1,0]) = true := by
  decide +kernel

theorem leaf6_0_3_4 : failed host0 pat6 (atPath host0 pat6 [4,3,0]) = true := by
  decide +kernel

theorem leaf6_0_3_7 : failed host0 pat6 (atPath host0 pat6 [7,3,0]) = true := by
  decide +kernel

end E1182ElevenBlock
