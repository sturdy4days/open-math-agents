import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf22_0_3_20 : failed host0 pat22 (atPath host0 pat22 [20,3,0]) = true := by
  decide +kernel

theorem leaf22_0_4_7 : failed host0 pat22 (atPath host0 pat22 [7,4,0]) = true := by
  decide +kernel

theorem leaf22_0_4_8 : failed host0 pat22 (atPath host0 pat22 [8,4,0]) = true := by
  decide +kernel

theorem leaf22_0_4_11 : failed host0 pat22 (atPath host0 pat22 [11,4,0]) = true := by
  decide +kernel

theorem leaf22_0_4_12 : failed host0 pat22 (atPath host0 pat22 [12,4,0]) = true := by
  decide +kernel

theorem leaf22_0_4_13 : failed host0 pat22 (atPath host0 pat22 [13,4,0]) = true := by
  decide +kernel

theorem leaf22_0_4_14 : failed host0 pat22 (atPath host0 pat22 [14,4,0]) = true := by
  decide +kernel

theorem leaf22_0_4_17 : failed host0 pat22 (atPath host0 pat22 [17,4,0]) = true := by
  decide +kernel

theorem leaf22_0_4_18 : failed host0 pat22 (atPath host0 pat22 [18,4,0]) = true := by
  decide +kernel

theorem leaf22_0_7_8 : failed host0 pat22 (atPath host0 pat22 [8,7,0]) = true := by
  decide +kernel

end E1182ElevenBlock
