import HostChecks7
namespace E1182TwelveBlock.Word32
def p14E : Nat := spreadCells 0x9706316709310b0a40fa0f90008004002501
def p14R : Nat := spreadCells 0xffffffffffffffffffffffdffffff7ff3fff
set_option maxHeartbeats 0 in
theorem okS14 : sourceWords host7 pat14 p14E p14R := by
  unfold sourceWords
  decide +kernel
abbrev perm14 := permit p14E p14R h7J h7B
abbrev apart14 := field h7A 384
abbrev start14 := initial pat14 h7I h7U h7T
def leaves14 : List (List Nat) := [[0],[1,1],[3,1],[4,1],[6,1],[7,1],[2],[5],[0,6],[1,6],[3,6],[4,6],[6,6]]
def branches14 : List (List Nat) := [[1],[6],[]]
abbrev test14 := fails perm14 apart14 start14
end E1182TwelveBlock.Word32
