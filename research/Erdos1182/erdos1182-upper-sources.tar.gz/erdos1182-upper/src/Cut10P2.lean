import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf10_0_4_8 : failed host0 pat10 (atPath host0 pat10 [8,4,0]) = true := by
  decide +kernel

theorem leaf10_0_4_11 : failed host0 pat10 (atPath host0 pat10 [11,4,0]) = true := by
  decide +kernel

theorem leaf10_0_4_12 : failed host0 pat10 (atPath host0 pat10 [12,4,0]) = true := by
  decide +kernel

theorem leaf10_0_4_13 : failed host0 pat10 (atPath host0 pat10 [13,4,0]) = true := by
  decide +kernel

theorem leaf10_0_4_14 : failed host0 pat10 (atPath host0 pat10 [14,4,0]) = true := by
  decide +kernel

theorem leaf10_0_4_17 : failed host0 pat10 (atPath host0 pat10 [17,4,0]) = true := by
  decide +kernel

theorem leaf10_0_4_18 : failed host0 pat10 (atPath host0 pat10 [18,4,0]) = true := by
  decide +kernel

end E1182ElevenBlock
