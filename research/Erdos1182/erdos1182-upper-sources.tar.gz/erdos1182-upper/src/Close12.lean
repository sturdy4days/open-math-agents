import SeedSteps12
namespace E1182Twelve
open SimpleGraph E1182Cover
theorem closes
    (q10 : rows l10 l11 4 b10 o10 z10 0 1)
    (q11 : rows l11 l12 13 b11 o11 z11 0 4)
    (q12 : rows l12 l13 43 b12 o12 z12 0 13)
    (q13 : rows l13 l14 163 b13 o13 z13 0 43)
    (q14 : rows l14 l15 719 b14 o14 z14 0 163)
    (q15 : rows l15 l16 3130 b15 o15 z15 0 719)
    (q16 : leaves l16 b16 0 3130)
    {D : SimpleGraph (Fin 12)} (size : D.edgeSet.ncard=16)
    (forbidden : ∀ q, ¬ atlas q ⊑ Dᶜ)
    (start : ∃ m ∈ [508028, 511874, 2013757560, 18738424009021844676149310, 4161765624, 18738424009020744896020528, 74294540672716477532429352960, 18742925023579729721098256], codeGraph 12 m ⊑ D) : False := by
  have a10 := @advance D forbidden l10 l11 1 4 b10 o10 z10 10 q10
  have a11 := @advance D forbidden l11 l12 4 13 b11 o11 z11 11 q11
  have a12 := @advance D forbidden l12 l13 13 43 b12 o12 z12 12 q12
  have a13 := @advance D forbidden l13 l14 43 163 b13 o13 z13 13 q13
  have a14 := @advance D forbidden l14 l15 163 719 b14 o14 z14 14 q14
  have a15 := @advance D forbidden l15 l16 719 3130 b15 o15 z15 15 q15
  obtain ⟨m,hm,sub⟩ := start
  apply stop (ss:=l16) (n:=3130) _ size forbidden q16
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hm
  rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact a15 (a14 (a13 (a12 (a11 (a10 (start_at (by decide) seed0 sub))))))
  · exact a15 (a14 (a13 (a12 (a11 (start_at (by decide) seed1 sub)))))
  · exact a15 (a14 (a13 (a12 (start_at (by decide) seed2 sub))))
  · exact a15 (start_at (by decide) seed3 sub)
  · exact a15 (start_at (by decide) seed4 sub)
  · exact a15 (start_at (by decide) seed5 sub)
  · exact start_at (by decide) seed6 sub
  · exact start_at (by decide) seed7 sub
end E1182Twelve
#print axioms E1182Twelve.closes
