import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf10_0_14 : failed host0 pat10 (atPath host0 pat10 [14,0]) = true := by
  decide +kernel

theorem leaf10_0_17 : failed host0 pat10 (atPath host0 pat10 [17,0]) = true := by
  decide +kernel

end E1182ElevenBlock
