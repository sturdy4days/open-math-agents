import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf10_0_11_14 : failed host0 pat10 (atPath host0 pat10 [14,11,0]) = true := by
  decide +kernel

theorem leaf10_0_11_18 : failed host0 pat10 (atPath host0 pat10 [18,11,0]) = true := by
  decide +kernel

theorem leaf10_0_11_20 : failed host0 pat10 (atPath host0 pat10 [20,11,0]) = true := by
  decide +kernel

theorem leaf10_0_12 : failed host0 pat10 (atPath host0 pat10 [12,0]) = true := by
  decide +kernel

theorem leaf10_0_13 : failed host0 pat10 (atPath host0 pat10 [13,0]) = true := by
  decide +kernel

end E1182ElevenBlock
