import Intro12
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice12x4 : ((leaves12.drop 4).take 2).all test12=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice12x6 : ((leaves12.drop 6).take 7).all test12=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice12x13 : ((leaves12.drop 13).take 1).all test12=true := by decide +kernel
end E1182TwelveBlock.Word32
