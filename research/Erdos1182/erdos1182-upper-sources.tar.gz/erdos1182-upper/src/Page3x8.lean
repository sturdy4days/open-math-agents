import Intro3
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice3x48 : ((leaves3.drop 48).take 8).all test3=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice3x56 : ((leaves3.drop 56).take 2).all test3=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice3x58 : ((leaves3.drop 58).take 8).all test3=true := by decide +kernel
end E1182TwelveBlock.Word32
