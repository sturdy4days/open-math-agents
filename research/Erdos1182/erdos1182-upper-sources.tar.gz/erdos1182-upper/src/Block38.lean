import TwinRule
import ValidHost3
import WordCut38
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem blocked38 : ¬ (codeGraph 11 pat38.mask) ⊑ (triGraph 21 host3.original)ᶜ := by
  apply null_of_test host3 pat38 hostValid3 (by decide +kernel) (twins_from_types pat38 128798188439163021817215083568042 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact Word32.miss38
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked38
