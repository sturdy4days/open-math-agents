import Intro2
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x111 : ((leaves2.drop 111).take 3).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x114 : ((leaves2.drop 114).take 10).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x124 : ((leaves2.drop 124).take 3).all test2=true := by decide +kernel
end E1182TwelveBlock.Word32
