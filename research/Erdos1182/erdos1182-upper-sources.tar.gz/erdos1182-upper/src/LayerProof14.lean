import Check14_0
import Check14_10
import Check14_20
import Check14_30
import Check14_40
import Check14_50
import Check14_60
import Check14_70
import Check14_80
import Check14_90
import Check14_100
import Check14_110
import Check14_120
import Check14_130
import Check14_140
import Check14_150
import Check14_160
namespace E1182Twelve
theorem cover14_0_20 : rows l14 l15 719 b14 o14 z14 0 20 := rows_append (d:=10) (e:=10) r14_0 r14_10
theorem cover14_20_20 : rows l14 l15 719 b14 o14 z14 20 20 := rows_append (d:=10) (e:=10) r14_20 r14_30
theorem cover14_40_20 : rows l14 l15 719 b14 o14 z14 40 20 := rows_append (d:=10) (e:=10) r14_40 r14_50
theorem cover14_60_20 : rows l14 l15 719 b14 o14 z14 60 20 := rows_append (d:=10) (e:=10) r14_60 r14_70
theorem cover14_80_20 : rows l14 l15 719 b14 o14 z14 80 20 := rows_append (d:=10) (e:=10) r14_80 r14_90
theorem cover14_100_20 : rows l14 l15 719 b14 o14 z14 100 20 := rows_append (d:=10) (e:=10) r14_100 r14_110
theorem cover14_120_20 : rows l14 l15 719 b14 o14 z14 120 20 := rows_append (d:=10) (e:=10) r14_120 r14_130
theorem cover14_140_20 : rows l14 l15 719 b14 o14 z14 140 20 := rows_append (d:=10) (e:=10) r14_140 r14_150
theorem cover14_0_40 : rows l14 l15 719 b14 o14 z14 0 40 := rows_append (d:=20) (e:=20) cover14_0_20 cover14_20_20
theorem cover14_40_40 : rows l14 l15 719 b14 o14 z14 40 40 := rows_append (d:=20) (e:=20) cover14_40_20 cover14_60_20
theorem cover14_80_40 : rows l14 l15 719 b14 o14 z14 80 40 := rows_append (d:=20) (e:=20) cover14_80_20 cover14_100_20
theorem cover14_120_40 : rows l14 l15 719 b14 o14 z14 120 40 := rows_append (d:=20) (e:=20) cover14_120_20 cover14_140_20
theorem cover14_0_80 : rows l14 l15 719 b14 o14 z14 0 80 := rows_append (d:=40) (e:=40) cover14_0_40 cover14_40_40
theorem cover14_80_80 : rows l14 l15 719 b14 o14 z14 80 80 := rows_append (d:=40) (e:=40) cover14_80_40 cover14_120_40
theorem cover14_0_160 : rows l14 l15 719 b14 o14 z14 0 160 := rows_append (d:=80) (e:=80) cover14_0_80 cover14_80_80
theorem cover14_0_163 : rows l14 l15 719 b14 o14 z14 0 163 := rows_append (d:=160) (e:=3) cover14_0_160 r14_160
theorem layer14 : rows l14 l15 719 b14 o14 z14 0 163 := cover14_0_163
end E1182Twelve
