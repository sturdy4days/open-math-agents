import Descent
import ValidHost3
namespace E1182ElevenBlock
theorem leaf7_16_2 : failed host3 pat7 (atPath host3 pat7 [2,16]) = true := by
  decide +kernel

theorem leaf7_16_3 : failed host3 pat7 (atPath host3 pat7 [3,16]) = true := by
  decide +kernel

theorem leaf7_16_4 : failed host3 pat7 (atPath host3 pat7 [4,16]) = true := by
  decide +kernel

theorem leaf7_16_5 : failed host3 pat7 (atPath host3 pat7 [5,16]) = true := by
  decide +kernel

theorem leaf7_16_9 : failed host3 pat7 (atPath host3 pat7 [9,16]) = true := by
  decide +kernel

theorem leaf7_16_10 : failed host3 pat7 (atPath host3 pat7 [10,16]) = true := by
  decide +kernel

theorem leaf7_16_12 : failed host3 pat7 (atPath host3 pat7 [12,16]) = true := by
  decide +kernel

theorem leaf7_16_14 : failed host3 pat7 (atPath host3 pat7 [14,16]) = true := by
  decide +kernel

theorem leaf7_16_15 : failed host3 pat7 (atPath host3 pat7 [15,16]) = true := by
  decide +kernel

theorem leaf7_16_18 : failed host3 pat7 (atPath host3 pat7 [18,16]) = true := by
  decide +kernel

end E1182ElevenBlock
