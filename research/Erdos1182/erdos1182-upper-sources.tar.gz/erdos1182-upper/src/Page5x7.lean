import Intro5
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice5x36 : ((leaves5.drop 36).take 1).all test5=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice5x37 : ((leaves5.drop 37).take 2).all test5=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice5x39 : ((leaves5.drop 39).take 6).all test5=true := by decide +kernel
end E1182TwelveBlock.Word32
