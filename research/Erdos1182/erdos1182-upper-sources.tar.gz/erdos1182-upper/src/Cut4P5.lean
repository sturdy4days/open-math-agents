import Descent
import ValidHost1
namespace E1182ElevenBlock
theorem leaf4_3_0_0 : failed host1 pat4 (atPath host1 pat4 [0,0,3]) = true := by
  decide +kernel

theorem leaf4_3_0_4 : failed host1 pat4 (atPath host1 pat4 [4,0,3]) = true := by
  decide +kernel

theorem leaf4_3_0_5 : failed host1 pat4 (atPath host1 pat4 [5,0,3]) = true := by
  decide +kernel

theorem leaf4_3_0_6 : failed host1 pat4 (atPath host1 pat4 [6,0,3]) = true := by
  decide +kernel

theorem leaf4_3_0_8 : failed host1 pat4 (atPath host1 pat4 [8,0,3]) = true := by
  decide +kernel

theorem leaf4_3_0_9 : failed host1 pat4 (atPath host1 pat4 [9,0,3]) = true := by
  decide +kernel

theorem leaf4_3_0_10 : failed host1 pat4 (atPath host1 pat4 [10,0,3]) = true := by
  decide +kernel

theorem leaf4_3_0_13 : failed host1 pat4 (atPath host1 pat4 [13,0,3]) = true := by
  decide +kernel

theorem leaf4_3_0_14 : failed host1 pat4 (atPath host1 pat4 [14,0,3]) = true := by
  decide +kernel

theorem leaf4_3_4 : failed host1 pat4 (atPath host1 pat4 [4,3]) = true := by
  decide +kernel

end E1182ElevenBlock
