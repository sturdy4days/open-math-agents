import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf19_0_17 : failed host0 pat19 (atPath host0 pat19 [17,0]) = true := by
  decide +kernel

end E1182ElevenBlock
