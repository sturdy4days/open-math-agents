import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf19_0_3_20 : failed host0 pat19 (atPath host0 pat19 [20,3,0]) = true := by
  decide +kernel

theorem leaf19_0_4_7 : failed host0 pat19 (atPath host0 pat19 [7,4,0]) = true := by
  decide +kernel

theorem leaf19_0_4_8 : failed host0 pat19 (atPath host0 pat19 [8,4,0]) = true := by
  decide +kernel

theorem leaf19_0_4_11 : failed host0 pat19 (atPath host0 pat19 [11,4,0]) = true := by
  decide +kernel

theorem leaf19_0_4_12 : failed host0 pat19 (atPath host0 pat19 [12,4,0]) = true := by
  decide +kernel

theorem leaf19_0_4_13 : failed host0 pat19 (atPath host0 pat19 [13,4,0]) = true := by
  decide +kernel

theorem leaf19_0_4_14 : failed host0 pat19 (atPath host0 pat19 [14,4,0]) = true := by
  decide +kernel

theorem leaf19_0_4_17 : failed host0 pat19 (atPath host0 pat19 [17,4,0]) = true := by
  decide +kernel

end E1182ElevenBlock
