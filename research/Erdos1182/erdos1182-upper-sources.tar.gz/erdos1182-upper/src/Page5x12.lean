import Intro5
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice5x85 : ((leaves5.drop 85).take 1).all test5=true := by decide +kernel
end E1182TwelveBlock.Word32
