import TwinRule
import ValidHost4
import WordCut15
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem blocked15 : ¬ (codeGraph 11 pat15.mask) ⊑ (triGraph 21 host4.original)ᶜ := by
  apply null_of_test host4 pat15 hostValid4 (by decide +kernel) (twins_from_types pat15 106535404315194471425913152690218 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact Word32.miss15
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked15
