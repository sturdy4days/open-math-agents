import Intro13
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x3 : ((leaves13.drop 3).take 2).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x5 : ((leaves13.drop 5).take 2).all test13=true := by decide +kernel
end E1182TwelveBlock.Word32
