import Semantics12
open SimpleGraph E1182BitsTwelve E1182Cover
namespace E1182Twelve

theorem advance {D : SimpleGraph (Fin 12)} (forbidden : ∀ q, ¬ atlas q ⊑ Dᶜ)
    {ss ts n m tags offsets tape e : Nat} (haveRows : rows ss ts m tags offsets tape 0 n)
    (atLayer : reached D ss n e) : reached D ts m (e+1) := by
  obtain ⟨i,hi,sym,eq,sub⟩ := atLayer
  have ok := haveRows ⟨i,hi⟩
  simp only [Nat.zero_add] at ok
  exact hit_advances ok sym eq sub forbidden

theorem stop {D : SimpleGraph (Fin 12)} {ss tags n e : Nat} (finished : reached D ss n e)
    (fullSize : D.edgeSet.ncard=e) (forbidden : ∀ q, ¬ atlas q ⊑ Dᶜ) (leaf : leaves ss tags 0 n) : False := by
  obtain ⟨i,hi,hs,sz,sub⟩ := finished
  obtain ⟨iso⟩ := exact_copy sub (sz.trans fullSize.symm)
  obtain ⟨bound,disj⟩ := leaf ⟨i,hi⟩
  simp only [Nat.zero_add] at bound disj
  obtain ⟨hw,none⟩ := placed_avoids forbidden bound
  apply none
  let w := placed (field tags 16 i)
  let m := field ss 144 i
  have emb : codeGraph 12 w ⊑ (codeGraph 12 m)ᶜ := by
    refine ⟨⟨⟨id,?_⟩,Function.injective_id⟩⟩
    intro a b h
    refine ⟨h.ne,?_⟩
    intro both
    have h₁ := ((symmetric_adj hw a b).mp h).2
    have h₂ := ((symmetric_adj hs a b).mp both).2
    have ne := congrArg (fun k : Nat => k.testBit (addr a b)) disj
    simp only [neighbors,←hw a b,Bool.or_self] at h₁
    simp only [neighbors,←hs a b,Bool.or_self] at h₂
    simp only [Nat.testBit_and,Nat.zero_testBit,h₁,h₂] at ne
    contradiction
  exact emb.trans (SimpleGraph.Embedding.complEquiv iso.toEmbedding).isContained

end E1182Twelve
#print axioms E1182Twelve.advance
#print axioms E1182Twelve.stop
