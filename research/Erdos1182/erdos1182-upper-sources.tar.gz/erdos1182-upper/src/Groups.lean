import Portfolio

/-! Disjoint sets of missing hosts give a lower bound for the size of a family. -/
namespace E1182Portfolio
open SimpleGraph Finset

theorem small_subset {M B : ℕ} (T : Fin B → Finset (Fin M))
    (disj : Pairwise fun i j => Disjoint (T i)ᶜ (T j)ᶜ)
    (I : Finset (Fin M)) (small : I.card < B) : ∃ j, I ⊆ T j := by
  classical
  by_contra none
  have point (j : Fin B) : ∃ a : I, a.val ∉ T j := by
    by_contra! h
    apply none
    exact ⟨j,fun a ha => h ⟨a,ha⟩⟩
  choose f gap using point
  have inj : Function.Injective f := by
    intro a b eq
    by_contra! different
    have ha : (f a).val ∈ (T a)ᶜ := mem_compl.mpr (gap a)
    have hb : (f a).val ∈ (T b)ᶜ := by rw [eq]; exact mem_compl.mpr (gap b)
    exact Finset.disjoint_left.mp (disj different) ha hb
  have h := Fintype.card_le_of_injective f inj
  exact (show Fintype.card I < Fintype.card (Fin B) by simpa using small).not_ge h
end E1182Portfolio
#print axioms E1182Portfolio.small_subset
