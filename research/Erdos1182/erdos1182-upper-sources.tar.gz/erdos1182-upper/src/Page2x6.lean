import Intro2
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x32 : ((leaves2.drop 32).take 7).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x39 : ((leaves2.drop 39).take 3).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x42 : ((leaves2.drop 42).take 1).all test2=true := by decide +kernel
end E1182TwelveBlock.Word32
