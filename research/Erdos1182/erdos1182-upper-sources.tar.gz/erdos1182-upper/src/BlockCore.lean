import AnchoredTwelve
import Tables12

namespace E1182TwelveBlock
open SimpleGraph E1182Cover
def rank (h : Host) (i : Fin 23) : Fin 23 := Fin.ofNat 23 h.rank[i.val]!
def move (h : Host) (v i : Fin 23) : Fin 23 := Fin.ofNat 23 ((h.moves[v.val]! >>> (5*i.val)) % 32)
def allowedRoot (h : Host) (v : Fin 23) : Prop := h.root.testBit h.colours[v.val]! = true
instance (h : Host) (v : Fin 23) : Decidable (allowedRoot h v) :=
  inferInstanceAs (Decidable (_ = true))

def domains (h : Host) (p : Pattern) : List (Fin 12 × Nat) :=
  ((List.finRange 12).take p.count).map fun i => (i, if i = 0 then h.root else h.full)

structure HostValid (h : Host) : Prop where
  full : ∀ v : Fin 23, h.full.testBit h.colours[v.val]! = true
  sep : ∀ u v : Fin 23, h.colours[u.val]! ≠ h.colours[v.val]! →
    (h.apart[h.colours[u.val]!]!).testBit h.colours[v.val]! = true
  blue : ∀ u v : Fin 23, (codeGraph 23 h.canonical)ᶜ.Adj u v →
    (h.joined[h.colours[u.val]!]!).testBit h.colours[v.val]! = true
  higher : ∀ u v : Fin 23, u < v → (h.high[h.colours[u.val]!]!).testBit h.colours[v.val]! = true
  moves : ∀ v : Fin 23, Function.Injective (move h v) ∧
    (∀ i j, (codeGraph 23 h.canonical)ᶜ.Adj i j → (codeGraph 23 h.canonical)ᶜ.Adj (move h v i) (move h v j)) ∧
    allowedRoot h (move h v v)
  labels : Function.Injective (rank h) ∧ ∀ i j, (triGraph 23 h.original)ᶜ.Adj i j →
    (codeGraph 23 h.canonical)ᶜ.Adj (rank h i) (rank h j)
def consumeDomains {n : ℕ} (allowed : Fin n → Fin n → ℕ → ℕ) (apart : List ℕ)
    (i : Fin n) (v : ℕ) (remaining : List ℕ) (ds : List (Fin n × ℕ)) :=
  ds.map fun u => (u.1, let mask := u.2 &&& allowed i u.1 v
                        if remaining.contains v then mask else mask &&& apart[v]!)

def capSearch {n : ℕ} (allowed : Fin n → Fin n → ℕ → ℕ) (apart : List ℕ)
    (k : ℕ) (ds : List (Fin n × ℕ)) (supply : List ℕ) : Bool :=
  Nat.rec (motive := fun _ => List (Fin n × ℕ) → List ℕ → Bool) (fun _ _ => true)
    (fun _ rec current available => match current with
      | [] => true
      | (i,domain)::t => domain.bitIndices.any fun v =>
        available.contains v && (let remaining := available.erase v
                                 let next := consumeDomains allowed apart i v remaining t
                                 next.all (fun u => u.2 != 0) && rec next remaining)) k ds supply

def classMask {n : ℕ} (edges twins joined high : List ℕ) (full : ℕ)
    (i j : Fin n) (v : ℕ) : ℕ :=
  let mask := if edges[i.val]!.testBit j.val then joined[v]! else full
  if twins[i.val]! = twins[j.val]! ∧ i < j then mask &&& high[v]! else mask

def rejects (h : Host) (p : Pattern) : Bool :=
  capSearch (classMask p.edges p.tags h.joined h.high h.full) h.apart (domains h p).length
    (domains h p) ((List.finRange 23).map fun x => h.colours[x.val]!)

theorem null_of_test (h : Host) (p : Pattern) (hv : HostValid h)
    (pattern : ∀ i j : Fin 12, p.edges[i.val]!.testBit j.val = true → (codeGraph 12 p.mask).Adj i j)
    (twins : ∀ i j a b : Fin 12, i≠j → a≠b → p.tags[i.val]! = p.tags[a.val]! →
      p.tags[j.val]! = p.tags[b.val]! → (codeGraph 12 p.mask).Adj i j → (codeGraph 12 p.mask).Adj a b)
    (alone : ∀ i : Fin 12, p.tags[i.val]! = p.tags[0]! → i = 0)
    (nd : ((domains h p).map Prod.fst).Nodup)
    (blocked : rejects h p = false) : ¬ (codeGraph 12 p.mask) ⊑ (triGraph 23 h.original)ᶜ := by
  rintro ⟨e⟩
  let chart : Copy (triGraph 23 h.original)ᶜ (codeGraph 23 h.canonical)ᶜ :=
    ⟨⟨rank h, fun {_ _} a => hv.labels.2 _ _ a⟩,hv.labels.1⟩
  have relocate (v : Fin 23) : ∃ a : (codeGraph 23 h.canonical)ᶜ.Copy (codeGraph 23 h.canonical)ᶜ,
      allowedRoot h (a v) := by
    obtain ⟨inj,edges,home⟩ := hv.moves v
    exact ⟨⟨⟨move h v,fun {_ _} q => edges _ _ q⟩,inj⟩,home⟩
  have initial : ∀ u ∈ domains h p, ∀ j : Fin 23,
      (u.1 = 0 → allowedRoot h j) → u.2.testBit h.colours[j.val]! = true := by
    intro u hu j w
    obtain ⟨i,_,rfl⟩ := List.mem_map.mp hu
    by_cases iz : i=0
    · simpa only [if_pos iz,allowedRoot] using w iz
    · simpa only [if_neg iz] using hv.full j
  exact ruledOutFromClasses p.edges p.tags h.colours h.apart h.joined h.high h.full (domains h p)
    0 (allowedRoot h) alone relocate pattern twins hv.full hv.sep hv.blue hv.higher nd initial blocked
    ⟨chart.comp e⟩

end E1182TwelveBlock
#print axioms E1182TwelveBlock.null_of_test

namespace E1182TwelveBlock
open SimpleGraph E1182Cover

/-- Distinct vertices of the same source type have the same adjacency table.
Checking the 12-by-12 table avoids repeating the same comparison for four indices. -/
theorem twins_from_types (p : Pattern) (table : Nat)
    (typed : ∀ i j : Fin 12, i ≠ j → ((codeGraph 12 p.mask).Adj i j ↔
       table.testBit (p.tags[i.val]!*12+p.tags[j.val]!)=true)) :
    ∀ i j a b : Fin 12, i≠j → a≠b → p.tags[i.val]! = p.tags[a.val]! →
      p.tags[j.val]! = p.tags[b.val]! → (codeGraph 12 p.mask).Adj i j → (codeGraph 12 p.mask).Adj a b := by
  intro i j a b ij ab ia jb h
  have hh := (typed i j ij).mp h
  rw [ia,jb] at hh
  exact (typed a b ab).mpr hh
end E1182TwelveBlock
#print axioms E1182TwelveBlock.twins_from_types
namespace E1182TwelveBlock
def field (x w i : ℕ) := (x >>> (w*i)) % (2^w)
/-- Enumerate candidate colours using bit tests on a fixed-width machine word. -/
def anyMask (mask : ℕ) (f : ℕ → Bool) : ℕ → Bool
  | 0 => false
  | k+1 => (mask.testBit k && f k) || anyMask mask f k

theorem anyMask_complete {mask k v : ℕ} (f : ℕ → Bool) (small : v < k)
    (mem : mask.testBit v = true) (hit : f v = true) : anyMask mask f k=true := by
  induction k with
  | zero => omega
  | succ k ih =>
    rw [anyMask,Bool.or_eq_true]
    rcases Nat.lt_or_eq_of_le (Nat.le_of_lt_succ small) with lt|rfl
    · exact Or.inr (ih lt)
    · left
      simp only [mem,hit,Bool.true_and]

end E1182TwelveBlock

namespace E1182TwelveBlock

/-- Colours with two, three and four remaining copies are marked in three bit planes.
The upper plane of T contains the four-copy reserve. -/
def spareCounts (supply : List ℕ) (U T : ℕ) : Prop :=
  ∀ a : Fin 23, supply.count a.val ≤ 4 ∧
    (2 ≤ supply.count a.val → U.testBit a.val = true) ∧
    (3 ≤ supply.count a.val → T.testBit a.val = true) ∧
    (4 ≤ supply.count a.val → T.testBit (32+a.val) = true)

def consumeTwo (U T v : ℕ) : ℕ :=
  if T.testBit v || !U.testBit v then U else U ^^^ (2 ^ v)

def consumeThree (T v : ℕ) : ℕ :=
  if T.testBit (32+v) then T ^^^ (2 ^ (32+v))
  else if T.testBit v then T ^^^ (2 ^ v) else T

theorem spareCounts_erase (supply : List ℕ) (U T v : ℕ) (hv : v < 23)
    (h : spareCounts supply U T) :
    spareCounts (supply.erase v) (consumeTwo U T v) (consumeThree T v) ∧
      ((supply.erase v).contains v = true → U.testBit v = true) := by
  constructor
  · intro a
    obtain ⟨bound,two,three,four⟩ := h a
    have ha := a.isLt
    by_cases av : a.val = v
    · subst v
      simp only [List.count_erase_self]
      refine ⟨by omega, ?_, ?_, by omega⟩
      · intro hn
        have ht := three (by omega)
        simpa [consumeTwo,ht] using two (by omega)
      · intro hn
        have hf := four (by omega)
        have ne : 32+a.val ≠ a.val := by omega
        simp [consumeThree,hf,Nat.testBit_two_pow_of_ne ne,three (by omega)]
    · rw [List.count_erase_of_ne av]
      have d0 : v ≠ a.val := Ne.symm av
      have d1 : 32+v ≠ a.val := by omega
      have d2 : v ≠ 32+a.val := by omega
      have d3 : 32+v ≠ 32+a.val := by omega
      refine ⟨bound, ?_, ?_, ?_⟩
      · intro hn
        unfold consumeTwo
        split <;> simp [Nat.testBit_two_pow_of_ne d0,two hn]
      · intro hn
        unfold consumeThree
        split <;> (try split) <;> simp [Nat.testBit_two_pow_of_ne d0,Nat.testBit_two_pow_of_ne d1,three hn]
      · intro hn
        unfold consumeThree
        split <;> (try split) <;> simp [Nat.testBit_two_pow_of_ne d2,Nat.testBit_two_pow_of_ne d3,four hn]
  · intro mem
    have occ := List.count_pos_iff.mpr (List.contains_iff_mem.mp mem)
    simp only [List.count_erase_self] at occ
    apply (h ⟨v,hv⟩).2.1
    change 2 ≤ supply.count v
    omega

end E1182TwelveBlock
namespace E1182TwelveBlock.Word32

def smear : ℕ → ℕ → ℕ
  | 0, word => word
  | k+1, word => let v := smear k word; v ||| (v >>> (2^k))

theorem smear_hit {k word j a : ℕ} (small : a < 2^k) (hit : word.testBit (j+a)=true) :
    (smear k word).testBit j = true := by
  induction k generalizing j a with
  | zero =>
    have eq : a=0 := by simpa using small
    simpa [smear,eq] using hit
  | succ k ih =>
    rw [smear,Nat.testBit_or,Bool.or_eq_true]
    by_cases h : a<2^k
    · exact Or.inl (ih h hit)
    · right
      simp only [Nat.testBit_shiftRight]
      have rest : a-2^k < 2^k := by rw [pow_succ] at small; omega
      apply ih rest
      convert hit using 1
      congr 1
      omega

def guards : List (Fin 12) → Nat
  | [] => 0
  | i::t => 2^(32*i.val) ||| guards t

theorem guard_bit {t : List (Fin 12)} {a : ℕ} (h : (guards t).testBit a=true) :
    ∃ j∈t, a=32*j.val := by
  induction t with
  | nil => simp [guards] at h
  | cons i t ih =>
    rw [guards,Nat.testBit_or,Bool.or_eq_true] at h
    rcases h with h|h
    · exact ⟨i,List.mem_cons_self,by simpa [Nat.testBit_two_pow,eq_comm] using h⟩
    · obtain ⟨j,hj,eq⟩ := ih h
      exact ⟨j,List.mem_cons_of_mem _ hj,eq⟩

def plans : List (Fin 12) → List (Fin 12 × Nat)
  | [] => []
  | i::t => (i,guards t)::plans t

def present (ds : List (Fin 12 × ℕ)) (word : ℕ) : Prop :=
  ∀ u∈ds, ∀ a, u.2.testBit a=true → a<23 ∧ word.testBit (32*u.1.val+a)=true

theorem guards_pass {ds : List (Fin 12 × ℕ)} {word : ℕ} (valid : present ds word)
    (nonempty : ds.all (fun u => u.2 != 0) = true) :
    smear 5 word &&& guards (ds.map Prod.fst) = guards (ds.map Prod.fst) := by
  apply Nat.eq_of_testBit_eq
  intro a
  simp only [Nat.testBit_and]
  cases hg : (guards (ds.map Prod.fst)).testBit a with
  | false => simp
  | true =>
    obtain ⟨j,hj,rfl⟩ := guard_bit hg
    obtain ⟨u,hu,rfl⟩ := List.mem_map.mp hj
    have nonzero := bne_iff_ne.mp (List.all_eq_true.mp nonempty u hu)
    obtain ⟨x,hx⟩ := Nat.exists_testBit_of_ne_zero nonzero
    obtain ⟨bound,bit⟩ := valid u hu x hx
    have here := smear_hit (k:=5) (by omega : x < 2^5) bit
    simp [here]

end E1182TwelveBlock.Word32
#print axioms E1182TwelveBlock.Word32.guards_pass
namespace E1182TwelveBlock.Word32

def search (permit : Fin 12 → ℕ → ℕ) (apart : ℕ → ℕ) : List (Fin 12 × ℕ) → ℕ → ℕ → ℕ → Bool
  | [],_,_,_ => true
  | (i,g)::t,word,U,T => anyMask ((word >>> (32*i.val)) % (2^23)) (fun v =>
      let w := word &&& permit i v
      let w' := if U.testBit v then w else w &&& apart v
      (smear 5 w' &&& g == g) && search permit apart t w' (consumeTwo U T v) (consumeThree T v)) 23

theorem search_complete (allow : Fin 12 → Fin 12 → ℕ → ℕ) (apart : List ℕ)
    (perm : Fin 12 → ℕ → ℕ) (diff : ℕ → ℕ)
    (allowed : ∀ i j v a, v < 23 → a < 23 → (allow i j v).testBit a=true →
      (perm i v).testBit (32*j.val+a)=true)
    (separate : ∀ (j : Fin 12) (v a : ℕ), v < 23 → a < 23 → apart[v]!.testBit a=true →
      (diff v).testBit (32*j.val+a)=true)
    (k : ℕ) (ds : List (Fin 12 × ℕ)) (word U T : ℕ) (supply : List ℕ) (len : ds.length=k)
    (valid : present ds word) (stores : spareCounts supply U T)
    (success : capSearch allow apart k ds supply=true) :
    search perm diff (plans (ds.map Prod.fst)) word U T=true := by
  induction k generalizing ds word U T supply with
  | zero => simp at len; simp [len,plans,search]
  | succ k ih =>
    rcases ds with _ | ⟨⟨i,d⟩,t⟩
    · rfl
    · have tl : t.length=k := by simpa only [List.length_cons,Nat.succ.injEq] using len
      obtain ⟨v,member,pass⟩ := List.any_eq_true.mp success
      let remv := supply.erase v
      let next := consumeDomains allow apart i v remv t
      change (supply.contains v && (next.all (fun u => u.2 != 0) && capSearch allow apart k next remv))=true at pass
      simp only [Bool.and_eq_true] at pass
      obtain ⟨small,bit⟩ := valid (i,d) List.mem_cons_self v (Nat.mem_bitIndices.mp member)
      obtain ⟨store',spare⟩ := spareCounts_erase supply U T v small stores
      let w := word &&& perm i v
      let w' := if U.testBit v then w else w &&& diff v
      have step : present next w' := by
        intro x hx a ht
        obtain ⟨⟨j,b⟩,inside,rfl⟩ := List.mem_map.mp hx
        change (if remv.contains v then b &&& allow i j v else (b &&& allow i j v) &&& apart[v]!).testBit a=true at ht
        have prep : (b &&& allow i j v).testBit a=true := by
          split at ht
          · exact ht
          · rw [Nat.testBit_and,Bool.and_eq_true] at ht
            exact ht.1
        rw [Nat.testBit_and,Bool.and_eq_true] at prep
        obtain ⟨bc,ac⟩ := prep
        obtain ⟨sm,old⟩ := valid (j,b) (List.mem_cons_of_mem _ inside) a bc
        have wb : w.testBit (32*j.val+a)=true := by simp [w,old,allowed i j v a small sm ac]
        refine ⟨sm,?_⟩
        change w'.testBit (32*j.val+a)=true
        simp only [w']
        split
        · exact wb
        · rename_i zero
          have no : ¬remv.contains v=true := fun h => zero (spare h)
          simp only [if_neg no,Nat.testBit_and,Bool.and_eq_true] at ht
          simp only [Nat.testBit_and,wb,Bool.true_and]
          exact separate j v a small sm ht.2
      have eq : next.map Prod.fst=t.map Prod.fst := by simp [next,consumeDomains,List.map_map,Function.comp_def]
      have below := ih next w' (consumeTwo U T v) (consumeThree T v) remv ((List.length_map _).trans tl) step store' pass.2.2
      rw [eq] at below
      have guard := guards_pass step pass.2.1
      rw [eq] at guard
      apply anyMask_complete _ small
      · simpa only [Nat.testBit_mod_two_pow,decide_eq_true small,Bool.true_and,Nat.testBit_shiftRight] using bit
      · rw [Bool.and_eq_true]
        exact ⟨beq_iff_eq.mpr guard,below⟩

end E1182TwelveBlock.Word32
#print axioms E1182TwelveBlock.Word32.search_complete
namespace E1182TwelveBlock.Word32

def rows (f : ℕ → ℕ) : ℕ → ℕ
  | 0 => 0
  | k+1 => rows f k ||| (f k <<< (32*k))

theorem rows_has (f : ℕ → ℕ) {n j a : ℕ} (lt : j<n) (bit : (f j).testBit a=true) :
    (rows f n).testBit (32*j+a)=true := by
  induction n with
  | zero => omega
  | succ n ih =>
    rw [rows,Nat.testBit_or,Bool.or_eq_true]
    rcases Nat.lt_or_eq_of_le (Nat.le_of_lt_succ lt) with h|rfl
    · exact Or.inl (ih h)
    · right
      simpa [Nat.testBit_shiftLeft] using bit

def permit (E R J B : ℕ) (i : Fin 12) (v : ℕ) : ℕ :=
  (field E 384 i.val ||| field J 384 v) &&& (field R 384 i.val ||| field B 384 v)

def hostWords (h : Host) (J B A I U T : ℕ) : Prop :=
  (∀ v : Fin 23, field J 384 v.val=rows (fun _ => h.joined[v.val]!) 12 ∧
    field B 384 v.val=rows (fun _ => h.high[v.val]!) 12 ∧
    field A 384 v.val=rows (fun _ => h.apart[v.val]!) 12) ∧
  I=rows (fun j => if j=0 then h.root else h.full) 12 ∧ h.root < 2^23 ∧ h.full < 2^23 ∧
  spareCounts ((List.finRange 23).map (fun v : Fin 23 => h.colours[v.val]!)) U T

def sourceWords (_h : Host) (p : Pattern) (E R : ℕ) : Prop :=
  ∀ i : Fin 12, field E 384 i.val=rows (fun j => if p.edges[i.val]!.testBit j then 0 else (2^23-1)) 12 ∧
    field R 384 i.val=rows (fun j => if p.tags[i.val]! = p.tags[j]! ∧ i.val<j then 0 else (2^23-1)) 12

theorem null (h : Host) (p : Pattern) (E R J B A I U T : ℕ)
    (host : hostWords h J B A I U T) (src : sourceWords h p E R)
    (proof : search (permit E R J B) (field A 384) (plans ((List.finRange 12).take p.count)) I U T=false) : rejects h p=false := by
  apply Bool.eq_false_iff.mpr
  intro found
  obtain ⟨map,init,root,full,spare⟩ := host
  have allow (i j : Fin 12) (v a : ℕ) (hv : v<23) (wa : a<23)
      (bt : (classMask p.edges p.tags h.joined h.high h.full i j v).testBit a=true) :
      (permit E R J B i v).testBit (32*j.val+a)=true := by
    obtain ⟨white,black,_⟩ := map ⟨v,hv⟩
    obtain ⟨left,right⟩ := src i
    rw [permit,Nat.testBit_and,Bool.and_eq_true]
    let e := p.edges[i.val]!.testBit j.val=true
    let t := p.tags[i.val]! = p.tags[j.val]! ∧ i<j
    change (if t then (if e then h.joined[v]! else h.full) &&& h.high[v]! else if e then h.joined[v]! else h.full).testBit a=true at bt
    have lo (no : ¬e) : (field E 384 i.val).testBit (32*j.val+a)=true := by
      rw [left]
      apply rows_has _ j.isLt
      change (if e then 0 else 2^23-1).testBit a=true
      rw [if_neg no,Nat.testBit_two_pow_sub_one,decide_eq_true wa]
    have hi (no : ¬t) : (field R 384 i.val).testBit (32*j.val+a)=true := by
      rw [right]
      apply rows_has _ j.isLt
      change (if t then 0 else 2^23-1).testBit a=true
      rw [if_neg no,Nat.testBit_two_pow_sub_one,decide_eq_true wa]
    have leftHit : (if e then h.joined[v]! else h.full).testBit a=true := by
      by_cases yes : t
      · rw [if_pos yes,Nat.testBit_and,Bool.and_eq_true] at bt
        exact bt.1
      · rwa [if_neg yes] at bt
    constructor
    · rw [Nat.testBit_or,Bool.or_eq_true]
      by_cases yes : e
      · right
        rw [white]
        apply rows_has _ j.isLt
        rwa [if_pos yes] at leftHit
      · exact Or.inl (lo yes)
    · rw [Nat.testBit_or,Bool.or_eq_true]
      by_cases yes : t
      · right
        rw [black]
        apply rows_has _ j.isLt
        rw [if_pos yes,Nat.testBit_and,Bool.and_eq_true] at bt
        exact bt.2
      · exact Or.inl (hi yes)
  have separate (j : Fin 12) (v a : ℕ) (hv : v<23) (_ : a<23) (hit : h.apart[v]!.testBit a = true) :=
    show (field A 384 v).testBit (32*j.val+a)=true by rw [(map ⟨v,hv⟩).2.2]; exact rows_has _ j.isLt hit
  have start : present (domains h p) I := by
    intro pair hp v bit
    obtain ⟨i,_,rfl⟩ := List.mem_map.mp hp
    change (if i=0 then h.root else h.full).testBit v=true at bit
    have upper : (if i=0 then h.root else h.full)<2^23 := by split <;> assumption
    have limit : v<23 := by
      by_contra! le
      rw [Nat.testBit_lt_two_pow (upper.trans_le (Nat.pow_le_pow_right (by decide : 0<2) le))] at bit
      exact Bool.noConfusion bit
    refine ⟨limit,?_⟩
    rw [init]
    apply rows_has _ i.isLt
    simpa using bit
  have val := search_complete (classMask p.edges p.tags h.joined h.high h.full) h.apart _ _ allow separate
    (domains h p).length (domains h p) I U T _ rfl start spare found
  have eq : (domains h p).map Prod.fst=(List.finRange 12).take p.count := by simp [domains,List.map_map,Function.comp_def]
  rw [eq,proof] at val
  exact Bool.noConfusion val

end E1182TwelveBlock.Word32
namespace E1182TwelveBlock.Word32

structure Node where
  todo : List (Fin 12 × Nat)
  word : ℕ
  two : ℕ
  three : ℕ

def initial (p : Pattern) (I U T : ℕ) : Node := ⟨plans ((List.finRange 12).take p.count), I, U, T⟩

def step (P : Fin 12 → ℕ → ℕ) (D : ℕ → ℕ) (node : Node) (v : ℕ) : Node :=
  match node.todo with
  | [] => node
  | (i,_)::t =>
    let w := node.word &&& P i v
    ⟨t, if node.two.testBit v then w else w &&& D v, consumeTwo node.two node.three v, consumeThree node.three v⟩

def choices (P : Fin 12 → ℕ → ℕ) (D : ℕ → ℕ) (node : Node) : List ℕ :=
  match node.todo with
  | [] => []
  | (i,g)::_ => (List.range 23).filter fun v => node.word.testBit (32*i.val+v) &&
      (smear 5 (step P D node v).word &&& g == g)

def atPath (P : Fin 12 → ℕ → ℕ) (D : ℕ → ℕ) (root : Node) : List ℕ → Node
  | [] => root
  | v::path => step P D (atPath P D root path) v

def rejected (P : Fin 12 → ℕ → ℕ) (D : ℕ → ℕ) (n : Node) : Prop :=
  search P D n.todo n.word n.two n.three = false
instance (P : Fin 12 → ℕ → ℕ) (D : ℕ → ℕ) (n : Node) : Decidable (rejected P D n) :=
  inferInstanceAs (Decidable (_ = false))

theorem from_any {d k : ℕ} {f : ℕ → Bool} (h : anyMask d f k=true) : ∃ v<k, d.testBit v=true ∧ f v=true := by
  induction k with
  | zero => contradiction
  | succ k ih =>
    rw [anyMask,Bool.or_eq_true,Bool.and_eq_true] at h
    rcases h with h|h
    · exact ⟨k,Nat.lt_succ_self _,h⟩
    · obtain ⟨v,lt,hv⟩ := ih h
      exact ⟨v,lt.trans (Nat.lt_succ_self _),hv⟩

theorem reject_branches (P : Fin 12 → ℕ → ℕ) (D : ℕ → ℕ) (root : Node) (path next : List ℕ)
    (inside : (atPath P D root path).todo ≠ []) (all : choices P D (atPath P D root path)=next)
    (done : ∀ v∈next, rejected P D (atPath P D root (v::path))) :
    rejected P D (atPath P D root path) := by
  let n := atPath P D root path
  rw [←all] at done
  change ∀ v∈choices P D n, rejected P D (step P D n v) at done
  change n.todo≠[] at inside
  change search P D n.todo n.word n.two n.three=false
  cases eq : n.todo with
  | nil => contradiction
  | cons head t =>
    rcases head with ⟨i,g⟩
    apply Bool.eq_false_iff.mpr
    intro yes
    obtain ⟨v,small,inmask,pass⟩ := from_any yes
    simp only [Bool.and_eq_true] at pass
    have bit : n.word.testBit (32*i.val+v)=true := by
      simpa only [Nat.testBit_mod_two_pow,decide_eq_true small,Bool.true_and,Nat.testBit_shiftRight] using inmask
    have mem : v∈choices P D n := by
      rw [choices,eq]
      apply List.mem_filter.mpr
      refine ⟨List.mem_range.mpr small,?_⟩
      simp only [bit,Bool.true_and,step,eq]
      exact pass.1
    have wrong := done v mem
    unfold rejected at wrong
    simp only [step,eq] at wrong
    rw [wrong] at pass
    exact Bool.noConfusion pass.2

end E1182TwelveBlock.Word32
#print axioms E1182TwelveBlock.Word32.reject_branches

namespace E1182TwelveBlock.Word32

/-- A finite list of checked subtrees certifies its root by adding parents after all their children. -/
def collectParents (P : Fin 12 → Nat → Nat) (D : Nat → Nat) (root : Node)
    (done work : List (List Nat)) : Bool :=
  match work with
  | [] => done.contains []
  | path::remaining =>
    let n := atPath P D root path
    !n.todo.isEmpty && (choices P D n).all (fun a => done.contains (a::path)) &&
      collectParents P D root (path::done) remaining

def fails (P : Fin 12 → Nat → Nat) (D : Nat → Nat) (root : Node) (path : List Nat) : Bool :=
  decide (rejected P D (atPath P D root path))

theorem certified_frontier (P : Fin 12 → Nat → Nat) (D : Nat → Nat) (root : Node)
    (done work : List (List Nat)) (leaves : done.all (fails P D root)=true)
    (edges : collectParents P D root done work=true) : rejected P D root := by
  induction work generalizing done with
  | nil =>
    obtain has : []∈done := List.contains_iff_mem.mp edges
    have yes := List.all_eq_true.mp leaves [] has
    exact of_decide_eq_true yes
  | cons path remaining ih =>
    simp only [collectParents, Bool.and_eq_true] at edges
    obtain ⟨⟨nonempty,children⟩,tail⟩ := edges
    have inside : (atPath P D root path).todo≠[] := by
      simpa using nonempty
    have node : rejected P D (atPath P D root path) := by
      apply reject_branches P D root path _ inside rfl
      intro a ha
      have child := List.all_eq_true.mp children a ha
      have yes := List.all_eq_true.mp leaves (a::path) (List.contains_iff_mem.mp child)
      exact of_decide_eq_true yes
    apply ih (path::done) _ tail
    rw [List.all_cons,Bool.and_eq_true]
    exact ⟨decide_eq_true node, leaves⟩

theorem prepend_chunk {α : Type} {xs : List α} {f : α → Bool} {offset width : Nat}
    (chunk : ((xs.drop offset).take width).all f=true)
    (tail : (xs.drop (offset+width)).all f=true) : (xs.drop offset).all f=true := by
  have joined := List.take_append_drop width (xs.drop offset)
  rw [←joined,List.all_append,Bool.and_eq_true]
  exact ⟨chunk, by simpa only [List.drop_drop,Nat.add_comm] using tail⟩

end E1182TwelveBlock.Word32
#print axioms E1182TwelveBlock.Word32.certified_frontier
namespace E1182TwelveBlock.Word32

def spreadCells (x : Nat) : Nat :=
  let a128 := x &&& 0xffff00000000000000000000000000000000
  let w128 := (x ^^^ a128) ||| (a128 <<< 3968)
  let a64 := w128 &&& 0xffffffffffffffff0000000000000000
  let w64 := (w128 ^^^ a64) ||| (a64 <<< 1984)
  let a32 := w64 &&& 0xffffffff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ffffffff00000000
  let w32 := (w64 ^^^ a32) ||| (a32 <<< 992)
  let a16 := w32 &&& 0xffff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ffff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ffff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ffff0000
  let w16 := (w32 ^^^ a16) ||| (a16 <<< 496)
  let a8 := w16 &&& 0xff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ff00
  let w8 := (w16 ^^^ a8) ||| (a8 <<< 248)
  let a4 := w8 &&& 0xf000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000f0
  let w4 := (w8 ^^^ a4) ||| (a4 <<< 124)
  let a2 := w4 &&& 0xc0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c0000000000000000000000000000000c
  let w2 := (w4 ^^^ a2) ||| (a2 <<< 62)
  let a1 := w2 &&& 0x200000000000000020000000000000002000000000000000200000000000000020000000000000002000000000000000200000000000000020000000000000002000000000000000200000000000000020000000000000002000000000000000200000000000000020000000000000002000000000000000200000000000000020000000000000002000000000000000200000000000000020000000000000002000000000000000200000000000000020000000000000002000000000000000200000000000000020000000000000002000000000000000200000000000000020000000000000002000000000000000200000000000000020000000000000002000000000000000200000000000000020000000000000002000000000000000200000000000000020000000000000002000000000000000200000000000000020000000000000002000000000000000200000000000000020000000000000002000000000000000200000000000000020000000000000002000000000000000200000000000000020000000000000002000000000000000200000000000000020000000000000002000000000000000200000000000000020000000000000002000000000000000200000000000000020000000000000002000000000000000200000000000000020000000000000002000000000000000200000000000000020000000000000002000000000000000200000000000000020000000000000002000000000000000200000000000000020000000000000002
  let w1 := (w2 ^^^ a1) ||| (a1 <<< 31)
  w1 * 0x7fffff

end E1182TwelveBlock.Word32
