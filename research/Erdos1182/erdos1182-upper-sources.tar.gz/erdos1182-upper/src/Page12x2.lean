import Intro12
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice12x14 : ((leaves12.drop 14).take 1).all test12=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice12x15 : ((leaves12.drop 15).take 5).all test12=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice12x20 : ((leaves12.drop 20).take 1).all test12=true := by decide +kernel
end E1182TwelveBlock.Word32
