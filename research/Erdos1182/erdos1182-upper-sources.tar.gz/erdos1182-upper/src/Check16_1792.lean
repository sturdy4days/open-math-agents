import RowChecks12
namespace E1182Twelve
set_option maxHeartbeats 0 in
set_option maxRecDepth 4000 in
theorem r16_1792 : leaves l16 b16 1792 64 := by decide +kernel
end E1182Twelve
