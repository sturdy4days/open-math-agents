import Intro2
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x223 : ((leaves2.drop 223).take 2).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x225 : ((leaves2.drop 225).take 2).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x227 : ((leaves2.drop 227).take 7).all test2=true := by decide +kernel
end E1182TwelveBlock.Word32
