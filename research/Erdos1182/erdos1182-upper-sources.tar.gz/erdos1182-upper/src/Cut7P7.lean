import Descent
import ValidHost3
namespace E1182ElevenBlock
theorem leaf7_18_4 : failed host3 pat7 (atPath host3 pat7 [4,18]) = true := by
  decide +kernel

theorem leaf7_18_5 : failed host3 pat7 (atPath host3 pat7 [5,18]) = true := by
  decide +kernel

theorem leaf7_18_8 : failed host3 pat7 (atPath host3 pat7 [8,18]) = true := by
  decide +kernel

theorem leaf7_18_9 : failed host3 pat7 (atPath host3 pat7 [9,18]) = true := by
  decide +kernel

theorem leaf7_18_10 : failed host3 pat7 (atPath host3 pat7 [10,18]) = true := by
  decide +kernel

theorem leaf7_18_11 : failed host3 pat7 (atPath host3 pat7 [11,18]) = true := by
  decide +kernel

end E1182ElevenBlock
