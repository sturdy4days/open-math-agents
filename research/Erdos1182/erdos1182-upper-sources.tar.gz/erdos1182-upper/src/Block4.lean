import Cut4P0
import Cut4P1
import Cut4P2
import Cut4P3
import Cut4P4
import Cut4P5
import Cut4P6
import Cut4P7
import Cut4P8
import Cut4P9
import Descent
import Descent
import TwinRule
import ValidHost1
namespace E1182ElevenBlock
open SimpleGraph E1182Cover

private theorem leaf4_0_0 : failed host1 pat4 (atPath host1 pat4 [0,0]) = true := by
  apply failed_atPath _ _ _ [3,5,6,7,9,10,11,12,13] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf4_0_0_3
  · exact leaf4_0_0_5
  · exact leaf4_0_0_6
  · exact leaf4_0_0_7
  · exact leaf4_0_0_9
  · exact leaf4_0_0_10
  · exact leaf4_0_0_11
  · exact leaf4_0_0_12
  · exact leaf4_0_0_13

private theorem leaf4_0_3 : failed host1 pat4 (atPath host1 pat4 [3,0]) = true := by
  apply failed_atPath _ _ _ [5,6,7,9,10,11,12,13] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf4_0_3_5
  · exact leaf4_0_3_6
  · exact leaf4_0_3_7
  · exact leaf4_0_3_9
  · exact leaf4_0_3_10
  · exact leaf4_0_3_11
  · exact leaf4_0_3_12
  · exact leaf4_0_3_13

private theorem leaf4_0_5 : failed host1 pat4 (atPath host1 pat4 [5,0]) = true := by
  apply failed_atPath _ _ _ [6,7,9,10,11,12,13] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf4_0_5_6
  · exact leaf4_0_5_7
  · exact leaf4_0_5_9
  · exact leaf4_0_5_10
  · exact leaf4_0_5_11
  · exact leaf4_0_5_12
  · exact leaf4_0_5_13

private theorem leaf4_0 : failed host1 pat4 (atPath host1 pat4 [0]) = true := by
  apply failed_atPath _ _ _ [0,3,5,6,7,9,10,11,12,13] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf4_0_0
  · exact leaf4_0_3
  · exact leaf4_0_5
  · exact leaf4_0_6
  · exact leaf4_0_7
  · exact leaf4_0_9
  · exact leaf4_0_10
  · exact leaf4_0_11
  · exact leaf4_0_12
  · exact leaf4_0_13

private theorem leaf4_2_1 : failed host1 pat4 (atPath host1 pat4 [1,2]) = true := by
  apply failed_atPath _ _ _ [1,4,5,7,8,9,11,12,14] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf4_2_1_1
  · exact leaf4_2_1_4
  · exact leaf4_2_1_5
  · exact leaf4_2_1_7
  · exact leaf4_2_1_8
  · exact leaf4_2_1_9
  · exact leaf4_2_1_11
  · exact leaf4_2_1_12
  · exact leaf4_2_1_14

private theorem leaf4_2 : failed host1 pat4 (atPath host1 pat4 [2]) = true := by
  apply failed_atPath _ _ _ [1,4,5,7,8,9,11,12,14] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf4_2_1
  · exact leaf4_2_4
  · exact leaf4_2_5
  · exact leaf4_2_7
  · exact leaf4_2_8
  · exact leaf4_2_9
  · exact leaf4_2_11
  · exact leaf4_2_12
  · exact leaf4_2_14

private theorem leaf4_3_0 : failed host1 pat4 (atPath host1 pat4 [0,3]) = true := by
  apply failed_atPath _ _ _ [0,4,5,6,8,9,10,13,14] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf4_3_0_0
  · exact leaf4_3_0_4
  · exact leaf4_3_0_5
  · exact leaf4_3_0_6
  · exact leaf4_3_0_8
  · exact leaf4_3_0_9
  · exact leaf4_3_0_10
  · exact leaf4_3_0_13
  · exact leaf4_3_0_14

private theorem leaf4_3 : failed host1 pat4 (atPath host1 pat4 [3]) = true := by
  apply failed_atPath _ _ _ [0,4,5,6,8,9,10,13,14] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf4_3_0
  · exact leaf4_3_4
  · exact leaf4_3_5
  · exact leaf4_3_6
  · exact leaf4_3_8
  · exact leaf4_3_9
  · exact leaf4_3_10
  · exact leaf4_3_13
  · exact leaf4_3_14

private theorem leaf4_7_0 : failed host1 pat4 (atPath host1 pat4 [0,7]) = true := by
  apply failed_atPath _ _ _ [0,1,2,4,9,10,11,12,13] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf4_7_0_0
  · exact leaf4_7_0_1
  · exact leaf4_7_0_2
  · exact leaf4_7_0_4
  · exact leaf4_7_0_9
  · exact leaf4_7_0_10
  · exact leaf4_7_0_11
  · exact leaf4_7_0_12
  · exact leaf4_7_0_13

private theorem leaf4_7_1 : failed host1 pat4 (atPath host1 pat4 [1,7]) = true := by
  apply failed_atPath _ _ _ [1,2,4,9,10,11,12,13] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf4_7_1_1
  · exact leaf4_7_1_2
  · exact leaf4_7_1_4
  · exact leaf4_7_1_9
  · exact leaf4_7_1_10
  · exact leaf4_7_1_11
  · exact leaf4_7_1_12
  · exact leaf4_7_1_13

private theorem leaf4_7 : failed host1 pat4 (atPath host1 pat4 [7]) = true := by
  apply failed_atPath _ _ _ [0,1,2,4,9,10,11,12,13] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact leaf4_7_0
  · exact leaf4_7_1
  · exact leaf4_7_2
  · exact leaf4_7_4
  · exact leaf4_7_9
  · exact leaf4_7_10
  · exact leaf4_7_11
  · exact leaf4_7_12
  · exact leaf4_7_13

private theorem leaf4_root : failed host1 pat4 (atPath host1 pat4 []) = true := by
  apply failed_atPath _ _ _ [0,2,3,7] (by decide +kernel) (by decide +kernel)
  intro v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hv
  rcases hv with rfl | rfl | rfl | rfl
  · exact leaf4_0
  · exact leaf4_2
  · exact leaf4_3
  · exact leaf4_7

theorem blocked4 : ¬ (codeGraph 11 pat4.mask) ⊑ (triGraph 21 host1.original)ᶜ := by
  apply null_of_test host1 pat4 hostValid1 (by decide +kernel) (twins_from_types pat4 353076509173233522425551205029153042 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact rejects_of_failed_root _ _ leaf4_root
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked4
