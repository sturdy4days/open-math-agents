import TwinRule
import ValidHost5
import WordCut37
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem blocked37 : ¬ (codeGraph 11 pat37.mask) ⊑ (triGraph 21 host5.original)ᶜ := by
  apply null_of_test host5 pat37 hostValid5 (by decide +kernel) (twins_from_types pat37 490672417757408154581591664150632698 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact Word32.miss37
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked37
