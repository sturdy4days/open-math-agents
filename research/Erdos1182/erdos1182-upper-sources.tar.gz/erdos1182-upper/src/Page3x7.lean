import Intro3
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice3x45 : ((leaves3.drop 45).take 1).all test3=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice3x46 : ((leaves3.drop 46).take 1).all test3=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice3x47 : ((leaves3.drop 47).take 1).all test3=true := by decide +kernel
end E1182TwelveBlock.Word32
