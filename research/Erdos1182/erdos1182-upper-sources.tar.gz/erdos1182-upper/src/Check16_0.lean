import RowChecks12
namespace E1182Twelve
set_option maxHeartbeats 0 in
set_option maxRecDepth 4000 in
theorem r16_0 : leaves l16 b16 0 64 := by decide +kernel
end E1182Twelve
