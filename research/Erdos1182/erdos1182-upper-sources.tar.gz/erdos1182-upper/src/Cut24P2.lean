import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf24_0_4_3 : failed host0 pat24 (atPath host0 pat24 [3,4,0]) = true := by
  decide +kernel

theorem leaf24_0_4_7 : failed host0 pat24 (atPath host0 pat24 [7,4,0]) = true := by
  decide +kernel

theorem leaf24_0_4_8 : failed host0 pat24 (atPath host0 pat24 [8,4,0]) = true := by
  decide +kernel

theorem leaf24_0_4_11 : failed host0 pat24 (atPath host0 pat24 [11,4,0]) = true := by
  decide +kernel

theorem leaf24_0_4_12 : failed host0 pat24 (atPath host0 pat24 [12,4,0]) = true := by
  decide +kernel

theorem leaf24_0_4_13 : failed host0 pat24 (atPath host0 pat24 [13,4,0]) = true := by
  decide +kernel

theorem leaf24_0_4_14 : failed host0 pat24 (atPath host0 pat24 [14,4,0]) = true := by
  decide +kernel

theorem leaf24_0_4_17 : failed host0 pat24 (atPath host0 pat24 [17,4,0]) = true := by
  decide +kernel

end E1182ElevenBlock
