import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf24_0_11_7 : failed host0 pat24 (atPath host0 pat24 [7,11,0]) = true := by
  decide +kernel

theorem leaf24_0_11_8 : failed host0 pat24 (atPath host0 pat24 [8,11,0]) = true := by
  decide +kernel

theorem leaf24_0_11_10 : failed host0 pat24 (atPath host0 pat24 [10,11,0]) = true := by
  decide +kernel

theorem leaf24_0_11_12 : failed host0 pat24 (atPath host0 pat24 [12,11,0]) = true := by
  decide +kernel

theorem leaf24_0_11_14 : failed host0 pat24 (atPath host0 pat24 [14,11,0]) = true := by
  decide +kernel

theorem leaf24_0_12 : failed host0 pat24 (atPath host0 pat24 [12,0]) = true := by
  decide +kernel

theorem leaf24_0_13 : failed host0 pat24 (atPath host0 pat24 [13,0]) = true := by
  decide +kernel

theorem leaf24_0_14_1 : failed host0 pat24 (atPath host0 pat24 [1,14,0]) = true := by
  decide +kernel

end E1182ElevenBlock
