import RowChecks12
namespace E1182Twelve
set_option maxHeartbeats 0 in
set_option maxRecDepth 4000 in
theorem r10_0 : rows l10 l11 4 b10 o10 z10 0 1 := by decide +kernel
end E1182Twelve
