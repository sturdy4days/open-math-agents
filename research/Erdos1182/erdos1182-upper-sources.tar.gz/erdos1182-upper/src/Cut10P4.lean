import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf10_0_7_17 : failed host0 pat10 (atPath host0 pat10 [17,7,0]) = true := by
  decide +kernel

theorem leaf10_0_7_18 : failed host0 pat10 (atPath host0 pat10 [18,7,0]) = true := by
  decide +kernel

theorem leaf10_0_7_20 : failed host0 pat10 (atPath host0 pat10 [20,7,0]) = true := by
  decide +kernel

theorem leaf10_0_8 : failed host0 pat10 (atPath host0 pat10 [8,0]) = true := by
  decide +kernel

theorem leaf10_0_9 : failed host0 pat10 (atPath host0 pat10 [9,0]) = true := by
  decide +kernel

end E1182ElevenBlock
