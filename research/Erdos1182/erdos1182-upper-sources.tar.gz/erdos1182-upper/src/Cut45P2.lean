import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf45_0_4_18 : failed host0 pat45 (atPath host0 pat45 [18,4,0]) = true := by
  decide +kernel

theorem leaf45_0_7_8 : failed host0 pat45 (atPath host0 pat45 [8,7,0]) = true := by
  decide +kernel

theorem leaf45_0_7_10 : failed host0 pat45 (atPath host0 pat45 [10,7,0]) = true := by
  decide +kernel

theorem leaf45_0_7_11 : failed host0 pat45 (atPath host0 pat45 [11,7,0]) = true := by
  decide +kernel

theorem leaf45_0_7_14 : failed host0 pat45 (atPath host0 pat45 [14,7,0]) = true := by
  decide +kernel

theorem leaf45_0_7_17 : failed host0 pat45 (atPath host0 pat45 [17,7,0]) = true := by
  decide +kernel

theorem leaf45_0_7_18 : failed host0 pat45 (atPath host0 pat45 [18,7,0]) = true := by
  decide +kernel

theorem leaf45_0_7_20 : failed host0 pat45 (atPath host0 pat45 [20,7,0]) = true := by
  decide +kernel

end E1182ElevenBlock
