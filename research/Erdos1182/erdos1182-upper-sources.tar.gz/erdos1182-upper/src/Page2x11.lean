import Intro2
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x61 : ((leaves2.drop 61).take 3).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x64 : ((leaves2.drop 64).take 6).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x70 : ((leaves2.drop 70).take 1).all test2=true := by decide +kernel
end E1182TwelveBlock.Word32
