import Mathlib.Data.Finset.Sort
import Mathlib.Data.List.Perm.Subperm
import Mathlib.Data.Nat.BitIndices
import Mathlib.Tactic.IntervalCases
import Mathlib.Combinatorics.SimpleGraph.Copy
import Mathlib.Combinatorics.SimpleGraph.Finite
open SimpleGraph Finset
namespace E1182TwelveBlock
theorem sorted_copy {n m : ℕ} {S : SimpleGraph (Fin n)} {H : SimpleGraph (Fin m)}
    (b : Fin n → ℕ)
    (twins : ∀ i j i' j' : Fin n, i ≠ j → i' ≠ j' → b i = b i' → b j = b j' →
      S.Adj i j → S.Adj i' j')
    (root : Fin n) (alone : ∀ i, b i = b root → i = root) (f : S.Copy H) :
    ∃ e : S.Copy H, (∀ i j, b i = b j → i < j → e i < e j) ∧ e root = f root := by
  classical
  let cell (t : ℕ) := Finset.univ.filter fun i : Fin n => b i = t
  let target (t : ℕ) := (cell t).map f.toEmbedding
  let p (t : ℕ) : cell t ≃o target t :=
    ((cell t).orderIsoOfFin rfl).symm.trans ((target t).orderIsoOfFin (Finset.card_map _))
  let v (i : Fin n) : Fin m := (p (b i) ⟨i,by simp [cell]⟩).val
  have value (i : Fin n) (t : ℕ) (hi : b i = t) :
      v i = (p t ⟨i,by simp [cell,hi]⟩).val := by subst t; rfl
  have increasing (i j : Fin n) (same : b i = b j) (lt : i < j) : v i < v j := by
    rw [value i (b j) same,value j (b j) rfl]
    exact (p (b j)).strictMono lt
  have inverse (i : Fin n) : ∃ u : Fin n, b u = b i ∧ f u = v i := by
    have mem : v i ∈ target (b i) := (p (b i) ⟨i,by simp [cell]⟩).property
    obtain ⟨u,hu,eq⟩ := Finset.mem_map.mp mem
    exact ⟨u,(Finset.mem_filter.mp hu).2,eq⟩
  have inj : Function.Injective v := by
    intro i j eq
    obtain ⟨a,ha,hai⟩ := inverse i
    obtain ⟨c,hc,hcj⟩ := inverse j
    have h : a = c := f.injective (hai.trans (eq.trans hcj.symm))
    have same : b i = b j := ha.symm.trans ((congrArg b h).trans hc)
    rcases lt_trichotomy i j with lt | yes | gt
    · exact ((increasing i j same lt).ne eq).elim
    · exact yes
    · exact ((increasing j i same.symm gt).ne eq.symm).elim
  have fixed : v root = f root := by
    obtain ⟨a,ha,eq⟩ := inverse root
    exact eq.symm.trans (congrArg f (alone a ha))
  refine ⟨⟨⟨v,?_⟩,inj⟩,increasing,fixed⟩
  intro i j adj
  obtain ⟨a,ha,hai⟩ := inverse i
  obtain ⟨c,hc,hcj⟩ := inverse j
  have ne : a ≠ c := fun eq => adj.ne (inj (hai.symm.trans ((congrArg f eq).trans hcj)))
  rw [←hai,←hcj]
  exact f.toHom.map_rel' (twins i j a c adj.ne ne ha.symm hc.symm adj)

set_option maxRecDepth 90000 in
set_option maxHeartbeats 0 in
theorem ruledOutFromClasses {n m : ℕ} {S : SimpleGraph (Fin n)} {H : SimpleGraph (Fin m)}
    (edges tags colours apart joined high : List ℕ) (full : ℕ) (ds : List (Fin n × ℕ))
      (root : Fin n) (home : Fin m → Prop)
      (alone : ∀ i : Fin n, tags[i.val]! = tags[root.val]! → i = root)
      (move : ∀ v : Fin m, ∃ a : H.Copy H, home (a v))
      (pattern : ∀ i j : Fin n, edges[i.val]!.testBit j.val = true → S.Adj i j)
      (twins : ∀ i j a b : Fin n, i≠j → a≠b → tags[i.val]! = tags[a.val]! →
        tags[j.val]! = tags[b.val]! → S.Adj i j → S.Adj a b)
      (all : ∀ v : Fin m, full.testBit colours[v.val]! = true)
      (other : ∀ u v : Fin m, colours[u.val]! ≠ colours[v.val]! →
        (apart[colours[u.val]!]!).testBit colours[v.val]! = true)
      (blue : ∀ u v : Fin m, H.Adj u v →
        (joined[colours[u.val]!]!).testBit colours[v.val]! = true)
      (higher : ∀ u v : Fin m, u < v → (high[colours[u.val]!]!).testBit colours[v.val]! = true)
      (nd : (ds.map Prod.fst).Nodup)
      (initial : ∀ u ∈ ds, ∀ j : Fin m, (u.1 = root → home j) → u.2.testBit colours[j.val]! = true) :
  let consumeDomains {n : ℕ} (allowed : Fin n → Fin n → ℕ → ℕ) (apart : List ℕ)
      (i : Fin n) (v : ℕ) (remaining : List ℕ) (ds : List (Fin n × ℕ)) :=
    ds.map fun u => (u.1, let mask := u.2 &&& allowed i u.1 v
                          if remaining.contains v then mask else mask &&& apart[v]!)

  let capSearch {n : ℕ} (allowed : Fin n → Fin n → ℕ → ℕ) (apart : List ℕ)
      (k : ℕ) (ds : List (Fin n × ℕ)) (supply : List ℕ) : Bool :=
    Nat.rec (motive := fun _ => List (Fin n × ℕ) → List ℕ → Bool) (fun _ _ => true)
      (fun _ rec current available => match current with
        | [] => true
        | (i,domain)::t => domain.bitIndices.any fun v =>
          available.contains v && (let remaining := available.erase v
                                   let next := consumeDomains allowed apart i v remaining t
                                   next.all (fun u => u.2 != 0) && rec next remaining)) k ds supply

  let classMask {n : ℕ} (edges twins joined high : List ℕ) (full : ℕ)
      (i j : Fin n) (v : ℕ) : ℕ :=
    let mask := if edges[i.val]!.testBit j.val then joined[v]! else full
    if twins[i.val]! = twins[j.val]! ∧ i < j then mask &&& high[v]! else mask
  (block : capSearch (classMask edges tags joined high full) apart ds.length ds
    ((List.finRange m).map fun x => colours[x.val]!) = false) → ¬ S ⊑ H := by
  intro consumeDomains capSearch classMask block
  have capSearch_complete {n : ℕ} (f : Fin n → ℕ) (allowed : Fin n → Fin n → ℕ → ℕ)
      (apart : List ℕ) (distinct : ∀ i j, f i ≠ f j → (apart[f i]!).testBit (f j) = true)
      (consistent : ∀ i j, i ≠ j → (allowed i j (f i)).testBit (f j) = true)
      (k : ℕ) (ds : List (Fin n × ℕ)) (supply : List ℕ)
      (nodup : (ds.map Prod.fst).Nodup)
      (enough : ∀ c, (ds.map (fun u => f u.1)).count c ≤ supply.count c)
      (valid : ∀ u ∈ ds, u.2.testBit (f u.1) = true) :
      capSearch allowed apart k ds supply = true := by
    induction k generalizing ds supply with
    | zero => rfl
    | succ k ih =>
      cases ds with
      | nil => rfl
      | cons q t =>
        obtain ⟨i,d⟩ := q
        let v := f i
        let remaining := supply.erase v
        let next := consumeDomains allowed apart i v remaining t
        simp only [List.map_cons,List.nodup_cons] at nodup
        have count_le (c : ℕ) : (t.map (fun u => f u.1)).count c ≤ remaining.count c := by
          have h := enough c
          change (v :: t.map (fun u => f u.1)).count c ≤ supply.count c at h
          by_cases eq : v=c
          · subst c
            rw [List.count_cons_self] at h
            simpa only [remaining,List.count_erase_self] using Nat.le_sub_one_of_lt h
          · change _ ≤ (supply.erase v).count c
            simpa [List.count_cons, eq, Ne.symm eq] using h
        have hv : v ∈ supply := by
          apply List.count_pos_iff.mp
          have h := enough v
          change (v :: t.map (fun u => f u.1)).count v ≤ supply.count v at h
          rw [List.count_cons_self] at h
          exact (Nat.zero_lt_succ _).trans_le h
        have good : ∀ u ∈ next, u.2.testBit (f u.1) = true := by
          intro u hu
          obtain ⟨⟨j,s⟩,ht,rfl⟩ := List.mem_map.mp hu
          have hj : i ≠ j := by
            intro e
            exact nodup.1 (List.mem_map.mpr ⟨(j,s),ht,e.symm⟩)
          have hd : s.testBit (f j)=true := valid (j,s) (List.mem_cons_of_mem _ ht)
          have hc := consistent i j hj
          change (if remaining.contains v then (s &&& allowed i j v) else (s &&& allowed i j v &&& apart[v]!)).testBit (f j) = true
          by_cases live : remaining.contains v = true
          · rw [if_pos live,Nat.testBit_and,hd,hc]; rfl
          · have diff : v ≠ f j := by
              intro eq
              have mem : f j ∈ t.map (fun u => f u.1) := List.mem_map.mpr ⟨(j,s),ht,rfl⟩
              have pos := (List.count_pos_iff.mpr mem).trans_le (count_le (f j))
              exact live (List.contains_iff_mem.mpr (eq ▸ List.count_pos_iff.mp pos))
            rw [if_neg live,Nat.testBit_and,Nat.testBit_and,hd,hc,distinct i j diff]; rfl
        have fst : next.map Prod.fst = t.map Prod.fst := by
          simp [next,consumeDomains,List.map_map,Function.comp_def]
        have imgs : next.map (fun u => f u.1) = t.map (fun u => f u.1) := by
          simp [next,consumeDomains,List.map_map,Function.comp_def]
        have nz : next.all (fun u => u.2 != 0) = true := by
          apply List.all_eq_true.mpr
          intro u hu
          apply bne_iff_ne.mpr
          intro e
          have h := good u hu
          simp [e] at h
        apply List.any_eq_true.mpr
        refine ⟨v,Nat.mem_bitIndices.mpr (valid (i,d) List.mem_cons_self),?_⟩
        change (supply.contains v && (next.all _ && capSearch allowed apart k next remaining))=true
        rw [List.contains_iff_mem.mpr hv,nz,ih next remaining (fst ▸ nodup.2) (imgs ▸ count_le) good]
        rfl

  have ruledOut {n m : ℕ} {S : SimpleGraph (Fin n)} {H : SimpleGraph (Fin m)}
      (edges tags colours apart joined high : List ℕ) (full : ℕ) (ds : List (Fin n × ℕ))
      (root : Fin n) (home : Fin m → Prop)
      (alone : ∀ i : Fin n, tags[i.val]! = tags[root.val]! → i = root)
      (move : ∀ v : Fin m, ∃ a : H.Copy H, home (a v))
      (pattern : ∀ i j : Fin n, edges[i.val]!.testBit j.val = true → S.Adj i j)
      (twins : ∀ i j a b : Fin n, i≠j → a≠b → tags[i.val]! = tags[a.val]! →
        tags[j.val]! = tags[b.val]! → S.Adj i j → S.Adj a b)
      (all : ∀ v : Fin m, full.testBit colours[v.val]! = true)
      (other : ∀ u v : Fin m, colours[u.val]! ≠ colours[v.val]! →
        (apart[colours[u.val]!]!).testBit colours[v.val]! = true)
      (blue : ∀ u v : Fin m, H.Adj u v →
        (joined[colours[u.val]!]!).testBit colours[v.val]! = true)
      (higher : ∀ u v : Fin m, u < v → (high[colours[u.val]!]!).testBit colours[v.val]! = true)
      (nd : (ds.map Prod.fst).Nodup)
      (initial : ∀ u ∈ ds, ∀ j : Fin m, (u.1 = root → home j) → u.2.testBit colours[j.val]! = true)
      (block : capSearch (classMask edges tags joined high full) apart ds.length ds
        ((List.finRange m).map fun x => colours[x.val]!) = false) : ¬ S ⊑ H := by
    rintro ⟨f₀⟩
    obtain ⟨a,atRoot⟩ := move (f₀ root)
    obtain ⟨e,sort,fixed⟩ := sorted_copy (fun i => tags[i.val]!) twins root alone (a.comp f₀)
    have inhab : home (e root) := fixed ▸ atRoot
    let f (i : Fin n) := colours[(e i).val]!
    have agree (i j : Fin n) (_ne : i≠j) :
        (classMask edges tags joined high full i j (f i)).testBit (f j) = true := by
      have a : (if edges[i.val]!.testBit j.val then joined[f i]! else full).testBit (f j) = true := by
        split
        next h => exact blue (e i) (e j) (e.toHom.map_rel' (pattern i j h))
        next => exact all _
      dsimp only [classMask]
      split
      next cond => exact (Nat.testBit_and ..).trans (by rw [a, higher _ _ (sort i j cond.1 cond.2)]; rfl)
      next => exact a
    have used : ((ds.map Prod.fst).map e).Subperm (List.finRange m) :=
      (nd.map e.injective).subperm (by intro x _; simp)
    obtain ⟨t,perm,sub⟩ := List.subperm_iff.mp used
    let c (x : Fin m) := colours[x.val]!
    have projected : (((ds.map Prod.fst).map e).map c).Subperm ((List.finRange m).map c) :=
      List.subperm_iff.mpr ⟨t.map c,perm.map c,sub.map c⟩
    have enough := List.subperm_iff_count.mp projected
    have ok := capSearch_complete f _ apart (fun i j h => other (e i) (e j) h)
      agree ds.length ds ((List.finRange m).map c) nd
      (by simpa [f,c,List.map_map,Function.comp_def] using enough)
      (fun u hu => initial u hu (e u.1) (fun eq => eq ▸ inhab))
    rw [block] at ok
    contradiction
  exact ruledOut edges tags colours apart joined high full ds root home alone move pattern twins all other blue higher nd initial block
end E1182TwelveBlock
#print axioms E1182TwelveBlock.sorted_copy
#print axioms E1182TwelveBlock.ruledOutFromClasses
