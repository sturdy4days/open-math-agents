import Intro10
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice10x18 : ((leaves10.drop 18).take 2).all test10=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice10x20 : ((leaves10.drop 20).take 1).all test10=true := by decide +kernel
end E1182TwelveBlock.Word32
