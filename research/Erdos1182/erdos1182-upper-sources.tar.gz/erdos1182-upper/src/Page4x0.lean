import Intro4
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice4x0 : ((leaves4.drop 0).take 1).all test4=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice4x1 : ((leaves4.drop 1).take 1).all test4=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice4x2 : ((leaves4.drop 2).take 1).all test4=true := by decide +kernel
end E1182TwelveBlock.Word32
