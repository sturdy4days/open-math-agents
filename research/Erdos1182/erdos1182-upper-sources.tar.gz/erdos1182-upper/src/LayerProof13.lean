import Check13_0
import Check13_10
import Check13_20
import Check13_30
import Check13_40
namespace E1182Twelve
theorem cover13_0_20 : rows l13 l14 163 b13 o13 z13 0 20 := rows_append (d:=10) (e:=10) r13_0 r13_10
theorem cover13_20_20 : rows l13 l14 163 b13 o13 z13 20 20 := rows_append (d:=10) (e:=10) r13_20 r13_30
theorem cover13_0_40 : rows l13 l14 163 b13 o13 z13 0 40 := rows_append (d:=20) (e:=20) cover13_0_20 cover13_20_20
theorem cover13_0_43 : rows l13 l14 163 b13 o13 z13 0 43 := rows_append (d:=40) (e:=3) cover13_0_40 r13_40
theorem layer13 : rows l13 l14 163 b13 o13 z13 0 43 := cover13_0_43
end E1182Twelve
