import Intro13
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x128 : ((leaves13.drop 128).take 2).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x130 : ((leaves13.drop 130).take 3).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x133 : ((leaves13.drop 133).take 3).all test13=true := by decide +kernel
end E1182TwelveBlock.Word32
