import Lean.Elab.Tactic.Omega

namespace E1182Bits
def exchange (x mask shift : Nat) : Nat :=
  let d := (x ^^^ (x >>> shift)) &&& mask
  x ^^^ d ^^^ (d <<< shift)

/-- Exchange disjoint sets of equally-spaced bit positions in parallel. -/
theorem testBit_exchange (x mask shift k : Nat)
    (disjoint : mask.testBit k = true → shift ≤ k → mask.testBit (k-shift) = false) :
    (exchange x mask shift).testBit k =
      if mask.testBit k then x.testBit (shift+k)
      else if shift ≤ k ∧ mask.testBit (k-shift) then x.testBit (k-shift) else x.testBit k := by
  simp only [exchange, Nat.testBit_xor, Nat.testBit_shiftLeft, Nat.testBit_and, Nat.testBit_shiftRight]
  by_cases bound : shift ≤ k
  · have back : shift + (k-shift) = k := by omega
    rw [back]
    cases lo : mask.testBit k <;> cases hi : mask.testBit (k-shift) <;>
      cases x.testBit (shift+k) <;> cases x.testBit k <;> cases x.testBit (k-shift) <;>
      simp_all
  · have neg : decide (shift ≤ k) = false := decide_eq_false bound
    simp only [neg, Bool.false_and, Bool.xor_false]
    cases lo : mask.testBit k <;> cases x.testBit k <;> cases x.testBit (shift+k) <;>
      simp [bound]

end E1182Bits
#print axioms E1182Bits.testBit_exchange
