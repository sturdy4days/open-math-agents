import Descent
import ValidHost1
namespace E1182ElevenBlock
theorem leaf4_0_5_10 : failed host1 pat4 (atPath host1 pat4 [10,5,0]) = true := by
  decide +kernel

theorem leaf4_0_5_11 : failed host1 pat4 (atPath host1 pat4 [11,5,0]) = true := by
  decide +kernel

theorem leaf4_0_5_12 : failed host1 pat4 (atPath host1 pat4 [12,5,0]) = true := by
  decide +kernel

theorem leaf4_0_5_13 : failed host1 pat4 (atPath host1 pat4 [13,5,0]) = true := by
  decide +kernel

theorem leaf4_0_6 : failed host1 pat4 (atPath host1 pat4 [6,0]) = true := by
  decide +kernel

theorem leaf4_0_7 : failed host1 pat4 (atPath host1 pat4 [7,0]) = true := by
  decide +kernel

theorem leaf4_0_9 : failed host1 pat4 (atPath host1 pat4 [9,0]) = true := by
  decide +kernel

theorem leaf4_0_10 : failed host1 pat4 (atPath host1 pat4 [10,0]) = true := by
  decide +kernel

theorem leaf4_0_11 : failed host1 pat4 (atPath host1 pat4 [11,0]) = true := by
  decide +kernel

theorem leaf4_0_12 : failed host1 pat4 (atPath host1 pat4 [12,0]) = true := by
  decide +kernel

end E1182ElevenBlock
