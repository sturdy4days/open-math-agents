import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf22_0_13 : failed host0 pat22 (atPath host0 pat22 [13,0]) = true := by
  decide +kernel

theorem leaf22_0_14 : failed host0 pat22 (atPath host0 pat22 [14,0]) = true := by
  decide +kernel

theorem leaf22_0_17 : failed host0 pat22 (atPath host0 pat22 [17,0]) = true := by
  decide +kernel

end E1182ElevenBlock
