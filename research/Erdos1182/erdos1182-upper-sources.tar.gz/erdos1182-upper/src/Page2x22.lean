import Intro2
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x164 : ((leaves2.drop 164).take 3).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x167 : ((leaves2.drop 167).take 4).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x171 : ((leaves2.drop 171).take 7).all test2=true := by decide +kernel
end E1182TwelveBlock.Word32
