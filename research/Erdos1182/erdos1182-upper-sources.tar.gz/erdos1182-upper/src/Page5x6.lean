import Intro5
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice5x34 : ((leaves5.drop 34).take 1).all test5=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice5x35 : ((leaves5.drop 35).take 1).all test5=true := by decide +kernel
end E1182TwelveBlock.Word32
