import GlueTen
import FirstTwelve
import Close12
namespace E1182Twelve
open SimpleGraph E1182Cover E1182BitsTwelve

def triGraph (h mask : ℕ) : SimpleGraph (Fin h) where
  Adj i j := i≠j ∧ mask.testBit ((max i j).val.choose 2+(min i j).val)=true
  symm := ⟨fun i j e => ⟨e.1.symm,by simpa only [min_comm j i,max_comm j i] using e.2⟩⟩
  loopless := ⟨fun i e => e.1 rfl⟩

instance (h mask : Nat) : DecidableRel (triGraph h mask).Adj :=
  fun _ _ => inferInstanceAs (Decidable (_≠_ ∧ _=true))

def masks : List Nat := [0x1f0078f803cf803df007fc01e1f001f003e00f807c003c0781e0f0f01e7bfc0,0x15402ad500aaa8056a8055500b5402aa01aa015405502a82a855154aaab556ad,0x980192600653003130032600698014c004c00980260130130260984c4c9a512,0x914a1386185108a4308c1022c86188168d102a2148904630c2494281d0a4873,0xa0c30e8a50821862a114d022c16819442d102a2148904630c2494281d0a4873,0x6c30c4d0a51091253440c310c81681861d102a2148904630c2494281d0a4873,0x660a992805aa22340c0808a41024c50724808545904048a115126182d64418,0xa1106c0984e4408060650a165e02a01953428300c30140455959a04a01a8204,0x1852522525259494b494925252252594949293252494a4a64a49525929324a65,0x1ac0b4290a509aa0494a14350d81681681d502a2140904620c2496881d0a4873]
def extras : List Nat := [0x15402ad500aaa8056a8055500b5402aa01aa015405502a82a855154aaab556ad,0x980192600653003130032600698014c004c00980260130130260984c4c9a512,0x914a1386185108a4308c1022c86188168d102a2148904630c2494281d0a4873,0xa0c30e8a50821862a114d022c16819442d102a2148904630c2494281d0a4873,0x6c30c4d0a51091253440c310c81681861d102a2148904630c2494281d0a4873,0x660a992805aa22340c0808a41024c50724808545904048a115126182d64418,0xa1106c0984e4408060650a165e02a01953428300c30140455959a04a01a8204,0x1852522525259494b494925252252594949293252494a4a64a49525929324a65,0x1ac0b4290a509aa0494a14350d81681681d502a2140904620c2496881d0a4873]

theorem first_matches : codeGraph 23 40985474950844763926564131426557755203912057542345515927787833703577696920095796140223645013612874172055202285572651784863984 = triGraph 23 0x1f0078f803cf803df007fc01e1f001f003e00f807c003c0781e0f0f01e7bfc0 := by
  ext i j
  exact (show ∀ i j : Fin 23, (codeGraph 23 40985474950844763926564131426557755203912057542345515927787833703577696920095796140223645013612874172055202285572651784863984).Adj i j ↔ (triGraph 23 0x1f0078f803cf803df007fc01e1f001f003e00f807c003c0781e0f0f01e7bfc0).Adj i j by decide +kernel) i j

theorem red_card {G : SimpleGraph (Fin 12)} (h : G.edgeSet.ncard=50) :
    Gᶜ.edgeSet.ncard=16 := by
  classical
  have dis : Disjoint G.edgeSet Gᶜ.edgeSet := disjoint_edgeSet.mpr disjoint_compl_right
  have edge := Set.ncard_union_eq dis (Set.toFinite _) (Set.toFinite _)
  have topSize : (⊤ : SimpleGraph (Fin 12)).edgeSet.ncard = 66 := by
    calc
      _ = (⊤ : SimpleGraph (Fin 12)).edgeFinset.card := Set.ncard_eq_toFinset_card' _
      _ = (Fintype.card (Fin 12)).choose 2 := card_edgeFinset_top_eq_card_choose_two
      _ = 66 := by decide
  rw [←edgeSet_sup,sup_compl_eq_top,topSize] at edge
  omega

theorem no_common
    (q10 : rows l10 l11 4 b10 o10 z10 0 1)
    (q11 : rows l11 l12 13 b11 o11 z11 0 4)
    (q12 : rows l12 l13 43 b12 o12 z12 0 13)
    (q13 : rows l13 l14 163 b13 o13 z13 0 43)
    (q14 : rows l14 l15 719 b14 o14 z14 0 163)
    (q15 : rows l15 l16 3130 b15 o15 z15 0 719)
    (q16 : leaves l16 b16 0 3130)
    (blocked : ∀ q : Fin 15, ¬ atlas q ⊑ (E1182TwelveBlock.triGraph 23 E1182TwelveBlock.selectedMasks[q.val]!)ᶜ)
    (G : SimpleGraph (Fin 12)) (hG : G.edgeSet.ncard=50) :
    ∃ m∈masks, ¬ G ⊑ (triGraph 23 m)ᶜ := by
  classical
  by_contra! h
  obtain ⟨f⟩ := h 0x1f0078f803cf803df007fc01e1f001f003e00f807c003c0781e0f0f01e7bfc0 (List.mem_cons_self)
  have hr := red_card hG
  have pull : ∀ i j, (codeGraph 23 40985474950844763926564131426557755203912057542345515927787833703577696920095796140223645013612874172055202285572651784863984).Adj (f i) (f j) → Gᶜ.Adj i j := by
    rw [first_matches]
    intro i j edge
    exact ⟨fun he => edge.ne (congrArg f he),fun bad => (f.toHom.map_rel' bad).2 edge⟩
  have avoid (q : Fin 15) : ¬ atlas q ⊑ (Gᶜ)ᶜ := by
    intro bad
    have mem : ∀ j : Fin 15, E1182TwelveBlock.selectedMasks[j.val]! ∈ masks := by decide +kernel
    apply blocked q
    have embed := h _ (mem q)
    have eq : triGraph 23 E1182TwelveBlock.selectedMasks[q.val]! = E1182TwelveBlock.triGraph 23 E1182TwelveBlock.selectedMasks[q.val]! := by ext; rfl
    rw [←eq]
    exact (by simpa using bad : atlas q ⊑ G).trans embed
  exact closes q10 q11 q12 q13 q14 q15 q16 hr avoid (from_first_host_twelve Gᶜ hr f.toEmbedding pull)

theorem fixed_twelve
    (q10 : rows l10 l11 4 b10 o10 z10 0 1)
    (q11 : rows l11 l12 13 b11 o11 z11 0 4)
    (q12 : rows l12 l13 43 b12 o12 z12 0 13)
    (q13 : rows l13 l14 163 b13 o13 z13 0 43)
    (q14 : rows l14 l15 719 b14 o14 z14 0 163)
    (q15 : rows l15 l16 3130 b15 o15 z15 0 719)
    (q16 : leaves l16 b16 0 3130)
    (blocked : ∀ q : Fin 15, ¬ atlas q ⊑ (E1182TwelveBlock.triGraph 23 E1182TwelveBlock.selectedMasks[q.val]!)ᶜ) :
    let ms := [0x1f0078f803cf803df007fc01e1f001f003e00f807c003c0781e0f0f01e7bfc0,0x15402ad500aaa8056a8055500b5402aa01aa015405502a82a855154aaab556ad,0x980192600653003130032600698014c004c00980260130130260984c4c9a512,0x914a1386185108a4308c1022c86188168d102a2148904630c2494281d0a4873,0xa0c30e8a50821862a114d022c16819442d102a2148904630c2494281d0a4873,0x6c30c4d0a51091253440c310c81681861d102a2148904630c2494281d0a4873,0x660a992805aa22340c0808a41024c50724808545904048a115126182d64418,0xa1106c0984e4408060650a165e02a01953428300c30140455959a04a01a8204,0x1852522525259494b494925252252594949293252494a4a64a49525929324a65,0x1ac0b4290a509aa0494a14350d81681681d502a2140904620c2496881d0a4873]
    let C (a : Fin ms.length) : SimpleGraph (Fin 23) := triGraph 23 ms[a.val]
    ∀ f : Fin ms.length → Fin 12 ↪ Fin 23, (⨅ a, (C a)ᶜ.comap (f a)).edgeSet.ncard ≤ 49 := by
  classical
  intro _ms _C f
  let D := ⨅ a : Fin masks.length, (triGraph 23 (masks[a.val]))ᶜ.comap (f a)
  change D.edgeSet.ncard ≤ 49
  by_contra! big
  obtain ⟨G,sub,sz⟩ := trim_edges D (q:=50) (by omega)
  obtain ⟨m,hm,notIn⟩ := no_common q10 q11 q12 q13 q14 q15 q16 blocked G sz
  obtain ⟨i,hi,rfl⟩ := List.getElem_of_mem hm
  let a : Fin masks.length := ⟨i,hi⟩
  exact notIn (isContained_iff_exists_le_comap.mpr ⟨f a,sub.trans (iInf_le _ a)⟩)

end E1182Twelve
#print axioms E1182Twelve.fixed_twelve
