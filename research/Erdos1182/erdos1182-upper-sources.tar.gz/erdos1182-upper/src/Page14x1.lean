import Intro14
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice14x2 : ((leaves14.drop 2).take 4).all test14=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice14x6 : ((leaves14.drop 6).take 1).all test14=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice14x7 : ((leaves14.drop 7).take 1).all test14=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice14x8 : ((leaves14.drop 8).take 1).all test14=true := by decide +kernel
end E1182TwelveBlock.Word32
