import Intro3
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice3x0 : ((leaves3.drop 0).take 1).all test3=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice3x1 : ((leaves3.drop 1).take 1).all test3=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice3x2 : ((leaves3.drop 2).take 4).all test3=true := by decide +kernel
end E1182TwelveBlock.Word32
