import Descent
import ValidHost3
namespace E1182ElevenBlock
theorem leaf7_1_0 : failed host3 pat7 (atPath host3 pat7 [0,1]) = true := by
  decide +kernel

theorem leaf7_1_2 : failed host3 pat7 (atPath host3 pat7 [2,1]) = true := by
  decide +kernel

theorem leaf7_1_3 : failed host3 pat7 (atPath host3 pat7 [3,1]) = true := by
  decide +kernel

end E1182ElevenBlock
