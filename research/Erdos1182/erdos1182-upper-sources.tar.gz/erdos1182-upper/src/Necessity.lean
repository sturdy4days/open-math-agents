import Catalogue11
import Catalogue12

/-! Necessary catalogue members in every family enforcing the target edge bound. -/
namespace E1182Portfolio
open SimpleGraph

theorem hits_each_gap {n h M B q : ℕ} (C : Fin M → SimpleGraph (Fin h))
    (T : Fin B → Finset (Fin M))
    (examples : ∀ j, ∃ G : SimpleGraph (Fin n), G.Connected ∧ q+1 ≤ G.edgeSet.ncard ∧
      ∀ a ∈ T j, G ⊑ (C a)ᶜ) (I : Finset (Fin M))
    (bounds : ∀ f : ∀ _a : I, Fin n ↪ Fin h, let D := ⨅ a : I, (C a.val)ᶜ.comap (f a)
      D.Connected → D.edgeSet.ncard ≤ q) (j : Fin B) : ∃ a ∈ I, a ∉ T j := by
  classical
  by_contra! h
  obtain ⟨G,con,count,within⟩ := examples j
  let f (a : I) := (within a.val (h _ a.property)).some
  have sub : G ≤ ⨅ a : I, (C a.val)ᶜ.comap (f a).toEmbedding :=
    le_iInf fun a {_ _} edge => (f a).toHom.map_rel' edge
  exact (Nat.not_succ_le_self q) ((count.trans (Set.ncard_le_ncard (edgeSet_subset_edgeSet.mpr sub))).trans
    (bounds (fun a => (f a).toEmbedding) (con.mono sub)))

theorem forced11 (I : Finset (Fin 8))
    (bound : ∀ f : ∀ _a : I, Fin 11 ↪ Fin 21, let D := ⨅ a : I, (catalogue11 a.val)ᶜ.comap (f a)
      D.Connected → D.edgeSet.ncard ≤ 41) : ({0,1,2,3,4,6,7} : Finset (Fin 8)) ⊆ I := by
  have hit := hits_each_gap catalogue11 total11 (q:=41) (by intro j; fin_cases j <;> first | exact portfolio11x0 | exact portfolio11x1 | exact portfolio11x2 | exact portfolio11x3 | exact portfolio11x4 | exact portfolio11x5 | exact portfolio11x6) I bound
  have table : ∀ a ∈ ({0,1,2,3,4,6,7} : Finset (Fin 8)), ∃ j : Fin 7, ∀ b, b ∉ total11 j → b=a := by decide +kernel
  intro a ha
  obtain ⟨j,only⟩ := table a ha
  obtain ⟨b,hb,miss⟩ := hit j
  exact only b miss ▸ hb

theorem forced12 (I : Finset (Fin 10))
    (bound : ∀ f : ∀ _a : I, Fin 12 ↪ Fin 23, let D := ⨅ a : I, (catalogue12 a.val)ᶜ.comap (f a)
      D.Connected → D.edgeSet.ncard ≤ 49) : ({0,7,8,9} : Finset (Fin 10)) ⊆ I ∧ (4∈I ∨ 5∈I) := by
  have hit := hits_each_gap catalogue12 total12 (q:=49) (by intro j; fin_cases j <;> first | exact portfolio12x0 | exact portfolio12x1 | exact portfolio12x2 | exact portfolio12x3 | exact portfolio12x4) I bound
  have table : ∀ a ∈ ({0,7,8,9} : Finset (Fin 10)), ∃ j : Fin 5, ∀ b, b ∉ total12 j → b=a := by decide +kernel
  constructor
  · intro a ha
    obtain ⟨j,only⟩ := table a ha
    obtain ⟨b,hb,miss⟩ := hit j
    exact only b miss ▸ hb
  · obtain ⟨b,hb,gap⟩ := hit 3
    have table2 : ∀ b, b ∉ total12 3 → b=4 ∨ b=5 := by decide +kernel
    rcases table2 b gap with rfl|rfl
    · exact Or.inl hb
    · exact Or.inr hb
end E1182Portfolio
#print axioms E1182Portfolio.forced11
#print axioms E1182Portfolio.forced12
