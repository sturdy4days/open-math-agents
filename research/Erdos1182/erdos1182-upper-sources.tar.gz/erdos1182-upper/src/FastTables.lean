import FastSearch
namespace E1182ElevenBlock

def packRows (f : ℕ → ℕ) : ℕ → ℕ
  | 0 => 0
  | n+1 => packRows f n ||| (f n <<< (21*n))

theorem packRows_has (f : ℕ → ℕ) {n j a : ℕ} (inRows : j < n) (bit : (f j).testBit a=true) :
    (packRows f n).testBit (21*j+a)=true := by
  induction n with
  | zero => omega
  | succ n ih =>
    rw [packRows,Nat.testBit_or,Bool.or_eq_true]
    rcases Nat.lt_or_eq_of_le (Nat.le_of_lt_succ inRows) with lt|rfl
    · exact Or.inl (ih lt)
    · right
      simpa [Nat.testBit_shiftLeft] using bit

def field (x w i : ℕ) := (x >>> (w*i)) % (2^w)
def perms (word : ℕ) (i : Fin 11) (v : ℕ) := field word 231 (21*i.val+v)
def knocks (word : ℕ) (v : ℕ) := field word 231 v
def agreement (h : Host) (p : Pattern) (P D I : ℕ) : Prop :=
  (∀ i : Fin 11, ∀ v : Fin 21, perms P i v.val =
    packRows (fun j => classMask p.edges p.tags h.joined h.high h.full i (Fin.ofNat 11 j) v.val) 11) ∧
  (∀ v : Fin 21, knocks D v.val = packRows (fun _ => h.apart[v.val]!) 11) ∧
  I = packRows (fun j => if j=0 then h.root else h.full) 11 ∧
  h.root < 2^21 ∧ h.full < 2^21

theorem rejects_via_word (h : Host) (p : Pattern) (P D I : ℕ) (tables : agreement h p P D I)
    (no : fastSearch (perms P) (knocks D) ((List.finRange 11).take p.count) I
      ((List.finRange 21).map fun (u : Fin 21) => h.colours[u.val]!) = false) : rejects h p=false := by
  apply Bool.eq_false_iff.mpr
  intro old
  obtain ⟨perm,dif,init,hroot,hfull⟩ := tables
  have allow (i j : Fin 11) (v a : ℕ) (small : v < 21) (_ : a < 21)
      (hit : (classMask p.edges p.tags h.joined h.high h.full i j v).testBit a=true) :
      (perms P i v).testBit (21*j.val+a)=true := by
    rw [perm i ⟨v,small⟩]
    apply packRows_has _ j.isLt
    simpa [Fin.ofNat_eq_cast] using hit
  have apart (j : Fin 11) (v a : ℕ) (small : v < 21) (_ : a < 21) (hit : h.apart[v]!.testBit a=true) :
      (knocks D v).testBit (21*j.val+a)=true := by
    rw [dif ⟨v,small⟩]
    exact packRows_has _ j.isLt hit
  have start : presents (domains h p) I := by
    intro u hu v bit
    obtain ⟨i,_,rfl⟩ := List.mem_map.mp hu
    have below : (if i=0 then h.root else h.full) < 2^21 := by split <;> assumption
    change (if i=0 then h.root else h.full).testBit v=true at bit
    have limit : v < 21 := by
      by_contra! le
      have top := Nat.pow_le_pow_right (by decide : 0 < 2) le
      rw [Nat.testBit_lt_two_pow (below.trans_le top)] at bit
      exact Bool.noConfusion bit
    refine ⟨limit,?_⟩
    rw [init]
    apply packRows_has _ i.isLt
    simpa using bit
  have g := capSearch_fast (classMask p.edges p.tags h.joined h.high h.full) h.apart
    (perms P) (knocks D) allow apart (domains h p).length (domains h p) I
    ((List.finRange 21).map fun (u : Fin 21) => h.colours[u.val]!) rfl start old
  have rows : (domains h p).map Prod.fst = (List.finRange 11).take p.count := by
    simp [domains,List.map_map,Function.comp_def]
  rw [rows,no] at g
  exact Bool.noConfusion g

end E1182ElevenBlock
#print axioms E1182ElevenBlock.rejects_via_word
