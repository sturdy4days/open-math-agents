import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf16_0_4_17 : failed host0 pat16 (atPath host0 pat16 [17,4,0]) = true := by
  decide +kernel

theorem leaf16_0_4_18 : failed host0 pat16 (atPath host0 pat16 [18,4,0]) = true := by
  decide +kernel

theorem leaf16_0_7_8 : failed host0 pat16 (atPath host0 pat16 [8,7,0]) = true := by
  decide +kernel

theorem leaf16_0_7_10 : failed host0 pat16 (atPath host0 pat16 [10,7,0]) = true := by
  decide +kernel

theorem leaf16_0_7_11 : failed host0 pat16 (atPath host0 pat16 [11,7,0]) = true := by
  decide +kernel

theorem leaf16_0_7_14 : failed host0 pat16 (atPath host0 pat16 [14,7,0]) = true := by
  decide +kernel

theorem leaf16_0_7_17 : failed host0 pat16 (atPath host0 pat16 [17,7,0]) = true := by
  decide +kernel

end E1182ElevenBlock
