import Intro12
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice12x21 : ((leaves12.drop 21).take 1).all test12=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice12x22 : ((leaves12.drop 22).take 2).all test12=true := by decide +kernel
end E1182TwelveBlock.Word32
