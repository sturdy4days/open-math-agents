import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf6_0_11 : failed host0 pat6 (atPath host0 pat6 [11,0]) = true := by
  decide +kernel

theorem leaf6_0_12 : failed host0 pat6 (atPath host0 pat6 [12,0]) = true := by
  decide +kernel

theorem leaf6_0_13 : failed host0 pat6 (atPath host0 pat6 [13,0]) = true := by
  decide +kernel

theorem leaf6_0_14 : failed host0 pat6 (atPath host0 pat6 [14,0]) = true := by
  decide +kernel

theorem leaf6_0_17 : failed host0 pat6 (atPath host0 pat6 [17,0]) = true := by
  decide +kernel

theorem leaf6_0_18 : failed host0 pat6 (atPath host0 pat6 [18,0]) = true := by
  decide +kernel

end E1182ElevenBlock
