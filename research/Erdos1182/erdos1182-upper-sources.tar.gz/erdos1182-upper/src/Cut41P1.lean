import Descent
import ValidHost1
namespace E1182ElevenBlock
theorem leaf41_0_3 : failed host1 pat41 (atPath host1 pat41 [3,0]) = true := by
  decide +kernel

theorem leaf41_0_5 : failed host1 pat41 (atPath host1 pat41 [5,0]) = true := by
  decide +kernel

theorem leaf41_0_6 : failed host1 pat41 (atPath host1 pat41 [6,0]) = true := by
  decide +kernel

theorem leaf41_0_7 : failed host1 pat41 (atPath host1 pat41 [7,0]) = true := by
  decide +kernel

theorem leaf41_0_9 : failed host1 pat41 (atPath host1 pat41 [9,0]) = true := by
  decide +kernel

theorem leaf41_0_10 : failed host1 pat41 (atPath host1 pat41 [10,0]) = true := by
  decide +kernel

end E1182ElevenBlock
