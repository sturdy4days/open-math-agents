import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf16_0_14 : failed host0 pat16 (atPath host0 pat16 [14,0]) = true := by
  decide +kernel

theorem leaf16_0_17 : failed host0 pat16 (atPath host0 pat16 [17,0]) = true := by
  decide +kernel

end E1182ElevenBlock
