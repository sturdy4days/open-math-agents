import HostChecks8
namespace E1182TwelveBlock.Word32
def p7E : Nat := spreadCells 0x84e44120f10e08ec40030030b88b84b82601
def p7R : Nat := spreadCells 0xffffffffffffefffffffffdffffff7ff3fff
set_option maxHeartbeats 0 in
theorem okS7 : sourceWords host8 pat7 p7E p7R := by
  unfold sourceWords
  decide +kernel
abbrev perm7 := permit p7E p7R h8J h8B
abbrev apart7 := field h8A 384
abbrev start7 := initial pat7 h8I h8U h8T
def leaves7 : List (List Nat) := [[0],[1],[0,3],[3,3],[4,3],[5,3],[6,3],[8,3],[9,3],[12,3],[13,3],[14,3],[5],[0,7],[1,7],[2,7],[4,7],[7,7,7],[9,7,7],[10,7,7],[11,7,7],[12,7,7],[13,7,7],[9,7],[10,7],[11,7],[12,7],[13,7]]
def branches7 : List (List Nat) := [[3],[7,7],[7],[]]
abbrev test7 := fails perm7 apart7 start7
end E1182TwelveBlock.Word32
