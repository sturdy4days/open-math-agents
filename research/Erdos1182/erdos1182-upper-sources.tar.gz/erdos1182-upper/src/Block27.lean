import TwinRule
import ValidHost1
import WordCut27
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem blocked27 : ¬ (codeGraph 11 pat27.mask) ⊑ (triGraph 21 host1.original)ᶜ := by
  apply null_of_test host1 pat27 hostValid1 (by decide +kernel) (twins_from_types pat27 436284480954706176364511571551382238 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact Word32.miss27
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked27
