import Intro13
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x7 : ((leaves13.drop 7).take 2).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x9 : ((leaves13.drop 9).take 4).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x13 : ((leaves13.drop 13).take 1).all test13=true := by decide +kernel
end E1182TwelveBlock.Word32
