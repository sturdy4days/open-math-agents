import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf22_0_1 : failed host0 pat22 (atPath host0 pat22 [1,0]) = true := by
  decide +kernel

theorem leaf22_0_3_4 : failed host0 pat22 (atPath host0 pat22 [4,3,0]) = true := by
  decide +kernel

theorem leaf22_0_3_7 : failed host0 pat22 (atPath host0 pat22 [7,3,0]) = true := by
  decide +kernel

theorem leaf22_0_3_10 : failed host0 pat22 (atPath host0 pat22 [10,3,0]) = true := by
  decide +kernel

theorem leaf22_0_3_11 : failed host0 pat22 (atPath host0 pat22 [11,3,0]) = true := by
  decide +kernel

theorem leaf22_0_3_12 : failed host0 pat22 (atPath host0 pat22 [12,3,0]) = true := by
  decide +kernel

theorem leaf22_0_3_13 : failed host0 pat22 (atPath host0 pat22 [13,3,0]) = true := by
  decide +kernel

theorem leaf22_0_3_14 : failed host0 pat22 (atPath host0 pat22 [14,3,0]) = true := by
  decide +kernel

theorem leaf22_0_3_17 : failed host0 pat22 (atPath host0 pat22 [17,3,0]) = true := by
  decide +kernel

end E1182ElevenBlock
