import FrontierClose
import Page10x0
import Page10x1
import Page10x2
import Page10x3
import Page10x4
namespace E1182TwelveBlock.Word32
private theorem appendParts10 (offset width : Nat)
    (head : ((leaves10.drop offset).take width).all test10 = true)
    (tail : (leaves10.drop (offset+width)).all test10 = true) :
    (leaves10.drop offset).all test10 = true :=
  prepend_chunk (xs := leaves10) (f := test10) (offset := offset) (width := width) head tail

set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem miss10 : rejects host7 pat10 = false :=
  closeFrontier host7 pat10 p10E p10R h7J h7B h7A h7I h7U h7T
    okH7 okS10 leaves10 branches10
    (appendParts10 0 1 slice10x0 (appendParts10 1 2 slice10x1 (appendParts10 3 2 slice10x3 (appendParts10 5 1 slice10x5 (appendParts10 6 1 slice10x6 (appendParts10 7 1 slice10x7 (appendParts10 8 2 slice10x8 (appendParts10 10 1 slice10x10 (appendParts10 11 1 slice10x11 (appendParts10 12 4 slice10x12 (appendParts10 16 1 slice10x16 (appendParts10 17 1 slice10x17 (appendParts10 18 2 slice10x18 (appendParts10 20 1 slice10x20 (by decide +kernel))))))))))))))) (by decide +kernel)
end E1182TwelveBlock.Word32
#print axioms E1182TwelveBlock.Word32.miss10
namespace E1182TwelveBlock
open SimpleGraph E1182Cover
set_option maxHeartbeats 0 in
theorem blocked10 : ¬ (codeGraph 12 pat10.mask) ⊑ (triGraph 23 host7.original)ᶜ := by
  apply null_of_test host7 pat10 hostValid7 (by decide +kernel)
    (twins_from_types pat10 0x3c35c66877636a60e30000003477e55a6 (by decide +kernel)) (by decide +kernel) (by decide +kernel)
  exact Word32.miss10
end E1182TwelveBlock
#print axioms E1182TwelveBlock.blocked10
