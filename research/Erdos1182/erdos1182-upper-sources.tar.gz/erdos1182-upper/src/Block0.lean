import TwinRule
import ValidHost0
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
set_option maxRecDepth 30000 in
set_option maxHeartbeats 7000000 in
theorem blocked0 : ¬ (codeGraph 11 pat0.mask) ⊑ (triGraph 21 host0.original)ᶜ := by
  apply null_of_test host0 pat0 hostValid0 (by decide +kernel) (twins_from_types pat0 6146 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  decide +kernel
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked0
