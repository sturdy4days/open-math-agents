import FrontierClose
import Page3x0
import Page3x1
import Page3x2
import Page3x3
import Page3x4
import Page3x5
import Page3x6
import Page3x7
import Page3x8
import Page3x9
import Page3x10
namespace E1182TwelveBlock.Word32
private theorem appendParts3 (offset width : Nat)
    (head : ((leaves3.drop offset).take width).all test3 = true)
    (tail : (leaves3.drop (offset+width)).all test3 = true) :
    (leaves3.drop offset).all test3 = true :=
  prepend_chunk (xs := leaves3) (f := test3) (offset := offset) (width := width) head tail

set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem miss3 : rejects host4 pat3 = false :=
  closeFrontier host4 pat3 p3E p3R h4J h4B h4A h4I h4U h4T
    okH4 okS3 leaves3 branches3
    (appendParts3 0 1 slice3x0 (appendParts3 1 1 slice3x1 (appendParts3 2 4 slice3x2 (appendParts3 6 5 slice3x6 (appendParts3 11 1 slice3x11 (appendParts3 12 1 slice3x12 (appendParts3 13 1 slice3x13 (appendParts3 14 3 slice3x14 (appendParts3 17 6 slice3x17 (appendParts3 23 1 slice3x23 (appendParts3 24 1 slice3x24 (appendParts3 25 3 slice3x25 (appendParts3 28 5 slice3x28 (appendParts3 33 1 slice3x33 (appendParts3 34 1 slice3x34 (appendParts3 35 1 slice3x35 (appendParts3 36 3 slice3x36 (appendParts3 39 5 slice3x39 (appendParts3 44 1 slice3x44 (appendParts3 45 1 slice3x45 (appendParts3 46 1 slice3x46 (appendParts3 47 1 slice3x47 (appendParts3 48 8 slice3x48 (appendParts3 56 2 slice3x56 (appendParts3 58 8 slice3x58 (appendParts3 66 3 slice3x66 (appendParts3 69 7 slice3x69 (appendParts3 76 1 slice3x76 (by decide +kernel))))))))))))))))))))))))))))) (by decide +kernel)
end E1182TwelveBlock.Word32
#print axioms E1182TwelveBlock.Word32.miss3
namespace E1182TwelveBlock
open SimpleGraph E1182Cover
set_option maxHeartbeats 0 in
theorem blocked3 : ¬ (codeGraph 12 pat3.mask) ⊑ (triGraph 23 host4.original)ᶜ := by
  apply null_of_test host4 pat3 hostValid4 (by decide +kernel)
    (twins_from_types pat3 0x13023000000031032 (by decide +kernel)) (by decide +kernel) (by decide +kernel)
  exact Word32.miss3
end E1182TwelveBlock
#print axioms E1182TwelveBlock.blocked3
