import Intro3
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice3x34 : ((leaves3.drop 34).take 1).all test3=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice3x35 : ((leaves3.drop 35).take 1).all test3=true := by decide +kernel
end E1182TwelveBlock.Word32
