import HostChecks6
namespace E1182TwelveBlock.Word32
def p0E : Nat := spreadCells 0xfffffffffffff80f41f20f10f08f04f02f41
def p0R : Nat := spreadCells 0xfff7ff3ff1fffffffff7ff5ff4ff47f43fff
set_option maxHeartbeats 0 in
theorem okS0 : sourceWords host6 pat0 p0E p0R := by
  unfold sourceWords
  decide +kernel
abbrev perm0 := permit p0E p0R h6J h6B
abbrev apart0 := field h6A 384
abbrev start0 := initial pat0 h6I h6U h6T
def leaves0 : List (List Nat) := [[0],[1],[2],[5],[6],[9],[11],[12],[13],[14],[17]]
def branches0 : List (List Nat) := [[]]
abbrev test0 := fails perm0 apart0 start0
end E1182TwelveBlock.Word32
