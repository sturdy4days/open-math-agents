import Pos0
import Pos64
import Pos128
import Pos192
import Pos256
import Pos320
import Pos384
import Pos448
import Pos512
import Pos576
import Pos640
import Pos704
import Pos768
import Pos832
import Pos896
import Pos960
import Pos1024
import Pos1088
import Pos1152
import Pos1216
import Pos1280
import Pos1344
import Pos1408
import Pos1472
import Pos1536
import Pos1600
import Pos1664
import Pos1728
import Pos1792
import Pos1856
import Pos1920
import Pos1984
import Pos2048
import Pos2112
import Pos2176
import Pos2240
namespace E1182Eleven
open E1182Bits
theorem pj0_128 : posSlice l13 pats pscripts ptable 0 128 := posJoin (a:=64) (b:=64) p0 p64
theorem pj128_128 : posSlice l13 pats pscripts ptable 128 128 := posJoin (a:=64) (b:=64) p128 p192
theorem pj256_128 : posSlice l13 pats pscripts ptable 256 128 := posJoin (a:=64) (b:=64) p256 p320
theorem pj384_128 : posSlice l13 pats pscripts ptable 384 128 := posJoin (a:=64) (b:=64) p384 p448
theorem pj512_128 : posSlice l13 pats pscripts ptable 512 128 := posJoin (a:=64) (b:=64) p512 p576
theorem pj640_128 : posSlice l13 pats pscripts ptable 640 128 := posJoin (a:=64) (b:=64) p640 p704
theorem pj768_128 : posSlice l13 pats pscripts ptable 768 128 := posJoin (a:=64) (b:=64) p768 p832
theorem pj896_128 : posSlice l13 pats pscripts ptable 896 128 := posJoin (a:=64) (b:=64) p896 p960
theorem pj1024_128 : posSlice l13 pats pscripts ptable 1024 128 := posJoin (a:=64) (b:=64) p1024 p1088
theorem pj1152_128 : posSlice l13 pats pscripts ptable 1152 128 := posJoin (a:=64) (b:=64) p1152 p1216
theorem pj1280_128 : posSlice l13 pats pscripts ptable 1280 128 := posJoin (a:=64) (b:=64) p1280 p1344
theorem pj1408_128 : posSlice l13 pats pscripts ptable 1408 128 := posJoin (a:=64) (b:=64) p1408 p1472
theorem pj1536_128 : posSlice l13 pats pscripts ptable 1536 128 := posJoin (a:=64) (b:=64) p1536 p1600
theorem pj1664_128 : posSlice l13 pats pscripts ptable 1664 128 := posJoin (a:=64) (b:=64) p1664 p1728
theorem pj1792_128 : posSlice l13 pats pscripts ptable 1792 128 := posJoin (a:=64) (b:=64) p1792 p1856
theorem pj1920_128 : posSlice l13 pats pscripts ptable 1920 128 := posJoin (a:=64) (b:=64) p1920 p1984
theorem pj2048_128 : posSlice l13 pats pscripts ptable 2048 128 := posJoin (a:=64) (b:=64) p2048 p2112
theorem pj2176_121 : posSlice l13 pats pscripts ptable 2176 121 := posJoin (a:=64) (b:=57) p2176 p2240
theorem pj0_256 : posSlice l13 pats pscripts ptable 0 256 := posJoin (a:=128) (b:=128) pj0_128 pj128_128
theorem pj256_256 : posSlice l13 pats pscripts ptable 256 256 := posJoin (a:=128) (b:=128) pj256_128 pj384_128
theorem pj512_256 : posSlice l13 pats pscripts ptable 512 256 := posJoin (a:=128) (b:=128) pj512_128 pj640_128
theorem pj768_256 : posSlice l13 pats pscripts ptable 768 256 := posJoin (a:=128) (b:=128) pj768_128 pj896_128
theorem pj1024_256 : posSlice l13 pats pscripts ptable 1024 256 := posJoin (a:=128) (b:=128) pj1024_128 pj1152_128
theorem pj1280_256 : posSlice l13 pats pscripts ptable 1280 256 := posJoin (a:=128) (b:=128) pj1280_128 pj1408_128
theorem pj1536_256 : posSlice l13 pats pscripts ptable 1536 256 := posJoin (a:=128) (b:=128) pj1536_128 pj1664_128
theorem pj1792_256 : posSlice l13 pats pscripts ptable 1792 256 := posJoin (a:=128) (b:=128) pj1792_128 pj1920_128
theorem pj2048_249 : posSlice l13 pats pscripts ptable 2048 249 := posJoin (a:=128) (b:=121) pj2048_128 pj2176_121
theorem pj0_512 : posSlice l13 pats pscripts ptable 0 512 := posJoin (a:=256) (b:=256) pj0_256 pj256_256
theorem pj512_512 : posSlice l13 pats pscripts ptable 512 512 := posJoin (a:=256) (b:=256) pj512_256 pj768_256
theorem pj1024_512 : posSlice l13 pats pscripts ptable 1024 512 := posJoin (a:=256) (b:=256) pj1024_256 pj1280_256
theorem pj1536_512 : posSlice l13 pats pscripts ptable 1536 512 := posJoin (a:=256) (b:=256) pj1536_256 pj1792_256
theorem pj0_1024 : posSlice l13 pats pscripts ptable 0 1024 := posJoin (a:=512) (b:=512) pj0_512 pj512_512
theorem pj1024_1024 : posSlice l13 pats pscripts ptable 1024 1024 := posJoin (a:=512) (b:=512) pj1024_512 pj1536_512
theorem pj0_2048 : posSlice l13 pats pscripts ptable 0 2048 := posJoin (a:=1024) (b:=1024) pj0_1024 pj1024_1024
theorem pj0_2297 : posSlice l13 pats pscripts ptable 0 2297 := posJoin (a:=2048) (b:=249) pj0_2048 pj2048_249
theorem allPositive : posSlice l13 pats pscripts ptable 0 2297 := pj0_2297
end E1182Eleven
#print axioms E1182Eleven.allPositive
