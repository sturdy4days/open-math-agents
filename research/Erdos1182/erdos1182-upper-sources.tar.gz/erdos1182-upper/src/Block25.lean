import TwinRule
import ValidHost1
import WordCut25
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem blocked25 : ¬ (codeGraph 11 pat25.mask) ⊑ (triGraph 21 host1.original)ᶜ := by
  apply null_of_test host1 pat25 hostValid1 (by decide +kernel) (twins_from_types pat25 425866969215420409964203681158261502 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact Word32.miss25
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked25
