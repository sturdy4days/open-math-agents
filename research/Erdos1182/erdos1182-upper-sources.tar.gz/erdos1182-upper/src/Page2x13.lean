import Intro2
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x75 : ((leaves2.drop 75).take 9).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x84 : ((leaves2.drop 84).take 5).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x89 : ((leaves2.drop 89).take 8).all test2=true := by decide +kernel
end E1182TwelveBlock.Word32
