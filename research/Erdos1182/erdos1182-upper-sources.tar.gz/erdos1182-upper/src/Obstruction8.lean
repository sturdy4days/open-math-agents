import FrontierClose
import Page8x0
import Page8x1
import Page8x2
import Page8x3
import Page8x4
import Page8x5
import Page8x6
import Page8x7
namespace E1182TwelveBlock.Word32
private theorem appendParts8 (offset width : Nat)
    (head : ((leaves8.drop offset).take width).all test8 = true)
    (tail : (leaves8.drop (offset+width)).all test8 = true) :
    (leaves8.drop offset).all test8 = true :=
  prepend_chunk (xs := leaves8) (f := test8) (offset := offset) (width := width) head tail

set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem miss8 : rejects host7 pat8 = false :=
  closeFrontier host7 pat8 p8E p8R h7J h7B h7A h7I h7U h7T
    okH7 okS8 leaves8 branches8
    (appendParts8 0 3 slice8x0 (appendParts8 3 3 slice8x3 (appendParts8 6 1 slice8x6 (appendParts8 7 2 slice8x7 (appendParts8 9 2 slice8x9 (appendParts8 11 1 slice8x11 (appendParts8 12 2 slice8x12 (appendParts8 14 1 slice8x14 (appendParts8 15 1 slice8x15 (appendParts8 16 2 slice8x16 (appendParts8 18 1 slice8x18 (appendParts8 19 1 slice8x19 (appendParts8 20 2 slice8x20 (appendParts8 22 2 slice8x22 (appendParts8 24 1 slice8x24 (appendParts8 25 2 slice8x25 (appendParts8 27 2 slice8x27 (appendParts8 29 1 slice8x29 (appendParts8 30 2 slice8x30 (by decide +kernel)))))))))))))))))))) (by decide +kernel)
end E1182TwelveBlock.Word32
#print axioms E1182TwelveBlock.Word32.miss8
namespace E1182TwelveBlock
open SimpleGraph E1182Cover
set_option maxHeartbeats 0 in
theorem blocked8 : ¬ (codeGraph 12 pat8.mask) ⊑ (triGraph 23 host7.original)ᶜ := by
  apply null_of_test host7 pat8 hostValid7 (by decide +kernel)
    (twins_from_types pat8 0x6085d22ea36339319b26b5330003f90fa (by decide +kernel)) (by decide +kernel) (by decide +kernel)
  exact Word32.miss8
end E1182TwelveBlock
#print axioms E1182TwelveBlock.blocked8
