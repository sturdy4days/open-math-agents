import Intro2
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x211 : ((leaves2.drop 211).take 3).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x214 : ((leaves2.drop 214).take 6).all test2=true := by decide +kernel
end E1182TwelveBlock.Word32
