import Intro3
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice3x6 : ((leaves3.drop 6).take 5).all test3=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice3x11 : ((leaves3.drop 11).take 1).all test3=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice3x12 : ((leaves3.drop 12).take 1).all test3=true := by decide +kernel
end E1182TwelveBlock.Word32
