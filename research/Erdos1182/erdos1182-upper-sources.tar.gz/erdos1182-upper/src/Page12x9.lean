import Intro12
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice12x52 : ((leaves12.drop 52).take 1).all test12=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice12x53 : ((leaves12.drop 53).take 1).all test12=true := by decide +kernel
end E1182TwelveBlock.Word32
