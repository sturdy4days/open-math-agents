import Permutation
namespace E1182Bits

def field (w width i : Nat) : Nat := (w >>> (width*i)) % 2^width

def triPos (a b : Fin 11) : Nat := b.val*(b.val-1)/2 + a.val

def witness (record : Nat) (a b : Fin 11) : Nat := field record 22 (triPos a b)

def rowOK (s targets count scripts record : Nat) : Prop :=
  ∀ a b : Fin 11, a < b → ¬ neighbors s a b →
    let tag := witness record a b
    tag % 4096 < count ∧
      relabel 10 (insertPair s a b) (field scripts 80 (tag >>> 12)) = field targets 121 (tag % 4096)

instance (m : Nat) (a b : Fin 11) : Decidable (neighbors m a b) := by
  unfold neighbors; infer_instance

instance (s targets count scripts record : Nat) : Decidable (rowOK s targets count scripts record) := by
  unfold rowOK; infer_instance

/-- For every missing edge, the recorded relabelling gives a spanning copy of a representative of the next layer. -/
theorem augmentation {s targets count scripts record : Nat}
    (cert : rowOK s targets count scripts record) (a b : Fin 11) (lt : a<b) (no : ¬ neighbors s a b) :
    ∃ t < count, ∃ p : Fin 11 → Fin 11, Function.Injective p ∧
      ∀ i j : Fin 11, neighbors (field targets 121 t) i j →
        neighbors s (p i) (p j) ∨ (p i=a ∧ p j=b) ∨ (p i=b ∧ p j=a) := by
  obtain ⟨bound,step⟩ := cert a b lt no
  exact ⟨_,bound,transition step⟩

end E1182Bits
#print axioms E1182Bits.augmentation
