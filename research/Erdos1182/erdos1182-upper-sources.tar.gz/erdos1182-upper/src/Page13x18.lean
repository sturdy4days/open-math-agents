import Intro13
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x103 : ((leaves13.drop 103).take 5).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x108 : ((leaves13.drop 108).take 1).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x109 : ((leaves13.drop 109).take 1).all test13=true := by decide +kernel
end E1182TwelveBlock.Word32
