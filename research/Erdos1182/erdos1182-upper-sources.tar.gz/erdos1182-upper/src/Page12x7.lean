import Intro12
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice12x44 : ((leaves12.drop 44).take 4).all test12=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice12x48 : ((leaves12.drop 48).take 1).all test12=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice12x49 : ((leaves12.drop 49).take 1).all test12=true := by decide +kernel
end E1182TwelveBlock.Word32
