import Intro4
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice4x16 : ((leaves4.drop 16).take 2).all test4=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice4x18 : ((leaves4.drop 18).take 5).all test4=true := by decide +kernel
end E1182TwelveBlock.Word32
