import RowChecks12
namespace E1182Twelve
set_option maxHeartbeats 0 in
set_option maxRecDepth 4000 in
theorem r15_130 : rows l15 l16 3130 b15 o15 z15 130 10 := by decide +kernel
end E1182Twelve
