import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf26_0_8 : failed host0 pat26 (atPath host0 pat26 [8,0]) = true := by
  decide +kernel

theorem leaf26_0_9 : failed host0 pat26 (atPath host0 pat26 [9,0]) = true := by
  decide +kernel

theorem leaf26_0_10_11 : failed host0 pat26 (atPath host0 pat26 [11,10,0]) = true := by
  decide +kernel

theorem leaf26_0_10_13 : failed host0 pat26 (atPath host0 pat26 [13,10,0]) = true := by
  decide +kernel

theorem leaf26_0_10_14 : failed host0 pat26 (atPath host0 pat26 [14,10,0]) = true := by
  decide +kernel

theorem leaf26_0_10_17 : failed host0 pat26 (atPath host0 pat26 [17,10,0]) = true := by
  decide +kernel

theorem leaf26_0_10_18 : failed host0 pat26 (atPath host0 pat26 [18,10,0]) = true := by
  decide +kernel

theorem leaf26_0_10_20 : failed host0 pat26 (atPath host0 pat26 [20,10,0]) = true := by
  decide +kernel

end E1182ElevenBlock
