import Intro13
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x0 : ((leaves13.drop 0).take 1).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x1 : ((leaves13.drop 1).take 1).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x2 : ((leaves13.drop 2).take 1).all test13=true := by decide +kernel
end E1182TwelveBlock.Word32
