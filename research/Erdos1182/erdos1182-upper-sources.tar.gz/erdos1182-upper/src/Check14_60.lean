import RowChecks12
namespace E1182Twelve
set_option maxHeartbeats 0 in
set_option maxRecDepth 4000 in
theorem r14_60 : rows l14 l15 719 b14 o14 z14 60 10 := by decide +kernel
end E1182Twelve
