import Descent
import ValidHost3
namespace E1182ElevenBlock
theorem leaf7_1_5 : failed host3 pat7 (atPath host3 pat7 [5,1]) = true := by
  decide +kernel

theorem leaf7_1_6 : failed host3 pat7 (atPath host3 pat7 [6,1]) = true := by
  decide +kernel

theorem leaf7_1_8 : failed host3 pat7 (atPath host3 pat7 [8,1]) = true := by
  decide +kernel

theorem leaf7_1_12 : failed host3 pat7 (atPath host3 pat7 [12,1]) = true := by
  decide +kernel

theorem leaf7_1_13 : failed host3 pat7 (atPath host3 pat7 [13,1]) = true := by
  decide +kernel

theorem leaf7_1_14 : failed host3 pat7 (atPath host3 pat7 [14,1]) = true := by
  decide +kernel

theorem leaf7_1_15 : failed host3 pat7 (atPath host3 pat7 [15,1]) = true := by
  decide +kernel

theorem leaf7_1_16 : failed host3 pat7 (atPath host3 pat7 [16,1]) = true := by
  decide +kernel

theorem leaf7_1_17 : failed host3 pat7 (atPath host3 pat7 [17,1]) = true := by
  decide +kernel

theorem leaf7_1_18 : failed host3 pat7 (atPath host3 pat7 [18,1]) = true := by
  decide +kernel

end E1182ElevenBlock
