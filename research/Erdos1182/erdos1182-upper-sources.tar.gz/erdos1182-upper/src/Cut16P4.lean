import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf16_0_10_17 : failed host0 pat16 (atPath host0 pat16 [17,10,0]) = true := by
  decide +kernel

theorem leaf16_0_10_18 : failed host0 pat16 (atPath host0 pat16 [18,10,0]) = true := by
  decide +kernel

theorem leaf16_0_10_20 : failed host0 pat16 (atPath host0 pat16 [20,10,0]) = true := by
  decide +kernel

theorem leaf16_0_11 : failed host0 pat16 (atPath host0 pat16 [11,0]) = true := by
  decide +kernel

theorem leaf16_0_12 : failed host0 pat16 (atPath host0 pat16 [12,0]) = true := by
  decide +kernel

theorem leaf16_0_13 : failed host0 pat16 (atPath host0 pat16 [13,0]) = true := by
  decide +kernel

end E1182ElevenBlock
