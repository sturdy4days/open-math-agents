import Intro3
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice3x36 : ((leaves3.drop 36).take 3).all test3=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice3x39 : ((leaves3.drop 39).take 5).all test3=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice3x44 : ((leaves3.drop 44).take 1).all test3=true := by decide +kernel
end E1182TwelveBlock.Word32
