import TwinRule
import ValidHost0
import WordCut20
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem blocked20 : ¬ (codeGraph 11 pat20.mask) ⊑ (triGraph 21 host0.original)ᶜ := by
  apply null_of_test host0 pat20 hostValid0 (by decide +kernel) (twins_from_types pat20 918413493854395160722412707885993690 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact Word32.miss20
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked20
