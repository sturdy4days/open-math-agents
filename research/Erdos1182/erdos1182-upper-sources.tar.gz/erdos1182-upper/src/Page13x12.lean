import Intro13
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x69 : ((leaves13.drop 69).take 2).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x71 : ((leaves13.drop 71).take 2).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x73 : ((leaves13.drop 73).take 1).all test13=true := by decide +kernel
end E1182TwelveBlock.Word32
