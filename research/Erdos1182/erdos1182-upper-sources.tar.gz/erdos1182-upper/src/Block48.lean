import TwinRule
import ValidHost0
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
set_option maxRecDepth 30000 in
set_option maxHeartbeats 7000000 in
theorem blocked48 : ¬ (codeGraph 11 pat48.mask) ⊑ (triGraph 21 host0.original)ᶜ := by
  apply null_of_test host0 pat48 hostValid0 (by decide +kernel) (twins_from_types pat48 429892517667436536878231701582732586 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  decide +kernel
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked48
