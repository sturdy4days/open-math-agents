import Descent
import ValidHost1
namespace E1182ElevenBlock
theorem leaf41_0_11 : failed host1 pat41 (atPath host1 pat41 [11,0]) = true := by
  decide +kernel

theorem leaf41_0_13 : failed host1 pat41 (atPath host1 pat41 [13,0]) = true := by
  decide +kernel

theorem leaf41_2_1 : failed host1 pat41 (atPath host1 pat41 [1,2]) = true := by
  decide +kernel

theorem leaf41_2_4 : failed host1 pat41 (atPath host1 pat41 [4,2]) = true := by
  decide +kernel

theorem leaf41_2_5 : failed host1 pat41 (atPath host1 pat41 [5,2]) = true := by
  decide +kernel

end E1182ElevenBlock
