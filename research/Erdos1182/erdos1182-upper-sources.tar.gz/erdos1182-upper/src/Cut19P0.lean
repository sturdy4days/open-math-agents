import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf19_0_1_4 : failed host0 pat19 (atPath host0 pat19 [4,1,0]) = true := by
  decide +kernel

theorem leaf19_0_1_8 : failed host0 pat19 (atPath host0 pat19 [8,1,0]) = true := by
  decide +kernel

theorem leaf19_0_1_9 : failed host0 pat19 (atPath host0 pat19 [9,1,0]) = true := by
  decide +kernel

theorem leaf19_0_1_10 : failed host0 pat19 (atPath host0 pat19 [10,1,0]) = true := by
  decide +kernel

theorem leaf19_0_1_11 : failed host0 pat19 (atPath host0 pat19 [11,1,0]) = true := by
  decide +kernel

theorem leaf19_0_1_12 : failed host0 pat19 (atPath host0 pat19 [12,1,0]) = true := by
  decide +kernel

theorem leaf19_0_1_13 : failed host0 pat19 (atPath host0 pat19 [13,1,0]) = true := by
  decide +kernel

theorem leaf19_0_1_14 : failed host0 pat19 (atPath host0 pat19 [14,1,0]) = true := by
  decide +kernel

theorem leaf19_0_1_18 : failed host0 pat19 (atPath host0 pat19 [18,1,0]) = true := by
  decide +kernel

theorem leaf19_0_3_4 : failed host0 pat19 (atPath host0 pat19 [4,3,0]) = true := by
  decide +kernel

end E1182ElevenBlock
