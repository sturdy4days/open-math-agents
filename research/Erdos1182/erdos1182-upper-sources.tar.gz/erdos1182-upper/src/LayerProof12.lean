import Check12_0
import Check12_10
namespace E1182Twelve
theorem cover12_0_13 : rows l12 l13 43 b12 o12 z12 0 13 := rows_append (d:=10) (e:=3) r12_0 r12_10
theorem layer12 : rows l12 l13 43 b12 o12 z12 0 13 := cover12_0_13
end E1182Twelve
