import Descent
import ValidHost1
namespace E1182ElevenBlock
theorem leaf4_0_0_3 : failed host1 pat4 (atPath host1 pat4 [3,0,0]) = true := by
  decide +kernel

theorem leaf4_0_0_5 : failed host1 pat4 (atPath host1 pat4 [5,0,0]) = true := by
  decide +kernel

theorem leaf4_0_0_6 : failed host1 pat4 (atPath host1 pat4 [6,0,0]) = true := by
  decide +kernel

theorem leaf4_0_0_7 : failed host1 pat4 (atPath host1 pat4 [7,0,0]) = true := by
  decide +kernel

theorem leaf4_0_0_9 : failed host1 pat4 (atPath host1 pat4 [9,0,0]) = true := by
  decide +kernel

theorem leaf4_0_0_10 : failed host1 pat4 (atPath host1 pat4 [10,0,0]) = true := by
  decide +kernel

theorem leaf4_0_0_11 : failed host1 pat4 (atPath host1 pat4 [11,0,0]) = true := by
  decide +kernel

theorem leaf4_0_0_12 : failed host1 pat4 (atPath host1 pat4 [12,0,0]) = true := by
  decide +kernel

theorem leaf4_0_0_13 : failed host1 pat4 (atPath host1 pat4 [13,0,0]) = true := by
  decide +kernel

theorem leaf4_0_3_5 : failed host1 pat4 (atPath host1 pat4 [5,3,0]) = true := by
  decide +kernel

end E1182ElevenBlock
