import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf10_0_7_8 : failed host0 pat10 (atPath host0 pat10 [8,7,0]) = true := by
  decide +kernel

theorem leaf10_0_7_10 : failed host0 pat10 (atPath host0 pat10 [10,7,0]) = true := by
  decide +kernel

theorem leaf10_0_7_11 : failed host0 pat10 (atPath host0 pat10 [11,7,0]) = true := by
  decide +kernel

theorem leaf10_0_7_14 : failed host0 pat10 (atPath host0 pat10 [14,7,0]) = true := by
  decide +kernel

end E1182ElevenBlock
