import TwinRule
import ValidHost1
import WordCut31
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem blocked31 : ¬ (codeGraph 11 pat31.mask) ⊑ (triGraph 21 host1.original)ᶜ := by
  apply null_of_test host1 pat31 hostValid1 (by decide +kernel) (twins_from_types pat31 441839189324171713068350309391226 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact Word32.miss31
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked31
