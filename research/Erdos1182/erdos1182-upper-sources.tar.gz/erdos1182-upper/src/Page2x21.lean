import Intro2
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x154 : ((leaves2.drop 154).take 2).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x156 : ((leaves2.drop 156).take 8).all test2=true := by decide +kernel
end E1182TwelveBlock.Word32
