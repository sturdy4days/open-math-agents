import Intro13
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x35 : ((leaves13.drop 35).take 4).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x39 : ((leaves13.drop 39).take 2).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x41 : ((leaves13.drop 41).take 1).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x42 : ((leaves13.drop 42).take 1).all test13=true := by decide +kernel
end E1182TwelveBlock.Word32
