import FrontierClose
import Page14x0
import Page14x1
import Page14x2
namespace E1182TwelveBlock.Word32
private theorem appendParts14 (offset width : Nat)
    (head : ((leaves14.drop offset).take width).all test14 = true)
    (tail : (leaves14.drop (offset+width)).all test14 = true) :
    (leaves14.drop offset).all test14 = true :=
  prepend_chunk (xs := leaves14) (f := test14) (offset := offset) (width := width) head tail

set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem miss14 : rejects host7 pat14 = false :=
  closeFrontier host7 pat14 p14E p14R h7J h7B h7A h7I h7U h7T
    okH7 okS14 leaves14 branches14
    (appendParts14 0 1 slice14x0 (appendParts14 1 1 slice14x1 (appendParts14 2 4 slice14x2 (appendParts14 6 1 slice14x6 (appendParts14 7 1 slice14x7 (appendParts14 8 1 slice14x8 (appendParts14 9 1 slice14x9 (appendParts14 10 3 slice14x10 (by decide +kernel))))))))) (by decide +kernel)
end E1182TwelveBlock.Word32
#print axioms E1182TwelveBlock.Word32.miss14
namespace E1182TwelveBlock
open SimpleGraph E1182Cover
set_option maxHeartbeats 0 in
theorem blocked14 : ¬ (codeGraph 12 pat14.mask) ⊑ (triGraph 23 host7.original)ᶜ := by
  apply null_of_test host7 pat14 hostValid7 (by decide +kernel)
    (twins_from_types pat14 0x6839c29836c2f43593000053000000fd3ad2 (by decide +kernel)) (by decide +kernel) (by decide +kernel)
  exact Word32.miss14
end E1182TwelveBlock
#print axioms E1182TwelveBlock.blocked14
