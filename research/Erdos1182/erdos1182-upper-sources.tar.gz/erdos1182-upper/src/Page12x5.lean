import Intro12
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice12x31 : ((leaves12.drop 31).take 3).all test12=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice12x34 : ((leaves12.drop 34).take 5).all test12=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice12x39 : ((leaves12.drop 39).take 3).all test12=true := by decide +kernel
end E1182TwelveBlock.Word32
