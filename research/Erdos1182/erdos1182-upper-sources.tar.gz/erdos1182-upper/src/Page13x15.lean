import Intro13
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x84 : ((leaves13.drop 84).take 1).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x85 : ((leaves13.drop 85).take 2).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x87 : ((leaves13.drop 87).take 3).all test13=true := by decide +kernel
end E1182TwelveBlock.Word32
