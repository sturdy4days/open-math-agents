import Exchange
namespace E1182Bits

def partner (mask d k : Nat) :=
  if mask.testBit k then d+k else if d≤k ∧ mask.testBit (k-d) then k-d else k

def apart (mask d k : Nat) : Prop :=
  mask.testBit k = true → d ≤ k → mask.testBit (k-d) = false

instance (m d k : Nat) : Decidable (apart m d k) := by unfold apart; infer_instance

theorem exchange_at (x mask d k : Nat) (good : apart mask d k) :
    (exchange x mask d).testBit k = x.testBit (partner mask d k) := by
  rw [testBit_exchange x mask d k good]
  unfold partner
  by_cases lo : mask.testBit k = true
  · simp [lo]
  · by_cases hi : d≤k ∧ mask.testBit (k-d)=true <;> simp [lo,hi]

def addr (i j : Fin 11) := 11*i.val+j.val
def swapI (a b i : Fin 11) := if i=a then b else if i=b then a else i

def rowM (a : Fin 11) := 2047 <<< (11*a.val)
def colM (a : Fin 11) := 1298708349570020393652962442872833 <<< a.val

def swapFull (w : Nat) (a b : Fin 11) :=
  let d := b.val-a.val
  exchange (exchange w (colM a) d) (rowM a) (11*d)

def layout (a b i j : Fin 11) : Prop :=
  let d := b.val-a.val
  let k := addr i j
  let k' := addr (swapI a b i) j
  apart (rowM a) (11*d) k ∧ partner (rowM a) (11*d) k = k' ∧
    apart (colM a) d k' ∧ partner (colM a) d k' = addr (swapI a b i) (swapI a b j)

instance (a b i j : Fin 11) : Decidable (layout a b i j) := by unfold layout; infer_instance

theorem row_bit (a : Fin 11) (k : Nat) :
    (rowM a).testBit k = decide (11*a.val ≤ k ∧ k < 11*a.val+11) := by
  unfold rowM
  rw [Nat.testBit_shiftLeft, show 2047 = 2^11-1 by decide, Nat.testBit_two_pow_sub_one]
  rw [Bool.eq_iff_iff]
  simp only [Bool.and_eq_true, decide_eq_true_eq]
  omega

theorem col_zero : ∀ i : Fin 121,
    (1298708349570020393652962442872833 : Nat).testBit i.val = decide (i.val%11 = 0) := by
  decide +kernel

theorem col_bit (a : Fin 11) (k : Nat) (hk : k < 121) :
    (colM a).testBit k = decide (k % 11 = a.val) := by
  unfold colM
  rw [Nat.testBit_shiftLeft, col_zero ⟨k-a.val,by omega⟩]
  rw [Bool.eq_iff_iff]
  simp only [Bool.and_eq_true, decide_eq_true_eq]
  omega

theorem row_layout (a b i j : Fin 11) (h : a < b) :
    apart (rowM a) (11*(b.val-a.val)) (addr i j) ∧
      partner (rowM a) (11*(b.val-a.val)) (addr i j) = addr (swapI a b i) j := by
  unfold apart partner addr swapI
  simp only [row_bit, decide_eq_true_eq, decide_eq_false_iff_not, Fin.ext_iff]
  simp only [Fin.lt_def] at h
  have hh : 11*(b.val-a.val) = 11*b.val-11*a.val := Nat.mul_sub _ _ _
  rw [hh]
  constructor
  · omega
  · (repeat' split) <;> omega

theorem col_layout (a b i j : Fin 11) (h : a < b) :
    apart (colM a) (b.val-a.val) (addr i j) ∧
      partner (colM a) (b.val-a.val) (addr i j) = addr i (swapI a b j) := by
  unfold apart partner addr swapI
  rw [col_bit a (11*i.val+j.val) (by omega), col_bit a (11*i.val+j.val-(b.val-a.val)) (by omega)]
  simp only [ decide_eq_true_eq, decide_eq_false_iff_not, Fin.ext_iff]
  simp only [Fin.lt_def] at h
  constructor
  · omega
  · (repeat' split) <;> omega

theorem layout_ok (a b i j : Fin 11) (h : a<b) : layout a b i j := by
  have ⟨r,s⟩ := row_layout a b i j h
  exact ⟨r,s,col_layout a b (swapI a b i) j h⟩

theorem swapFull_at (w : Nat) {a b : Fin 11} (lt : a<b) (i j : Fin 11) :
    (swapFull w a b).testBit (addr i j) = w.testBit (addr (swapI a b i) (swapI a b j)) := by
  obtain ⟨hr,er,hc,ec⟩ := layout_ok a b i j lt
  rw [swapFull,exchange_at _ _ _ _ hr,er,exchange_at _ _ _ _ hc,ec]

end E1182Bits
#print axioms E1182Bits.swapFull_at
