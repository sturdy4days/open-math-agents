import Intro2
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x6 : ((leaves2.drop 6).take 7).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x13 : ((leaves2.drop 13).take 1).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x14 : ((leaves2.drop 14).take 1).all test2=true := by decide +kernel
end E1182TwelveBlock.Word32
