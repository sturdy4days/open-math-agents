import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf16_0_7_18 : failed host0 pat16 (atPath host0 pat16 [18,7,0]) = true := by
  decide +kernel

theorem leaf16_0_7_20 : failed host0 pat16 (atPath host0 pat16 [20,7,0]) = true := by
  decide +kernel

theorem leaf16_0_8 : failed host0 pat16 (atPath host0 pat16 [8,0]) = true := by
  decide +kernel

theorem leaf16_0_9 : failed host0 pat16 (atPath host0 pat16 [9,0]) = true := by
  decide +kernel

theorem leaf16_0_10_11 : failed host0 pat16 (atPath host0 pat16 [11,10,0]) = true := by
  decide +kernel

theorem leaf16_0_10_13 : failed host0 pat16 (atPath host0 pat16 [13,10,0]) = true := by
  decide +kernel

theorem leaf16_0_10_14 : failed host0 pat16 (atPath host0 pat16 [14,10,0]) = true := by
  decide +kernel

end E1182ElevenBlock
