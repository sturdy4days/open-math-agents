import TwinRule
import ValidHost1
import WordCut39
namespace E1182ElevenBlock
open SimpleGraph E1182Cover
theorem blocked39 : ¬ (codeGraph 11 pat39.mask) ⊑ (triGraph 21 host1.original)ᶜ := by
  apply null_of_test host1 pat39 hostValid1 (by decide +kernel) (twins_from_types pat39 133737241275437988381150252620538 (by decide +kernel))
      (by decide +kernel) (by decide +kernel)
  exact Word32.miss39
end E1182ElevenBlock
#print axioms E1182ElevenBlock.blocked39
