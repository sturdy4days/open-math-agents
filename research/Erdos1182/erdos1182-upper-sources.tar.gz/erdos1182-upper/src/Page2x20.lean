import Intro2
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x151 : ((leaves2.drop 151).take 1).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x152 : ((leaves2.drop 152).take 1).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x153 : ((leaves2.drop 153).take 1).all test2=true := by decide +kernel
end E1182TwelveBlock.Word32
