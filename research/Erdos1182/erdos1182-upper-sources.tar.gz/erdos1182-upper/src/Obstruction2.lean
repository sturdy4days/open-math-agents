import FrontierClose
import Page2x0
import Page2x1
import Page2x2
import Page2x3
import Page2x4
import Page2x5
import Page2x6
import Page2x7
import Page2x8
import Page2x9
import Page2x10
import Page2x11
import Page2x12
import Page2x13
import Page2x14
import Page2x15
import Page2x16
import Page2x17
import Page2x18
import Page2x19
import Page2x20
import Page2x21
import Page2x22
import Page2x23
import Page2x24
import Page2x25
import Page2x26
import Page2x27
import Page2x28
import Page2x29
import Page2x30
import Page2x31
import Page2x32
namespace E1182TwelveBlock.Word32
private theorem appendParts2 (offset width : Nat)
    (head : ((leaves2.drop offset).take width).all test2 = true)
    (tail : (leaves2.drop (offset+width)).all test2 = true) :
    (leaves2.drop offset).all test2 = true :=
  prepend_chunk (xs := leaves2) (f := test2) (offset := offset) (width := width) head tail

set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem miss2 : rejects host6 pat2 = false :=
  closeFrontier host6 pat2 p2E p2R h6J h6B h6A h6I h6U h6T
    okH6 okS2 leaves2 branches2
    (appendParts2 0 1 slice2x0 (appendParts2 1 1 slice2x1 (appendParts2 2 1 slice2x2 (appendParts2 3 1 slice2x3 (appendParts2 4 2 slice2x4 (appendParts2 6 7 slice2x6 (appendParts2 13 1 slice2x13 (appendParts2 14 1 slice2x14 (appendParts2 15 1 slice2x15 (appendParts2 16 1 slice2x16 (appendParts2 17 1 slice2x17 (appendParts2 18 2 slice2x18 (appendParts2 20 9 slice2x20 (appendParts2 29 3 slice2x29 (appendParts2 32 7 slice2x32 (appendParts2 39 3 slice2x39 (appendParts2 42 1 slice2x42 (appendParts2 43 1 slice2x43 (appendParts2 44 1 slice2x44 (appendParts2 45 1 slice2x45 (appendParts2 46 1 slice2x46 (appendParts2 47 3 slice2x47 (appendParts2 50 6 slice2x50 (appendParts2 56 1 slice2x56 (appendParts2 57 1 slice2x57 (appendParts2 58 1 slice2x58 (appendParts2 59 1 slice2x59 (appendParts2 60 1 slice2x60 (appendParts2 61 3 slice2x61 (appendParts2 64 6 slice2x64 (appendParts2 70 1 slice2x70 (appendParts2 71 1 slice2x71 (appendParts2 72 1 slice2x72 (appendParts2 73 2 slice2x73 (appendParts2 75 9 slice2x75 (appendParts2 84 5 slice2x84 (appendParts2 89 8 slice2x89 (appendParts2 97 1 slice2x97 (appendParts2 98 1 slice2x98 (appendParts2 99 1 slice2x99 (appendParts2 100 1 slice2x100 (appendParts2 101 3 slice2x101 (appendParts2 104 7 slice2x104 (appendParts2 111 3 slice2x111 (appendParts2 114 10 slice2x114 (appendParts2 124 3 slice2x124 (appendParts2 127 10 slice2x127 (appendParts2 137 1 slice2x137 (appendParts2 138 1 slice2x138 (appendParts2 139 1 slice2x139 (appendParts2 140 1 slice2x140 (appendParts2 141 4 slice2x141 (appendParts2 145 5 slice2x145 (appendParts2 150 1 slice2x150 (appendParts2 151 1 slice2x151 (appendParts2 152 1 slice2x152 (appendParts2 153 1 slice2x153 (appendParts2 154 2 slice2x154 (appendParts2 156 8 slice2x156 (appendParts2 164 3 slice2x164 (appendParts2 167 4 slice2x167 (appendParts2 171 7 slice2x171 (appendParts2 178 1 slice2x178 (appendParts2 179 1 slice2x179 (appendParts2 180 1 slice2x180 (appendParts2 181 1 slice2x181 (appendParts2 182 2 slice2x182 (appendParts2 184 8 slice2x184 (appendParts2 192 3 slice2x192 (appendParts2 195 5 slice2x195 (appendParts2 200 6 slice2x200 (appendParts2 206 1 slice2x206 (appendParts2 207 1 slice2x207 (appendParts2 208 1 slice2x208 (appendParts2 209 1 slice2x209 (appendParts2 210 1 slice2x210 (appendParts2 211 3 slice2x211 (appendParts2 214 6 slice2x214 (appendParts2 220 1 slice2x220 (appendParts2 221 1 slice2x221 (appendParts2 222 1 slice2x222 (appendParts2 223 2 slice2x223 (appendParts2 225 2 slice2x225 (appendParts2 227 7 slice2x227 (by decide +kernel))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) (by decide +kernel)
end E1182TwelveBlock.Word32
#print axioms E1182TwelveBlock.Word32.miss2
namespace E1182TwelveBlock
open SimpleGraph E1182Cover
set_option maxHeartbeats 0 in
theorem blocked2 : ¬ (codeGraph 12 pat2.mask) ⊑ (triGraph 23 host6.original)ᶜ := by
  apply null_of_test host6 pat2 hostValid6 (by decide +kernel)
    (twins_from_types pat2 0x3000000011012 (by decide +kernel)) (by decide +kernel) (by decide +kernel)
  exact Word32.miss2
end E1182TwelveBlock
#print axioms E1182TwelveBlock.blocked2
