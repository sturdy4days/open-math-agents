import CodeGraph
import Mathlib.Combinatorics.SimpleGraph.Operations

open SimpleGraph
namespace E1182Twelve

/-- If a blue graph is forbidden in the host, some edge of any injective placement of it
    must be red in every candidate that embeds in blue. -/
theorem forbidden_edge {V W A B : Type*} {R : SimpleGraph V} {D : SimpleGraph W}
    {P : SimpleGraph A} {H : SimpleGraph B} (red : R.Copy D) (blue : P.Copy Rᶜ)
    (host : Dᶜ ⊑ H) (forbidden : ¬ P ⊑ H) :
    ∃ i j, P.Adj i j ∧ D.Adj (red (blue i)) (red (blue j)) := by
  classical
  by_contra! none
  apply forbidden
  apply IsContained.trans _ host
  refine ⟨⟨⟨fun i => red (blue i), ?_⟩, red.injective.comp blue.injective⟩⟩
  intro x y e
  exact ⟨fun h => e.ne (blue.injective (red.injective h)), none x y e⟩

/-- It suffices to check the red one-edge extensions that hit a single forbidden blue copy. -/
theorem branch_forbidden {V W A B : Type*} {R : SimpleGraph V} {D : SimpleGraph W}
    {P : SimpleGraph A} {H : SimpleGraph B} {Q : Prop} (red : R ⊑ D) (blue : P.Copy Rᶜ)
    (host : Dᶜ ⊑ H) (forbidden : ¬ P ⊑ H)
    (branches : ∀ i j, P.Adj i j → (R ⊔ edge (blue i) (blue j)) ⊑ D → Q) : Q := by
  obtain ⟨f⟩ := red
  obtain ⟨i,j,e,adj⟩ := forbidden_edge f blue host forbidden
  apply branches i j e
  refine ⟨⟨⟨f,?_⟩, f.injective⟩⟩
  intro x y edge'
  rcases edge' with present | extra
  · exact f.toHom.map_rel' present
  · rw [SimpleGraph.edge_adj] at extra
    rcases extra.1 with ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩
    · exact adj
    · exact adj.symm

end E1182Twelve
#print axioms E1182Twelve.forbidden_edge
#print axioms E1182Twelve.branch_forbidden
