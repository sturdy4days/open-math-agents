import Intro13
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x28 : ((leaves13.drop 28).take 1).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x29 : ((leaves13.drop 29).take 2).all test13=true := by decide +kernel
end E1182TwelveBlock.Word32
