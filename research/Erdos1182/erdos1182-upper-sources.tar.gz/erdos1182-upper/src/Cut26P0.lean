import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf26_0_1 : failed host0 pat26 (atPath host0 pat26 [1,0]) = true := by
  decide +kernel

theorem leaf26_0_3_4 : failed host0 pat26 (atPath host0 pat26 [4,3,0]) = true := by
  decide +kernel

theorem leaf26_0_3_7 : failed host0 pat26 (atPath host0 pat26 [7,3,0]) = true := by
  decide +kernel

theorem leaf26_0_3_10 : failed host0 pat26 (atPath host0 pat26 [10,3,0]) = true := by
  decide +kernel

theorem leaf26_0_3_11 : failed host0 pat26 (atPath host0 pat26 [11,3,0]) = true := by
  decide +kernel

theorem leaf26_0_3_12 : failed host0 pat26 (atPath host0 pat26 [12,3,0]) = true := by
  decide +kernel

theorem leaf26_0_3_13 : failed host0 pat26 (atPath host0 pat26 [13,3,0]) = true := by
  decide +kernel

end E1182ElevenBlock
