import Intro13
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x74 : ((leaves13.drop 74).take 2).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x76 : ((leaves13.drop 76).take 4).all test13=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice13x80 : ((leaves13.drop 80).take 1).all test13=true := by decide +kernel
end E1182TwelveBlock.Word32
