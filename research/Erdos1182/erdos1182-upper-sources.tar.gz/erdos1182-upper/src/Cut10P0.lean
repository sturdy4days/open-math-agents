import Descent
import ValidHost0
namespace E1182ElevenBlock
theorem leaf10_0_1 : failed host0 pat10 (atPath host0 pat10 [1,0]) = true := by
  decide +kernel

theorem leaf10_0_3_4 : failed host0 pat10 (atPath host0 pat10 [4,3,0]) = true := by
  decide +kernel

theorem leaf10_0_3_7 : failed host0 pat10 (atPath host0 pat10 [7,3,0]) = true := by
  decide +kernel

theorem leaf10_0_3_10 : failed host0 pat10 (atPath host0 pat10 [10,3,0]) = true := by
  decide +kernel

end E1182ElevenBlock
