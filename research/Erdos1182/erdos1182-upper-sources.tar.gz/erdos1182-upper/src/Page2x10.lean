import Intro2
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x58 : ((leaves2.drop 58).take 1).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x59 : ((leaves2.drop 59).take 1).all test2=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice2x60 : ((leaves2.drop 60).take 1).all test2=true := by decide +kernel
end E1182TwelveBlock.Word32
