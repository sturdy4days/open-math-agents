import Intro3
namespace E1182TwelveBlock.Word32
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice3x66 : ((leaves3.drop 66).take 3).all test3=true := by decide +kernel
set_option maxHeartbeats 0 in
set_option maxRecDepth 9000 in
theorem slice3x69 : ((leaves3.drop 69).take 7).all test3=true := by decide +kernel
end E1182TwelveBlock.Word32
