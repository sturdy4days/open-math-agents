import HostRule
namespace E1182ElevenBlock

def extractDomain (s : ℕ) (i : Fin 11) := (s >>> (21*i.val)) % (2^21)
theorem extract_bit (s : ℕ) (i : Fin 11) {a : ℕ} (ha : a < 21) :
    (extractDomain s i).testBit a = s.testBit (21*i.val+a) := by
  simp only [extractDomain,Nat.testBit_mod_two_pow,decide_eq_true ha,Bool.true_and,Nat.testBit_shiftRight]

def presents (ds : List (Fin 11 × ℕ)) (s : ℕ) : Prop :=
  ∀ u∈ds, ∀ v, u.2.testBit v = true →
     v < 21 ∧ s.testBit (21*u.1.val+v) = true

def fastSearch (perm : Fin 11 → ℕ → ℕ) (apart : ℕ → ℕ) :
    List (Fin 11) → ℕ → List ℕ → Bool
  | [],_,_ => true
  | i::t,word,supply =>
    (extractDomain word i).bitIndices.any fun v =>
      supply.contains v && (let remv := supply.erase v
                            let mask := word &&& perm i v
                            let ns := if remv.contains v then mask else mask &&& apart v
                            t.all (fun j => extractDomain ns j != 0) &&
                            fastSearch perm apart t ns remv)

theorem step_presents (allow : Fin 11 → Fin 11 → ℕ → ℕ) (apart : List ℕ)
    (perm : Fin 11 → ℕ → ℕ) (diff : ℕ → ℕ)
    (allowed : ∀ i j v a, v < 21 → a < 21 → (allow i j v).testBit a=true →
      (perm i v).testBit (21*j.val+a)=true)
    (separate : ∀ (j : Fin 11) (v a : ℕ), v < 21 → a < 21 → apart[v]!.testBit a=true →
      (diff v).testBit (21*j.val+a)=true)
    (i : Fin 11) (v : ℕ) (hv : v < 21) (remv : List ℕ) (t : List (Fin 11 × ℕ))
    (word : Nat) (prev : presents t word) :
    presents (consumeDomains allow apart i v remv t)
      (if remv.contains v then word &&& perm i v else (word &&& perm i v) &&& diff v) := by
  intro u hu a hit
  obtain ⟨⟨j,d⟩,mem,rfl⟩ := List.mem_map.mp hu
  split <;> rename_i flag
  · change (if remv.contains v then d &&& allow i j v else _).testBit a = true at hit
    simp only [if_pos flag,Nat.testBit_and,Bool.and_eq_true] at hit
    obtain ⟨small,live⟩ := prev (j,d) mem a hit.1
    exact ⟨small,by simpa only [Nat.testBit_and,Bool.and_eq_true] using And.intro live (allowed i j v a hv small hit.2)⟩
  · change (if remv.contains v then d &&& allow i j v else _).testBit a = true at hit
    simp only [if_neg flag,Nat.testBit_and,Bool.and_eq_true] at hit
    obtain ⟨small,live⟩ := prev (j,d) mem a hit.1.1
    refine ⟨small,?_⟩
    simp only [Nat.testBit_and,Bool.and_eq_true]
    exact ⟨⟨live,allowed i j v a hv small hit.1.2⟩,separate j v a hv small hit.2⟩

theorem capSearch_fast (allow : Fin 11 → Fin 11 → ℕ → ℕ) (apart : List ℕ)
    (perm : Fin 11 → ℕ → ℕ) (diff : ℕ → ℕ)
    (allowed : ∀ i j v a, v < 21 → a < 21 → (allow i j v).testBit a=true →
      (perm i v).testBit (21*j.val+a)=true)
    (separate : ∀ (j : Fin 11) (v a : ℕ), v < 21 → a < 21 → apart[v]!.testBit a=true →
      (diff v).testBit (21*j.val+a)=true)
    (k : ℕ) (ds : List (Fin 11 × ℕ)) (word : ℕ) (supply : List ℕ) (len : ds.length=k)
    (valid : presents ds word) (old : capSearch allow apart k ds supply=true) :
    fastSearch perm diff (ds.map Prod.fst) word supply=true := by
  induction k generalizing ds word supply with
  | zero => simp at len; simp [len,fastSearch]
  | succ k ih =>
    rcases ds with _ | ⟨⟨i,d⟩,t⟩
    · simp
      rfl
    · have tl : t.length=k := by simpa only [List.length_cons,Nat.succ.injEq] using len
      obtain ⟨v,member,pass⟩ := List.any_eq_true.mp old
      let remv := supply.erase v
      let next := consumeDomains allow apart i v remv t
      change (supply.contains v && (next.all (fun u => u.2 != 0) && capSearch allow apart k next remv))=true at pass
      simp only [Bool.and_eq_true] at pass
      obtain ⟨small,bit⟩ := valid (i,d) List.mem_cons_self v (Nat.mem_bitIndices.mp member)
      let ns := if remv.contains v then word &&& perm i v else (word &&& perm i v) &&& diff v
      have step : presents next ns := step_presents allow apart perm diff allowed separate i v small remv t word
        (fun u hu => valid u (List.mem_cons_of_mem _ hu))
      have eq : next.map Prod.fst=t.map Prod.fst := by simp [next,consumeDomains,List.map_map,Function.comp_def]
      have hlen : next.length=k := (List.length_map _).trans tl
      have sub := ih next ns remv hlen step pass.2.2
      rw [eq] at sub
      apply List.any_eq_true.mpr
      refine ⟨v,Nat.mem_bitIndices.mpr ((extract_bit word i small).trans bit),?_⟩
      change (supply.contains v && ((t.map Prod.fst).all (fun j => extractDomain ns j != 0) &&
        fastSearch perm diff (t.map Prod.fst) ns remv))=true
      simp only [Bool.and_eq_true]
      refine ⟨pass.1,?_,sub⟩
      apply List.all_eq_true.mpr
      intro j hj
      rw [←eq] at hj
      obtain ⟨u,hu,rfl⟩ := List.mem_map.mp hj
      have nonzero := bne_iff_ne.mp (List.all_eq_true.mp pass.2.1 u hu)
      obtain ⟨a,ha⟩ := Nat.exists_testBit_of_ne_zero nonzero
      obtain ⟨bound,bit⟩ := step u hu a ha
      apply bne_iff_ne.mpr
      intro zero
      have pbit := (extract_bit ns u.1 bound).trans bit
      simp only [zero,Nat.zero_testBit,Bool.false_eq_true] at pbit

end E1182ElevenBlock
#print axioms E1182ElevenBlock.capSearch_fast
