import Descent
import ValidHost3
namespace E1182ElevenBlock
theorem leaf7_0_1 : failed host3 pat7 (atPath host3 pat7 [1,0]) = true := by
  decide +kernel

theorem leaf7_0_2 : failed host3 pat7 (atPath host3 pat7 [2,0]) = true := by
  decide +kernel

theorem leaf7_0_3 : failed host3 pat7 (atPath host3 pat7 [3,0]) = true := by
  decide +kernel

theorem leaf7_0_4 : failed host3 pat7 (atPath host3 pat7 [4,0]) = true := by
  decide +kernel

end E1182ElevenBlock
