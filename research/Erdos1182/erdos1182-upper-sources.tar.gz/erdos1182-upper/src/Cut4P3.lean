import Descent
import ValidHost1
namespace E1182ElevenBlock
theorem leaf4_0_13 : failed host1 pat4 (atPath host1 pat4 [13,0]) = true := by
  decide +kernel

theorem leaf4_2_1_1 : failed host1 pat4 (atPath host1 pat4 [1,1,2]) = true := by
  decide +kernel

theorem leaf4_2_1_4 : failed host1 pat4 (atPath host1 pat4 [4,1,2]) = true := by
  decide +kernel

theorem leaf4_2_1_5 : failed host1 pat4 (atPath host1 pat4 [5,1,2]) = true := by
  decide +kernel

theorem leaf4_2_1_7 : failed host1 pat4 (atPath host1 pat4 [7,1,2]) = true := by
  decide +kernel

theorem leaf4_2_1_8 : failed host1 pat4 (atPath host1 pat4 [8,1,2]) = true := by
  decide +kernel

theorem leaf4_2_1_9 : failed host1 pat4 (atPath host1 pat4 [9,1,2]) = true := by
  decide +kernel

theorem leaf4_2_1_11 : failed host1 pat4 (atPath host1 pat4 [11,1,2]) = true := by
  decide +kernel

theorem leaf4_2_1_12 : failed host1 pat4 (atPath host1 pat4 [12,1,2]) = true := by
  decide +kernel

theorem leaf4_2_1_14 : failed host1 pat4 (atPath host1 pat4 [14,1,2]) = true := by
  decide +kernel

end E1182ElevenBlock
