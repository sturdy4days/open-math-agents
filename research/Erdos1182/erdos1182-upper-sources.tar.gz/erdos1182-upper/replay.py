"""Replay the local modules using the pinned Lean binary with Mathlib and FormalConjectures available."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
p=Path(__file__).resolve().parent; m=json.loads((p/'manifest.json').read_text());out=p/'build';out.mkdir(exist_ok=True)
paths=os.pathsep.join([str(out),os.environ['LEAN_PATH']]);env={**os.environ,'LEAN_PATH':paths,'LEAN_NUM_THREADS':'1'}
for item in m['dependencyOrder']:
 src=p/'src'/item['source'];assert hashlib.sha256(src.read_bytes()).hexdigest()==item['sha256'];name=item['name'].replace('.','/');dest=out/(name+'.olean');dest.parent.mkdir(parents=True,exist_ok=True)
 run=subprocess.run([os.environ.get('LEAN','lean'),'-j1','-o',str(dest),item['source']],cwd=p/'src',env=env,check=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);print(name,run.stdout,flush=True);assert 'sorryAx'not in run.stdout and 'error:'not in run.stdout
