"""Replay the archived finite graph classification."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import time

root = Path(__file__).resolve().parent
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--build',type=Path,required=True)
p.add_argument('--reuse-dir',type=Path,action='append',default=[],help='allowed hash-pinned kernel objects')
p.add_argument('--fresh',action='append',default=[],help='always recompile the specified module')
p.add_argument('--lean',default='lean')
p.add_argument('--link-cache',action='store_true',help='hard-link verified immutable objects into the new build')
p.add_argument('--memory-mib',default=6600,type=int)
args = p.parse_args()
manifest = json.loads((root/'manifest.json').read_text())
modules = [r['module'] for r in manifest['modules']]
expected_objects = {r['module']:r['object'] for r in manifest['modules']}
unknown = set(args.fresh) - set(modules)
if unknown:
    raise SystemExit('Unknown module '+str(unknown))
version = subprocess.check_output([args.lean,'--version'],text=True).strip()
if 'version 4.33.1,' not in version:
    raise SystemExit('Requires Lean 4.33.1')
work = args.build.resolve()
lib, logs, records = [work/name for name in ['lib','logs','receipts']]
for d in [lib,logs,records]:
    d.mkdir(parents=True,exist_ok=True)
env = dict(os.environ, LEAN_NUM_THREADS='1')
paths = [str(Path(s).resolve()) for s in env.get('LEAN_PATH','').split(os.pathsep) if s]
env['LEAN_PATH'] = os.pathsep.join([str(lib)]+paths)
def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()
def check(source,name,audit):
    partial = lib/(name+'.partial.olean')
    log = logs/(name+'.log')
    with log.open('w') as sink:
        proc = subprocess.run([args.lean,'-j1','-M'+str(args.memory_mib),'-o',str(partial),source.name],
            cwd=source.parent,env=env,stdout=sink,stderr=subprocess.STDOUT)
    lines = log.read_text().splitlines()
    if proc.returncode or any('warning:' in l or 'error:' in l for l in lines):
        raise SystemExit(f'{name} kernel diagnostics: {log}')
    for theorem in audit:
        report = [l for l in lines if l.startswith("'"+theorem+"' depends on axioms: [")]
        if len(report)!=1:
            raise SystemExit(f'Missing axiom report for {theorem}')
        axioms = set(report[0].split('[',1)[1].strip(']').split(', '))
        if axioms - {'propext','Classical.choice','Quot.sound'}:
            raise SystemExit(report[0])
    return partial
times=[]
object_hashes={}
for r in manifest['modules']:
    n = r['module']
    source = root/'src'/(n+'.lean')
    if sha(source)!=r['source']:
        raise SystemExit('Source SHA-256 mismatch '+n)
    incoming = {k:object_hashes[k] for k in r['imports']}
    stamp = {'source':r['source'],'imports':incoming}
    receipt = records/(n+'.json')
    out = lib/(n+'.olean')
    start = time.monotonic()
    mode='built'
    if n not in args.fresh and receipt.exists() and out.is_file():
        hist = json.loads(receipt.read_text())
        if hist['inputs']==stamp and hist['object']==sha(out):
            object_hashes[n] = hist['object']
            times.append({'module':n,'mode':'resumed'})
            continue
    cached = None
    if n not in args.fresh and all(h==expected_objects[k] for k,h in incoming.items()):
        cached=next((d/(n+'.olean') for d in args.reuse_dir if (d/(n+'.olean')).is_file()
                     and sha(d/(n+'.olean'))==r['object']),None)
    if cached:
        tmp = lib/(n+'.cached.olean')
        if tmp.exists():tmp.unlink()
        if args.link_cache:
            try:os.link(cached,tmp)
            except OSError:shutil.copyfile(cached,tmp)
        else:shutil.copyfile(cached,tmp)
        tmp.replace(out)
        mode = 'reused'
    else:
        check(source,n,r['audit']).replace(out)
    h = sha(out)
    object_hashes[n] = h
    elapsed = round(time.monotonic()-start,3)
    temp=receipt.with_suffix('.tmp')
    temp.write_text(json.dumps({'inputs':stamp,'object':h,'mode':mode,'seconds':elapsed})+'\n')
    temp.replace(receipt)
    times.append({'module':n,'mode':mode,'seconds':elapsed})
    if mode=='built':
        print(n,f'{elapsed:.2f} seconds',flush=True)
source=root/'AxiomAudit.lean'
audit=[line.split()[2] for line in source.read_text().splitlines() if line.startswith('#print axioms ')]
check(source,'AxiomAudit',audit).replace(lib/'AxiomAudit.olean')
summary={'lean':version,'built':[r['module'] for r in times if r['mode']=='built'],
         'reused':sum(r['mode']=='reused' for r in times),'resumed':sum(r['mode']=='resumed' for r in times),
         'verified':manifest['entry'],'axiomAudit':(logs/'AxiomAudit.log').read_text().splitlines()}
(work/'replay-result.json').write_text(json.dumps(summary,indent=2)+'\n')
print('Verified',manifest['entry'],'across',len(modules),'modules.')
print((logs/'AxiomAudit.log').read_text(),end='')
