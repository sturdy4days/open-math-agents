import EarlyCatalogue
import BitmapLevel9

namespace EarlyRamsey
open BBHExtension SimpleGraph

/-- The independent bit-parallel proof covers every connector, so it also
covers the connectors that satisfy the inductive priority selector. -/
theorem step9 : selectedRows (decode 10 Terminal18.target) priorityRow (atlas 9) (atlas 10) := by
  intro P memP S memS dom _
  exact BitmapLevel9.all_parents P memP S memS dom

end EarlyRamsey
