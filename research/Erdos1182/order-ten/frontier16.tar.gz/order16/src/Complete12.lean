import Mathlib.Tactic.IntervalCases
import Level0
import Level1
import Level2
import Level3
import Level4
import Level5
import Level6
import Level7
import Level8
import Level9
import Level10
import Level11

namespace EarlyRamsey
open BBHExtension SimpleGraph

/-- Every maximal triangle-free host of any verified order whose complement
avoids the fixed ten-vertex graph is isomorphic to a listed representative. -/
theorem complete12 (k : ℕ) (bound : k ≤ 12) (H : SimpleGraph (Fin k))
    (maxH : Maximal (fun D : SimpleGraph (Fin k) => D.CliqueFree 3) H)
    (avoid : ¬ decode 10 Terminal18.target ⊑ Hᶜ) :
    ∃ X ∈ atlas k, Nonempty (H ≃g X) := by
  apply selected_atlas_complete (decode 10 Terminal18.target) 12 atlas ?_ (fun _ => priorityRow)
    (fun _ => priority_parent _) (fun _ => priority_image) ?_ k bound H maxH avoid
  · have eq : decode 0 0 = (⊥ : SimpleGraph (Fin 0)) := Subsingleton.elim _ _
    simp [atlas,codes,words0,eq]
  · intro j hj
    interval_cases j
    · exact step0
    · exact step1
    · exact step2
    · exact step3
    · exact step4
    · exact step5
    · exact step6
    · exact step7
    · exact step8
    · exact step9
    · exact step10
    · exact step11

/-- The numeric graph code can be passed directly to a subsequent finite check. -/
theorem complete12_code (k : ℕ) (bound : k ≤ 12) (H : SimpleGraph (Fin k))
    (maxH : Maximal (fun D : SimpleGraph (Fin k) => D.CliqueFree 3) H)
    (avoid : ¬ decode 10 Terminal18.target ⊑ Hᶜ) :
    ∃ p ∈ codes k, Nonempty (H ≃g decode k p) := by
  obtain ⟨X,mem,iso⟩ := complete12 k bound H maxH avoid
  obtain ⟨p,hp,rfl⟩ := List.mem_map.mp mem
  exact ⟨p,hp,iso⟩

/-- Every triangle-free avoiding host extends on the same labeled vertices to
a maximal host with one of the certified graph codes. -/
theorem spanning12 (k : ℕ) (bound : k ≤ 12) (H : SimpleGraph (Fin k))
    (free : H.CliqueFree 3) (avoid : ¬ decode 10 Terminal18.target ⊑ Hᶜ) :
    ∃ K : SimpleGraph (Fin k), H ≤ K ∧ Maximal (fun D : SimpleGraph (Fin k) => D.CliqueFree 3) K ∧
      ∃ p ∈ codes k, Nonempty (K ≃g decode k p) := by
  classical
  let fam : Set (SimpleGraph (Fin k)) := {D | D.CliqueFree 3}
  obtain ⟨K,hK,maxK⟩ := fam.toFinite.exists_le_maximal (show H∈fam from free)
  exact ⟨K,hK,maxK,complete12_code k bound K maxK
    (fun h => avoid (h.mono_right (compl_le_compl hK)))⟩

end EarlyRamsey

#print axioms EarlyRamsey.complete12_code
#print axioms EarlyRamsey.spanning12
