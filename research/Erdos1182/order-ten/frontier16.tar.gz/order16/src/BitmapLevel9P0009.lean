import BitmapLevel9Data
namespace BitmapLevel9.BitmapLevel9P0009
open SimpleGraph BBHExtension ExtensionBitmap
def p : ℕ := 4086633664
def masks : Array ℕ := #[304, 336, 416, 448, 131, 69, 42, 28, 15]
set_option maxRecDepth 12000
set_option maxHeartbeats 2500000
def rs0 : List (ℕ × ℕ × Witness) := [(0,305,.undominated 0),
(0,338,.undominated 1),
(0,420,.undominated 2),
(0,456,.undominated 3),
(0,147,.undominated 4),
(0,101,.undominated 5),
(0,106,.undominated 6),
(0,156,.undominated 7),
(0,271,.undominated 8),
(273,2,.gap 0 1),
(289,4,.gap 0 2),
(257,8,.gap 0 3),
(33,64,.gap 0 6),
(17,128,.gap 0 7),
(274,1,.gap 1 0),
(258,4,.gap 1 2),
(322,8,.gap 1 3),
(66,32,.gap 1 5),
(18,128,.gap 1 7),
(292,1,.gap 2 0),
(260,2,.gap 2 1),
(388,8,.gap 2 3),
(132,16,.gap 2 4),
(36,64,.gap 2 6)]
private theorem valid0 : rs0.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs1 : List (ℕ × ℕ × Witness) := [(264,1,.gap 3 0),
(328,2,.gap 3 1),
(392,4,.gap 3 2),
(136,16,.gap 3 4),
(72,32,.gap 3 5),
(144,4,.gap 4 2),
(144,8,.gap 4 3),
(17,32,.gap 4 5),
(18,64,.gap 4 6),
(19,256,.gap 4 8),
(96,2,.gap 5 1),
(96,8,.gap 5 3),
(33,16,.gap 5 4),
(36,128,.gap 5 7),
(37,256,.gap 5 8),
(96,1,.gap 6 0),
(96,4,.gap 6 2),
(66,16,.gap 6 4),
(72,128,.gap 6 7),
(74,256,.gap 6 8),
(144,1,.gap 7 0),
(144,2,.gap 7 1),
(132,32,.gap 7 5),
(136,64,.gap 7 6)]
private theorem valid1 : rs1.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs2 : List (ℕ × ℕ × Witness) := [(140,256,.gap 7 8),
(259,16,.gap 8 4),
(261,32,.gap 8 5),
(266,64,.gap 8 6),
(268,128,.gap 8 7),
(15,496,.permutes 4000346439713 144106118682885),
(28,483,.permutes 27226439286803 321166111737062),
(42,469,.permutes 27226439286803 321132792218885),
(56,455,.permutes 19115143757857 150844653805794),
(69,442,.permutes 27226439286803 319999961073925),
(84,427,.permutes 19115143757857 115694675042497),
(131,380,.permutes 27226439286803 318901489634534),
(162,349,.permutes 19115143757857 80545769987233),
(193,318,.permutes 19115143757857 45362505160866),
(262,249,.permutes 20072748419211 149741053781056),
(265,246,.permutes 20072748419211 114592081650720),
(304,207,.permutes 2141996208128 323437046368288),
(336,175,.permutes 2141996208128 324536523424832),
(416,95,.permutes 2141996208128 325669286446176),
(448,63,.permutes 2141996208128 325702571362432),
(511,0,.permutes 35115652612096 10178205453377)]
private theorem valid2 : rs2.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs := rs0 ++ rs1 ++ rs2
theorem complete : certifiedRows (decode 10 target) ([p].map (decode 9)) (children.map (decode 10)) := by
  apply parent_rows children masks rs
  · decide +kernel
  · decide +kernel
  · simp only [rs,List.all_append,valid0,valid1,valid2,Bool.and_self]
end BitmapLevel9.BitmapLevel9P0009
#print axioms BitmapLevel9.BitmapLevel9P0009.complete
