import Production13P0108
import Production13P0109
import Production13P0110
import Production13P0111
import Production13P0112
import Production13P0113
import Production13P0114
import Production13P0115
import Production13P0116
import Production13P0117
import Production13P0118
import Production13P0119
namespace Production13
open BBHExtension SimpleGraph
theorem Production13Group009 : selectedRows (decode 10 target) priorityRow (group009.map (decode 13)) (children.map (decode 14)) := by
  intro P mem S hS dom row
  simp only [group009,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact Production13P0108.complete _ (by simp [Production13P0108.p]) S hS dom row
  · exact Production13P0109.complete _ (by simp [Production13P0109.p]) S hS dom row
  · exact Production13P0110.complete _ (by simp [Production13P0110.p]) S hS dom row
  · exact Production13P0111.complete _ (by simp [Production13P0111.p]) S hS dom row
  · exact Production13P0112.complete _ (by simp [Production13P0112.p]) S hS dom row
  · exact Production13P0113.complete _ (by simp [Production13P0113.p]) S hS dom row
  · exact Production13P0114.complete _ (by simp [Production13P0114.p]) S hS dom row
  · exact Production13P0115.complete _ (by simp [Production13P0115.p]) S hS dom row
  · exact Production13P0116.complete _ (by simp [Production13P0116.p]) S hS dom row
  · exact Production13P0117.complete _ (by simp [Production13P0117.p]) S hS dom row
  · exact Production13P0118.complete _ (by simp [Production13P0118.p]) S hS dom row
  · exact Production13P0119.complete _ (by simp [Production13P0119.p]) S hS dom row
end Production13
#print axioms Production13.Production13Group009
