import BitmapCover
import FastWitness

namespace ExtensionBitmap
open SimpleGraph BBHExtension

private theorem bit_mono {a b : ℕ} (h : a &&& b = a) {i : ℕ} (hi : a.testBit i = true) :
    b.testBit i = true := by
  have r := congrArg (fun x : ℕ => x.testBit i) h
  simpa [Nat.testBit_and,hi] using r

/-- An undominated vertex, an ordered pair of old vertices with no surviving
common neighbor, a blue embedding, or a canonical child isomorphism. -/
def valid (n k t p : ℕ) (children : List ℕ) (masks : Array ℕ) :
    ℕ × ℕ × Witness → Bool
  | (_,u,.undominated y) => let b := masks[y]?.getD 0
    decide (y<k) && u.testBit y && (b &&& u == b)
  | (l,u,.gap x y) => let c := (masks[x]?.getD 0) &&& (masks[y]?.getD 0)
    decide (x<k ∧ y<k) && l.testBit x && u.testBit y && !adjacent p x y && (c &&& l == c)
  | (l,u,.embeds code) => fastCube n k t p l u code
  | (l,u,.permutes b code) => (l ||| u == 2^k-1) && decide (b ∈ children) && fastIso k p l b code

theorem valid_sound {n k t p l u : ℕ} (cs : List ℕ) {masks : Array ℕ}
    (rows : masksMatch k p masks = true) (tag : Witness) (ht : valid n k t p cs masks (l,u,tag) = true)
    (S : Finset (Fin k)) (hl : subset k l ⊆ S) (hu : Disjoint S (subset k u))
    (dom : ∀ y, y ∉ S → ∃ x ∈ S, (decode k p).Adj x y) :
    let H := extend (decode k p) S
    defect H ∨ decode n t ⊑ Hᶜ ∨ ∃ b ∈ cs, Nonempty (H ≃g decode (k+1) b) := by
  have bits := of_decide_eq_true rows
  have inside (i : Fin k) (on : l.testBit i.val = true) : i∈S := hl (by simpa [subset] using on)
  have outside (i : Fin k) (on : u.testBit i.val = true) : i∉S :=
    fun hi => Finset.disjoint_left.mp hu hi (by simpa [subset] using on)
  cases tag with
  | undominated y =>
    obtain ⟨⟨lt,bit⟩,leu⟩ : (y<k ∧ u.testBit y=true) ∧ (masks[y]?.getD 0) &&& u = masks[y]?.getD 0 :=
      by simpa [valid] using ht
    let j : Fin k := ⟨y,lt⟩
    obtain ⟨i,hi,ij⟩ := dom j (outside j bit)
    exact (outside i (bit_mono leu ((bits j i).trans ij.symm)) hi).elim
  | gap x y =>
    let c := masks[x]?.getD 0 &&& masks[y]?.getD 0
    obtain ⟨⟨⟨⟨⟨hx,hy⟩,bx⟩,by'⟩,off⟩,lec⟩ :
        ((((x<k ∧ y<k) ∧ l.testBit x=true) ∧ u.testBit y=true) ∧ adjacent p x y=false) ∧
          c &&& l = c := by simpa [valid,c] using ht
    let i : Fin k := ⟨x,hx⟩
    let j : Fin k := ⟨y,hy⟩
    have on := inside i bx
    have out := outside j by'
    have ne : i≠j := fun eq => out (eq ▸ on)
    refine Or.inl ⟨i.succ,j.succ,fun eq => ne (Fin.succ_inj.mp eq),?_,?_⟩
    · intro edge
      have h := ((extend_old _ _ i j).mp edge).1
      change adjacent p x y = true at h
      simp [off] at h
    · intro z
      refine Fin.cases ?_ (fun a => ?_) z
      · exact fun pair => out ((extend_left _ _ j).mp pair.2.symm)
      · rintro ⟨ia,ja⟩
        obtain ⟨first,noboth⟩ := (extend_old _ _ i a).mp ia
        have second := ((extend_old _ _ j a).mp ja).1
        have common : c.testBit a.val=true := by
          rw [Nat.testBit_and,Bool.and_eq_true]
          exact ⟨(bits i a).trans first,(bits j a).trans second⟩
        exact noboth ⟨on,inside a (bit_mono lec common)⟩
  | embeds code => exact Or.inr (Or.inl (cube_covers (fastCube_sound ht) hl hu))
  | permutes b code =>
    obtain ⟨⟨all,mem⟩,iso⟩ : (l ||| u = 2^k-1 ∧ b∈cs) ∧ fastIso k p l b code = true := by
      simpa [valid] using ht
    have eq : S = subset k l := Finset.Subset.antisymm (fun i hi => by
      have bit := congrArg (fun w : ℕ => w.testBit i.val) all
      have split : l.testBit i.val=true ∨ u.testBit i.val=true := by
        simpa [Nat.testBit_or,i.isLt] using bit
      rcases split with h|h
      · simpa [subset] using h
      · exact (outside i h hi).elim) hl
    subst S
    exact Or.inr (Or.inr ⟨b,mem,fastIso_sound iso⟩)

theorem parent_rows {n k t p : ℕ} (children : List ℕ) (masks : Array ℕ)
    (rs : List (ℕ × ℕ × Witness)) (matchRows : masksMatch k p masks = true)
    (fill : covered k rs = 2^(2^k)-1) (checked : rs.all (valid n k t p children masks) = true) :
    certifiedRows (decode n t) ([p].map (decode k)) (children.map (decode (k+1))) := by
  intro P hP S _ dom
  obtain rfl : P = decode k p := by simpa using hP
  obtain ⟨⟨l,u,tag⟩,mem,lo,hi⟩ := covers rs fill S
  have pass := List.all_eq_true.mp checked _ mem
  rcases valid_sound children matchRows tag pass S lo hi dom with bad|hit|⟨b,hb,iso⟩
  · exact Or.inl bad
  · exact Or.inr (Or.inl hit)
  · exact Or.inr (Or.inr ⟨_,List.mem_map_of_mem hb,iso⟩)
end ExtensionBitmap
#print axioms ExtensionBitmap.parent_rows
