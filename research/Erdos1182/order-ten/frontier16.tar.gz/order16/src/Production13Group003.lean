import Production13P0036
import Production13P0037
import Production13P0038
import Production13P0039
import Production13P0040
import Production13P0041
import Production13P0042
import Production13P0043
import Production13P0044
import Production13P0045
import Production13P0046
import Production13P0047
namespace Production13
open BBHExtension SimpleGraph
theorem Production13Group003 : selectedRows (decode 10 target) priorityRow (group003.map (decode 13)) (children.map (decode 14)) := by
  intro P mem S hS dom row
  simp only [group003,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact Production13P0036.complete _ (by simp [Production13P0036.p]) S hS dom row
  · exact Production13P0037.complete _ (by simp [Production13P0037.p]) S hS dom row
  · exact Production13P0038.complete _ (by simp [Production13P0038.p]) S hS dom row
  · exact Production13P0039.complete _ (by simp [Production13P0039.p]) S hS dom row
  · exact Production13P0040.complete _ (by simp [Production13P0040.p]) S hS dom row
  · exact Production13P0041.complete _ (by simp [Production13P0041.p]) S hS dom row
  · exact Production13P0042.complete _ (by simp [Production13P0042.p]) S hS dom row
  · exact Production13P0043.complete _ (by simp [Production13P0043.p]) S hS dom row
  · exact Production13P0044.complete _ (by simp [Production13P0044.p]) S hS dom row
  · exact Production13P0045.complete _ (by simp [Production13P0045.p]) S hS dom row
  · exact Production13P0046.complete _ (by simp [Production13P0046.p]) S hS dom row
  · exact Production13P0047.complete _ (by simp [Production13P0047.p]) S hS dom row
end Production13
#print axioms Production13.Production13Group003
