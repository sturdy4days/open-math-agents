import Verify4_000
import Verify4_001

namespace EarlyRamsey
open BBHExtension SimpleGraph

theorem step4 : selectedRows (decode 10 Terminal18.target) priorityRow (atlas 4) (atlas 5) := by
  apply level_step
  intro p hp
  change p ∈ words4 at hp
  simp only [words4,List.mem_cons,List.not_mem_nil,or_false] at hp
  rcases hp with rfl | rfl
  · exact Verify4_000.checked
  · exact Verify4_001.checked

end EarlyRamsey
