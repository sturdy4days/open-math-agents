import Production13P0048
import Production13P0049
import Production13P0050
import Production13P0051
import Production13P0052
import Production13P0053
import Production13P0054
import Production13P0055
import Production13P0056
import Production13P0057
import Production13P0058
import Production13P0059
namespace Production13
open BBHExtension SimpleGraph
theorem Production13Group004 : selectedRows (decode 10 target) priorityRow (group004.map (decode 13)) (children.map (decode 14)) := by
  intro P mem S hS dom row
  simp only [group004,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact Production13P0048.complete _ (by simp [Production13P0048.p]) S hS dom row
  · exact Production13P0049.complete _ (by simp [Production13P0049.p]) S hS dom row
  · exact Production13P0050.complete _ (by simp [Production13P0050.p]) S hS dom row
  · exact Production13P0051.complete _ (by simp [Production13P0051.p]) S hS dom row
  · exact Production13P0052.complete _ (by simp [Production13P0052.p]) S hS dom row
  · exact Production13P0053.complete _ (by simp [Production13P0053.p]) S hS dom row
  · exact Production13P0054.complete _ (by simp [Production13P0054.p]) S hS dom row
  · exact Production13P0055.complete _ (by simp [Production13P0055.p]) S hS dom row
  · exact Production13P0056.complete _ (by simp [Production13P0056.p]) S hS dom row
  · exact Production13P0057.complete _ (by simp [Production13P0057.p]) S hS dom row
  · exact Production13P0058.complete _ (by simp [Production13P0058.p]) S hS dom row
  · exact Production13P0059.complete _ (by simp [Production13P0059.p]) S hS dom row
end Production13
#print axioms Production13.Production13Group004
