import BitmapLevel9Data
namespace BitmapLevel9.BitmapLevel9P0012
open SimpleGraph BBHExtension ExtensionBitmap
def p : ℕ := 16775020545
def masks : Array ℕ := #[66, 385, 448, 448, 448, 448, 61, 62, 62]
set_option maxRecDepth 12000
set_option maxHeartbeats 2500000
def rs0 : List (ℕ × ℕ × Witness) := [(0,67,.undominated 0),
(0,387,.undominated 1),
(0,452,.undominated 2),
(0,456,.undominated 3),
(0,464,.undominated 4),
(0,480,.undominated 5),
(0,125,.undominated 6),
(0,190,.undominated 7),
(0,318,.undominated 8),
(65,4,.gap 0 2),
(65,8,.gap 0 3),
(65,16,.gap 0 4),
(65,32,.gap 0 5),
(3,128,.gap 0 7),
(3,256,.gap 0 8),
(386,4,.gap 1 2),
(386,8,.gap 1 3),
(386,16,.gap 1 4),
(386,32,.gap 1 5),
(3,64,.gap 1 6),
(68,1,.gap 2 0),
(388,2,.gap 2 1),
(452,8,.gap 2 3),
(452,16,.gap 2 4)]
private theorem valid0 : rs0.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs1 : List (ℕ × ℕ × Witness) := [(452,32,.gap 2 5),
(72,1,.gap 3 0),
(392,2,.gap 3 1),
(456,4,.gap 3 2),
(456,16,.gap 3 4),
(456,32,.gap 3 5),
(80,1,.gap 4 0),
(400,2,.gap 4 1),
(464,4,.gap 4 2),
(464,8,.gap 4 3),
(464,32,.gap 4 5),
(96,1,.gap 5 0),
(416,2,.gap 5 1),
(480,4,.gap 5 2),
(480,8,.gap 5 3),
(480,16,.gap 5 4),
(65,2,.gap 6 1),
(124,128,.gap 6 7),
(124,256,.gap 6 8),
(130,1,.gap 7 0),
(188,64,.gap 7 6),
(190,256,.gap 7 8),
(258,1,.gap 8 0),
(316,64,.gap 8 6)]
private theorem valid1 : rs1.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs2 : List (ℕ × ℕ × Witness) := [(318,128,.gap 8 7),
(61,450,.permutes 4277380481025 325696166693953),
(62,449,.permutes 4277382578177 325463164718145),
(66,445,.permutes 4362873176064 256463441366048),
(133,378,.permutes 8141638991891 255402549775392),
(137,374,.permutes 8141638991891 255402548727840),
(141,370,.permutes 4277147303937 324630945666113),
(145,366,.permutes 8141638991891 255402515174432),
(149,362,.permutes 4277147303937 324630979219521),
(153,358,.permutes 4277147303937 324630980267073),
(157,354,.permutes 8141638991891 10141629089026),
(161,350,.permutes 8141638991891 255401441433632),
(165,346,.permutes 4277147303937 324631012741185),
(169,342,.permutes 4277147303937 324631013788737),
(173,338,.permutes 8141638991891 10142702798082),
(177,334,.permutes 4277147303937 324631014804545),
(181,330,.permutes 8141638991891 10142736319746),
(185,326,.permutes 8141638991891 10142737335554),
(261,250,.permutes 8141638991891 256467701664800),
(265,246,.permutes 8141638991891 256467700617248),
(269,242,.permutes 4277147303937 289480933315649),
(273,238,.permutes 8141638991891 256467667063840),
(277,234,.permutes 4277147303937 289480966869057),
(281,230,.permutes 4277147303937 289480967916609)]
private theorem valid2 : rs2.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs3 : List (ℕ × ℕ × Witness) := [(285,226,.permutes 8141638991891 9042117461282),
(289,222,.permutes 8141638991891 256466593323040),
(293,218,.permutes 4277147303937 289481000390721),
(297,214,.permutes 4277147303937 289481001438273),
(301,210,.permutes 8141638991891 9043191170338),
(305,206,.permutes 4277147303937 289481002454081),
(309,202,.permutes 8141638991891 9043224692002),
(313,198,.permutes 8141638991891 9043225707810),
(385,126,.permutes 8692541981696 325698113933409),
(448,63,.permutes 8692739080193 325702574506049),
(511,0,.permutes 35115652612096 10178205453377)]
private theorem valid3 : rs3.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs := rs0 ++ rs1 ++ rs2 ++ rs3
theorem complete : certifiedRows (decode 10 target) ([p].map (decode 9)) (children.map (decode 10)) := by
  apply parent_rows children masks rs
  · decide +kernel
  · decide +kernel
  · simp only [rs,List.all_append,valid0,valid1,valid2,valid3,Bool.and_self]
end BitmapLevel9.BitmapLevel9P0012
#print axioms BitmapLevel9.BitmapLevel9P0012.complete
