import TwinParent

namespace BBHExtension
open SimpleGraph

/-- Vertex zero has minimum degree. Using `Nat.card` makes this independent
of the choice of decidable adjacency or a `Fintype` on the neighbor sets. -/
def rootMinimum {k : ℕ} (H : SimpleGraph (Fin (k+1))) : Prop :=
  ∀ v, Nat.card (H.neighborSet 0) ≤ Nat.card (H.neighborSet v)

theorem rootMinimum_image {k} {H K : SimpleGraph (Fin (k+1))}
    (e : H ≃g K) (root : e 0 = 0) (h : rootMinimum H) : rootMinimum K := by
  intro v
  obtain ⟨x,rfl⟩ := e.surjective v
  have zero := Nat.card_congr (e.mapNeighborSet 0)
  rw [root] at zero
  rw [← zero, ← Nat.card_congr (e.mapNeighborSet x)]
  exact h x

theorem renamedExtension_zero {k} {P Q : SimpleGraph (Fin k)} (e : P ≃g Q)
    (S : Finset (Fin k)) : renamedExtension e S 0 = 0 := by
  change (finSuccEquiv k).symm (Option.map e ((finSuccEquiv k) 0)) = 0
  simp

/-- Choose a minimum-degree vertex in the given graph before applying the
saturated-parent construction. The root of the resulting extension is that vertex. -/
theorem minimum_parent {k : ℕ} {V : Type*} (G : SimpleGraph V) (H : SimpleGraph (Fin (k+1)))
    (hm : Maximal (fun D : SimpleGraph (Fin (k+1)) => D.CliqueFree 3) H)
    (avoid : ¬ G ⊑ Hᶜ) :
    ∃ (P : SimpleGraph (Fin k)) (S : Finset (Fin k)),
      Maximal (fun D : SimpleGraph (Fin k) => D.CliqueFree 3) P ∧
      (¬ G ⊑ Pᶜ) ∧ (∀ y, y∉S → ∃ x∈S, P.Adj x y) ∧
      rootMinimum (extend P S) ∧ Nonempty (H ≃g extend P S) := by
  classical
  obtain ⟨u, _, hu⟩ := Finset.univ.exists_min_image (fun x => Nat.card (H.neighborSet x))
    Finset.univ_nonempty
  let e := Equiv.swap 0 u
  let K := H.comap e
  let j : K ≃g H := SimpleGraph.Iso.comap e H
  have zero : j 0 = u := by
    change e 0 = u
    exact Equiv.swap_apply_left _ _
  have least : rootMinimum K := by
    intro x
    rw [Nat.card_congr (j.mapNeighborSet 0), Nat.card_congr (j.mapNeighborSet x), zero]
    exact hu (j x) (Finset.mem_univ _)
  have avoids : ¬ G ⊑ Kᶜ := fun hit => avoid
    (hit.trans ⟨(SimpleGraph.Embedding.complEquiv j.toEmbedding).toCopy⟩)
  obtain ⟨P,S,maxP,avoidP,dom,eq⟩ := parent G K (maximal_triangleFree_comap H hm e) avoids
  exact ⟨P, S, maxP, avoidP, dom, eq ▸ least, eq ▸ ⟨j.symm⟩⟩

/-- Only dominating rows in which the new vertex is a minimum-degree vertex
require a defect, an embedding, or a next-level representative. -/
def certifiedMinimumRows {V : Type*} (G : SimpleGraph V) {k : ℕ}
    (parents : List (SimpleGraph (Fin k))) (children : List (SimpleGraph (Fin (k+1)))) : Prop :=
  ∀ P∈parents, ∀ S ∈ (Finset.univ : Finset (Fin k)).powerset,
    (∀ y, y∉S → ∃ x∈S, P.Adj x y) → rootMinimum (extend P S) →
    defect (extend P S) ∨ G ⊑ (extend P S)ᶜ ∨
      ∃ D∈children, Nonempty (extend P S ≃g D)

theorem minimum_atlas_complete {V : Type*} (G : SimpleGraph V) (N : ℕ)
    (atlas : (k : ℕ) → List (SimpleGraph (Fin k))) (init : ⊥ ∈ atlas 0)
    (rows : ∀ k<N, certifiedMinimumRows G (atlas k) (atlas (k+1))) :
    ∀ k, k≤N → ∀ H : SimpleGraph (Fin k),
      Maximal (fun D : SimpleGraph (Fin k) => D.CliqueFree 3) H → (¬ G ⊑ Hᶜ) →
      ∃ D∈atlas k, Nonempty (H ≃g D) := by
  classical
  intro k
  induction k with
  | zero =>
    intro _ H _ _
    have eq : H=⊥ := Subsingleton.elim _ _
    subst H
    exact ⟨⊥,init,⟨RelIso.refl _⟩⟩
  | succ k ih =>
    intro bound H maxH avoid
    obtain ⟨P,S,maxP,avoidP,dom,minS,⟨i⟩⟩ := minimum_parent G H maxH avoid
    obtain ⟨Q,hQ,⟨e⟩⟩ := ih (Nat.le_of_succ_le bound) P maxP avoidP
    let T := S.map e.toEquiv.toEmbedding
    let j := renamedExtension e S
    let iso : H ≃g extend Q T := i.trans j
    rcases rows k bound Q hQ T (Finset.mem_powerset.mpr (Finset.subset_univ T))
      (dom_image e S dom) (rootMinimum_image j (renamedExtension_zero e S) minS)
      with bad | hit | ⟨D,hD,⟨f⟩⟩
    · exact (no_defect maxH iso bad).elim
    · exact (avoid (hit.trans ⟨(SimpleGraph.Embedding.complEquiv iso.symm.toEmbedding).toCopy⟩)).elim
    · exact ⟨D,hD,⟨iso.trans f⟩⟩

theorem minimum_complement_covers {V : Type*} (G : SimpleGraph V) (N : ℕ)
    (atlas : (k : ℕ) → List (SimpleGraph (Fin k))) (init : ⊥ ∈ atlas 0)
    (rows : ∀ k<N, certifiedMinimumRows G (atlas k) (atlas (k+1))) (endRow : atlas N = []) :
    ∀ H : SimpleGraph (Fin N), H.CliqueFree 3 → G ⊑ Hᶜ := by
  classical
  intro H ht
  let family : Set (SimpleGraph (Fin N)) := {D | D.CliqueFree 3}
  obtain ⟨P,leP,maxP⟩ := family.toFinite.exists_le_maximal (show H∈family from ht)
  by_contra miss
  obtain ⟨D,hD,_⟩ := minimum_atlas_complete G N atlas init rows N le_rfl P maxP
    (fun hit => miss (hit.mono_right (compl_le_compl leP)))
  simp [endRow] at hD

end BBHExtension

#print axioms BBHExtension.minimum_parent
#print axioms BBHExtension.minimum_atlas_complete
#print axioms BBHExtension.minimum_complement_covers
