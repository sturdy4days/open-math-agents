import BitmapLevel9Data
namespace BitmapLevel9.BitmapLevel9P0007
open SimpleGraph BBHExtension ExtensionBitmap
def p : ℕ := 14931206656
def masks : Array ℕ := #[384, 384, 384, 176, 328, 328, 176, 79, 55]
set_option maxRecDepth 12000
set_option maxHeartbeats 2500000
def rs0 : List (ℕ × ℕ × Witness) := [(0,385,.undominated 0),
(0,386,.undominated 1),
(0,388,.undominated 2),
(0,184,.undominated 3),
(0,344,.undominated 4),
(0,360,.undominated 5),
(0,240,.undominated 6),
(0,207,.undominated 7),
(0,311,.undominated 8),
(385,2,.gap 0 1),
(385,4,.gap 0 2),
(129,8,.gap 0 3),
(257,16,.gap 0 4),
(257,32,.gap 0 5),
(129,64,.gap 0 6),
(386,1,.gap 1 0),
(386,4,.gap 1 2),
(130,8,.gap 1 3),
(258,16,.gap 1 4),
(258,32,.gap 1 5),
(130,64,.gap 1 6),
(388,1,.gap 2 0),
(388,2,.gap 2 1),
(132,8,.gap 2 3)]
private theorem valid0 : rs0.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs1 : List (ℕ × ℕ × Witness) := [(260,16,.gap 2 4),
(260,32,.gap 2 5),
(132,64,.gap 2 6),
(136,1,.gap 3 0),
(136,2,.gap 3 1),
(136,4,.gap 3 2),
(184,64,.gap 3 6),
(56,256,.gap 3 8),
(272,1,.gap 4 0),
(272,2,.gap 4 1),
(272,4,.gap 4 2),
(344,32,.gap 4 5),
(88,128,.gap 4 7),
(288,1,.gap 5 0),
(288,2,.gap 5 1),
(288,4,.gap 5 2),
(360,16,.gap 5 4),
(104,128,.gap 5 7),
(192,1,.gap 6 0),
(192,2,.gap 6 1),
(192,4,.gap 6 2),
(240,8,.gap 6 3),
(112,256,.gap 6 8),
(200,16,.gap 7 4)]
private theorem valid1 : rs1.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs2 : List (ℕ × ℕ × Witness) := [(200,32,.gap 7 5),
(135,256,.gap 7 8),
(304,8,.gap 8 3),
(304,64,.gap 8 6),
(263,128,.gap 8 7),
(31,480,.permutes 8141638991891 291373870911718),
(47,464,.permutes 8141638991891 291373870944485),
(55,456,.permutes 7105820778496 316940844403777),
(79,432,.permutes 7105820778496 281791871224897),
(87,424,.permutes 8141638991891 325458731439300),
(103,408,.permutes 8141638991891 325458731440292),
(176,335,.permutes 4382864965632 291582347578433),
(328,183,.permutes 4382864965632 325700461530177),
(384,127,.permutes 7670745022464 325702574508064),
(511,0,.permutes 35115652612096 10178205453377)]
private theorem valid2 : rs2.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs := rs0 ++ rs1 ++ rs2
theorem complete : certifiedRows (decode 10 target) ([p].map (decode 9)) (children.map (decode 10)) := by
  apply parent_rows children masks rs
  · decide +kernel
  · decide +kernel
  · simp only [rs,List.all_append,valid0,valid1,valid2,Bool.and_self]
end BitmapLevel9.BitmapLevel9P0007
#print axioms BitmapLevel9.BitmapLevel9P0007.complete
