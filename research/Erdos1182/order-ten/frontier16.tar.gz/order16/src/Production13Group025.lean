import Production13P0300
import Production13P0301
import Production13P0302
import Production13P0303
import Production13P0304
import Production13P0305
import Production13P0306
import Production13P0307
import Production13P0308
import Production13P0309
namespace Production13
open BBHExtension SimpleGraph
theorem Production13Group025 : selectedRows (decode 10 target) priorityRow (group025.map (decode 13)) (children.map (decode 14)) := by
  intro P mem S hS dom row
  simp only [group025,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact Production13P0300.complete _ (by simp [Production13P0300.p]) S hS dom row
  · exact Production13P0301.complete _ (by simp [Production13P0301.p]) S hS dom row
  · exact Production13P0302.complete _ (by simp [Production13P0302.p]) S hS dom row
  · exact Production13P0303.complete _ (by simp [Production13P0303.p]) S hS dom row
  · exact Production13P0304.complete _ (by simp [Production13P0304.p]) S hS dom row
  · exact Production13P0305.complete _ (by simp [Production13P0305.p]) S hS dom row
  · exact Production13P0306.complete _ (by simp [Production13P0306.p]) S hS dom row
  · exact Production13P0307.complete _ (by simp [Production13P0307.p]) S hS dom row
  · exact Production13P0308.complete _ (by simp [Production13P0308.p]) S hS dom row
  · exact Production13P0309.complete _ (by simp [Production13P0309.p]) S hS dom row
end Production13
#print axioms Production13.Production13Group025
