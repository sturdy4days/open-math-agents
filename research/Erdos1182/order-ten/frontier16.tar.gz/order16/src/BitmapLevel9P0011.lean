import BitmapLevel9Data
namespace BitmapLevel9.BitmapLevel9P0011
open SimpleGraph BBHExtension ExtensionBitmap
def p : ℕ := 34085011457
def masks : Array ℕ := #[130, 257, 384, 384, 384, 384, 384, 125, 126]
set_option maxRecDepth 12000
set_option maxHeartbeats 2500000
def rs0 : List (ℕ × ℕ × Witness) := [(0,131,.undominated 0),
(0,259,.undominated 1),
(0,388,.undominated 2),
(0,392,.undominated 3),
(0,400,.undominated 4),
(0,416,.undominated 5),
(0,448,.undominated 6),
(0,253,.undominated 7),
(0,382,.undominated 8),
(129,4,.gap 0 2),
(129,8,.gap 0 3),
(129,16,.gap 0 4),
(129,32,.gap 0 5),
(129,64,.gap 0 6),
(3,256,.gap 0 8),
(258,4,.gap 1 2),
(258,8,.gap 1 3),
(258,16,.gap 1 4),
(258,32,.gap 1 5),
(258,64,.gap 1 6),
(3,128,.gap 1 7),
(132,1,.gap 2 0),
(260,2,.gap 2 1),
(388,8,.gap 2 3)]
private theorem valid0 : rs0.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs1 : List (ℕ × ℕ × Witness) := [(388,16,.gap 2 4),
(388,32,.gap 2 5),
(388,64,.gap 2 6),
(136,1,.gap 3 0),
(264,2,.gap 3 1),
(392,4,.gap 3 2),
(392,16,.gap 3 4),
(392,32,.gap 3 5),
(392,64,.gap 3 6),
(144,1,.gap 4 0),
(272,2,.gap 4 1),
(400,4,.gap 4 2),
(400,8,.gap 4 3),
(400,32,.gap 4 5),
(400,64,.gap 4 6),
(160,1,.gap 5 0),
(288,2,.gap 5 1),
(416,4,.gap 5 2),
(416,8,.gap 5 3),
(416,16,.gap 5 4),
(416,64,.gap 5 6),
(192,1,.gap 6 0),
(320,2,.gap 6 1),
(448,4,.gap 6 2)]
private theorem valid1 : rs1.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs2 : List (ℕ × ℕ × Witness) := [(448,8,.gap 6 3),
(448,16,.gap 6 4),
(448,32,.gap 6 5),
(129,2,.gap 7 1),
(252,256,.gap 7 8),
(258,1,.gap 8 0),
(380,128,.gap 8 7),
(125,386,.permutes 8692739080193 281791937252386),
(126,385,.permutes 8692739080193 316941949602881),
(130,381,.permutes 8795025571840 291447023733792),
(257,254,.permutes 8795025571840 325497524456512),
(384,127,.permutes 17522661261313 325702574506049),
(511,0,.permutes 35115652612096 10178205453377)]
private theorem valid2 : rs2.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs := rs0 ++ rs1 ++ rs2
theorem complete : certifiedRows (decode 10 target) ([p].map (decode 9)) (children.map (decode 10)) := by
  apply parent_rows children masks rs
  · decide +kernel
  · decide +kernel
  · simp only [rs,List.all_append,valid0,valid1,valid2,Bool.and_self]
end BitmapLevel9.BitmapLevel9P0011
#print axioms BitmapLevel9.BitmapLevel9P0011.complete
