import Production13P0012
import Production13P0013
import Production13P0014
import Production13P0015
import Production13P0016
import Production13P0017
import Production13P0018
import Production13P0019
import Production13P0020
import Production13P0021
import Production13P0022
import Production13P0023
namespace Production13
open BBHExtension SimpleGraph
theorem Production13Group001 : selectedRows (decode 10 target) priorityRow (group001.map (decode 13)) (children.map (decode 14)) := by
  intro P mem S hS dom row
  simp only [group001,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact Production13P0012.complete _ (by simp [Production13P0012.p]) S hS dom row
  · exact Production13P0013.complete _ (by simp [Production13P0013.p]) S hS dom row
  · exact Production13P0014.complete _ (by simp [Production13P0014.p]) S hS dom row
  · exact Production13P0015.complete _ (by simp [Production13P0015.p]) S hS dom row
  · exact Production13P0016.complete _ (by simp [Production13P0016.p]) S hS dom row
  · exact Production13P0017.complete _ (by simp [Production13P0017.p]) S hS dom row
  · exact Production13P0018.complete _ (by simp [Production13P0018.p]) S hS dom row
  · exact Production13P0019.complete _ (by simp [Production13P0019.p]) S hS dom row
  · exact Production13P0020.complete _ (by simp [Production13P0020.p]) S hS dom row
  · exact Production13P0021.complete _ (by simp [Production13P0021.p]) S hS dom row
  · exact Production13P0022.complete _ (by simp [Production13P0022.p]) S hS dom row
  · exact Production13P0023.complete _ (by simp [Production13P0023.p]) S hS dom row
end Production13
#print axioms Production13.Production13Group001
