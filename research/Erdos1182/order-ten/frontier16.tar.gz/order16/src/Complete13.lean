import Complete12
import CompactLevel12
import Frontier

namespace EarlyRamsey
open BBHExtension SimpleGraph

/-- The committed catalogue through order twelve, extended by the explicit
canonical child list of the new kernel-verified transition. -/
def codes13 (k : ℕ) : List ℕ := if k = 13 then CompactLevel12.children else codes k

theorem complete13_code (k : ℕ) (bound : k ≤ 13) (H : SimpleGraph (Fin k))
    (maxH : Maximal (fun D : SimpleGraph (Fin k) => D.CliqueFree 3) H)
    (avoid : ¬ decode 10 Terminal18.target ⊑ Hᶜ) :
    ∃ p ∈ codes13 k, Nonempty (H ≃g decode k p) := by
  by_cases small : k ≤ 12
  · have ne : k ≠ 13 := by omega
    simpa only [codes13, if_neg ne] using complete12_code k small H maxH avoid
  · obtain rfl : k=13 := by omega
    let cat (j : ℕ) := (codes13 j).map (decode j)
    have start (K : SimpleGraph (Fin 12))
        (maxK : Maximal (fun D : SimpleGraph (Fin 12) => D.CliqueFree 3) K)
        (noK : ¬decode 10 Terminal18.target ⊑ Kᶜ) :
        ∃ X ∈ cat 12, Nonempty (K ≃g X) := by
      exact complete12 12 le_rfl K maxK noK
    have next : ∀ j, 12 ≤ j → j < 13 → selectedRows (decode 10 Terminal18.target)
        priorityRow (cat j) (cat (j+1)) := by
      intro j hj lo
      obtain rfl : j=12 := by omega
      exact CompactLevel12.all_parents
    obtain ⟨X,mem,iso⟩ := continue_from cat start next 13 (by decide) le_rfl H maxH avoid
    obtain ⟨p,hp,rfl⟩ := List.mem_map.mp mem
    exact ⟨p,hp,iso⟩

theorem spanning13 (k : ℕ) (bound : k ≤ 13) (H : SimpleGraph (Fin k))
    (free : H.CliqueFree 3) (avoid : ¬ decode 10 Terminal18.target ⊑ Hᶜ) :
    ∃ K : SimpleGraph (Fin k), H ≤ K ∧ Maximal (fun D : SimpleGraph (Fin k) => D.CliqueFree 3) K ∧
      ∃ p ∈ codes13 k, Nonempty (K ≃g decode k p) := by
  classical
  let fam : Set (SimpleGraph (Fin k)) := {D | D.CliqueFree 3}
  obtain ⟨K,hK,maxK⟩ := fam.toFinite.exists_le_maximal (show H∈fam from free)
  exact ⟨K,hK,maxK,complete13_code k bound K maxK
    (fun h => avoid (h.mono_right (compl_le_compl hK)))⟩

end EarlyRamsey

#print axioms EarlyRamsey.complete13_code
#print axioms EarlyRamsey.spanning13
