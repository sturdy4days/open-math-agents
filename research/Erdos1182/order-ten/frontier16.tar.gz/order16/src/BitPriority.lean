import PureWitness
import Records

namespace BBHExtension
open SimpleGraph

/-- Atlas extensions index the root by zero in Lean. The graph6 generator
keeps the old indices and appends the root as vertex `k`. -/
def generatorLabel {k} (v : Fin (k+1)) : ℕ := Fin.cases k (fun i => i.val) v

/-- Adjacency on generator labels, with the root last and the parent in
triangular bit order. The root has exactly the set of neighbors in `s`. -/
def generatorAdjacent (k p s x y : ℕ) : Bool :=
  if x=k then y != k && s.testBit y else if y=k then s.testBit x else
  adjacent p x y && !(s.testBit x && s.testBit y)

theorem generator_adj_iff {k p s} (x y : Fin (k+1)) :
    generatorAdjacent k p s (generatorLabel x) (generatorLabel y) = true ↔
    (extend (decode k p) (subset k s)).Adj x y := by
  revert y
  refine Fin.cases ?_ (fun i => ?_) x
  · intro y
    refine Fin.cases ?_ (fun j => ?_) y
    · simp [generatorLabel,generatorAdjacent]
    · simp [generatorLabel,generatorAdjacent,ne_of_lt j.isLt,extend_left,subset]
  · intro y
    refine Fin.cases ?_ (fun j => ?_) y
    · rw [SimpleGraph.adj_comm,extend_left]
      simp [generatorLabel,generatorAdjacent,ne_of_lt i.isLt,subset]
    · rw [extend_old]
      simp [generatorLabel,generatorAdjacent,ne_of_lt i.isLt,ne_of_lt j.isLt,subset,decode]
      grind

/-- Pack the first `n` Boolean entries as a neighborhood word. -/
def adjacencyBits : ℕ → (ℕ → Bool) → ℕ
  | 0, _ => 0
  | n+1, f => adjacencyBits n f ||| (if f n then 2^n else 0)

theorem adjacencyBits_test (n i : ℕ) (f : ℕ → Bool) :
    (adjacencyBits n f).testBit i = true ↔ i<n ∧ f i = true := by
  induction n with
  | zero => simp [adjacencyBits]
  | succ n ih =>
    by_cases eq : i=n
    · subst i
      cases hf : f n <;> simp [adjacencyBits,hf,Nat.testBit_or,ih]
    · cases hf : f n <;> simp [adjacencyBits,hf,Nat.testBit_or,ih,Ne.symm eq] <;> omega

def generatorRow (k p s x : ℕ) : ℕ := adjacencyBits (k+1) (generatorAdjacent k p s x)

theorem generatorRow_iff {k p s} (x y : Fin (k+1)) :
    (generatorRow k p s (generatorLabel x)).testBit (generatorLabel y) = true ↔
    (extend (decode k p) (subset k s)).Adj x y := by
  have small (v : Fin (k+1)) : generatorLabel v < k+1 :=
    Fin.cases (by simp [generatorLabel]) (fun j => by simp [generatorLabel]) v
  rw [generatorRow,adjacencyBits_test, and_iff_right (small _),generator_adj_iff]

/-- Evaluate the two surviving cases using parent and connector bit words.
All loops are bounded by the vertex count; deletion checks surviving nonedges. -/
def checkPriority (k p s : ℕ) : Bool :=
  let E (i j : Fin (k+1)) := (generatorRow k p s (generatorLabel i)).testBit (generatorLabel j) = true
  letI (i j : Fin (k+1)) : Decidable (E i j) := inferInstanceAs (Decidable ((_ : Bool) = true))
  let N (i : Fin (k+1)) := (Finset.univ.filter (fun j => E i j)).card
  let twinRow := decide (∃ z : Fin k, ∀ j : Fin k, s.testBit j.val = adjacent p z.val j.val)
  let twins := decide (∃ u v : Fin (k+1), u ≠ v ∧ ∀ w, E u w ↔ E v w)
  let independent := decide (∀ i j : Fin k, s.testBit i.val = true → s.testBit j.val = true → adjacent p i.val j.val = false)
  let deletable (u : Fin (k+1)) := decide (∀ i, i ≠ u → ∀ j, j ≠ u → i ≠ j → ¬E i j →
          ∃ w, w ≠ u ∧ E i w ∧ E j w)
  let pure := decide (∃ u, deletable u = true)
  let minimum := decide (∀ v, N 0 ≤ N v)
  twinRow || (!twins && (independent || (!pure && minimum)))

theorem checkPriority_iff {k p s : ℕ} (free : (extend (decode k p) (subset k s)).CliqueFree 3) :
    checkPriority k p s = true ↔ priorityRow (decode k p) (subset k s) := by
  let P := decode k p
  let S := subset k s
  let H := extend P S
  have row : (∃ z : Fin k, ∀ j : Fin k, s.testBit j.val = adjacent p z.val j.val) ↔ neighborRow P S := by
    unfold neighborRow
    apply exists_congr
    intro z
    apply forall_congr'
    intro j
    change _ ↔ (j ∈ subset k s ↔ adjacent p z.val j.val = true)
    rw [Bool.eq_iff_iff]
    simp [subset]
  have indep : (∀ i j : Fin k, s.testBit i.val = true → s.testBit j.val = true → adjacent p i.val j.val = false) ↔
      independentRow P S := by
    simp only [independentRow,P,S,subset,Finset.mem_filter,Finset.mem_univ,true_and,decode,Bool.not_eq_true]
    grind
  have degree (v : Fin (k+1)) :
      (Finset.univ.filter (fun j => H.Adj v j)).card = Nat.card (H.neighborSet v) := by
    rw [Nat.card_eq_fintype_card,H.card_neighborSet_eq_degree, ← H.card_neighborFinset_eq_degree]
    congr 1
    ext x
    simp
  simp only [checkPriority,Bool.or_eq_true,Bool.and_eq_true,Bool.not_eq_true',decide_eq_false_iff_not,decide_eq_true_eq,generatorRow_iff]
  change _ ↔ priorityRow P S
  rw [row,indep]
  unfold priorityRow hasTwins rootMinimum
  rw [pureDeletion_iff_common_neighbors _ free]
  apply or_congr Iff.rfl
  apply and_congr Iff.rfl
  apply or_congr Iff.rfl
  apply and_congr Iff.rfl
  apply forall_congr'
  intro v
  change ((Finset.univ.filter (fun j => H.Adj 0 j)).card ≤ (Finset.univ.filter (fun j => H.Adj v j)).card) ↔ _
  rw [degree,degree]

/-- On a three-vertex star the row which clones a leaf passes; joining all old
vertices makes a four-vertex star whose new root fails the twin priority. -/
theorem checkPriority_star : checkPriority 3 3 1 = true ∧ checkPriority 3 3 7 = false := by
  decide +kernel

end BBHExtension

#print axioms BBHExtension.checkPriority_iff
