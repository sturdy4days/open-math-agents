import EarlyCatalogue

namespace EarlyRamsey

open BBHExtension SimpleGraph

/-- Continue a classification from an already verified order. Only that
frontier and the subsequent transitions are needed. -/
theorem continue_from {base top : ℕ} (catalogue : ∀ k, List (SimpleGraph (Fin k)))
    (frontier : ∀ H : SimpleGraph (Fin base),
      Maximal (fun D : SimpleGraph (Fin base) => D.CliqueFree 3) H → (¬ decode 10 Terminal18.target ⊑ Hᶜ) →
      ∃ D ∈ catalogue base, Nonempty (H ≃g D))
    (steps : ∀ k, base ≤ k → k < top →
      selectedRows (decode 10 Terminal18.target) priorityRow (catalogue k) (catalogue (k+1))) :
    ∀ k, base ≤ k → k ≤ top → ∀ H : SimpleGraph (Fin k),
      Maximal (fun D : SimpleGraph (Fin k) => D.CliqueFree 3) H → (¬ decode 10 Terminal18.target ⊑ Hᶜ) →
      ∃ D ∈ catalogue k, Nonempty (H ≃g D) := by
  intro k lo
  induction k, lo using Nat.le_induction with
  | base => exact fun _ => frontier
  | succ k lo ih =>
    intro hi H maxH avoid
    obtain ⟨P,S,maxP,avoidP,dom,chosen,⟨e⟩⟩ := priority_parent _ H maxH avoid
    obtain ⟨Q,hQ,⟨f⟩⟩ := ih (by omega) P maxP avoidP
    let T := S.map f.toEquiv.toEmbedding
    let iso : H ≃g extend Q T := e.trans (renamedExtension f S)
    rcases steps k lo hi Q hQ T (Finset.mem_powerset.2 (Finset.subset_univ _))
        (dom_image f S dom) (priority_image f S chosen) with bad|hit|⟨D,mem,⟨g⟩⟩
    · exact False.elim (no_defect maxH iso bad)
    · exact False.elim (avoid (hit.trans ⟨(SimpleGraph.Embedding.complEquiv iso.symm.toEmbedding).toCopy⟩))
    · exact ⟨D,mem,⟨iso.trans g⟩⟩

end EarlyRamsey

#print axioms EarlyRamsey.continue_from
