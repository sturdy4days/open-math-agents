import EarlyCatalogue
import TwinLevel11

namespace EarlyRamsey
open BBHExtension SimpleGraph

theorem step11 : selectedRows (decode 10 Terminal18.target) priorityRow (atlas 11) (atlas 12) :=
  TwinLevel11.all_parents

end EarlyRamsey
