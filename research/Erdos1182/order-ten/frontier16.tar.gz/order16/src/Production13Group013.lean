import Production13P0156
import Production13P0157
import Production13P0158
import Production13P0159
import Production13P0160
import Production13P0161
import Production13P0162
import Production13P0163
import Production13P0164
import Production13P0165
import Production13P0166
import Production13P0167
namespace Production13
open BBHExtension SimpleGraph
theorem Production13Group013 : selectedRows (decode 10 target) priorityRow (group013.map (decode 13)) (children.map (decode 14)) := by
  intro P mem S hS dom row
  simp only [group013,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact Production13P0156.complete _ (by simp [Production13P0156.p]) S hS dom row
  · exact Production13P0157.complete _ (by simp [Production13P0157.p]) S hS dom row
  · exact Production13P0158.complete _ (by simp [Production13P0158.p]) S hS dom row
  · exact Production13P0159.complete _ (by simp [Production13P0159.p]) S hS dom row
  · exact Production13P0160.complete _ (by simp [Production13P0160.p]) S hS dom row
  · exact Production13P0161.complete _ (by simp [Production13P0161.p]) S hS dom row
  · exact Production13P0162.complete _ (by simp [Production13P0162.p]) S hS dom row
  · exact Production13P0163.complete _ (by simp [Production13P0163.p]) S hS dom row
  · exact Production13P0164.complete _ (by simp [Production13P0164.p]) S hS dom row
  · exact Production13P0165.complete _ (by simp [Production13P0165.p]) S hS dom row
  · exact Production13P0166.complete _ (by simp [Production13P0166.p]) S hS dom row
  · exact Production13P0167.complete _ (by simp [Production13P0167.p]) S hS dom row
end Production13
#print axioms Production13.Production13Group013
