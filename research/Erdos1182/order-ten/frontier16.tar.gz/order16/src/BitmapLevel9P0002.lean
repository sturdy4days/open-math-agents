import BitmapLevel9Data
namespace BitmapLevel9.BitmapLevel9P0002
open SimpleGraph BBHExtension ExtensionBitmap
def p : ℕ := 17076617216
def masks : Array ℕ := #[320, 384, 384, 384, 320, 320, 177, 78, 63]
set_option maxRecDepth 12000
set_option maxHeartbeats 2500000
def rs0 : List (ℕ × ℕ × Witness) := [(0,321,.undominated 0),
(0,386,.undominated 1),
(0,388,.undominated 2),
(0,392,.undominated 3),
(0,336,.undominated 4),
(0,352,.undominated 5),
(0,241,.undominated 6),
(0,206,.undominated 7),
(0,319,.undominated 8),
(257,2,.gap 0 1),
(257,4,.gap 0 2),
(257,8,.gap 0 3),
(321,16,.gap 0 4),
(321,32,.gap 0 5),
(65,128,.gap 0 7),
(258,1,.gap 1 0),
(386,4,.gap 1 2),
(386,8,.gap 1 3),
(258,16,.gap 1 4),
(258,32,.gap 1 5),
(130,64,.gap 1 6),
(260,1,.gap 2 0),
(388,2,.gap 2 1),
(388,8,.gap 2 3)]
private theorem valid0 : rs0.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs1 : List (ℕ × ℕ × Witness) := [(260,16,.gap 2 4),
(260,32,.gap 2 5),
(132,64,.gap 2 6),
(264,1,.gap 3 0),
(392,2,.gap 3 1),
(392,4,.gap 3 2),
(264,16,.gap 3 4),
(264,32,.gap 3 5),
(136,64,.gap 3 6),
(336,1,.gap 4 0),
(272,2,.gap 4 1),
(272,4,.gap 4 2),
(272,8,.gap 4 3),
(336,32,.gap 4 5),
(80,128,.gap 4 7),
(352,1,.gap 5 0),
(288,2,.gap 5 1),
(288,4,.gap 5 2),
(288,8,.gap 5 3),
(352,16,.gap 5 4),
(96,128,.gap 5 7),
(192,2,.gap 6 1),
(192,4,.gap 6 2),
(192,8,.gap 6 3)]
private theorem valid1 : rs1.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs2 : List (ℕ × ℕ × Witness) := [(113,256,.gap 6 8),
(192,1,.gap 7 0),
(192,16,.gap 7 4),
(192,32,.gap 7 5),
(142,256,.gap 7 8),
(305,64,.gap 8 6),
(270,128,.gap 8 7),
(63,448,.permutes 4346403651584 316941949602881),
(78,433,.permutes 4382864965632 324630945536161),
(177,334,.permutes 4382864965632 325696166596706),
(320,191,.permutes 8793960218624 324637419376738),
(384,127,.permutes 8793960218624 325700357724321),
(511,0,.permutes 35115652612096 10178205453377)]
private theorem valid2 : rs2.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs := rs0 ++ rs1 ++ rs2
theorem complete : certifiedRows (decode 10 target) ([p].map (decode 9)) (children.map (decode 10)) := by
  apply parent_rows children masks rs
  · decide +kernel
  · decide +kernel
  · simp only [rs,List.all_append,valid0,valid1,valid2,Bool.and_self]
end BitmapLevel9.BitmapLevel9P0002
#print axioms BitmapLevel9.BitmapLevel9P0002.complete
