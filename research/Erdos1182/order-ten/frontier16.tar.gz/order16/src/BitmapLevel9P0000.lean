import BitmapLevel9Data
namespace BitmapLevel9.BitmapLevel9P0000
open SimpleGraph BBHExtension ExtensionBitmap
def p : ℕ := 68451041280
def masks : Array ℕ := #[256, 256, 256, 256, 256, 256, 256, 256, 255]
set_option maxRecDepth 12000
set_option maxHeartbeats 2500000
def rs0 : List (ℕ × ℕ × Witness) := [(0,257,.undominated 0),
(0,258,.undominated 1),
(0,260,.undominated 2),
(0,264,.undominated 3),
(0,272,.undominated 4),
(0,288,.undominated 5),
(0,320,.undominated 6),
(0,384,.undominated 7),
(257,2,.gap 0 1),
(257,4,.gap 0 2),
(257,8,.gap 0 3),
(257,16,.gap 0 4),
(257,32,.gap 0 5),
(257,64,.gap 0 6),
(257,128,.gap 0 7),
(258,1,.gap 1 0),
(258,4,.gap 1 2),
(258,8,.gap 1 3),
(258,16,.gap 1 4),
(258,32,.gap 1 5),
(258,64,.gap 1 6),
(258,128,.gap 1 7),
(260,1,.gap 2 0),
(260,2,.gap 2 1)]
private theorem valid0 : rs0.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs1 : List (ℕ × ℕ × Witness) := [(260,8,.gap 2 3),
(260,16,.gap 2 4),
(260,32,.gap 2 5),
(260,64,.gap 2 6),
(260,128,.gap 2 7),
(264,1,.gap 3 0),
(264,2,.gap 3 1),
(264,4,.gap 3 2),
(264,16,.gap 3 4),
(264,32,.gap 3 5),
(264,64,.gap 3 6),
(264,128,.gap 3 7),
(272,1,.gap 4 0),
(272,2,.gap 4 1),
(272,4,.gap 4 2),
(272,8,.gap 4 3),
(272,32,.gap 4 5),
(272,64,.gap 4 6),
(272,128,.gap 4 7),
(288,1,.gap 5 0),
(288,2,.gap 5 1),
(288,4,.gap 5 2),
(288,8,.gap 5 3),
(288,16,.gap 5 4)]
private theorem valid1 : rs1.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs2 : List (ℕ × ℕ × Witness) := [(288,64,.gap 5 6),
(288,128,.gap 5 7),
(320,1,.gap 6 0),
(320,2,.gap 6 1),
(320,4,.gap 6 2),
(320,8,.gap 6 3),
(320,16,.gap 6 4),
(320,32,.gap 6 5),
(320,128,.gap 6 7),
(384,1,.gap 7 0),
(384,2,.gap 7 1),
(384,4,.gap 7 2),
(384,8,.gap 7 3),
(384,16,.gap 7 4),
(384,32,.gap 7 5),
(384,64,.gap 7 6),
(255,256,.permutes 17591917608960 316941949602881),
(256,255,.permutes 35115652612096 325702574508064),
(511,0,.permutes 35115652612096 10178205453377)]
private theorem valid2 : rs2.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs := rs0 ++ rs1 ++ rs2
theorem complete : certifiedRows (decode 10 target) ([p].map (decode 9)) (children.map (decode 10)) := by
  apply parent_rows children masks rs
  · decide +kernel
  · decide +kernel
  · simp only [rs,List.all_append,valid0,valid1,valid2,Bool.and_self]
end BitmapLevel9.BitmapLevel9P0000
#print axioms BitmapLevel9.BitmapLevel9P0000.complete
