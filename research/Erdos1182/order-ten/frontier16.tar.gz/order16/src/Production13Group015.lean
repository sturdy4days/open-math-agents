import Production13P0180
import Production13P0181
import Production13P0182
import Production13P0183
import Production13P0184
import Production13P0185
import Production13P0186
import Production13P0187
import Production13P0188
import Production13P0189
import Production13P0190
import Production13P0191
namespace Production13
open BBHExtension SimpleGraph
theorem Production13Group015 : selectedRows (decode 10 target) priorityRow (group015.map (decode 13)) (children.map (decode 14)) := by
  intro P mem S hS dom row
  simp only [group015,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact Production13P0180.complete _ (by simp [Production13P0180.p]) S hS dom row
  · exact Production13P0181.complete _ (by simp [Production13P0181.p]) S hS dom row
  · exact Production13P0182.complete _ (by simp [Production13P0182.p]) S hS dom row
  · exact Production13P0183.complete _ (by simp [Production13P0183.p]) S hS dom row
  · exact Production13P0184.complete _ (by simp [Production13P0184.p]) S hS dom row
  · exact Production13P0185.complete _ (by simp [Production13P0185.p]) S hS dom row
  · exact Production13P0186.complete _ (by simp [Production13P0186.p]) S hS dom row
  · exact Production13P0187.complete _ (by simp [Production13P0187.p]) S hS dom row
  · exact Production13P0188.complete _ (by simp [Production13P0188.p]) S hS dom row
  · exact Production13P0189.complete _ (by simp [Production13P0189.p]) S hS dom row
  · exact Production13P0190.complete _ (by simp [Production13P0190.p]) S hS dom row
  · exact Production13P0191.complete _ (by simp [Production13P0191.p]) S hS dom row
end Production13
#print axioms Production13.Production13Group015
