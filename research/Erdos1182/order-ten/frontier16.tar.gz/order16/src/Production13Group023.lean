import Production13P0276
import Production13P0277
import Production13P0278
import Production13P0279
import Production13P0280
import Production13P0281
import Production13P0282
import Production13P0283
import Production13P0284
import Production13P0285
import Production13P0286
import Production13P0287
namespace Production13
open BBHExtension SimpleGraph
theorem Production13Group023 : selectedRows (decode 10 target) priorityRow (group023.map (decode 13)) (children.map (decode 14)) := by
  intro P mem S hS dom row
  simp only [group023,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact Production13P0276.complete _ (by simp [Production13P0276.p]) S hS dom row
  · exact Production13P0277.complete _ (by simp [Production13P0277.p]) S hS dom row
  · exact Production13P0278.complete _ (by simp [Production13P0278.p]) S hS dom row
  · exact Production13P0279.complete _ (by simp [Production13P0279.p]) S hS dom row
  · exact Production13P0280.complete _ (by simp [Production13P0280.p]) S hS dom row
  · exact Production13P0281.complete _ (by simp [Production13P0281.p]) S hS dom row
  · exact Production13P0282.complete _ (by simp [Production13P0282.p]) S hS dom row
  · exact Production13P0283.complete _ (by simp [Production13P0283.p]) S hS dom row
  · exact Production13P0284.complete _ (by simp [Production13P0284.p]) S hS dom row
  · exact Production13P0285.complete _ (by simp [Production13P0285.p]) S hS dom row
  · exact Production13P0286.complete _ (by simp [Production13P0286.p]) S hS dom row
  · exact Production13P0287.complete _ (by simp [Production13P0287.p]) S hS dom row
end Production13
#print axioms Production13.Production13Group023
