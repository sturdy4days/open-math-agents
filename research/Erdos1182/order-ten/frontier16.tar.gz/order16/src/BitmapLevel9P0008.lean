import BitmapLevel9Data
namespace BitmapLevel9.BitmapLevel9P0008
open SimpleGraph BBHExtension ExtensionBitmap
def p : ℕ := 16773514304
def masks : Array ℕ := #[112, 448, 448, 448, 385, 385, 15, 62, 62]
set_option maxRecDepth 12000
set_option maxHeartbeats 2500000
def rs0 : List (ℕ × ℕ × Witness) := [(0,113,.undominated 0),
(0,450,.undominated 1),
(0,452,.undominated 2),
(0,456,.undominated 3),
(0,401,.undominated 4),
(0,417,.undominated 5),
(0,79,.undominated 6),
(0,190,.undominated 7),
(0,318,.undominated 8),
(65,2,.gap 0 1),
(65,4,.gap 0 2),
(65,8,.gap 0 3),
(49,128,.gap 0 7),
(49,256,.gap 0 8),
(66,1,.gap 1 0),
(450,4,.gap 1 2),
(450,8,.gap 1 3),
(386,16,.gap 1 4),
(386,32,.gap 1 5),
(68,1,.gap 2 0),
(452,2,.gap 2 1),
(452,8,.gap 2 3),
(388,16,.gap 2 4),
(388,32,.gap 2 5)]
private theorem valid0 : rs0.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs1 : List (ℕ × ℕ × Witness) := [(72,1,.gap 3 0),
(456,2,.gap 3 1),
(456,4,.gap 3 2),
(392,16,.gap 3 4),
(392,32,.gap 3 5),
(400,2,.gap 4 1),
(400,4,.gap 4 2),
(400,8,.gap 4 3),
(401,32,.gap 4 5),
(17,64,.gap 4 6),
(416,2,.gap 5 1),
(416,4,.gap 5 2),
(416,8,.gap 5 3),
(417,16,.gap 5 4),
(33,64,.gap 5 6),
(65,16,.gap 6 4),
(65,32,.gap 6 5),
(78,128,.gap 6 7),
(78,256,.gap 6 8),
(176,1,.gap 7 0),
(142,64,.gap 7 6),
(190,256,.gap 7 8),
(304,1,.gap 8 0),
(270,64,.gap 8 6)]
private theorem valid1 : rs1.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs2 : List (ℕ × ℕ × Witness) := [(318,128,.gap 8 7),
(15,496,.permutes 7933641765632 325494199517381),
(62,449,.permutes 8140821373451 325459839785121),
(112,399,.permutes 7105820778496 325702571266146),
(131,380,.permutes 4277147303937 325697240435776),
(133,378,.permutes 4277147303937 325697240434784),
(135,376,.permutes 2176647089152 317767688590404),
(137,374,.permutes 4277147303937 325697240402048),
(139,372,.permutes 2176647089152 317767689638979),
(141,370,.permutes 2176647089152 317767689639010),
(146,365,.permutes 2141996208128 325697039173763),
(148,363,.permutes 2141996208128 325697039174786),
(150,361,.permutes 2141996208128 316901215604834),
(152,359,.permutes 2141996208128 325697039175778),
(154,357,.permutes 2141996208128 316901215603842),
(156,355,.permutes 2141996208128 316901215602819),
(162,349,.permutes 2141996208128 325697040189571),
(164,347,.permutes 2141996208128 325697040190594),
(166,345,.permutes 2141996208128 316901214589026),
(168,343,.permutes 2141996208128 325697040191586),
(170,341,.permutes 2141996208128 316901214588034),
(172,339,.permutes 2141996208128 316901214587011),
(208,303,.permutes 8141638991891 324635205834913),
(224,287,.permutes 8141638991891 324635205833921)]
private theorem valid2 : rs2.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs3 : List (ℕ × ℕ × Witness) := [(259,252,.permutes 4277147303937 291612379974720),
(261,250,.permutes 4277147303937 291612379973728),
(263,248,.permutes 2176647089152 282584390243396),
(265,246,.permutes 4277147303937 291612379940992),
(267,244,.permutes 2176647089152 282584391291971),
(269,242,.permutes 2176647089152 282584391292002),
(274,237,.permutes 2141996208128 291612178712707),
(276,235,.permutes 2141996208128 291612178713730),
(278,233,.permutes 2141996208128 281716877070434),
(280,231,.permutes 2141996208128 291612178714722),
(282,229,.permutes 2141996208128 281716877069442),
(284,227,.permutes 2141996208128 281716877068419),
(290,221,.permutes 2141996208128 291612179728515),
(292,219,.permutes 2141996208128 291612179729538),
(294,217,.permutes 2141996208128 281716876054626),
(296,215,.permutes 2141996208128 291612179730530),
(298,213,.permutes 2141996208128 281716876053634),
(300,211,.permutes 2141996208128 281716876052611),
(336,175,.permutes 8141638991891 289485193484449),
(352,159,.permutes 8141638991891 289485193483457),
(385,126,.permutes 4346403651584 325697240435776),
(448,63,.permutes 8692541981696 325702574508033),
(511,0,.permutes 35115652612096 10178205453377)]
private theorem valid3 : rs3.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs := rs0 ++ rs1 ++ rs2 ++ rs3
theorem complete : certifiedRows (decode 10 target) ([p].map (decode 9)) (children.map (decode 10)) := by
  apply parent_rows children masks rs
  · decide +kernel
  · decide +kernel
  · simp only [rs,List.all_append,valid0,valid1,valid2,valid3,Bool.and_self]
end BitmapLevel9.BitmapLevel9P0008
#print axioms BitmapLevel9.BitmapLevel9P0008.complete
