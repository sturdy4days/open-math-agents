import Minimum

namespace BBHExtension
open SimpleGraph

/-- Two distinct vertices with the same open neighborhood. -/
def hasTwins {A : Type*} (H : SimpleGraph A) : Prop :=
  ∃ u v, u ≠ v ∧ ∀ w, H.Adj u w ↔ H.Adj v w

theorem twins_image {A B : Type*} {H : SimpleGraph A} {K : SimpleGraph B}
    (e : H ≃g K) (tw : hasTwins H) : hasTwins K := by
  obtain ⟨u,v,ne,eq⟩ := tw
  refine ⟨e u, e v, e.injective.ne ne, ?_⟩
  intro y
  obtain ⟨x,rfl⟩ := e.surjective y
  simpa only [e.map_rel_iff] using eq x

def neighborRow {k} (P : SimpleGraph (Fin k)) (S : Finset (Fin k)) : Prop :=
  ∃ z, ∀ j, j∈S ↔ P.Adj z j

theorem neighborRow_image {k} {P Q : SimpleGraph (Fin k)} (e : P ≃g Q)
    (S : Finset (Fin k)) (row : neighborRow P S) :
    neighborRow Q (S.map e.toEquiv.toEmbedding) := by
  obtain ⟨z,hz⟩ := row
  refine ⟨e z, ?_⟩
  intro j
  obtain ⟨x,rfl⟩ := e.surjective j
  exact (Finset.mem_map' ..).trans ((hz x).trans e.map_rel_iff.symm)

def twinMinimumRow {k} (P : SimpleGraph (Fin k)) (S : Finset (Fin k)) : Prop :=
  neighborRow P S ∨ ¬hasTwins (extend P S) ∧ rootMinimum (extend P S)

/-- The row selection predicate is separated from the atlas induction. Each
maximal avoiding child supplies one selected row with a maximal avoiding parent. -/
def parentWith {k} {V : Type*} (G : SimpleGraph V) (H : SimpleGraph (Fin (k+1)))
    (select : SimpleGraph (Fin k) → Finset (Fin k) → Prop) : Prop :=
  ∃ (P : SimpleGraph (Fin k)) (S : Finset (Fin k)),
    Maximal (fun D : SimpleGraph (Fin k) => D.CliqueFree 3) P ∧ (¬ G ⊑ Pᶜ) ∧
    (∀ y, y∉S → ∃ x∈S, P.Adj x y) ∧ select P S ∧ Nonempty (H ≃g extend P S)

theorem twinMinimum_parent {k} {V : Type*} (G : SimpleGraph V) (H : SimpleGraph (Fin (k+1)))
    (hm : Maximal (fun D : SimpleGraph (Fin (k+1)) => D.CliqueFree 3) H)
    (avoid : ¬ G ⊑ Hᶜ) : parentWith G H twinMinimumRow := by
  classical
  by_cases tw : hasTwins H
  · obtain ⟨u,v,ne,eq⟩ := tw
    obtain ⟨P,S,z,maxP,noP,row,dom,iso⟩ := twin_parent G H hm avoid u v ne eq
    exact ⟨P,S,maxP,noP,dom,Or.inl ⟨z,row⟩,iso⟩
  · obtain ⟨P,S,maxP,noP,dom,least,⟨e⟩⟩ := minimum_parent G H hm avoid
    exact ⟨P,S,maxP,noP,dom,Or.inr ⟨fun t => tw (twins_image e.symm t),least⟩,⟨e⟩⟩

theorem twinMinimum_image {k} {P Q : SimpleGraph (Fin k)} (e : P ≃g Q) (S : Finset (Fin k))
    (row : twinMinimumRow P S) : twinMinimumRow Q (S.map e.toEquiv.toEmbedding) := by
  rcases row with old | ⟨no,least⟩
  · exact Or.inl (neighborRow_image e S old)
  · let j := renamedExtension e S
    exact Or.inr ⟨fun t => no (twins_image j.symm t),
      rootMinimum_image j (renamedExtension_zero e S) least⟩

def selectedRows {V : Type*} (G : SimpleGraph V) {k : ℕ}
    (select : SimpleGraph (Fin k) → Finset (Fin k) → Prop)
    (parents : List (SimpleGraph (Fin k))) (children : List (SimpleGraph (Fin (k+1)))) : Prop :=
  ∀ P∈parents, ∀ S ∈ (Finset.univ : Finset (Fin k)).powerset,
    (∀ y, y∉S → ∃ x∈S, P.Adj x y) → select P S →
    defect (extend P S) ∨ G ⊑ (extend P S)ᶜ ∨ ∃ D∈children, Nonempty (extend P S ≃g D)

theorem selected_atlas_complete {V : Type*} (G : SimpleGraph V) (N : ℕ)
    (atlas : (k : ℕ) → List (SimpleGraph (Fin k))) (init : ⊥ ∈ atlas 0)
    (select : (k : ℕ) → SimpleGraph (Fin k) → Finset (Fin k) → Prop)
    (parentRule : ∀ k (H : SimpleGraph (Fin (k+1))),
      Maximal (fun D : SimpleGraph (Fin (k+1)) => D.CliqueFree 3) H → (¬ G ⊑ Hᶜ) →
      parentWith G H (select k))
    (stable : ∀ k {P Q : SimpleGraph (Fin k)} (e : P ≃g Q) S, select k P S →
      select k Q (S.map e.toEquiv.toEmbedding))
    (rows : ∀ k<N, selectedRows G (select k) (atlas k) (atlas (k+1))) :
    ∀ k, k≤N → ∀ H : SimpleGraph (Fin k),
      Maximal (fun D : SimpleGraph (Fin k) => D.CliqueFree 3) H → (¬ G ⊑ Hᶜ) →
      ∃ D∈atlas k, Nonempty (H ≃g D) := by
  classical
  intro k
  induction k with
  | zero =>
    intro _ H _ _
    have eq : H=⊥ := Subsingleton.elim _ _
    subst H
    exact ⟨⊥,init,⟨RelIso.refl _⟩⟩
  | succ k ih =>
    intro bound H maxH avoid
    obtain ⟨P,S,maxP,avoidP,dom,chosen,⟨i⟩⟩ := parentRule k H maxH avoid
    obtain ⟨Q,hQ,⟨e⟩⟩ := ih (Nat.le_of_succ_le bound) P maxP avoidP
    let T := S.map e.toEquiv.toEmbedding
    let iso : H ≃g extend Q T := i.trans (renamedExtension e S)
    rcases rows k bound Q hQ T (Finset.mem_powerset.mpr (Finset.subset_univ T))
      (dom_image e S dom) (stable k e S chosen) with bad | hit | ⟨D,hD,⟨f⟩⟩
    · exact (no_defect maxH iso bad).elim
    · exact (avoid (hit.trans ⟨(SimpleGraph.Embedding.complEquiv iso.symm.toEmbedding).toCopy⟩)).elim
    · exact ⟨D,hD,⟨iso.trans f⟩⟩

theorem cover_of_atlas_complete {V : Type*} (G : SimpleGraph V) (N : ℕ)
    (atlas : (k : ℕ) → List (SimpleGraph (Fin k))) (endRow : atlas N = [])
    (complete : ∀ H : SimpleGraph (Fin N),
      Maximal (fun D : SimpleGraph (Fin N) => D.CliqueFree 3) H → (¬ G ⊑ Hᶜ) →
      ∃ D∈atlas N, Nonempty (H ≃g D)) :
    ∀ H : SimpleGraph (Fin N), H.CliqueFree 3 → G ⊑ Hᶜ := by
  classical
  intro H ht
  let family : Set (SimpleGraph (Fin N)) := {D | D.CliqueFree 3}
  obtain ⟨P,leP,maxP⟩ := family.toFinite.exists_le_maximal (show H∈family from ht)
  by_contra miss
  obtain ⟨D,hD,_⟩ := complete P maxP (fun hit => miss (hit.mono_right (compl_le_compl leP)))
  simp [endRow] at hD

theorem twinMinimum_complement_covers {V : Type*} (G : SimpleGraph V) (N : ℕ)
    (atlas : (k : ℕ) → List (SimpleGraph (Fin k))) (init : ⊥ ∈ atlas 0)
    (rows : ∀ k<N, selectedRows G twinMinimumRow (atlas k) (atlas (k+1))) (endRow : atlas N = []) :
    ∀ H : SimpleGraph (Fin N), H.CliqueFree 3 → G ⊑ Hᶜ :=
  cover_of_atlas_complete G N atlas endRow
    (selected_atlas_complete G N atlas init (fun _ => twinMinimumRow)
      (fun _ => twinMinimum_parent G) (fun _ => twinMinimum_image) rows N le_rfl)

end BBHExtension

#print axioms BBHExtension.twinMinimum_complement_covers
