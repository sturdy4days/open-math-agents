import Verify3_000

namespace EarlyRamsey
open BBHExtension SimpleGraph

theorem step3 : selectedRows (decode 10 Terminal18.target) priorityRow (atlas 3) (atlas 4) := by
  apply level_step
  intro p hp
  change p ∈ words3 at hp
  simp only [words3,List.mem_cons,List.not_mem_nil,or_false] at hp
  subst p
  exact Verify3_000.checked

end EarlyRamsey
