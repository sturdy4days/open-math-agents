import BitmapLevel9P0000
import BitmapLevel9P0001
import BitmapLevel9P0002
import BitmapLevel9P0003
import BitmapLevel9P0004
import BitmapLevel9P0005
import BitmapLevel9P0006
import BitmapLevel9P0007
import BitmapLevel9P0008
import BitmapLevel9P0009
import BitmapLevel9P0010
import BitmapLevel9P0011
import BitmapLevel9P0012
import BitmapLevel9P0013
import BitmapLevel9P0014
import BitmapLevel9P0015
namespace BitmapLevel9
open SimpleGraph BBHExtension
theorem all_parents : certifiedRows (decode 10 target) (parents.map (decode 9)) (children.map (decode 10)) := by
  intro P mem S hS dom
  simp only [parents,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact BitmapLevel9P0000.complete _ (by simp [BitmapLevel9P0000.p]) S hS dom
  · exact BitmapLevel9P0001.complete _ (by simp [BitmapLevel9P0001.p]) S hS dom
  · exact BitmapLevel9P0002.complete _ (by simp [BitmapLevel9P0002.p]) S hS dom
  · exact BitmapLevel9P0003.complete _ (by simp [BitmapLevel9P0003.p]) S hS dom
  · exact BitmapLevel9P0004.complete _ (by simp [BitmapLevel9P0004.p]) S hS dom
  · exact BitmapLevel9P0005.complete _ (by simp [BitmapLevel9P0005.p]) S hS dom
  · exact BitmapLevel9P0006.complete _ (by simp [BitmapLevel9P0006.p]) S hS dom
  · exact BitmapLevel9P0007.complete _ (by simp [BitmapLevel9P0007.p]) S hS dom
  · exact BitmapLevel9P0008.complete _ (by simp [BitmapLevel9P0008.p]) S hS dom
  · exact BitmapLevel9P0009.complete _ (by simp [BitmapLevel9P0009.p]) S hS dom
  · exact BitmapLevel9P0010.complete _ (by simp [BitmapLevel9P0010.p]) S hS dom
  · exact BitmapLevel9P0011.complete _ (by simp [BitmapLevel9P0011.p]) S hS dom
  · exact BitmapLevel9P0012.complete _ (by simp [BitmapLevel9P0012.p]) S hS dom
  · exact BitmapLevel9P0013.complete _ (by simp [BitmapLevel9P0013.p]) S hS dom
  · exact BitmapLevel9P0014.complete _ (by simp [BitmapLevel9P0014.p]) S hS dom
  · exact BitmapLevel9P0015.complete _ (by simp [BitmapLevel9P0015.p]) S hS dom
end BitmapLevel9
#print axioms BitmapLevel9.all_parents
