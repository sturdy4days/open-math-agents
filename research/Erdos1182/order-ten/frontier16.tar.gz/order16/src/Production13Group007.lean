import Production13P0084
import Production13P0085
import Production13P0086
import Production13P0087
import Production13P0088
import Production13P0089
import Production13P0090
import Production13P0091
import Production13P0092
import Production13P0093
import Production13P0094
import Production13P0095
namespace Production13
open BBHExtension SimpleGraph
theorem Production13Group007 : selectedRows (decode 10 target) priorityRow (group007.map (decode 13)) (children.map (decode 14)) := by
  intro P mem S hS dom row
  simp only [group007,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact Production13P0084.complete _ (by simp [Production13P0084.p]) S hS dom row
  · exact Production13P0085.complete _ (by simp [Production13P0085.p]) S hS dom row
  · exact Production13P0086.complete _ (by simp [Production13P0086.p]) S hS dom row
  · exact Production13P0087.complete _ (by simp [Production13P0087.p]) S hS dom row
  · exact Production13P0088.complete _ (by simp [Production13P0088.p]) S hS dom row
  · exact Production13P0089.complete _ (by simp [Production13P0089.p]) S hS dom row
  · exact Production13P0090.complete _ (by simp [Production13P0090.p]) S hS dom row
  · exact Production13P0091.complete _ (by simp [Production13P0091.p]) S hS dom row
  · exact Production13P0092.complete _ (by simp [Production13P0092.p]) S hS dom row
  · exact Production13P0093.complete _ (by simp [Production13P0093.p]) S hS dom row
  · exact Production13P0094.complete _ (by simp [Production13P0094.p]) S hS dom row
  · exact Production13P0095.complete _ (by simp [Production13P0095.p]) S hS dom row
end Production13
#print axioms Production13.Production13Group007
