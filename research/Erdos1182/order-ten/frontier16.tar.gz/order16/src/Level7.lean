import Verify7_000
import Verify7_001
import Verify7_002
import Verify7_003
import Verify7_004
import Verify7_005

namespace EarlyRamsey
open BBHExtension SimpleGraph

theorem step7 : selectedRows (decode 10 Terminal18.target) priorityRow (atlas 7) (atlas 8) := by
  apply level_step
  intro p hp
  change p ∈ words7 at hp
  simp only [words7,List.mem_cons,List.not_mem_nil,or_false] at hp
  rcases hp with rfl | rfl | rfl | rfl | rfl | rfl
  · exact Verify7_000.checked
  · exact Verify7_001.checked
  · exact Verify7_002.checked
  · exact Verify7_003.checked
  · exact Verify7_004.checked
  · exact Verify7_005.checked

end EarlyRamsey
