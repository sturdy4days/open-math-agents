import Verify10_000
import Verify10_001
import Verify10_002
import Verify10_003
import Verify10_004
import Verify10_005
import Verify10_006
import Verify10_007
import Verify10_008
import Verify10_009
import Verify10_010
import Verify10_011
import Verify10_012
import Verify10_013
import Verify10_014
import Verify10_015
import Verify10_016
import Verify10_017
import Verify10_018
import Verify10_019
import Verify10_020
import Verify10_021
import Verify10_022
import Verify10_023
import Verify10_024
import Verify10_025
import Verify10_026
import Verify10_027
import Verify10_028
import Verify10_029
import Verify10_030

namespace EarlyRamsey
open BBHExtension SimpleGraph

theorem step10 : selectedRows (decode 10 Terminal18.target) priorityRow (atlas 10) (atlas 11) := by
  apply level_step
  intro p hp
  change p ∈ words10 at hp
  simp only [words10,List.mem_cons,List.not_mem_nil,or_false] at hp
  rcases hp with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact Verify10_000.checked
  · exact Verify10_001.checked
  · exact Verify10_002.checked
  · exact Verify10_003.checked
  · exact Verify10_004.checked
  · exact Verify10_005.checked
  · exact Verify10_006.checked
  · exact Verify10_007.checked
  · exact Verify10_008.checked
  · exact Verify10_009.checked
  · exact Verify10_010.checked
  · exact Verify10_011.checked
  · exact Verify10_012.checked
  · exact Verify10_013.checked
  · exact Verify10_014.checked
  · exact Verify10_015.checked
  · exact Verify10_016.checked
  · exact Verify10_017.checked
  · exact Verify10_018.checked
  · exact Verify10_019.checked
  · exact Verify10_020.checked
  · exact Verify10_021.checked
  · exact Verify10_022.checked
  · exact Verify10_023.checked
  · exact Verify10_024.checked
  · exact Verify10_025.checked
  · exact Verify10_026.checked
  · exact Verify10_027.checked
  · exact Verify10_028.checked
  · exact Verify10_029.checked
  · exact Verify10_030.checked

end EarlyRamsey
