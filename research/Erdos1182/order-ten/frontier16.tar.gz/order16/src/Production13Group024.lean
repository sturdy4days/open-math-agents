import Production13P0288
import Production13P0289
import Production13P0290
import Production13P0291
import Production13P0292
import Production13P0293
import Production13P0294
import Production13P0295
import Production13P0296
import Production13P0297
import Production13P0298
import Production13P0299
namespace Production13
open BBHExtension SimpleGraph
theorem Production13Group024 : selectedRows (decode 10 target) priorityRow (group024.map (decode 13)) (children.map (decode 14)) := by
  intro P mem S hS dom row
  simp only [group024,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact Production13P0288.complete _ (by simp [Production13P0288.p]) S hS dom row
  · exact Production13P0289.complete _ (by simp [Production13P0289.p]) S hS dom row
  · exact Production13P0290.complete _ (by simp [Production13P0290.p]) S hS dom row
  · exact Production13P0291.complete _ (by simp [Production13P0291.p]) S hS dom row
  · exact Production13P0292.complete _ (by simp [Production13P0292.p]) S hS dom row
  · exact Production13P0293.complete _ (by simp [Production13P0293.p]) S hS dom row
  · exact Production13P0294.complete _ (by simp [Production13P0294.p]) S hS dom row
  · exact Production13P0295.complete _ (by simp [Production13P0295.p]) S hS dom row
  · exact Production13P0296.complete _ (by simp [Production13P0296.p]) S hS dom row
  · exact Production13P0297.complete _ (by simp [Production13P0297.p]) S hS dom row
  · exact Production13P0298.complete _ (by simp [Production13P0298.p]) S hS dom row
  · exact Production13P0299.complete _ (by simp [Production13P0299.p]) S hS dom row
end Production13
#print axioms Production13.Production13Group024
