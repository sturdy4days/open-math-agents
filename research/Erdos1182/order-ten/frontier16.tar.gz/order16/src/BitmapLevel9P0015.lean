import BitmapLevel9Data
namespace BitmapLevel9.BitmapLevel9P0015
open SimpleGraph BBHExtension ExtensionBitmap
def p : ℕ := 16233924755
def masks : Array ℕ := #[6, 57, 449, 450, 450, 450, 60, 60, 60]
set_option maxRecDepth 12000
set_option maxHeartbeats 2500000
def rs0 : List (ℕ × ℕ × Witness) := [(0,7,.undominated 0),
(0,59,.undominated 1),
(0,453,.undominated 2),
(0,458,.undominated 3),
(0,466,.undominated 4),
(0,482,.undominated 5),
(0,124,.undominated 6),
(0,188,.undominated 7),
(0,316,.undominated 8),
(3,8,.gap 0 3),
(3,16,.gap 0 4),
(3,32,.gap 0 5),
(5,64,.gap 0 6),
(5,128,.gap 0 7),
(5,256,.gap 0 8),
(3,4,.gap 1 2),
(58,64,.gap 1 6),
(58,128,.gap 1 7),
(58,256,.gap 1 8),
(5,2,.gap 2 1),
(452,8,.gap 2 3),
(452,16,.gap 2 4),
(452,32,.gap 2 5),
(10,1,.gap 3 0)]
private theorem valid0 : rs0.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs1 : List (ℕ × ℕ × Witness) := [(456,4,.gap 3 2),
(458,16,.gap 3 4),
(458,32,.gap 3 5),
(18,1,.gap 4 0),
(464,4,.gap 4 2),
(466,8,.gap 4 3),
(466,32,.gap 4 5),
(34,1,.gap 5 0),
(480,4,.gap 5 2),
(482,8,.gap 5 3),
(482,16,.gap 5 4),
(68,1,.gap 6 0),
(120,2,.gap 6 1),
(124,128,.gap 6 7),
(124,256,.gap 6 8),
(132,1,.gap 7 0),
(184,2,.gap 7 1),
(188,64,.gap 7 6),
(188,256,.gap 7 8),
(260,1,.gap 8 0),
(312,2,.gap 8 1),
(316,64,.gap 8 6),
(316,128,.gap 8 7),
(6,505,.permutes 4107987063072 107963977273376)]
private theorem valid1 : rs1.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs2 : List (ℕ × ℕ × Witness) := [(57,454,.permutes 8140821373451 216751169177601),
(60,451,.permutes 4277382578177 216744761458753),
(73,438,.permutes 20963438015233 113389594678273),
(81,430,.permutes 20963438015233 113423954415617),
(89,422,.permutes 1866082771232 105761599655975),
(97,414,.permutes 20963438015233 113458314121217),
(105,406,.permutes 1866082771232 105727273472039),
(113,398,.permutes 1866082771232 105692913734695),
(137,374,.permutes 20963438015233 114489105257473),
(145,366,.permutes 20963438015233 114523464994817),
(153,358,.permutes 1866082771232 105761599623208),
(161,350,.permutes 20963438015233 114557824700417),
(169,342,.permutes 1866082771232 105727273439272),
(177,334,.permutes 1866082771232 105692913701928),
(201,310,.permutes 1866082771232 2311976096897),
(209,302,.permutes 1866082771232 2311976095905),
(217,294,.permutes 2176647089152 6909601258625),
(225,286,.permutes 1866082771232 2311942541505),
(233,278,.permutes 2176647089152 5810090679425),
(241,270,.permutes 2176647089152 4710579051681),
(265,246,.permutes 20963438015233 115588583330817),
(273,238,.permutes 20963438015233 115622943068161),
(281,230,.permutes 1866082771232 105761598574633),
(289,222,.permutes 20963438015233 115657302773761)]
private theorem valid2 : rs2.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs3 : List (ℕ × ℕ × Witness) := [(297,214,.permutes 1866082771232 105727272390697),
(305,206,.permutes 1866082771232 105692912653353),
(329,182,.permutes 1866082771232 2310903403649),
(337,174,.permutes 1866082771232 2310903402657),
(345,166,.permutes 2176647089152 6875241553025),
(353,158,.permutes 1866082771232 2310869848257),
(361,150,.permutes 2176647089152 5775730973825),
(369,142,.permutes 2176647089152 4676219346081),
(393,118,.permutes 1866082771232 2309829694593),
(401,110,.permutes 1866082771232 2309829693601),
(409,102,.permutes 2176647089152 6840881815681),
(417,94,.permutes 1866082771232 2309796139201),
(425,86,.permutes 2176647089152 5741371236481),
(433,78,.permutes 2176647089152 4641859608737),
(449,62,.permutes 8140821373451 325702574476289),
(450,61,.permutes 4277382578177 325698314174561),
(511,0,.permutes 35115652612096 10178205453377)]
private theorem valid3 : rs3.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs := rs0 ++ rs1 ++ rs2 ++ rs3
theorem complete : certifiedRows (decode 10 target) ([p].map (decode 9)) (children.map (decode 10)) := by
  apply parent_rows children masks rs
  · decide +kernel
  · decide +kernel
  · simp only [rs,List.all_append,valid0,valid1,valid2,valid3,Bool.and_self]
end BitmapLevel9.BitmapLevel9P0015
#print axioms BitmapLevel9.BitmapLevel9P0015.complete
