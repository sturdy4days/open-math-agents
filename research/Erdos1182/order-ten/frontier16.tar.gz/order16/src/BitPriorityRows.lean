import BitPriority

namespace BBHExtension
open SimpleGraph

/-- The old edges erased on the connector are precisely those that could
complete a triangle through the newly inserted vertex. -/
theorem extend_triangleFree {k : ℕ} {P : SimpleGraph (Fin k)} (S : Finset (Fin k))
    (free : P.CliqueFree 3) : (extend P S).CliqueFree 3 := by
  intro T tri
  obtain ⟨x,y,z,xy,xz,yz,_⟩ := SimpleGraph.is3Clique_iff.mp tri
  have no (a b c : Fin k) (ab : P.Adj a b) (ac : P.Adj a c) (bc : P.Adj b c) : False :=
    P.isIndepSet_neighborSet_of_triangleFree free a ab ac bc.ne bc
  have right (a : Fin k) : (extend P S).Adj a.succ 0 ↔ a ∈ S :=
    ((extend P S).adj_comm ..).trans (extend_left P S a)
  revert xy xz yz
  refine Fin.cases ?_ (fun a => ?_) x <;>
    refine Fin.cases ?_ (fun b => ?_) y <;>
    refine Fin.cases ?_ (fun c => ?_) z <;>
    simp only [extend_left,extend_old,right,SimpleGraph.irrefl] <;> grind

theorem priority_accepted {k p s} (free : (decode k p).CliqueFree 3)
    (row : priorityRow (decode k p) (subset k s)) : checkPriority k p s = true :=
  (checkPriority_iff (extend_triangleFree _ free)).mpr row

/-- A verified witness is only needed for rows retained by the executable
priority test. Clique-freeness is verified just once per parent code. -/
theorem certified_priority_codes {n k t : ℕ} (parents children : List ℕ) (supply : ℕ → ℕ → Witness)
    (free : ∀ p∈parents, (decode k p).CliqueFree 3)
    (tests : ∀ p∈parents, ∀ s : Fin (2^k), checkPriority k p s = true →
      check (n:=n) (k:=k) t p children s (supply p s) = true) :
    selectedRows (decode n t) priorityRow (parents.map (decode k)) (children.map (decode (k+1))) := by
  intro P hP S _ dom row
  obtain ⟨p,hp,rfl⟩ := List.mem_map.mp hP
  obtain ⟨s,hs,rfl⟩ := subset_surj S
  have valid := tests p hp ⟨s,hs⟩ (priority_accepted (free p hp) row)
  rcases checked_row (supply p s) valid dom with bad | hit | ⟨b,hb,iso⟩
  · exact Or.inl bad
  · exact Or.inr (Or.inl hit)
  · exact Or.inr (Or.inr ⟨_,List.mem_map_of_mem hb,iso⟩)

end BBHExtension

#print axioms BBHExtension.certified_priority_codes
