import Production13P0228
import Production13P0229
import Production13P0230
import Production13P0231
import Production13P0232
import Production13P0233
import Production13P0234
import Production13P0235
import Production13P0236
import Production13P0237
import Production13P0238
import Production13P0239
namespace Production13
open BBHExtension SimpleGraph
theorem Production13Group019 : selectedRows (decode 10 target) priorityRow (group019.map (decode 13)) (children.map (decode 14)) := by
  intro P mem S hS dom row
  simp only [group019,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact Production13P0228.complete _ (by simp [Production13P0228.p]) S hS dom row
  · exact Production13P0229.complete _ (by simp [Production13P0229.p]) S hS dom row
  · exact Production13P0230.complete _ (by simp [Production13P0230.p]) S hS dom row
  · exact Production13P0231.complete _ (by simp [Production13P0231.p]) S hS dom row
  · exact Production13P0232.complete _ (by simp [Production13P0232.p]) S hS dom row
  · exact Production13P0233.complete _ (by simp [Production13P0233.p]) S hS dom row
  · exact Production13P0234.complete _ (by simp [Production13P0234.p]) S hS dom row
  · exact Production13P0235.complete _ (by simp [Production13P0235.p]) S hS dom row
  · exact Production13P0236.complete _ (by simp [Production13P0236.p]) S hS dom row
  · exact Production13P0237.complete _ (by simp [Production13P0237.p]) S hS dom row
  · exact Production13P0238.complete _ (by simp [Production13P0238.p]) S hS dom row
  · exact Production13P0239.complete _ (by simp [Production13P0239.p]) S hS dom row
end Production13
#print axioms Production13.Production13Group019
