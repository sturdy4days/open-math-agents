import Production13P0060
import Production13P0061
import Production13P0062
import Production13P0063
import Production13P0064
import Production13P0065
import Production13P0066
import Production13P0067
import Production13P0068
import Production13P0069
import Production13P0070
import Production13P0071
namespace Production13
open BBHExtension SimpleGraph
theorem Production13Group005 : selectedRows (decode 10 target) priorityRow (group005.map (decode 13)) (children.map (decode 14)) := by
  intro P mem S hS dom row
  simp only [group005,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact Production13P0060.complete _ (by simp [Production13P0060.p]) S hS dom row
  · exact Production13P0061.complete _ (by simp [Production13P0061.p]) S hS dom row
  · exact Production13P0062.complete _ (by simp [Production13P0062.p]) S hS dom row
  · exact Production13P0063.complete _ (by simp [Production13P0063.p]) S hS dom row
  · exact Production13P0064.complete _ (by simp [Production13P0064.p]) S hS dom row
  · exact Production13P0065.complete _ (by simp [Production13P0065.p]) S hS dom row
  · exact Production13P0066.complete _ (by simp [Production13P0066.p]) S hS dom row
  · exact Production13P0067.complete _ (by simp [Production13P0067.p]) S hS dom row
  · exact Production13P0068.complete _ (by simp [Production13P0068.p]) S hS dom row
  · exact Production13P0069.complete _ (by simp [Production13P0069.p]) S hS dom row
  · exact Production13P0070.complete _ (by simp [Production13P0070.p]) S hS dom row
  · exact Production13P0071.complete _ (by simp [Production13P0071.p]) S hS dom row
end Production13
#print axioms Production13.Production13Group005
