import Production13P0252
import Production13P0253
import Production13P0254
import Production13P0255
import Production13P0256
import Production13P0257
import Production13P0258
import Production13P0259
import Production13P0260
import Production13P0261
import Production13P0262
import Production13P0263
namespace Production13
open BBHExtension SimpleGraph
theorem Production13Group021 : selectedRows (decode 10 target) priorityRow (group021.map (decode 13)) (children.map (decode 14)) := by
  intro P mem S hS dom row
  simp only [group021,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact Production13P0252.complete _ (by simp [Production13P0252.p]) S hS dom row
  · exact Production13P0253.complete _ (by simp [Production13P0253.p]) S hS dom row
  · exact Production13P0254.complete _ (by simp [Production13P0254.p]) S hS dom row
  · exact Production13P0255.complete _ (by simp [Production13P0255.p]) S hS dom row
  · exact Production13P0256.complete _ (by simp [Production13P0256.p]) S hS dom row
  · exact Production13P0257.complete _ (by simp [Production13P0257.p]) S hS dom row
  · exact Production13P0258.complete _ (by simp [Production13P0258.p]) S hS dom row
  · exact Production13P0259.complete _ (by simp [Production13P0259.p]) S hS dom row
  · exact Production13P0260.complete _ (by simp [Production13P0260.p]) S hS dom row
  · exact Production13P0261.complete _ (by simp [Production13P0261.p]) S hS dom row
  · exact Production13P0262.complete _ (by simp [Production13P0262.p]) S hS dom row
  · exact Production13P0263.complete _ (by simp [Production13P0263.p]) S hS dom row
end Production13
#print axioms Production13.Production13Group021
