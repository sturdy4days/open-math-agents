import Verify8_000
import Verify8_001
import Verify8_002
import Verify8_003
import Verify8_004
import Verify8_005
import Verify8_006
import Verify8_007
import Verify8_008
import Verify8_009

namespace EarlyRamsey
open BBHExtension SimpleGraph

theorem step8 : selectedRows (decode 10 Terminal18.target) priorityRow (atlas 8) (atlas 9) := by
  apply level_step
  intro p hp
  change p ∈ words8 at hp
  simp only [words8,List.mem_cons,List.not_mem_nil,or_false] at hp
  rcases hp with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact Verify8_000.checked
  · exact Verify8_001.checked
  · exact Verify8_002.checked
  · exact Verify8_003.checked
  · exact Verify8_004.checked
  · exact Verify8_005.checked
  · exact Verify8_006.checked
  · exact Verify8_007.checked
  · exact Verify8_008.checked
  · exact Verify8_009.checked

end EarlyRamsey
