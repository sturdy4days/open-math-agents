import Production13P0120
import Production13P0121
import Production13P0122
import Production13P0123
import Production13P0124
import Production13P0125
import Production13P0126
import Production13P0127
import Production13P0128
import Production13P0129
import Production13P0130
import Production13P0131
namespace Production13
open BBHExtension SimpleGraph
theorem Production13Group010 : selectedRows (decode 10 target) priorityRow (group010.map (decode 13)) (children.map (decode 14)) := by
  intro P mem S hS dom row
  simp only [group010,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact Production13P0120.complete _ (by simp [Production13P0120.p]) S hS dom row
  · exact Production13P0121.complete _ (by simp [Production13P0121.p]) S hS dom row
  · exact Production13P0122.complete _ (by simp [Production13P0122.p]) S hS dom row
  · exact Production13P0123.complete _ (by simp [Production13P0123.p]) S hS dom row
  · exact Production13P0124.complete _ (by simp [Production13P0124.p]) S hS dom row
  · exact Production13P0125.complete _ (by simp [Production13P0125.p]) S hS dom row
  · exact Production13P0126.complete _ (by simp [Production13P0126.p]) S hS dom row
  · exact Production13P0127.complete _ (by simp [Production13P0127.p]) S hS dom row
  · exact Production13P0128.complete _ (by simp [Production13P0128.p]) S hS dom row
  · exact Production13P0129.complete _ (by simp [Production13P0129.p]) S hS dom row
  · exact Production13P0130.complete _ (by simp [Production13P0130.p]) S hS dom row
  · exact Production13P0131.complete _ (by simp [Production13P0131.p]) S hS dom row
end Production13
#print axioms Production13.Production13Group010
