import Verify1_000

namespace EarlyRamsey
open BBHExtension SimpleGraph

theorem step1 : selectedRows (decode 10 Terminal18.target) priorityRow (atlas 1) (atlas 2) := by
  apply level_step
  intro p hp
  change p ∈ words1 at hp
  simp only [words1,List.mem_cons,List.not_mem_nil,or_false] at hp
  subst p
  exact Verify1_000.checked

end EarlyRamsey
