import BitmapLevel9Data
namespace BitmapLevel9.BitmapLevel9P0010
open SimpleGraph BBHExtension ExtensionBitmap
def p : ℕ := 4154330304
def masks : Array ℕ := #[304, 304, 448, 448, 195, 195, 60, 60, 15]
set_option maxRecDepth 12000
set_option maxHeartbeats 2500000
def rs0 : List (ℕ × ℕ × Witness) := [(0,305,.undominated 0),
(0,306,.undominated 1),
(0,452,.undominated 2),
(0,456,.undominated 3),
(0,211,.undominated 4),
(0,227,.undominated 5),
(0,124,.undominated 6),
(0,188,.undominated 7),
(0,271,.undominated 8),
(305,2,.gap 0 1),
(257,4,.gap 0 2),
(257,8,.gap 0 3),
(49,64,.gap 0 6),
(49,128,.gap 0 7),
(306,1,.gap 1 0),
(258,4,.gap 1 2),
(258,8,.gap 1 3),
(50,64,.gap 1 6),
(50,128,.gap 1 7),
(260,1,.gap 2 0),
(260,2,.gap 2 1),
(452,8,.gap 2 3),
(196,16,.gap 2 4),
(196,32,.gap 2 5)]
private theorem valid0 : rs0.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs1 : List (ℕ × ℕ × Witness) := [(264,1,.gap 3 0),
(264,2,.gap 3 1),
(456,4,.gap 3 2),
(200,16,.gap 3 4),
(200,32,.gap 3 5),
(208,4,.gap 4 2),
(208,8,.gap 4 3),
(211,32,.gap 4 5),
(19,256,.gap 4 8),
(224,4,.gap 5 2),
(224,8,.gap 5 3),
(227,16,.gap 5 4),
(35,256,.gap 5 8),
(112,1,.gap 6 0),
(112,2,.gap 6 1),
(124,128,.gap 6 7),
(76,256,.gap 6 8),
(176,1,.gap 7 0),
(176,2,.gap 7 1),
(188,64,.gap 7 6),
(140,256,.gap 7 8),
(259,16,.gap 8 4),
(259,32,.gap 8 5),
(268,64,.gap 8 6)]
private theorem valid1 : rs1.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs2 : List (ℕ × ℕ × Witness) := [(268,128,.gap 8 7),
(15,496,.permutes 2094048417867 325702574508064),
(29,482,.permutes 1866082771232 221173778713634),
(30,481,.permutes 1866082771232 221173778713665),
(45,466,.permutes 1866082771232 186023766363170),
(46,465,.permutes 1866082771232 186023766363201),
(60,451,.permutes 7933641765632 216921853267009),
(71,440,.permutes 1866082771232 291611173094500),
(75,436,.permutes 1866082771232 291611173094531),
(81,430,.permutes 27226439286803 220152644830368),
(82,429,.permutes 27226439286803 220152644798624),
(84,427,.permutes 27226439286803 288253577137376),
(85,426,.permutes 19115143757857 288081747087522),
(86,425,.permutes 19115143757857 288081780641953),
(88,423,.permutes 27226439286803 288253577105632),
(89,422,.permutes 19115143757857 288081748135074),
(90,421,.permutes 19115143757857 288081781689505),
(97,414,.permutes 27226439286803 184968272741568),
(98,413,.permutes 27226439286803 184968272709824),
(100,411,.permutes 27226439286803 287188425247968),
(101,410,.permutes 19115143757857 286982235459778),
(102,409,.permutes 19115143757857 286982269014209),
(104,407,.permutes 27226439286803 287188425216224),
(105,406,.permutes 19115143757857 286982236507330)]
private theorem valid2 : rs2.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs3 : List (ℕ × ℕ × Witness) := [(106,405,.permutes 19115143757857 286982270061761),
(135,376,.permutes 1866082771232 256461160744036),
(139,372,.permutes 1866082771232 256461160744067),
(145,366,.permutes 27226439286803 219087492940960),
(146,365,.permutes 27226439286803 219087492909216),
(148,363,.permutes 27226439286803 253069205048576),
(149,362,.permutes 19115143757857 252897375031458),
(150,361,.permutes 19115143757857 252897408585889),
(152,359,.permutes 27226439286803 253069205016832),
(153,358,.permutes 19115143757857 252897376079010),
(154,357,.permutes 19115143757857 252897409633441),
(161,350,.permutes 27226439286803 183903120852160),
(162,349,.permutes 27226439286803 183903120820416),
(164,347,.permutes 27226439286803 252004053159168),
(165,346,.permutes 19115143757857 251797863403714),
(166,345,.permutes 19115143757857 251797896958145),
(168,343,.permutes 27226439286803 252004053127424),
(169,342,.permutes 19115143757857 251797864451266),
(170,341,.permutes 19115143757857 251797898005697),
(195,316,.permutes 7933641765632 289487406040195),
(304,207,.permutes 7105820778496 216921857427488),
(336,175,.permutes 2176647089152 325669286448160),
(352,159,.permutes 2176647089152 325634960264224),
(400,111,.permutes 2176647089152 324570848562208)]
private theorem valid3 : rs3.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs4 : List (ℕ × ℕ × Witness) := [(416,95,.permutes 2176647089152 324536522378272),
(448,63,.permutes 7105820778496 289487408107616),
(511,0,.permutes 35115652612096 10178205453377)]
private theorem valid4 : rs4.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs := rs0 ++ rs1 ++ rs2 ++ rs3 ++ rs4
theorem complete : certifiedRows (decode 10 target) ([p].map (decode 9)) (children.map (decode 10)) := by
  apply parent_rows children masks rs
  · decide +kernel
  · decide +kernel
  · simp only [rs,List.all_append,valid0,valid1,valid2,valid3,valid4,Bool.and_self]
end BitmapLevel9.BitmapLevel9P0010
#print axioms BitmapLevel9.BitmapLevel9P0010.complete
