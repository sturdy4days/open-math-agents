import FastWitness
import LastData

namespace EarlyRamsey
open BBHExtension SimpleGraph

/-- Short batches use an explicit, left-to-right Boolean scan. -/
def span (f : ℕ → Bool) (start : ℕ) : ℕ → Bool
  | 0 => true
  | len+1 => span f start len && f (start+len)

theorem span_sound {f : ℕ → Bool} {start len : ℕ} (h : span f start len = true)
    {i : ℕ} (lo : start ≤ i) (hi : i < start+len) : f i = true := by
  induction len with
  | zero => omega
  | succ len ih =>
    obtain ⟨prev,last⟩ := Bool.and_eq_true_iff.mp h
    by_cases lt : i < start+len
    · exact ih prev lt
    · rwa [show i=start+len by omega]

theorem span_add {f : ℕ → Bool} {start a b : ℕ} (l : span f start a = true)
    (r : span f (start+a) b = true) : span f start (a+b) = true := by
  induction b with
  | zero => exact l
  | succ b ih =>
    obtain ⟨prev,last⟩ := Bool.and_eq_true_iff.mp r
    exact Bool.and_eq_true_iff.mpr ⟨ih prev,by simpa [Nat.add_assoc] using last⟩

/-- A row witness is selected from a small table by its fixed-width field in a
packed integer. The width may vary from one parent to the next. -/
def witnessAt (table : Array Witness) (packed width s : ℕ) : Witness :=
  table[(packed >>> (width*s)) % 2^width]?.getD (.gap 0 0)

abbrev rowStep (k : ℕ) (p : ℕ) (children : List ℕ) :=
  ∀ S : Finset (Fin k), (∀ y, y∉S → ∃ x∈S,(decode k p).Adj x y) →
    priorityRow (decode k p) S →
    defect (extend (decode k p) S) ∨
    decode 10 Terminal18.target ⊑ (extend (decode k p) S)ᶜ ∨
    ∃ b∈children, Nonempty (extend (decode k p) S ≃g decode (k+1) b)

theorem parent_step {k p : ℕ} (children : List ℕ) (masks : Array ℕ) (supply : ℕ → Witness)
    (maskOK : masksMatch k p masks = true)
    (checks : ∀ s < 2^k, fastWitness 10 k Terminal18.target p children masks s (supply s) = true) :
    rowStep k p children := by
  intro S dom _
  obtain ⟨s,hs,rfl⟩ := subset_surj S
  exact fastWitness_sound maskOK (supply s) (checks s hs) dom

theorem level_step {k : ℕ} (parents children : List ℕ)
    (work : ∀ p∈parents, rowStep k p children) :
    selectedRows (decode 10 Terminal18.target) priorityRow
      (parents.map (decode k)) (children.map (decode (k+1))) := by
  intro P hP S _ dom priority
  obtain ⟨p,hp,rfl⟩ := List.mem_map.mp hP
  rcases work p hp S dom priority with bad|blue|⟨b,hb,iso⟩
  · exact Or.inl bad
  · exact Or.inr (Or.inl blue)
  · exact Or.inr (Or.inr ⟨_,List.mem_map_of_mem hb,iso⟩)

end EarlyRamsey
