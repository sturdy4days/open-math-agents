import Verify6_000
import Verify6_001
import Verify6_002
import Verify6_003

namespace EarlyRamsey
open BBHExtension SimpleGraph

theorem step6 : selectedRows (decode 10 Terminal18.target) priorityRow (atlas 6) (atlas 7) := by
  apply level_step
  intro p hp
  change p ∈ words6 at hp
  simp only [words6,List.mem_cons,List.not_mem_nil,or_false] at hp
  rcases hp with rfl | rfl | rfl | rfl
  · exact Verify6_000.checked
  · exact Verify6_001.checked
  · exact Verify6_002.checked
  · exact Verify6_003.checked

end EarlyRamsey
