import Records

namespace BBHExtension

open SimpleGraph

/-- Red adjacency after adjoining vertex zero, in the numbering used by `extend`.
All other vertices retain their labels shifted up by one. -/
def extendBit (parent mask x y : ℕ) : Bool :=
  if x = 0 then y != 0 && mask.testBit (y-1)
  else if y = 0 then mask.testBit (x-1)
  else adjacent parent (x-1) (y-1) && !(mask.testBit (x-1) && mask.testBit (y-1))

theorem extendBit_iff {k : ℕ} (parent mask : ℕ) (x y : Fin (k+1)) :
    extendBit parent mask x.val y.val = true ↔
      (extend (decode k parent) (subset k mask)).Adj x y := by
  revert y
  refine Fin.cases ?_ (fun i => ?_) x
  · intro y
    refine Fin.cases ?_ (fun j => ?_) y
    · simp [extendBit]
    · simp [extendBit,extend_left,subset]
  · intro y
    refine Fin.cases ?_ (fun j => ?_) y
    · rw [SimpleGraph.adj_comm]
      simp [extendBit,extend_left,subset]
    · simp [extendBit,extend_old,subset,decode]
      cases mask.testBit i.val <;> simp

private def indices (test : ℕ → Bool) : ℕ → Bool
  | 0 => true
  | n+1 => test n && indices test n

private theorem of_indices {n : ℕ} {test : ℕ → Bool} (run : indices test n = true)
    {i : ℕ} (bound : i < n) : test i = true := by
  induction n with
  | zero => omega
  | succ n ih =>
    obtain ⟨last,rest⟩ := Bool.and_eq_true_iff.mp run
    rcases Nat.lt_or_eq_of_le (Nat.le_of_lt_succ bound) with h | rfl
    · exact ih rest h
    · exact last

/-- Read the five-bit image at a canonical child label. A separate range
check prevents an invalid image from being silently reduced modulo the order. -/
def mapEntry (code i : ℕ) : ℕ := (code >>> (5*i)) % 32

/-- Verify a map from canonical child labels to extension labels. The strict
lower triangle tests both distinctness of the images and adjacency preservation. -/
def fastIso (k parent mask child code : ℕ) : Bool :=
  indices (fun i =>
    let x := mapEntry code i
    decide (x ≤ k) && indices (fun j =>
      let y := mapEntry code j
      (x != y) && (adjacent child i j == extendBit parent mask x y)) i) (k+1)

theorem fastIso_sound {k parent mask child code : ℕ} (pass : fastIso k parent mask child code = true) :
    Nonempty (extend (decode k parent) (subset k mask) ≃g decode (k+1) child) := by
  let H := extend (decode k parent) (subset k mask)
  let D := decode (k+1) child
  have row (i : Fin (k+1)) := Bool.and_eq_true_iff.mp (of_indices pass i.isLt)
  let f (i : Fin (k+1)) : Fin (k+1) :=
    ⟨mapEntry code i.val,Nat.lt_succ_of_le (of_decide_eq_true (row i).1)⟩
  have pair (i j : Fin (k+1)) (lt : j < i) :
      f i ≠ f j ∧ (H.Adj (f i) (f j) ↔ D.Adj i j) := by
    obtain ⟨ne,eq⟩ := Bool.and_eq_true_iff.mp (of_indices (row i).2 lt)
    refine ⟨fun h => (bne_iff_ne.mp ne) (congrArg Fin.val h), ?_⟩
    have same : adjacent child i.val j.val = extendBit parent mask (f i).val (f j).val :=
      eq_of_beq eq
    exact (extendBit_iff parent mask (f i) (f j)).symm.trans
      (show _ ↔ adjacent child i.val j.val = true by rw [same])
  have inj : Function.Injective f := by
    intro i j eq
    rcases lt_trichotomy i j with lt | rfl | lt
    · exact ((pair j i lt).1 eq.symm).elim
    · rfl
    · exact ((pair i j lt).1 eq).elim
  let e : Fin (k+1) ≃ Fin (k+1) := Equiv.ofBijective f (Finite.injective_iff_bijective.mp inj)
  let g : D ≃g H := {
    toEquiv := e
    map_rel_iff' := by
      intro i j
      change H.Adj (f i) (f j) ↔ D.Adj i j
      rcases lt_trichotomy i j with lt | rfl | lt
      · rw [H.adj_comm,D.adj_comm]; exact (pair j i lt).2
      · simp
      · exact (pair i j lt).2 }
  exact ⟨g.symm⟩

end BBHExtension

#print axioms BBHExtension.fastIso_sound
