import Production13P0000
import Production13P0001
import Production13P0002
import Production13P0003
import Production13P0004
import Production13P0005
import Production13P0006
import Production13P0007
import Production13P0008
import Production13P0009
import Production13P0010
import Production13P0011
namespace Production13
open BBHExtension SimpleGraph
theorem Production13Group000 : selectedRows (decode 10 target) priorityRow (group000.map (decode 13)) (children.map (decode 14)) := by
  intro P mem S hS dom row
  simp only [group000,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact Production13P0000.complete _ (by simp [Production13P0000.p]) S hS dom row
  · exact Production13P0001.complete _ (by simp [Production13P0001.p]) S hS dom row
  · exact Production13P0002.complete _ (by simp [Production13P0002.p]) S hS dom row
  · exact Production13P0003.complete _ (by simp [Production13P0003.p]) S hS dom row
  · exact Production13P0004.complete _ (by simp [Production13P0004.p]) S hS dom row
  · exact Production13P0005.complete _ (by simp [Production13P0005.p]) S hS dom row
  · exact Production13P0006.complete _ (by simp [Production13P0006.p]) S hS dom row
  · exact Production13P0007.complete _ (by simp [Production13P0007.p]) S hS dom row
  · exact Production13P0008.complete _ (by simp [Production13P0008.p]) S hS dom row
  · exact Production13P0009.complete _ (by simp [Production13P0009.p]) S hS dom row
  · exact Production13P0010.complete _ (by simp [Production13P0010.p]) S hS dom row
  · exact Production13P0011.complete _ (by simp [Production13P0011.p]) S hS dom row
end Production13
#print axioms Production13.Production13Group000
