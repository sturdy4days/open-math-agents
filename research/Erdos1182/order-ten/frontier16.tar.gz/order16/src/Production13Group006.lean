import Production13P0072
import Production13P0073
import Production13P0074
import Production13P0075
import Production13P0076
import Production13P0077
import Production13P0078
import Production13P0079
import Production13P0080
import Production13P0081
import Production13P0082
import Production13P0083
namespace Production13
open BBHExtension SimpleGraph
theorem Production13Group006 : selectedRows (decode 10 target) priorityRow (group006.map (decode 13)) (children.map (decode 14)) := by
  intro P mem S hS dom row
  simp only [group006,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact Production13P0072.complete _ (by simp [Production13P0072.p]) S hS dom row
  · exact Production13P0073.complete _ (by simp [Production13P0073.p]) S hS dom row
  · exact Production13P0074.complete _ (by simp [Production13P0074.p]) S hS dom row
  · exact Production13P0075.complete _ (by simp [Production13P0075.p]) S hS dom row
  · exact Production13P0076.complete _ (by simp [Production13P0076.p]) S hS dom row
  · exact Production13P0077.complete _ (by simp [Production13P0077.p]) S hS dom row
  · exact Production13P0078.complete _ (by simp [Production13P0078.p]) S hS dom row
  · exact Production13P0079.complete _ (by simp [Production13P0079.p]) S hS dom row
  · exact Production13P0080.complete _ (by simp [Production13P0080.p]) S hS dom row
  · exact Production13P0081.complete _ (by simp [Production13P0081.p]) S hS dom row
  · exact Production13P0082.complete _ (by simp [Production13P0082.p]) S hS dom row
  · exact Production13P0083.complete _ (by simp [Production13P0083.p]) S hS dom row
end Production13
#print axioms Production13.Production13Group006
