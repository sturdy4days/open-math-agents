import Production13P0216
import Production13P0217
import Production13P0218
import Production13P0219
import Production13P0220
import Production13P0221
import Production13P0222
import Production13P0223
import Production13P0224
import Production13P0225
import Production13P0226
import Production13P0227
namespace Production13
open BBHExtension SimpleGraph
theorem Production13Group018 : selectedRows (decode 10 target) priorityRow (group018.map (decode 13)) (children.map (decode 14)) := by
  intro P mem S hS dom row
  simp only [group018,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact Production13P0216.complete _ (by simp [Production13P0216.p]) S hS dom row
  · exact Production13P0217.complete _ (by simp [Production13P0217.p]) S hS dom row
  · exact Production13P0218.complete _ (by simp [Production13P0218.p]) S hS dom row
  · exact Production13P0219.complete _ (by simp [Production13P0219.p]) S hS dom row
  · exact Production13P0220.complete _ (by simp [Production13P0220.p]) S hS dom row
  · exact Production13P0221.complete _ (by simp [Production13P0221.p]) S hS dom row
  · exact Production13P0222.complete _ (by simp [Production13P0222.p]) S hS dom row
  · exact Production13P0223.complete _ (by simp [Production13P0223.p]) S hS dom row
  · exact Production13P0224.complete _ (by simp [Production13P0224.p]) S hS dom row
  · exact Production13P0225.complete _ (by simp [Production13P0225.p]) S hS dom row
  · exact Production13P0226.complete _ (by simp [Production13P0226.p]) S hS dom row
  · exact Production13P0227.complete _ (by simp [Production13P0227.p]) S hS dom row
end Production13
#print axioms Production13.Production13Group018
