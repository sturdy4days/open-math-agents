import Production13P0144
import Production13P0145
import Production13P0146
import Production13P0147
import Production13P0148
import Production13P0149
import Production13P0150
import Production13P0151
import Production13P0152
import Production13P0153
import Production13P0154
import Production13P0155
namespace Production13
open BBHExtension SimpleGraph
theorem Production13Group012 : selectedRows (decode 10 target) priorityRow (group012.map (decode 13)) (children.map (decode 14)) := by
  intro P mem S hS dom row
  simp only [group012,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact Production13P0144.complete _ (by simp [Production13P0144.p]) S hS dom row
  · exact Production13P0145.complete _ (by simp [Production13P0145.p]) S hS dom row
  · exact Production13P0146.complete _ (by simp [Production13P0146.p]) S hS dom row
  · exact Production13P0147.complete _ (by simp [Production13P0147.p]) S hS dom row
  · exact Production13P0148.complete _ (by simp [Production13P0148.p]) S hS dom row
  · exact Production13P0149.complete _ (by simp [Production13P0149.p]) S hS dom row
  · exact Production13P0150.complete _ (by simp [Production13P0150.p]) S hS dom row
  · exact Production13P0151.complete _ (by simp [Production13P0151.p]) S hS dom row
  · exact Production13P0152.complete _ (by simp [Production13P0152.p]) S hS dom row
  · exact Production13P0153.complete _ (by simp [Production13P0153.p]) S hS dom row
  · exact Production13P0154.complete _ (by simp [Production13P0154.p]) S hS dom row
  · exact Production13P0155.complete _ (by simp [Production13P0155.p]) S hS dom row
end Production13
#print axioms Production13.Production13Group012
