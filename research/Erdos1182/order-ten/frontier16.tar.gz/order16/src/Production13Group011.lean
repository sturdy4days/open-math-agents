import Production13P0132
import Production13P0133
import Production13P0134
import Production13P0135
import Production13P0136
import Production13P0137
import Production13P0138
import Production13P0139
import Production13P0140
import Production13P0141
import Production13P0142
import Production13P0143
namespace Production13
open BBHExtension SimpleGraph
theorem Production13Group011 : selectedRows (decode 10 target) priorityRow (group011.map (decode 13)) (children.map (decode 14)) := by
  intro P mem S hS dom row
  simp only [group011,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact Production13P0132.complete _ (by simp [Production13P0132.p]) S hS dom row
  · exact Production13P0133.complete _ (by simp [Production13P0133.p]) S hS dom row
  · exact Production13P0134.complete _ (by simp [Production13P0134.p]) S hS dom row
  · exact Production13P0135.complete _ (by simp [Production13P0135.p]) S hS dom row
  · exact Production13P0136.complete _ (by simp [Production13P0136.p]) S hS dom row
  · exact Production13P0137.complete _ (by simp [Production13P0137.p]) S hS dom row
  · exact Production13P0138.complete _ (by simp [Production13P0138.p]) S hS dom row
  · exact Production13P0139.complete _ (by simp [Production13P0139.p]) S hS dom row
  · exact Production13P0140.complete _ (by simp [Production13P0140.p]) S hS dom row
  · exact Production13P0141.complete _ (by simp [Production13P0141.p]) S hS dom row
  · exact Production13P0142.complete _ (by simp [Production13P0142.p]) S hS dom row
  · exact Production13P0143.complete _ (by simp [Production13P0143.p]) S hS dom row
end Production13
#print axioms Production13.Production13Group011
