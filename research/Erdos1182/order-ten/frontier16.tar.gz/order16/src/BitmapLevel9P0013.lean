import BitmapLevel9Data
namespace BitmapLevel9.BitmapLevel9P0013
open SimpleGraph BBHExtension ExtensionBitmap
def p : ℕ := 8116958209
def masks : Array ℕ := #[98, 385, 480, 480, 480, 29, 29, 30, 30]
set_option maxRecDepth 12000
set_option maxHeartbeats 2500000
def rs0 : List (ℕ × ℕ × Witness) := [(0,99,.undominated 0),
(0,387,.undominated 1),
(0,484,.undominated 2),
(0,488,.undominated 3),
(0,496,.undominated 4),
(0,61,.undominated 5),
(0,93,.undominated 6),
(0,158,.undominated 7),
(0,286,.undominated 8),
(97,4,.gap 0 2),
(97,8,.gap 0 3),
(97,16,.gap 0 4),
(3,128,.gap 0 7),
(3,256,.gap 0 8),
(386,4,.gap 1 2),
(386,8,.gap 1 3),
(386,16,.gap 1 4),
(3,32,.gap 1 5),
(3,64,.gap 1 6),
(100,1,.gap 2 0),
(388,2,.gap 2 1),
(484,8,.gap 2 3),
(484,16,.gap 2 4),
(104,1,.gap 3 0)]
private theorem valid0 : rs0.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs1 : List (ℕ × ℕ × Witness) := [(392,2,.gap 3 1),
(488,4,.gap 3 2),
(488,16,.gap 3 4),
(112,1,.gap 4 0),
(400,2,.gap 4 1),
(496,4,.gap 4 2),
(496,8,.gap 4 3),
(33,2,.gap 5 1),
(61,64,.gap 5 6),
(60,128,.gap 5 7),
(60,256,.gap 5 8),
(65,2,.gap 6 1),
(93,32,.gap 6 5),
(92,128,.gap 6 7),
(92,256,.gap 6 8),
(130,1,.gap 7 0),
(156,32,.gap 7 5),
(156,64,.gap 7 6),
(158,256,.gap 7 8),
(258,1,.gap 8 0),
(284,32,.gap 8 5),
(284,64,.gap 8 6),
(286,128,.gap 8 7),
(29,482,.permutes 8140821373451 180430703731970)]
private theorem valid1 : rs1.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs2 : List (ℕ × ℕ × Witness) := [(30,481,.permutes 8140821373451 180432918355137),
(38,473,.permutes 1866082771232 77076586827808),
(42,469,.permutes 1866082771232 77110946565152),
(46,465,.permutes 20963438015233 183687471828006),
(50,461,.permutes 1866082771232 77145272749088),
(54,457,.permutes 20963438015233 148503099771942),
(58,453,.permutes 20963438015233 113318727684134),
(70,441,.permutes 1866082771232 78175024713760),
(74,437,.permutes 1866082771232 78209384451104),
(78,433,.permutes 20963438015233 182587960200231),
(82,429,.permutes 1866082771232 78243710635040),
(86,425,.permutes 20963438015233 147403588144167),
(90,421,.permutes 20963438015233 112219216056359),
(98,413,.permutes 7933641765632 252961900240928),
(133,378,.permutes 1866082771232 44093383315520),
(137,374,.permutes 1866082771232 44127743052864),
(141,370,.permutes 20963438015233 185852066139208),
(145,366,.permutes 1866082771232 44162069236800),
(149,362,.permutes 20963438015233 150667694083144),
(153,358,.permutes 20963438015233 115483321995336),
(164,347,.permutes 4000346439713 324637422584928),
(168,343,.permutes 4000346439713 324637421536384),
(172,339,.permutes 27226439286803 186058120894529),
(176,335,.permutes 4000346439713 324637387981984)]
private theorem valid2 : rs2.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs3 : List (ℕ × ℕ × Witness) := [(180,331,.permutes 27226439286803 150873782360129),
(184,327,.permutes 27226439286803 115689411319873),
(196,315,.permutes 4000346439713 323538984698976),
(200,311,.permutes 4000346439713 323538983650432),
(204,307,.permutes 27226439286803 186023761157185),
(208,303,.permutes 4000346439713 323538950096032),
(212,299,.permutes 27226439286803 150839422622785),
(216,295,.permutes 27226439286803 115655051582529),
(261,250,.permutes 1866082771232 45191821201472),
(265,246,.permutes 1866082771232 45226180938816),
(269,242,.permutes 20963438015233 184752554511433),
(273,238,.permutes 1866082771232 45260507122752),
(277,234,.permutes 20963438015233 149568182455369),
(281,230,.permutes 20963438015233 114383810367561),
(292,219,.permutes 4000346439713 289487410234464),
(296,215,.permutes 4000346439713 289487409185920),
(300,211,.permutes 27226439286803 184958609299521),
(304,207,.permutes 4000346439713 289487375631520),
(308,203,.permutes 27226439286803 149774270765121),
(312,199,.permutes 27226439286803 114589899724865),
(324,187,.permutes 4000346439713 288388972348512),
(328,183,.permutes 4000346439713 288388971299968),
(332,179,.permutes 27226439286803 184924249562177),
(336,175,.permutes 4000346439713 288388937745568)]
private theorem valid3 : rs3.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs4 : List (ℕ × ℕ × Witness) := [(340,171,.permutes 27226439286803 149739911027777),
(344,167,.permutes 27226439286803 114555539987521),
(385,126,.permutes 7933641765632 325495307868224),
(480,31,.permutes 4277380481025 325702574506049),
(511,0,.permutes 35115652612096 10178205453377)]
private theorem valid4 : rs4.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs := rs0 ++ rs1 ++ rs2 ++ rs3 ++ rs4
theorem complete : certifiedRows (decode 10 target) ([p].map (decode 9)) (children.map (decode 10)) := by
  apply parent_rows children masks rs
  · decide +kernel
  · decide +kernel
  · simp only [rs,List.all_append,valid0,valid1,valid2,valid3,valid4,Bool.and_self]
end BitmapLevel9.BitmapLevel9P0013
#print axioms BitmapLevel9.BitmapLevel9P0013.complete
