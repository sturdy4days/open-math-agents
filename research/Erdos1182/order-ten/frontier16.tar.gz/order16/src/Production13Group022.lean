import Production13P0264
import Production13P0265
import Production13P0266
import Production13P0267
import Production13P0268
import Production13P0269
import Production13P0270
import Production13P0271
import Production13P0272
import Production13P0273
import Production13P0274
import Production13P0275
namespace Production13
open BBHExtension SimpleGraph
theorem Production13Group022 : selectedRows (decode 10 target) priorityRow (group022.map (decode 13)) (children.map (decode 14)) := by
  intro P mem S hS dom row
  simp only [group022,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact Production13P0264.complete _ (by simp [Production13P0264.p]) S hS dom row
  · exact Production13P0265.complete _ (by simp [Production13P0265.p]) S hS dom row
  · exact Production13P0266.complete _ (by simp [Production13P0266.p]) S hS dom row
  · exact Production13P0267.complete _ (by simp [Production13P0267.p]) S hS dom row
  · exact Production13P0268.complete _ (by simp [Production13P0268.p]) S hS dom row
  · exact Production13P0269.complete _ (by simp [Production13P0269.p]) S hS dom row
  · exact Production13P0270.complete _ (by simp [Production13P0270.p]) S hS dom row
  · exact Production13P0271.complete _ (by simp [Production13P0271.p]) S hS dom row
  · exact Production13P0272.complete _ (by simp [Production13P0272.p]) S hS dom row
  · exact Production13P0273.complete _ (by simp [Production13P0273.p]) S hS dom row
  · exact Production13P0274.complete _ (by simp [Production13P0274.p]) S hS dom row
  · exact Production13P0275.complete _ (by simp [Production13P0275.p]) S hS dom row
end Production13
#print axioms Production13.Production13Group022
