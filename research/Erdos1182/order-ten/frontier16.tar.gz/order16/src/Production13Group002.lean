import Production13P0024
import Production13P0025
import Production13P0026
import Production13P0027
import Production13P0028
import Production13P0029
import Production13P0030
import Production13P0031
import Production13P0032
import Production13P0033
import Production13P0034
import Production13P0035
namespace Production13
open BBHExtension SimpleGraph
theorem Production13Group002 : selectedRows (decode 10 target) priorityRow (group002.map (decode 13)) (children.map (decode 14)) := by
  intro P mem S hS dom row
  simp only [group002,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact Production13P0024.complete _ (by simp [Production13P0024.p]) S hS dom row
  · exact Production13P0025.complete _ (by simp [Production13P0025.p]) S hS dom row
  · exact Production13P0026.complete _ (by simp [Production13P0026.p]) S hS dom row
  · exact Production13P0027.complete _ (by simp [Production13P0027.p]) S hS dom row
  · exact Production13P0028.complete _ (by simp [Production13P0028.p]) S hS dom row
  · exact Production13P0029.complete _ (by simp [Production13P0029.p]) S hS dom row
  · exact Production13P0030.complete _ (by simp [Production13P0030.p]) S hS dom row
  · exact Production13P0031.complete _ (by simp [Production13P0031.p]) S hS dom row
  · exact Production13P0032.complete _ (by simp [Production13P0032.p]) S hS dom row
  · exact Production13P0033.complete _ (by simp [Production13P0033.p]) S hS dom row
  · exact Production13P0034.complete _ (by simp [Production13P0034.p]) S hS dom row
  · exact Production13P0035.complete _ (by simp [Production13P0035.p]) S hS dom row
end Production13
#print axioms Production13.Production13Group002
