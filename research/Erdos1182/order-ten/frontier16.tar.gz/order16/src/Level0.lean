import Verify0_000

namespace EarlyRamsey
open BBHExtension SimpleGraph

theorem step0 : selectedRows (decode 10 Terminal18.target) priorityRow (atlas 0) (atlas 1) := by
  apply level_step
  intro p hp
  change p ∈ words0 at hp
  simp only [words0,List.mem_cons,List.not_mem_nil,or_false] at hp
  subst p
  exact Verify0_000.checked

end EarlyRamsey
