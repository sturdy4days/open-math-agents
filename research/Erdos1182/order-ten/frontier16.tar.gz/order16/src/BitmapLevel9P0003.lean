import BitmapLevel9Data
namespace BitmapLevel9.BitmapLevel9P0003
open SimpleGraph BBHExtension ExtensionBitmap
def p : ℕ := 17171578880
def masks : Array ℕ := #[320, 320, 384, 384, 384, 384, 131, 124, 63]
set_option maxRecDepth 12000
set_option maxHeartbeats 2500000
def rs0 : List (ℕ × ℕ × Witness) := [(0,321,.undominated 0),
(0,322,.undominated 1),
(0,388,.undominated 2),
(0,392,.undominated 3),
(0,400,.undominated 4),
(0,416,.undominated 5),
(0,195,.undominated 6),
(0,252,.undominated 7),
(0,319,.undominated 8),
(321,2,.gap 0 1),
(257,4,.gap 0 2),
(257,8,.gap 0 3),
(257,16,.gap 0 4),
(257,32,.gap 0 5),
(65,128,.gap 0 7),
(322,1,.gap 1 0),
(258,4,.gap 1 2),
(258,8,.gap 1 3),
(258,16,.gap 1 4),
(258,32,.gap 1 5),
(66,128,.gap 1 7),
(260,1,.gap 2 0),
(260,2,.gap 2 1),
(388,8,.gap 2 3)]
private theorem valid0 : rs0.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs1 : List (ℕ × ℕ × Witness) := [(388,16,.gap 2 4),
(388,32,.gap 2 5),
(132,64,.gap 2 6),
(264,1,.gap 3 0),
(264,2,.gap 3 1),
(392,4,.gap 3 2),
(392,16,.gap 3 4),
(392,32,.gap 3 5),
(136,64,.gap 3 6),
(272,1,.gap 4 0),
(272,2,.gap 4 1),
(400,4,.gap 4 2),
(400,8,.gap 4 3),
(400,32,.gap 4 5),
(144,64,.gap 4 6),
(288,1,.gap 5 0),
(288,2,.gap 5 1),
(416,4,.gap 5 2),
(416,8,.gap 5 3),
(416,16,.gap 5 4),
(160,64,.gap 5 6),
(192,4,.gap 6 2),
(192,8,.gap 6 3),
(192,16,.gap 6 4)]
private theorem valid1 : rs1.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs2 : List (ℕ × ℕ × Witness) := [(192,32,.gap 6 5),
(67,256,.gap 6 8),
(192,1,.gap 7 0),
(192,2,.gap 7 1),
(188,256,.gap 7 8),
(259,64,.gap 8 6),
(316,128,.gap 8 7),
(63,448,.permutes 8692541981696 316936414204007),
(124,387,.permutes 4362873176064 325463164718145),
(131,380,.permutes 7670745022464 325698141230211),
(320,191,.permutes 8793960218624 325702574508064),
(384,127,.permutes 8795025571840 325702574506049),
(511,0,.permutes 35115652612096 10178205453377)]
private theorem valid2 : rs2.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs := rs0 ++ rs1 ++ rs2
theorem complete : certifiedRows (decode 10 target) ([p].map (decode 9)) (children.map (decode 10)) := by
  apply parent_rows children masks rs
  · decide +kernel
  · decide +kernel
  · simp only [rs,List.all_append,valid0,valid1,valid2,Bool.and_self]
end BitmapLevel9.BitmapLevel9P0003
#print axioms BitmapLevel9.BitmapLevel9P0003.complete
