import BitmapLevel9Data
namespace BitmapLevel9.BitmapLevel9P0005
open SimpleGraph BBHExtension ExtensionBitmap
def p : ℕ := 8530063360
def masks : Array ℕ := #[384, 384, 352, 352, 352, 156, 156, 99, 31]
set_option maxRecDepth 12000
set_option maxHeartbeats 2500000
def rs0 : List (ℕ × ℕ × Witness) := [(0,385,.undominated 0),
(0,386,.undominated 1),
(0,356,.undominated 2),
(0,360,.undominated 3),
(0,368,.undominated 4),
(0,188,.undominated 5),
(0,220,.undominated 6),
(0,227,.undominated 7),
(0,287,.undominated 8),
(385,2,.gap 0 1),
(257,4,.gap 0 2),
(257,8,.gap 0 3),
(257,16,.gap 0 4),
(129,32,.gap 0 5),
(129,64,.gap 0 6),
(386,1,.gap 1 0),
(258,4,.gap 1 2),
(258,8,.gap 1 3),
(258,16,.gap 1 4),
(130,32,.gap 1 5),
(130,64,.gap 1 6),
(260,1,.gap 2 0),
(260,2,.gap 2 1),
(356,8,.gap 2 3)]
private theorem valid0 : rs0.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs1 : List (ℕ × ℕ × Witness) := [(356,16,.gap 2 4),
(100,128,.gap 2 7),
(264,1,.gap 3 0),
(264,2,.gap 3 1),
(360,4,.gap 3 2),
(360,16,.gap 3 4),
(104,128,.gap 3 7),
(272,1,.gap 4 0),
(272,2,.gap 4 1),
(368,4,.gap 4 2),
(368,8,.gap 4 3),
(112,128,.gap 4 7),
(160,1,.gap 5 0),
(160,2,.gap 5 1),
(188,64,.gap 5 6),
(60,256,.gap 5 8),
(192,1,.gap 6 0),
(192,2,.gap 6 1),
(220,32,.gap 6 5),
(92,256,.gap 6 8),
(224,4,.gap 7 2),
(224,8,.gap 7 3),
(224,16,.gap 7 4),
(131,256,.gap 7 8)]
private theorem valid1 : rs1.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs2 : List (ℕ × ℕ × Witness) := [(284,32,.gap 8 5),
(284,64,.gap 8 6),
(259,128,.gap 8 7),
(31,480,.permutes 7933641765632 316939733014593),
(39,472,.permutes 2176647089152 323538814930979),
(43,468,.permutes 2176647089152 323538814929956),
(47,464,.permutes 4277147303937 10178136179909),
(51,460,.permutes 2176647089152 323538814897189),
(55,456,.permutes 4277147303937 10178169734340),
(59,452,.permutes 4277147303937 10178170782915),
(71,440,.permutes 2176647089152 324637252816931),
(75,436,.permutes 2176647089152 324637252815908),
(79,432,.permutes 4277147303937 10177062438117),
(83,428,.permutes 2176647089152 324637252783141),
(87,424,.permutes 4277147303937 10177095992548),
(91,420,.permutes 4277147303937 10177097041123),
(99,412,.permutes 7105820778496 253205504103555),
(156,355,.permutes 4107987063072 325702574506049),
(352,159,.permutes 4362873176064 324570850623553),
(384,127,.permutes 4382864965632 325702574508064),
(511,0,.permutes 35115652612096 10178205453377)]
private theorem valid2 : rs2.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs := rs0 ++ rs1 ++ rs2
theorem complete : certifiedRows (decode 10 target) ([p].map (decode 9)) (children.map (decode 10)) := by
  apply parent_rows children masks rs
  · decide +kernel
  · decide +kernel
  · simp only [rs,List.all_append,valid0,valid1,valid2,Bool.and_self]
end BitmapLevel9.BitmapLevel9P0005
#print axioms BitmapLevel9.BitmapLevel9P0005.complete
