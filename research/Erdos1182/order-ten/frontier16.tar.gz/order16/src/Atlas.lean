import Extension

namespace BBHExtension
open SimpleGraph

def renamedJoin {A B : Type*} {P : SimpleGraph A} {Q : SimpleGraph B}
    (e : P ≃g Q) (S : Finset A) :
    joinGraph P S ≃g joinGraph Q (S.map e.toEquiv.toEmbedding) where
  toEquiv := e.toEquiv.optionCongr
  map_rel_iff' := by
    have mem (a : A) : e a ∈ S.map e.toEquiv.toEmbedding ↔ a∈S :=
      Finset.mem_map' ..
    rintro (_|x) (_|y)
    · rfl
    · exact mem y
    · exact mem x
    · exact and_congr e.map_rel_iff (not_congr (and_congr (mem x) (mem y)))

def renamedExtension {k} {P Q : SimpleGraph (Fin k)} (e : P ≃g Q) (S : Finset (Fin k)) :
    extend P S ≃g extend Q (S.map e.toEquiv.toEmbedding) :=
  ((SimpleGraph.Iso.comap (finSuccEquiv k) _).trans (renamedJoin e S)).trans
    (SimpleGraph.Iso.comap (finSuccEquiv k) _).symm

/-- A missing edge that could be inserted without closing a triangle. -/
def defect {A : Type*} (P : SimpleGraph A) : Prop :=
  ∃ u v, u≠v ∧ ¬P.Adj u v ∧ ∀ w, ¬(P.Adj u w ∧ P.Adj v w)

theorem no_defect {A B : Type*} [DecidableEq A] {P : SimpleGraph A} {Q : SimpleGraph B}
    (h : Maximal (fun D : SimpleGraph A => D.CliqueFree 3) P) (e : P ≃g Q) : ¬defect Q := by
  rintro ⟨u,v,ne,miss,all⟩
  obtain ⟨w,uw,vw⟩ := saturation_witness h (e.symm.injective.ne ne)
    (fun edge => miss (e.symm.map_rel_iff.mp edge))
  apply all (e w)
  exact ⟨by simpa using e.map_rel_iff.mpr uw,by simpa using e.map_rel_iff.mpr vw⟩

theorem dom_image {A B : Type*} {P : SimpleGraph A} {Q : SimpleGraph B}
    (e : P ≃g Q) (S : Finset A) (h : ∀ y, y∉S → ∃ x∈S, P.Adj x y) :
    ∀ y, y ∉ S.map e.toEquiv.toEmbedding → ∃ x∈S.map e.toEquiv.toEmbedding, Q.Adj x y := by
  intro y hyn
  obtain ⟨x,hx,xy⟩ := h (e.symm y) (fun h => hyn (by simpa using Finset.mem_map_of_mem e.toEquiv.toEmbedding h))
  exact ⟨e x,Finset.mem_map_of_mem _ hx,by simpa using e.map_rel_iff.mpr xy⟩

/-- A finite transition certificate. A row is a dominating set of an already listed
parent. The witness is a saturation defect, a prescribed embedding, or a
permutation onto the next stored representative. -/
def certifiedRows {V : Type*} (G : SimpleGraph V) {k : ℕ}
    (parents : List (SimpleGraph (Fin k))) (children : List (SimpleGraph (Fin (k+1)))) : Prop :=
  ∀ P∈parents, ∀ S ∈ (Finset.univ : Finset (Fin k)).powerset,
    (∀ y, y∉S → ∃ x∈S,P.Adj x y) →
    defect (extend P S) ∨ G ⊑ (extend P S)ᶜ ∨
      ∃ D∈children, Nonempty (extend P S ≃g D)

theorem atlas_complete {V : Type*} (G : SimpleGraph V) (N : ℕ)
    (atlas : (k : ℕ) → List (SimpleGraph (Fin k)))
    (init : ⊥ ∈ atlas 0)
    (rows : ∀ k<N, certifiedRows G (atlas k) (atlas (k+1))) :
    ∀ k, k≤N → ∀ H : SimpleGraph (Fin k),
      Maximal (fun D : SimpleGraph (Fin k) => D.CliqueFree 3) H → (¬ G ⊑ Hᶜ) →
      ∃ D∈atlas k, Nonempty (H ≃g D) := by
  classical
  intro k
  induction k with
  | zero =>
    intro _ H _ _
    have eq : H=⊥ := Subsingleton.elim _ _
    subst H
    exact ⟨⊥,init,⟨RelIso.refl _⟩⟩
  | succ k ih =>
    intro bound H max avoid
    obtain ⟨P,S,hP,noP,dom,rfl⟩ := parent G H max avoid
    obtain ⟨Q,hQ,⟨e⟩⟩ := ih (Nat.le_of_succ_le bound) P hP noP
    let T := S.map e.toEquiv.toEmbedding
    let j := renamedExtension e S
    rcases rows k bound Q hQ T (Finset.mem_powerset.mpr (Finset.subset_univ T)) (dom_image e S dom)
      with bad|hit|⟨D,hD,⟨iso⟩⟩
    · exact (no_defect max j bad).elim
    · exact (avoid (hit.trans ⟨(SimpleGraph.Embedding.complEquiv j.symm.toEmbedding).toCopy⟩)).elim
    · exact ⟨D,hD,⟨j.trans iso⟩⟩

theorem complement_covers {V : Type*} (G : SimpleGraph V) (N : ℕ)
    (atlas : (k : ℕ) → List (SimpleGraph (Fin k))) (init : ⊥ ∈ atlas 0)
    (rows : ∀ k<N, certifiedRows G (atlas k) (atlas (k+1))) (endRow : atlas N = []) :
    ∀ H : SimpleGraph (Fin N), H.CliqueFree 3 → G ⊑ Hᶜ := by
  classical
  intro H ht
  let fam : Set (SimpleGraph (Fin N)) := {D | D.CliqueFree 3}
  obtain ⟨P,leP,hP⟩ := fam.toFinite.exists_le_maximal (show H∈fam from ht)
  by_contra miss
  obtain ⟨D,hD,_⟩ := atlas_complete G N atlas init rows N le_rfl P hP
    (fun h => miss (h.mono_right (compl_le_compl leP)))
  simp [endRow] at hD

end BBHExtension
#print axioms BBHExtension.complement_covers
