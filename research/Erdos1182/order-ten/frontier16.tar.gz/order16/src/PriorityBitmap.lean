import CubeRows
import TwinCubes

namespace ExtensionBitmap
open SimpleGraph BBHExtension

/-- Ordinary rows prove the outcome directly. A twin cube reduces every
remaining admissible connector to one of the k old open neighborhoods. -/
theorem parent_twin_rows {n k t p : ℕ} (children : List ℕ) (masks : Array ℕ)
    (rs : List (ℕ × ℕ × Witness)) (twins : List (ℕ × ℕ × ℕ × ℕ))
    (matchRows : masksMatch k p masks = true)
    (fill : covered k rs ||| covered k twins = 2^(2^k)-1)
    (checked : rs.all (valid n k t p children masks) = true)
    (twinOK : twins.all (fun (l,u,x,y) => twinCube k masks l u x y) = true)
    (clones : ∀ z : Fin k, let s := masks[z.val]?.getD 0
               s < 2^k ∧ (covered k rs).testBit s = true) :
    selectedRows (decode n t) priorityRow ([p].map (decode k)) (children.map (decode (k+1))) := by
  intro P hP S _ dom priority
  obtain rfl : P = decode k p := by simpa using hP
  have hits : ∃ row ∈ rs, subset k row.1 ⊆ S ∧ Disjoint S (subset k row.2.1) := by
    obtain ⟨s,hs,rfl⟩ := subset_surj S
    have bit : (covered k rs ||| covered k twins).testBit s = true := by simp [fill,hs]
    rw [Nat.testBit_or,Bool.or_eq_true] at bit
    rcases bit with hit | twin
    · exact fits_at rs hs hit
    obtain ⟨⟨l,u,x,y⟩,mem,lo,hi⟩ := fits_at twins hs twin
    obtain ⟨z,eq⟩ := twinCube_priority matchRows (List.all_eq_true.mp twinOK _ mem) _ lo hi priority
    rw [eq]
    exact fits_at rs (clones z).1 (clones z).2
  obtain ⟨⟨l,u,tag⟩,mem,lo,hi⟩ := hits
  rcases valid_sound children matchRows tag (List.all_eq_true.mp checked _ mem) S lo hi dom
    with bad|hit|⟨b,hb,iso⟩
  · exact Or.inl bad
  · exact Or.inr (Or.inl hit)
  · exact Or.inr (Or.inr ⟨_,List.mem_map_of_mem hb,iso⟩)
end ExtensionBitmap
#print axioms ExtensionBitmap.parent_twin_rows
