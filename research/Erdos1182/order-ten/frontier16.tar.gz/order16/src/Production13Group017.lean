import Production13P0204
import Production13P0205
import Production13P0206
import Production13P0207
import Production13P0208
import Production13P0209
import Production13P0210
import Production13P0211
import Production13P0212
import Production13P0213
import Production13P0214
import Production13P0215
namespace Production13
open BBHExtension SimpleGraph
theorem Production13Group017 : selectedRows (decode 10 target) priorityRow (group017.map (decode 13)) (children.map (decode 14)) := by
  intro P mem S hS dom row
  simp only [group017,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact Production13P0204.complete _ (by simp [Production13P0204.p]) S hS dom row
  · exact Production13P0205.complete _ (by simp [Production13P0205.p]) S hS dom row
  · exact Production13P0206.complete _ (by simp [Production13P0206.p]) S hS dom row
  · exact Production13P0207.complete _ (by simp [Production13P0207.p]) S hS dom row
  · exact Production13P0208.complete _ (by simp [Production13P0208.p]) S hS dom row
  · exact Production13P0209.complete _ (by simp [Production13P0209.p]) S hS dom row
  · exact Production13P0210.complete _ (by simp [Production13P0210.p]) S hS dom row
  · exact Production13P0211.complete _ (by simp [Production13P0211.p]) S hS dom row
  · exact Production13P0212.complete _ (by simp [Production13P0212.p]) S hS dom row
  · exact Production13P0213.complete _ (by simp [Production13P0213.p]) S hS dom row
  · exact Production13P0214.complete _ (by simp [Production13P0214.p]) S hS dom row
  · exact Production13P0215.complete _ (by simp [Production13P0215.p]) S hS dom row
end Production13
#print axioms Production13.Production13Group017
