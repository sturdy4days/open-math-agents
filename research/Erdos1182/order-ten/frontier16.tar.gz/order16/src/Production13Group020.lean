import Production13P0240
import Production13P0241
import Production13P0242
import Production13P0243
import Production13P0244
import Production13P0245
import Production13P0246
import Production13P0247
import Production13P0248
import Production13P0249
import Production13P0250
import Production13P0251
namespace Production13
open BBHExtension SimpleGraph
theorem Production13Group020 : selectedRows (decode 10 target) priorityRow (group020.map (decode 13)) (children.map (decode 14)) := by
  intro P mem S hS dom row
  simp only [group020,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact Production13P0240.complete _ (by simp [Production13P0240.p]) S hS dom row
  · exact Production13P0241.complete _ (by simp [Production13P0241.p]) S hS dom row
  · exact Production13P0242.complete _ (by simp [Production13P0242.p]) S hS dom row
  · exact Production13P0243.complete _ (by simp [Production13P0243.p]) S hS dom row
  · exact Production13P0244.complete _ (by simp [Production13P0244.p]) S hS dom row
  · exact Production13P0245.complete _ (by simp [Production13P0245.p]) S hS dom row
  · exact Production13P0246.complete _ (by simp [Production13P0246.p]) S hS dom row
  · exact Production13P0247.complete _ (by simp [Production13P0247.p]) S hS dom row
  · exact Production13P0248.complete _ (by simp [Production13P0248.p]) S hS dom row
  · exact Production13P0249.complete _ (by simp [Production13P0249.p]) S hS dom row
  · exact Production13P0250.complete _ (by simp [Production13P0250.p]) S hS dom row
  · exact Production13P0251.complete _ (by simp [Production13P0251.p]) S hS dom row
end Production13
#print axioms Production13.Production13Group020
