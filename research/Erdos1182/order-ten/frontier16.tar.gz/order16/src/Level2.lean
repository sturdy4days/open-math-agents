import Verify2_000

namespace EarlyRamsey
open BBHExtension SimpleGraph

theorem step2 : selectedRows (decode 10 Terminal18.target) priorityRow (atlas 2) (atlas 3) := by
  apply level_step
  intro p hp
  change p ∈ words2 at hp
  simp only [words2,List.mem_cons,List.not_mem_nil,or_false] at hp
  subst p
  exact Verify2_000.checked

end EarlyRamsey
