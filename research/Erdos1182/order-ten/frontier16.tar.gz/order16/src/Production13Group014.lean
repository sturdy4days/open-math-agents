import Production13P0168
import Production13P0169
import Production13P0170
import Production13P0171
import Production13P0172
import Production13P0173
import Production13P0174
import Production13P0175
import Production13P0176
import Production13P0177
import Production13P0178
import Production13P0179
namespace Production13
open BBHExtension SimpleGraph
theorem Production13Group014 : selectedRows (decode 10 target) priorityRow (group014.map (decode 13)) (children.map (decode 14)) := by
  intro P mem S hS dom row
  simp only [group014,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact Production13P0168.complete _ (by simp [Production13P0168.p]) S hS dom row
  · exact Production13P0169.complete _ (by simp [Production13P0169.p]) S hS dom row
  · exact Production13P0170.complete _ (by simp [Production13P0170.p]) S hS dom row
  · exact Production13P0171.complete _ (by simp [Production13P0171.p]) S hS dom row
  · exact Production13P0172.complete _ (by simp [Production13P0172.p]) S hS dom row
  · exact Production13P0173.complete _ (by simp [Production13P0173.p]) S hS dom row
  · exact Production13P0174.complete _ (by simp [Production13P0174.p]) S hS dom row
  · exact Production13P0175.complete _ (by simp [Production13P0175.p]) S hS dom row
  · exact Production13P0176.complete _ (by simp [Production13P0176.p]) S hS dom row
  · exact Production13P0177.complete _ (by simp [Production13P0177.p]) S hS dom row
  · exact Production13P0178.complete _ (by simp [Production13P0178.p]) S hS dom row
  · exact Production13P0179.complete _ (by simp [Production13P0179.p]) S hS dom row
end Production13
#print axioms Production13.Production13Group014
