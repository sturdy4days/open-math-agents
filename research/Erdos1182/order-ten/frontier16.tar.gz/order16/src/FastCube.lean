import Cubes

namespace BBHExtension
open SimpleGraph

/-- Exact red envelope adjacency by native natural-number mask operations. Index zero
is the appended vertex; positive indices are the old vertices shifted by one. -/
def cubeAdj (p l u x y : ℕ) : Bool :=
  if x=0 then y != 0 && (l.testBit (y-1) || !u.testBit (y-1))
  else if y=0 then l.testBit (x-1) || !u.testBit (x-1)
  else adjacent p (x-1) (y-1) && !(l.testBit (x-1) && l.testBit (y-1))

theorem cubeAdj_iff {k} (p l u : ℕ) (x y : Fin (k+1)) :
    cubeAdj p l u x.val y.val = true ↔
    (envelope (decode k p) (subset k l) (subset k u)).Adj x y := by
  revert y
  refine Fin.cases ?_ (fun i => ?_) x
  · intro y
    refine Fin.cases ?_ (fun j => ?_) y
    · simp [cubeAdj]
    · change _ ↔ _ ∨ _
      simp [cubeAdj,extend_left,subset]
  · intro y
    refine Fin.cases ?_ (fun j => ?_) y
    · rw [SimpleGraph.adj_comm]
      change _ ↔ _ ∨ _
      simp [cubeAdj,extend_left,subset]
    · change _ ↔ _ ∨ _
      simp [cubeAdj,extend_old,subset,decode]
      cases l.testBit i.val <;> cases l.testBit j.val <;> simp

def fastCube (n k target parent require forbid code : ℕ) : Bool :=
  let f := fun x : Fin n => vertex k code x.val
  decide ((∀ x y, f x = f y → x=y) ∧ ∀ x y, (decode n target).Adj x y →
    f x ≠ f y ∧ cubeAdj parent require forbid (f x).val (f y).val = false)

theorem fastCube_sound {n k target parent require forbid code : ℕ}
    (pass : fastCube n k target parent require forbid code = true) :
    decode n target ⊑ (envelope (decode k parent) (subset k require) (subset k forbid))ᶜ := by
  obtain ⟨inj,adj⟩ := of_decide_eq_true pass
  let f : decode n target →g (envelope (decode k parent) (subset k require) (subset k forbid))ᶜ :=
    { toFun := fun x => vertex k code x.val
      map_rel' := fun {x y} h => ⟨(adj x y h).1,fun red => by
        have eq := (cubeAdj_iff _ _ _ _ _).2 red
        rw [(adj x y h).2] at eq
        contradiction⟩ }
  exact ⟨f.toCopy inj⟩

end BBHExtension
