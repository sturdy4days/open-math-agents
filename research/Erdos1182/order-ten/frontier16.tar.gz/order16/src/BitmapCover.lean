import Records

namespace ExtensionBitmap
open BBHExtension

/-- Bit s is the neighborhood whose membership bits are s. Adding one old
vertex doubles the table, with absent and present neighborhoods in the two halves. -/
def cube (l u : ℕ) : ℕ → ℕ
  | 0 => 1
  | k+1 =>
    let b := cube l u k
    (if l.testBit k then 0 else b % (2^(2^k))) |||
      ((if u.testBit k then 0 else b) <<< (2^k))

private theorem cube_bit {l u k s : ℕ} (hs : s < 2^k) (good : (cube l u k).testBit s = true)
    {j : ℕ} (hj : j < k) :
    (l.testBit j = true → s.testBit j = true) ∧
    (u.testBit j = true → s.testBit j = false) := by
  induction k generalizing s j with
  | zero => omega
  | succ k ih =>
    by_cases lower : s < 2^k
    · have hn : ¬s ≥ 2^k := by omega
      obtain ⟨off,prev⟩ : l.testBit k = false ∧ (cube l u k).testBit s = true := by
        cases h : l.testBit k <;> simp [cube,h,Nat.testBit_or,hn,lower] at good ⊢
        exact good
      rcases Nat.lt_or_eq_of_le (Nat.le_of_lt_succ hj) with lt|rfl
      · exact ih lower prev lt
      · exact ⟨by simp [off],fun _ => Nat.testBit_lt_two_pow lower⟩
    · have ge : 2^k ≤ s := by omega
      have sm : s - 2^k < 2^k := by rw [Nat.pow_succ] at hs; omega
      have idn : s = 2^k + (s - 2^k) := by omega
      obtain ⟨off,prev⟩ : u.testBit k = false ∧ (cube l u k).testBit (s-2^k) = true := by
        cases h : u.testBit k <;> cases hl : l.testBit k <;>
          simp [cube,h,hl,Nat.testBit_or,ge,lower] at good ⊢ <;> exact good
      rcases Nat.lt_or_eq_of_le (Nat.le_of_lt_succ hj) with lt|rfl
      · have eqb : s.testBit j = (s-2^k).testBit j := calc
          s.testBit j = (2^k+(s-2^k)).testBit j := congrArg (fun t : ℕ => t.testBit j) idn
          _ = _ := Nat.testBit_two_pow_add_gt lt _
        rw [eqb]
        exact ih sm prev lt
      · exact ⟨fun _ => Nat.testBit_of_two_pow_le_and_two_pow_add_one_gt ge hs, by simp [off]⟩

def covered {α : Type*} (k : ℕ) : List (ℕ × ℕ × α) → ℕ
  | [] => 0
  | (l,u,_) :: rs => cube l u k ||| covered k rs

private theorem covered_bit {α : Type*} (k s : ℕ) (rs : List (ℕ × ℕ × α))
    (good : (covered k rs).testBit s = true) :
    ∃ row ∈ rs, (cube row.1 row.2.1 k).testBit s = true := by
  induction rs with
  | nil => simp [covered] at good
  | cons head tail ih =>
    rcases head with ⟨l,u,tag⟩
    rw [covered,Nat.testBit_or,Bool.or_eq_true] at good
    rcases good with good|good
    · exact ⟨_,List.mem_cons_self,good⟩
    · obtain ⟨row,mem,ok⟩ := ih good
      exact ⟨row,List.mem_cons_of_mem _ mem,ok⟩

theorem fits_at {α : Type*} {k s : ℕ} (rs : List (ℕ × ℕ × α))
    (hs : s < 2^k) (bit : (covered k rs).testBit s = true) :
    ∃ row ∈ rs, subset k row.1 ⊆ subset k s ∧ Disjoint (subset k s) (subset k row.2.1) := by
  obtain ⟨row,mem,pass⟩ := covered_bit k s rs bit
  refine ⟨row,mem,?_,Finset.disjoint_left.mpr ?_⟩
  · intro i hi
    simp only [subset,Finset.mem_filter,Finset.mem_univ,true_and] at hi ⊢
    exact (cube_bit hs pass i.isLt).1 hi
  · intro i hi hu
    simp only [subset,Finset.mem_filter,Finset.mem_univ,true_and] at hi hu
    have v := (cube_bit hs pass i.isLt).2 hu
    simp [hi] at v

/-- One bitwise OR equality covers every possible connector. The row payload
can be a gap, an embedding, or an isomorphism, without affecting coverage. -/
theorem covers {α : Type*} {k : ℕ} (rs : List (ℕ × ℕ × α))
    (good : covered k rs = 2^(2^k)-1) (S : Finset (Fin k)) :
    ∃ row ∈ rs, subset k row.1 ⊆ S ∧ Disjoint S (subset k row.2.1) := by
  obtain ⟨s,hs,rfl⟩ := subset_surj S
  have bit : (covered k rs).testBit s = true := by simp [good,hs]
  exact fits_at rs hs bit

end ExtensionBitmap
#print axioms ExtensionBitmap.covers
