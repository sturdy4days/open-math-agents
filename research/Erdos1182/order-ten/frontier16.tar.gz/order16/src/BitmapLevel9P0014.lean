import BitmapLevel9Data
namespace BitmapLevel9.BitmapLevel9P0014
open SimpleGraph BBHExtension ExtensionBitmap
def p : ℕ := 16221241363
def masks : Array ℕ := #[70, 137, 385, 322, 448, 448, 57, 54, 60]
set_option maxRecDepth 12000
set_option maxHeartbeats 2500000
def rs0 : List (ℕ × ℕ × Witness) := [(0,71,.undominated 0),
(0,139,.undominated 1),
(0,389,.undominated 2),
(0,330,.undominated 3),
(0,464,.undominated 4),
(0,480,.undominated 5),
(0,121,.undominated 6),
(0,182,.undominated 7),
(0,316,.undominated 8),
(67,8,.gap 0 3),
(65,16,.gap 0 4),
(65,32,.gap 0 5),
(7,128,.gap 0 7),
(5,256,.gap 0 8),
(131,4,.gap 1 2),
(130,16,.gap 1 4),
(130,32,.gap 1 5),
(11,64,.gap 1 6),
(10,256,.gap 1 8),
(133,2,.gap 2 1),
(260,8,.gap 2 3),
(388,16,.gap 2 4),
(388,32,.gap 2 5),
(5,64,.gap 2 6)]
private theorem valid0 : rs0.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs1 : List (ℕ × ℕ × Witness) := [(74,1,.gap 3 0),
(264,4,.gap 3 2),
(328,16,.gap 3 4),
(328,32,.gap 3 5),
(10,128,.gap 3 7),
(80,1,.gap 4 0),
(144,2,.gap 4 1),
(400,4,.gap 4 2),
(336,8,.gap 4 3),
(464,32,.gap 4 5),
(96,1,.gap 5 0),
(160,2,.gap 5 1),
(416,4,.gap 5 2),
(352,8,.gap 5 3),
(480,16,.gap 5 4),
(73,2,.gap 6 1),
(65,4,.gap 6 2),
(112,128,.gap 6 7),
(120,256,.gap 6 8),
(134,1,.gap 7 0),
(130,8,.gap 7 3),
(176,64,.gap 7 6),
(180,256,.gap 7 8),
(260,1,.gap 8 0)]
private theorem valid1 : rs1.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs2 : List (ℕ × ℕ × Witness) := [(264,2,.gap 8 1),
(312,64,.gap 8 6),
(308,128,.gap 8 7),
(51,460,.permutes 4000346439713 325696166692961),
(54,457,.permutes 1866082771232 248802361638948),
(57,454,.permutes 1866082771232 282888262287427),
(60,451,.permutes 20963438015233 250966957129793),
(70,441,.permutes 2176647089152 255199508894724),
(76,435,.permutes 27226439286803 115731321586818),
(137,374,.permutes 2176647089152 289318696588291),
(140,371,.permutes 27226439286803 150882407680097),
(196,315,.permutes 2141996208128 256463336505541),
(200,311,.permutes 2141996208128 291612309684421),
(204,307,.permutes 27226439286803 9046481570881),
(259,252,.permutes 2141996208128 324632989273285),
(273,238,.permutes 19115143757857 247674764857504),
(274,237,.permutes 19115143757857 283924322356384),
(275,236,.permutes 19115143757857 316941917032545),
(289,222,.permutes 19115143757857 247674763808960),
(290,221,.permutes 19115143757857 283924321307840),
(291,220,.permutes 19115143757857 316941949538401),
(305,206,.permutes 27226439286803 35433686862116),
(306,205,.permutes 27226439286803 70651344979235),
(307,204,.permutes 2141996208128 9041016325317)]
private theorem valid2 : rs2.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs3 : List (ℕ × ℕ × Witness) := [(322,189,.permutes 4277147303937 324633090004065),
(385,126,.permutes 4277147303937 325697134597250),
(448,63,.permutes 8141638991891 289487406107713),
(511,0,.permutes 35115652612096 10178205453377)]
private theorem valid3 : rs3.all (valid 10 9 target p children masks) = true := by decide +kernel
def rs := rs0 ++ rs1 ++ rs2 ++ rs3
theorem complete : certifiedRows (decode 10 target) ([p].map (decode 9)) (children.map (decode 10)) := by
  apply parent_rows children masks rs
  · decide +kernel
  · decide +kernel
  · simp only [rs,List.all_append,valid0,valid1,valid2,valid3,Bool.and_self]
end BitmapLevel9.BitmapLevel9P0014
#print axioms BitmapLevel9.BitmapLevel9P0014.complete
