import Production13P0192
import Production13P0193
import Production13P0194
import Production13P0195
import Production13P0196
import Production13P0197
import Production13P0198
import Production13P0199
import Production13P0200
import Production13P0201
import Production13P0202
import Production13P0203
namespace Production13
open BBHExtension SimpleGraph
theorem Production13Group016 : selectedRows (decode 10 target) priorityRow (group016.map (decode 13)) (children.map (decode 14)) := by
  intro P mem S hS dom row
  simp only [group016,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact Production13P0192.complete _ (by simp [Production13P0192.p]) S hS dom row
  · exact Production13P0193.complete _ (by simp [Production13P0193.p]) S hS dom row
  · exact Production13P0194.complete _ (by simp [Production13P0194.p]) S hS dom row
  · exact Production13P0195.complete _ (by simp [Production13P0195.p]) S hS dom row
  · exact Production13P0196.complete _ (by simp [Production13P0196.p]) S hS dom row
  · exact Production13P0197.complete _ (by simp [Production13P0197.p]) S hS dom row
  · exact Production13P0198.complete _ (by simp [Production13P0198.p]) S hS dom row
  · exact Production13P0199.complete _ (by simp [Production13P0199.p]) S hS dom row
  · exact Production13P0200.complete _ (by simp [Production13P0200.p]) S hS dom row
  · exact Production13P0201.complete _ (by simp [Production13P0201.p]) S hS dom row
  · exact Production13P0202.complete _ (by simp [Production13P0202.p]) S hS dom row
  · exact Production13P0203.complete _ (by simp [Production13P0203.p]) S hS dom row
end Production13
#print axioms Production13.Production13Group016
