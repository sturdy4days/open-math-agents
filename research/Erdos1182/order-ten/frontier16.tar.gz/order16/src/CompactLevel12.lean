import CompactLevel12P0000
import CompactLevel12P0001
import CompactLevel12P0002
import CompactLevel12P0003
import CompactLevel12P0004
import CompactLevel12P0005
import CompactLevel12P0006
import CompactLevel12P0007
import CompactLevel12P0008
import CompactLevel12P0009
import CompactLevel12P0010
import CompactLevel12P0011
import CompactLevel12P0012
import CompactLevel12P0013
import CompactLevel12P0014
import CompactLevel12P0015
import CompactLevel12P0016
import CompactLevel12P0017
import CompactLevel12P0018
import CompactLevel12P0019
import CompactLevel12P0020
import CompactLevel12P0021
import CompactLevel12P0022
import CompactLevel12P0023
import CompactLevel12P0024
import CompactLevel12P0025
import CompactLevel12P0026
import CompactLevel12P0027
import CompactLevel12P0028
import CompactLevel12P0029
import CompactLevel12P0030
import CompactLevel12P0031
import CompactLevel12P0032
import CompactLevel12P0033
import CompactLevel12P0034
import CompactLevel12P0035
import CompactLevel12P0036
import CompactLevel12P0037
import CompactLevel12P0038
import CompactLevel12P0039
import CompactLevel12P0040
import CompactLevel12P0041
import CompactLevel12P0042
import CompactLevel12P0043
import CompactLevel12P0044
import CompactLevel12P0045
import CompactLevel12P0046
import CompactLevel12P0047
import CompactLevel12P0048
import CompactLevel12P0049
import CompactLevel12P0050
import CompactLevel12P0051
import CompactLevel12P0052
import CompactLevel12P0053
import CompactLevel12P0054
import CompactLevel12P0055
import CompactLevel12P0056
import CompactLevel12P0057
import CompactLevel12P0058
import CompactLevel12P0059
import CompactLevel12P0060
import CompactLevel12P0061
import CompactLevel12P0062
import CompactLevel12P0063
import CompactLevel12P0064
import CompactLevel12P0065
import CompactLevel12P0066
import CompactLevel12P0067
import CompactLevel12P0068
import CompactLevel12P0069
import CompactLevel12P0070
import CompactLevel12P0071
import CompactLevel12P0072
import CompactLevel12P0073
import CompactLevel12P0074
import CompactLevel12P0075
import CompactLevel12P0076
import CompactLevel12P0077
import CompactLevel12P0078
import CompactLevel12P0079
import CompactLevel12P0080
import CompactLevel12P0081
import CompactLevel12P0082
import CompactLevel12P0083
import CompactLevel12P0084
import CompactLevel12P0085
import CompactLevel12P0086
import CompactLevel12P0087
import CompactLevel12P0088
import CompactLevel12P0089
import CompactLevel12P0090
import CompactLevel12P0091
import CompactLevel12P0092
import CompactLevel12P0093
import CompactLevel12P0094
import CompactLevel12P0095
import CompactLevel12P0096
import CompactLevel12P0097
import CompactLevel12P0098
import CompactLevel12P0099
import CompactLevel12P0100
import CompactLevel12P0101
import CompactLevel12P0102
import CompactLevel12P0103
import CompactLevel12P0104
import CompactLevel12P0105
import CompactLevel12P0106
import CompactLevel12P0107
import CompactLevel12P0108
import CompactLevel12P0109
import CompactLevel12P0110
import CompactLevel12P0111
import CompactLevel12P0112
import CompactLevel12P0113
import CompactLevel12P0114
import CompactLevel12P0115
import CompactLevel12P0116
import CompactLevel12P0117
import CompactLevel12P0118
import CompactLevel12P0119
import CompactLevel12P0120
import CompactLevel12P0121
import CompactLevel12P0122
import CompactLevel12P0123
import CompactLevel12P0124
import CompactLevel12P0125
import CompactLevel12P0126
import CompactLevel12P0127
import CompactLevel12P0128
import CompactLevel12P0129
import CompactLevel12P0130
import CompactLevel12P0131
import CompactLevel12P0132
import CompactLevel12P0133
import CompactLevel12P0134
import CompactLevel12P0135
import CompactLevel12P0136
import CompactLevel12P0137
namespace CompactLevel12
open SimpleGraph BBHExtension
theorem all_parents : selectedRows (decode 10 target) priorityRow (parents.map (decode 12)) (children.map (decode 13)) := by
  intro P mem S hS dom prio
  simp only [parents,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact CompactLevel12P0000.complete _ (by simp [CompactLevel12P0000.p]) S hS dom prio
  · exact CompactLevel12P0001.complete _ (by simp [CompactLevel12P0001.p]) S hS dom prio
  · exact CompactLevel12P0002.complete _ (by simp [CompactLevel12P0002.p]) S hS dom prio
  · exact CompactLevel12P0003.complete _ (by simp [CompactLevel12P0003.p]) S hS dom prio
  · exact CompactLevel12P0004.complete _ (by simp [CompactLevel12P0004.p]) S hS dom prio
  · exact CompactLevel12P0005.complete _ (by simp [CompactLevel12P0005.p]) S hS dom prio
  · exact CompactLevel12P0006.complete _ (by simp [CompactLevel12P0006.p]) S hS dom prio
  · exact CompactLevel12P0007.complete _ (by simp [CompactLevel12P0007.p]) S hS dom prio
  · exact CompactLevel12P0008.complete _ (by simp [CompactLevel12P0008.p]) S hS dom prio
  · exact CompactLevel12P0009.complete _ (by simp [CompactLevel12P0009.p]) S hS dom prio
  · exact CompactLevel12P0010.complete _ (by simp [CompactLevel12P0010.p]) S hS dom prio
  · exact CompactLevel12P0011.complete _ (by simp [CompactLevel12P0011.p]) S hS dom prio
  · exact CompactLevel12P0012.complete _ (by simp [CompactLevel12P0012.p]) S hS dom prio
  · exact CompactLevel12P0013.complete _ (by simp [CompactLevel12P0013.p]) S hS dom prio
  · exact CompactLevel12P0014.complete _ (by simp [CompactLevel12P0014.p]) S hS dom prio
  · exact CompactLevel12P0015.complete _ (by simp [CompactLevel12P0015.p]) S hS dom prio
  · exact CompactLevel12P0016.complete _ (by simp [CompactLevel12P0016.p]) S hS dom prio
  · exact CompactLevel12P0017.complete _ (by simp [CompactLevel12P0017.p]) S hS dom prio
  · exact CompactLevel12P0018.complete _ (by simp [CompactLevel12P0018.p]) S hS dom prio
  · exact CompactLevel12P0019.complete _ (by simp [CompactLevel12P0019.p]) S hS dom prio
  · exact CompactLevel12P0020.complete _ (by simp [CompactLevel12P0020.p]) S hS dom prio
  · exact CompactLevel12P0021.complete _ (by simp [CompactLevel12P0021.p]) S hS dom prio
  · exact CompactLevel12P0022.complete _ (by simp [CompactLevel12P0022.p]) S hS dom prio
  · exact CompactLevel12P0023.complete _ (by simp [CompactLevel12P0023.p]) S hS dom prio
  · exact CompactLevel12P0024.complete _ (by simp [CompactLevel12P0024.p]) S hS dom prio
  · exact CompactLevel12P0025.complete _ (by simp [CompactLevel12P0025.p]) S hS dom prio
  · exact CompactLevel12P0026.complete _ (by simp [CompactLevel12P0026.p]) S hS dom prio
  · exact CompactLevel12P0027.complete _ (by simp [CompactLevel12P0027.p]) S hS dom prio
  · exact CompactLevel12P0028.complete _ (by simp [CompactLevel12P0028.p]) S hS dom prio
  · exact CompactLevel12P0029.complete _ (by simp [CompactLevel12P0029.p]) S hS dom prio
  · exact CompactLevel12P0030.complete _ (by simp [CompactLevel12P0030.p]) S hS dom prio
  · exact CompactLevel12P0031.complete _ (by simp [CompactLevel12P0031.p]) S hS dom prio
  · exact CompactLevel12P0032.complete _ (by simp [CompactLevel12P0032.p]) S hS dom prio
  · exact CompactLevel12P0033.complete _ (by simp [CompactLevel12P0033.p]) S hS dom prio
  · exact CompactLevel12P0034.complete _ (by simp [CompactLevel12P0034.p]) S hS dom prio
  · exact CompactLevel12P0035.complete _ (by simp [CompactLevel12P0035.p]) S hS dom prio
  · exact CompactLevel12P0036.complete _ (by simp [CompactLevel12P0036.p]) S hS dom prio
  · exact CompactLevel12P0037.complete _ (by simp [CompactLevel12P0037.p]) S hS dom prio
  · exact CompactLevel12P0038.complete _ (by simp [CompactLevel12P0038.p]) S hS dom prio
  · exact CompactLevel12P0039.complete _ (by simp [CompactLevel12P0039.p]) S hS dom prio
  · exact CompactLevel12P0040.complete _ (by simp [CompactLevel12P0040.p]) S hS dom prio
  · exact CompactLevel12P0041.complete _ (by simp [CompactLevel12P0041.p]) S hS dom prio
  · exact CompactLevel12P0042.complete _ (by simp [CompactLevel12P0042.p]) S hS dom prio
  · exact CompactLevel12P0043.complete _ (by simp [CompactLevel12P0043.p]) S hS dom prio
  · exact CompactLevel12P0044.complete _ (by simp [CompactLevel12P0044.p]) S hS dom prio
  · exact CompactLevel12P0045.complete _ (by simp [CompactLevel12P0045.p]) S hS dom prio
  · exact CompactLevel12P0046.complete _ (by simp [CompactLevel12P0046.p]) S hS dom prio
  · exact CompactLevel12P0047.complete _ (by simp [CompactLevel12P0047.p]) S hS dom prio
  · exact CompactLevel12P0048.complete _ (by simp [CompactLevel12P0048.p]) S hS dom prio
  · exact CompactLevel12P0049.complete _ (by simp [CompactLevel12P0049.p]) S hS dom prio
  · exact CompactLevel12P0050.complete _ (by simp [CompactLevel12P0050.p]) S hS dom prio
  · exact CompactLevel12P0051.complete _ (by simp [CompactLevel12P0051.p]) S hS dom prio
  · exact CompactLevel12P0052.complete _ (by simp [CompactLevel12P0052.p]) S hS dom prio
  · exact CompactLevel12P0053.complete _ (by simp [CompactLevel12P0053.p]) S hS dom prio
  · exact CompactLevel12P0054.complete _ (by simp [CompactLevel12P0054.p]) S hS dom prio
  · exact CompactLevel12P0055.complete _ (by simp [CompactLevel12P0055.p]) S hS dom prio
  · exact CompactLevel12P0056.complete _ (by simp [CompactLevel12P0056.p]) S hS dom prio
  · exact CompactLevel12P0057.complete _ (by simp [CompactLevel12P0057.p]) S hS dom prio
  · exact CompactLevel12P0058.complete _ (by simp [CompactLevel12P0058.p]) S hS dom prio
  · exact CompactLevel12P0059.complete _ (by simp [CompactLevel12P0059.p]) S hS dom prio
  · exact CompactLevel12P0060.complete _ (by simp [CompactLevel12P0060.p]) S hS dom prio
  · exact CompactLevel12P0061.complete _ (by simp [CompactLevel12P0061.p]) S hS dom prio
  · exact CompactLevel12P0062.complete _ (by simp [CompactLevel12P0062.p]) S hS dom prio
  · exact CompactLevel12P0063.complete _ (by simp [CompactLevel12P0063.p]) S hS dom prio
  · exact CompactLevel12P0064.complete _ (by simp [CompactLevel12P0064.p]) S hS dom prio
  · exact CompactLevel12P0065.complete _ (by simp [CompactLevel12P0065.p]) S hS dom prio
  · exact CompactLevel12P0066.complete _ (by simp [CompactLevel12P0066.p]) S hS dom prio
  · exact CompactLevel12P0067.complete _ (by simp [CompactLevel12P0067.p]) S hS dom prio
  · exact CompactLevel12P0068.complete _ (by simp [CompactLevel12P0068.p]) S hS dom prio
  · exact CompactLevel12P0069.complete _ (by simp [CompactLevel12P0069.p]) S hS dom prio
  · exact CompactLevel12P0070.complete _ (by simp [CompactLevel12P0070.p]) S hS dom prio
  · exact CompactLevel12P0071.complete _ (by simp [CompactLevel12P0071.p]) S hS dom prio
  · exact CompactLevel12P0072.complete _ (by simp [CompactLevel12P0072.p]) S hS dom prio
  · exact CompactLevel12P0073.complete _ (by simp [CompactLevel12P0073.p]) S hS dom prio
  · exact CompactLevel12P0074.complete _ (by simp [CompactLevel12P0074.p]) S hS dom prio
  · exact CompactLevel12P0075.complete _ (by simp [CompactLevel12P0075.p]) S hS dom prio
  · exact CompactLevel12P0076.complete _ (by simp [CompactLevel12P0076.p]) S hS dom prio
  · exact CompactLevel12P0077.complete _ (by simp [CompactLevel12P0077.p]) S hS dom prio
  · exact CompactLevel12P0078.complete _ (by simp [CompactLevel12P0078.p]) S hS dom prio
  · exact CompactLevel12P0079.complete _ (by simp [CompactLevel12P0079.p]) S hS dom prio
  · exact CompactLevel12P0080.complete _ (by simp [CompactLevel12P0080.p]) S hS dom prio
  · exact CompactLevel12P0081.complete _ (by simp [CompactLevel12P0081.p]) S hS dom prio
  · exact CompactLevel12P0082.complete _ (by simp [CompactLevel12P0082.p]) S hS dom prio
  · exact CompactLevel12P0083.complete _ (by simp [CompactLevel12P0083.p]) S hS dom prio
  · exact CompactLevel12P0084.complete _ (by simp [CompactLevel12P0084.p]) S hS dom prio
  · exact CompactLevel12P0085.complete _ (by simp [CompactLevel12P0085.p]) S hS dom prio
  · exact CompactLevel12P0086.complete _ (by simp [CompactLevel12P0086.p]) S hS dom prio
  · exact CompactLevel12P0087.complete _ (by simp [CompactLevel12P0087.p]) S hS dom prio
  · exact CompactLevel12P0088.complete _ (by simp [CompactLevel12P0088.p]) S hS dom prio
  · exact CompactLevel12P0089.complete _ (by simp [CompactLevel12P0089.p]) S hS dom prio
  · exact CompactLevel12P0090.complete _ (by simp [CompactLevel12P0090.p]) S hS dom prio
  · exact CompactLevel12P0091.complete _ (by simp [CompactLevel12P0091.p]) S hS dom prio
  · exact CompactLevel12P0092.complete _ (by simp [CompactLevel12P0092.p]) S hS dom prio
  · exact CompactLevel12P0093.complete _ (by simp [CompactLevel12P0093.p]) S hS dom prio
  · exact CompactLevel12P0094.complete _ (by simp [CompactLevel12P0094.p]) S hS dom prio
  · exact CompactLevel12P0095.complete _ (by simp [CompactLevel12P0095.p]) S hS dom prio
  · exact CompactLevel12P0096.complete _ (by simp [CompactLevel12P0096.p]) S hS dom prio
  · exact CompactLevel12P0097.complete _ (by simp [CompactLevel12P0097.p]) S hS dom prio
  · exact CompactLevel12P0098.complete _ (by simp [CompactLevel12P0098.p]) S hS dom prio
  · exact CompactLevel12P0099.complete _ (by simp [CompactLevel12P0099.p]) S hS dom prio
  · exact CompactLevel12P0100.complete _ (by simp [CompactLevel12P0100.p]) S hS dom prio
  · exact CompactLevel12P0101.complete _ (by simp [CompactLevel12P0101.p]) S hS dom prio
  · exact CompactLevel12P0102.complete _ (by simp [CompactLevel12P0102.p]) S hS dom prio
  · exact CompactLevel12P0103.complete _ (by simp [CompactLevel12P0103.p]) S hS dom prio
  · exact CompactLevel12P0104.complete _ (by simp [CompactLevel12P0104.p]) S hS dom prio
  · exact CompactLevel12P0105.complete _ (by simp [CompactLevel12P0105.p]) S hS dom prio
  · exact CompactLevel12P0106.complete _ (by simp [CompactLevel12P0106.p]) S hS dom prio
  · exact CompactLevel12P0107.complete _ (by simp [CompactLevel12P0107.p]) S hS dom prio
  · exact CompactLevel12P0108.complete _ (by simp [CompactLevel12P0108.p]) S hS dom prio
  · exact CompactLevel12P0109.complete _ (by simp [CompactLevel12P0109.p]) S hS dom prio
  · exact CompactLevel12P0110.complete _ (by simp [CompactLevel12P0110.p]) S hS dom prio
  · exact CompactLevel12P0111.complete _ (by simp [CompactLevel12P0111.p]) S hS dom prio
  · exact CompactLevel12P0112.complete _ (by simp [CompactLevel12P0112.p]) S hS dom prio
  · exact CompactLevel12P0113.complete _ (by simp [CompactLevel12P0113.p]) S hS dom prio
  · exact CompactLevel12P0114.complete _ (by simp [CompactLevel12P0114.p]) S hS dom prio
  · exact CompactLevel12P0115.complete _ (by simp [CompactLevel12P0115.p]) S hS dom prio
  · exact CompactLevel12P0116.complete _ (by simp [CompactLevel12P0116.p]) S hS dom prio
  · exact CompactLevel12P0117.complete _ (by simp [CompactLevel12P0117.p]) S hS dom prio
  · exact CompactLevel12P0118.complete _ (by simp [CompactLevel12P0118.p]) S hS dom prio
  · exact CompactLevel12P0119.complete _ (by simp [CompactLevel12P0119.p]) S hS dom prio
  · exact CompactLevel12P0120.complete _ (by simp [CompactLevel12P0120.p]) S hS dom prio
  · exact CompactLevel12P0121.complete _ (by simp [CompactLevel12P0121.p]) S hS dom prio
  · exact CompactLevel12P0122.complete _ (by simp [CompactLevel12P0122.p]) S hS dom prio
  · exact CompactLevel12P0123.complete _ (by simp [CompactLevel12P0123.p]) S hS dom prio
  · exact CompactLevel12P0124.complete _ (by simp [CompactLevel12P0124.p]) S hS dom prio
  · exact CompactLevel12P0125.complete _ (by simp [CompactLevel12P0125.p]) S hS dom prio
  · exact CompactLevel12P0126.complete _ (by simp [CompactLevel12P0126.p]) S hS dom prio
  · exact CompactLevel12P0127.complete _ (by simp [CompactLevel12P0127.p]) S hS dom prio
  · exact CompactLevel12P0128.complete _ (by simp [CompactLevel12P0128.p]) S hS dom prio
  · exact CompactLevel12P0129.complete _ (by simp [CompactLevel12P0129.p]) S hS dom prio
  · exact CompactLevel12P0130.complete _ (by simp [CompactLevel12P0130.p]) S hS dom prio
  · exact CompactLevel12P0131.complete _ (by simp [CompactLevel12P0131.p]) S hS dom prio
  · exact CompactLevel12P0132.complete _ (by simp [CompactLevel12P0132.p]) S hS dom prio
  · exact CompactLevel12P0133.complete _ (by simp [CompactLevel12P0133.p]) S hS dom prio
  · exact CompactLevel12P0134.complete _ (by simp [CompactLevel12P0134.p]) S hS dom prio
  · exact CompactLevel12P0135.complete _ (by simp [CompactLevel12P0135.p]) S hS dom prio
  · exact CompactLevel12P0136.complete _ (by simp [CompactLevel12P0136.p]) S hS dom prio
  · exact CompactLevel12P0137.complete _ (by simp [CompactLevel12P0137.p]) S hS dom prio
end CompactLevel12
#print axioms CompactLevel12.all_parents
