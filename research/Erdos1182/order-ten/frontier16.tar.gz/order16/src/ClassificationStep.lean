import ProductionJoin

namespace ExtensionBitmap
open SimpleGraph BBHExtension

/-- The maximal avoiding graphs at this level have the listed isomorphism types. -/
def level {V : Type*} (G : SimpleGraph V) (k : ℕ) (codes : List ℕ) : Prop :=
  ∀ H : SimpleGraph (Fin k), Maximal (fun D => D.CliqueFree 3) H → ¬ G ⊑ Hᶜ →
      ∃ p∈codes, Nonempty (H ≃g decode k p)

/-- One verified catalogue transition advances an already complete prefix. -/
theorem next_level {V : Type*} {G : SimpleGraph V} {k : ℕ} {ps cs : List ℕ}
    (prev : level G k ps)
    (rows : selectedRows G priorityRow (ps.map (decode k)) (cs.map (decode (k+1)))) :
    level G (k+1) cs := by
  intro H maxH avoid
  obtain ⟨P,S,maxP,avoidP,dom,priority,⟨e⟩⟩ := priority_parent G H maxH avoid
  obtain ⟨b,hb,⟨iso⟩⟩ := prev P maxP avoidP
  let T := S.map iso.toEquiv.toEmbedding
  let f : H ≃g extend (decode k b) T := e.trans (renamedExtension iso S)
  rcases rows _ (List.mem_map_of_mem hb) T (Finset.mem_powerset.mpr (Finset.subset_univ T))
      (dom_image iso S dom) (priority_image iso S priority) with bad | hit | ⟨D,hD,⟨g⟩⟩
  · exact (no_defect maxH f bad).elim
  · exact (avoid (hit.trans ⟨(SimpleGraph.Embedding.complEquiv f.symm.toEmbedding).toCopy⟩)).elim
  · obtain ⟨c,hc,rfl⟩ := List.mem_map.mp hD
    exact ⟨c,hc,⟨f.trans g⟩⟩
end ExtensionBitmap
#print axioms ExtensionBitmap.next_level
