import BitPriorityRows
import FastCube
import FastIso

namespace BBHExtension
open SimpleGraph

/-- Bit masks of the old red neighborhoods, certified once per parent. -/
def masksMatch (k parent : ℕ) (masks : Array ℕ) : Bool :=
  decide (∀ i j : Fin k, (masks[i.val]?.getD 0).testBit j.val = adjacent parent i.val j.val)

/-- The new root is bit zero. If old vertex i is joined to the root,
remove its neighbors inside the connector and set its new root bit. -/
def extensionMask (masks : Array ℕ) (s : ℕ) : ℕ → ℕ
  | 0 => s <<< 1
  | i+1 =>
    let r := masks[i]?.getD 0
    if s.testBit i then ((r ^^^ (r &&& s)) <<< 1) ||| 1 else r <<< 1

theorem extensionMask_iff {k p : ℕ} {masks : Array ℕ} (good : masksMatch k p masks = true)
    (s : ℕ) (i j : Fin (k+1)) :
    (extensionMask masks s i.val).testBit j.val = true ↔
      (extend (decode k p) (subset k s)).Adj i j := by
  have rows := of_decide_eq_true good
  rw [←extendBit_iff]
  revert j
  refine Fin.cases ?_ (fun x => ?_) i
  · intro j
    refine Fin.cases ?_ (fun y => ?_) j
    · simp [extensionMask,extendBit]
    · simp [extensionMask,extendBit,Nat.testBit_shiftLeft]
  · intro j
    refine Fin.cases ?_ (fun y => ?_) j
    · cases h : s.testBit x.val <;> simp [extensionMask,extendBit,h]
    · have r := rows x y
      cases hx : s.testBit x.val <;> cases hy : s.testBit y.val <;>
        cases a : adjacent p x.val y.val <;>
        simp [extensionMask,extendBit,Nat.testBit_shiftLeft,Nat.testBit_one_eq_true_iff_self_eq_zero,
          hx,hy,r,a]

/-- A zero mask intersection rules out a common bit at any index. -/
private theorem masks_apart {a b : ℕ} (h : a &&& b = 0) {i : ℕ}
    (ha : a.testBit i = true) (hb : b.testBit i = true) : False := by
  have bit := congrArg (fun w : ℕ => w.testBit i) h
  simp [Nat.testBit_and,ha,hb] at bit

def fastUndominated (k : ℕ) (masks : Array ℕ) (s u : ℕ) : Bool :=
  decide (u < k) && !s.testBit u && ((masks[u]?.getD 0 &&& s) == 0)

theorem fastUndominated_sound {k p s u : ℕ} {masks : Array ℕ} (rows : masksMatch k p masks = true)
    (run : fastUndominated k masks s u = true)
    (dom : ∀ y, y ∉ subset k s → ∃ x ∈ subset k s, (decode k p).Adj x y) : False := by
  have bits := of_decide_eq_true rows
  obtain ⟨⟨lt,off⟩,zero⟩ := show (u < k ∧ s.testBit u = false) ∧ masks[u]?.getD 0 &&& s = 0 by
    simpa [fastUndominated] using run
  let v : Fin k := ⟨u,lt⟩
  obtain ⟨x,inside,edge⟩ := dom v (by simp [v,subset,off])
  have rowbit := (bits v x).trans (show adjacent p v.val x.val = true from edge.symm)
  exact masks_apart zero rowbit (by simpa [subset] using inside)

def fastGap (k : ℕ) (masks : Array ℕ) (s u v : ℕ) : Bool :=
  let a := extensionMask masks s u
  let b := extensionMask masks s v
  decide (u ≤ k) && decide (v ≤ k) && (u != v) && !a.testBit v && ((a &&& b) == 0)

theorem fastGap_sound {k p s u v : ℕ} {masks : Array ℕ} (rows : masksMatch k p masks = true)
    (run : fastGap k masks s u v = true) : defect (extend (decode k p) (subset k s)) := by
  obtain ⟨⟨⟨⟨hu,hv⟩,ne⟩,off⟩,zero⟩ := show
      (((u ≤ k ∧ v ≤ k) ∧ u ≠ v) ∧ (extensionMask masks s u).testBit v = false) ∧
        extensionMask masks s u &&& extensionMask masks s v = 0 by simpa [fastGap] using run
  let i : Fin (k+1) := ⟨u,Nat.lt_succ_of_le hu⟩
  let j : Fin (k+1) := ⟨v,Nat.lt_succ_of_le hv⟩
  refine ⟨i,j,fun eq => ne (congrArg Fin.val eq),?_,?_⟩
  · intro red
    have h := (extensionMask_iff rows s i j).mpr red
    change (extensionMask masks s u).testBit v = true at h
    simp [off] at h
  · rintro w ⟨iw,jw⟩
    exact masks_apart zero ((extensionMask_iff rows s i w).mpr iw)
      ((extensionMask_iff rows s j w).mpr jw)

def fastBlue (n k t p s code : ℕ) : Bool :=
  let f := fun i : Fin n => vertex k code i.val
  decide ((∀ i j, f i = f j → i = j) ∧ ∀ i j, (decode n t).Adj i j →
    f i ≠ f j ∧ extendBit p s (f i).val (f j).val = false)

theorem fastBlue_sound {n k t p s code : ℕ} (run : fastBlue n k t p s code = true) :
    decode n t ⊑ (extend (decode k p) (subset k s))ᶜ := by
  obtain ⟨inj,edges⟩ := of_decide_eq_true run
  let f : decode n t →g (extend (decode k p) (subset k s))ᶜ :=
    { toFun := fun i => vertex k code i.val
      map_rel' := fun {i j} ij => ⟨(edges i j ij).1, fun red => by
        have h := (extendBit_iff p s _ _).mpr red
        rw [(edges i j ij).2] at h
        contradiction⟩ }
  exact ⟨f.toCopy inj⟩

/-- Map direction for `permutes` is canonical child to extension.
Non-domination and defect witnesses use only cached-row mask operations. -/
def fastWitness (n k target parent : ℕ) (children : List ℕ) (masks : Array ℕ)
    (s : ℕ) : Witness → Bool
  | .undominated u => fastUndominated k masks s u
  | .gap u v => fastGap k masks s u v
  | .embeds code => fastBlue n k target parent s code
  | .permutes child code => decide (child ∈ children) && fastIso k parent s child code

theorem fastWitness_sound {n k t p s : ℕ} {cs : List ℕ} {masks : Array ℕ}
    (rows : masksMatch k p masks = true) (tag : Witness)
    (run : fastWitness n k t p cs masks s tag = true)
    (dom : ∀ y, y ∉ subset k s → ∃ x ∈ subset k s, (decode k p).Adj x y) :
    let H := extend (decode k p) (subset k s)
    defect H ∨ decode n t ⊑ Hᶜ ∨ ∃ b ∈ cs, Nonempty (H ≃g decode (k+1) b) := by
  cases tag with
  | undominated u => exact (fastUndominated_sound rows run dom).elim
  | gap u v => exact Or.inl (fastGap_sound rows run)
  | embeds code => exact Or.inr (Or.inl (fastBlue_sound run))
  | permutes child code =>
    obtain ⟨mem,valid⟩ := Bool.and_eq_true_iff.mp run
    exact Or.inr (Or.inr ⟨child,of_decide_eq_true mem,fastIso_sound valid⟩)

theorem fast_selected_rows {n k t : ℕ} (parents children : List ℕ) (masks : ℕ → Array ℕ)
    (supply : ℕ → ℕ → Witness) (rows : ∀ p∈parents, masksMatch k p (masks p) = true)
    (free : ∀ p∈parents, (decode k p).CliqueFree 3)
    (tests : ∀ p∈parents, ∀ s : Fin (2^k), checkPriority k p s = true →
      fastWitness n k t p children (masks p) s (supply p s) = true) :
    selectedRows (decode n t) priorityRow (parents.map (decode k)) (children.map (decode (k+1))) := by
  intro P hP S _ dom row
  obtain ⟨p,hp,rfl⟩ := List.mem_map.mp hP
  obtain ⟨s,hs,rfl⟩ := subset_surj S
  have pass := tests p hp ⟨s,hs⟩ (priority_accepted (free p hp) row)
  rcases fastWitness_sound (rows p hp) (supply p s) pass dom with bad|hit|⟨b,hb,iso⟩
  · exact Or.inl bad
  · exact Or.inr (Or.inl hit)
  · exact Or.inr (Or.inr ⟨_,List.mem_map_of_mem hb,iso⟩)

/-- Numeric inclusion/exclusion of a row in a fixed, independently verified
blue cube. The large blue embedding check can be shared by every row in the cube. -/
def fitsBlueCube (s l u : ℕ) : Bool := ((l &&& s) == l) && ((u &&& s) == 0)

theorem fitsBlueCube_sound {n k t p s l u code : ℕ}
    (mapOK : fastCube n k t p l u code = true) (fits : fitsBlueCube s l u = true) :
    decode n t ⊑ (extend (decode k p) (subset k s))ᶜ := by
  obtain ⟨pos,neg⟩ : l &&& s = l ∧ u &&& s = 0 := by simpa [fitsBlueCube] using fits
  apply cube_covers (fastCube_sound mapOK)
  · intro x hx
    simp only [subset,Finset.mem_filter,Finset.mem_univ,true_and] at hx ⊢
    have h := congrArg (fun w : ℕ => w.testBit x.val) pos
    simpa [Nat.testBit_and,hx] using h
  · apply Finset.disjoint_left.mpr
    intro x hx hu
    simp only [subset,Finset.mem_filter,Finset.mem_univ,true_and] at hx hu
    exact masks_apart neg hu hx

/-- In the priority-row proof, a cube may supply a blue embedding instead of
an individual row witness. The cube itself can be checked once beforehand. -/
theorem fast_selected_rows_or_cubes {n k t : ℕ} (parents children : List ℕ)
    (masks : ℕ → Array ℕ) (supply : ℕ → ℕ → Witness)
    (rows : ∀ p∈parents, masksMatch k p (masks p) = true)
    (free : ∀ p∈parents, (decode k p).CliqueFree 3)
    (tests : ∀ p∈parents, ∀ s : Fin (2^k), checkPriority k p s = true →
      fastWitness n k t p children (masks p) s (supply p s) = true ∨
        ∃ l u c, fastCube n k t p l u c = true ∧ fitsBlueCube s l u = true) :
    selectedRows (decode n t) priorityRow (parents.map (decode k)) (children.map (decode (k+1))) := by
  intro P hP S _ dom row
  obtain ⟨p,hp,rfl⟩ := List.mem_map.mp hP
  obtain ⟨s,hs,rfl⟩ := subset_surj S
  rcases tests p hp ⟨s,hs⟩ (priority_accepted (free p hp) row) with pass | ⟨_,_,_,mapOK,fits⟩
  · rcases fastWitness_sound (rows p hp) (supply p s) pass dom with bad|hit|⟨b,hb,iso⟩
    · exact Or.inl bad
    · exact Or.inr (Or.inl hit)
    · exact Or.inr (Or.inr ⟨_,List.mem_map_of_mem hb,iso⟩)
  · exact Or.inr (Or.inl (fitsBlueCube_sound mapOK fits))

end BBHExtension

#print axioms BBHExtension.fast_selected_rows

#print axioms BBHExtension.fast_selected_rows_or_cubes
