import Records

/-! Partial assignments of the new vertex's neighborhood certify many extensions at once. -/
namespace BBHExtension
open SimpleGraph

/-- An upper bound for all red extension graphs in which the new neighborhood contains L
and avoids U. Old edges internal to L disappear, and new red edges may only meet Uᶜ. -/
def envelope {k : ℕ} (P : SimpleGraph (Fin k)) (L U : Finset (Fin k)) :=
  extend P L ⊔ extend (⊥ : SimpleGraph (Fin k)) Uᶜ

theorem le_envelope {k : ℕ} (P : SimpleGraph (Fin k)) {L U S : Finset (Fin k)}
    (pos : L ⊆ S) (neg : Disjoint S U) : extend P S ≤ envelope P L U := by
  intro a b h
  change (extend P L).Adj a b ∨ (extend (⊥ : SimpleGraph (Fin k)) Uᶜ).Adj a b
  revert b
  refine Fin.cases ?_ (fun i => ?_) a
  · intro b
    refine Fin.cases ?_ (fun j => ?_) b
    · intro h
      exact (h.ne rfl).elim
    · intro h
      exact Or.inr ((extend_left _ _ j).mpr (Finset.mem_compl.mpr
        (Finset.disjoint_left.mp neg ((extend_left _ _ j).mp h))))
  · intro b
    refine Fin.cases ?_ (fun j => ?_) b
    · intro h
      exact Or.inr (((extend_left _ _ i).mpr (Finset.mem_compl.mpr
        (Finset.disjoint_left.mp neg ((extend_left _ _ i).mp h.symm)))).symm)
    · intro h
      obtain ⟨edge,excl⟩ := (extend_old _ _ i j).mp h
      exact Or.inl ((extend_old _ _ i j).mpr ⟨edge,fun h => excl ⟨pos h.1,pos h.2⟩⟩)

theorem cube_covers {V : Type*} {k : ℕ} {G : SimpleGraph V} {P : SimpleGraph (Fin k)}
    {L U S : Finset (Fin k)} (hit : G ⊑ (envelope P L U)ᶜ)
    (pos : L ⊆ S) (neg : Disjoint S U) : G ⊑ (extend P S)ᶜ :=
  hit.mono_right (compl_le_compl (le_envelope P pos neg))

def checkCube (n k target parent require forbid code : ℕ) : Bool :=
  let P := decode k parent
  let f := fun x : Fin n => vertex k code x.val
  decide ((∀ x y, f x = f y → x=y) ∧ ∀ x y, (decode n target).Adj x y →
    f x ≠ f y ∧ ¬((extend P (subset k require)).Adj (f x) (f y) ∨
             (extend (⊥ : SimpleGraph (Fin k)) (subset k forbid)ᶜ).Adj (f x) (f y)))

theorem checked_cube {n k target parent require forbid code : ℕ}
    (pass : checkCube n k target parent require forbid code = true) :
    decode n target ⊑ (envelope (decode k parent) (subset k require) (subset k forbid))ᶜ := by
  obtain ⟨inj,adj⟩ := of_decide_eq_true pass
  let f : decode n target →g (envelope (decode k parent) (subset k require) (subset k forbid))ᶜ :=
    { toFun := fun x => vertex k code x.val, map_rel' := fun q => adj _ _ q }
  exact ⟨f.toCopy inj⟩

end BBHExtension
