import Atlas

namespace BBHExtension
open SimpleGraph

theorem defect_back {A B : Type*} {P : SimpleGraph A} {Q : SimpleGraph B}
    (e : P ≃g Q) (h : defect Q) : defect P := by
  obtain ⟨u,v,ne,miss,all⟩ := h
  refine ⟨e.symm u,e.symm v,e.symm.injective.ne ne,
    fun edge => miss (e.symm.map_rel_iff.mp edge),fun w ⟨uw,vw⟩ => all (e w) ?_⟩
  exact ⟨by simpa using e.map_rel_iff.mpr uw,by simpa using e.map_rel_iff.mpr vw⟩

theorem certified_orbits {V : Type*} (G : SimpleGraph V) {k : ℕ}
    (parents : List (SimpleGraph (Fin k))) (children : List (SimpleGraph (Fin (k+1))))
    (reps : SimpleGraph (Fin k) → List (Finset (Fin k)))
    (orbit : ∀ P∈parents, ∀ S : Finset (Fin k),
      (∀ y, y∉S → ∃ x∈S,P.Adj x y) → ∃ e : P ≃g P,S.map e.toEquiv.toEmbedding ∈ reps P)
    (checked : ∀ P∈parents, ∀ T∈reps P, defect (extend P T) ∨
      G ⊑ (extend P T)ᶜ ∨ ∃ D∈children, Nonempty (extend P T ≃g D)) :
    certifiedRows G parents children := by
  intro P hP S _ dom
  obtain ⟨e,ht⟩ := orbit P hP S dom
  let j := renamedExtension e S
  rcases checked P hP _ ht with bad|hit|⟨D,hD,⟨iso⟩⟩
  · exact Or.inl (defect_back j bad)
  · exact Or.inr (Or.inl (hit.trans ⟨(SimpleGraph.Embedding.complEquiv j.symm.toEmbedding).toCopy⟩))
  · exact Or.inr (Or.inr ⟨D,hD,⟨j.trans iso⟩⟩)

end BBHExtension
#print axioms BBHExtension.certified_orbits
