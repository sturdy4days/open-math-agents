import Verify5_000
import Verify5_001
import Verify5_002

namespace EarlyRamsey
open BBHExtension SimpleGraph

theorem step5 : selectedRows (decode 10 Terminal18.target) priorityRow (atlas 5) (atlas 6) := by
  apply level_step
  intro p hp
  change p ∈ words5 at hp
  simp only [words5,List.mem_cons,List.not_mem_nil,or_false] at hp
  rcases hp with rfl | rfl | rfl
  · exact Verify5_000.checked
  · exact Verify5_001.checked
  · exact Verify5_002.checked

end EarlyRamsey
