import Mathlib.Combinatorics.SimpleGraph.Clique
import Mathlib.Logic.Equiv.Fin.Basic

namespace BBHExtension
open SimpleGraph

/-- Add a vertex with neighborhood S, erasing precisely the old edges inside S. -/
def joinRel {A : Type*} (P : SimpleGraph A) (S : Finset A) :
    Option A → Option A → Prop
  | none, none => False
  | none, some i | some i, none => i ∈ S
  | some i, some j => P.Adj i j ∧ ¬(i∈S ∧ j∈S)

def joinGraph {A : Type*} (P : SimpleGraph A) (S : Finset A) : SimpleGraph (Option A) where
  Adj := joinRel P S
  symm := by
    constructor
    rintro (_|x) (_|y) h
    · exact h
    · exact h
    · exact h
    · exact ⟨h.1.symm,fun g => h.2 g.symm⟩
  loopless := by
    constructor
    rintro (_|x)
    · exact id
    · exact fun h => P.loopless.irrefl x h.1

def extend {k : ℕ} (P : SimpleGraph (Fin k)) (S : Finset (Fin k)) :
    SimpleGraph (Fin (k+1)) := (joinGraph P S).comap (finSuccEquiv k)

theorem extend_left {k} (P : SimpleGraph (Fin k)) (S) (i : Fin k) :
    (extend P S).Adj 0 i.succ ↔ i∈S := by
  simp only [extend,comap_adj,finSuccEquiv_zero,finSuccEquiv_succ]; rfl

theorem extend_old {k} (P : SimpleGraph (Fin k)) (S) (i j : Fin k) :
    (extend P S).Adj i.succ j.succ ↔ P.Adj i j ∧ ¬(i∈S ∧ j∈S) := by
  simp only [extend,comap_adj,finSuccEquiv_succ]; rfl

theorem saturation_witness {A : Type*} [DecidableEq A] {P : SimpleGraph A}
    (hm : Maximal (fun D : SimpleGraph A => D.CliqueFree 3) P)
    {i j : A} (ne : i≠j) (no : ¬P.Adj i j) : ∃ z, P.Adj i z ∧ P.Adj j z := by
  obtain ⟨s,hx,hy,ci,cj⟩ := exists_of_maximal_cliqueFree_not_adj (n:=2) hm ne no
  have hcard := ci.card_eq
  rw [Finset.card_insert_of_notMem hx] at hcard
  have one : s.card=1 := by omega
  obtain ⟨z,rfl⟩ := Finset.card_eq_one.mp one
  have iz : i≠z := by simpa using hx
  have jz : j≠z := by simpa using hy
  exact ⟨z, ci.1 (Finset.mem_insert_self ..) (Finset.mem_insert_of_mem (Finset.mem_singleton_self _)) iz,
    cj.1 (Finset.mem_insert_self ..) (Finset.mem_insert_of_mem (Finset.mem_singleton_self _)) jz⟩

/-- The saturated deletion of the first vertex still avoids the complementary target.
Only its edges internal to the deleted vertex's neighborhood can differ from the induced graph. -/
theorem parent {k : ℕ} {V : Type*} (G : SimpleGraph V) (H : SimpleGraph (Fin (k+1)))
    (hm : Maximal (fun D : SimpleGraph (Fin (k+1)) => D.CliqueFree 3) H)
    (avoid : ¬ G ⊑ Hᶜ) :
    ∃ (P : SimpleGraph (Fin k)) (S : Finset (Fin k)),
      Maximal (fun D : SimpleGraph (Fin k) => D.CliqueFree 3) P ∧
      (¬ G ⊑ Pᶜ) ∧ (∀ j, j∉S → ∃ i∈S,P.Adj i j) ∧ H=extend P S := by
  classical
  let B := H.comap Fin.succ
  let f : Fin k ↪ Fin (k+1) := ⟨Fin.succ,Fin.succ_injective _⟩
  have sub : B ↪g H := SimpleGraph.Embedding.comap f H
  have ht : B.CliqueFree 3 := hm.1.comap ⟨sub.toCopy⟩
  let fam : Set (SimpleGraph (Fin k)) := {D | D.CliqueFree 3}
  obtain ⟨P,hBP,hmP⟩ := fam.toFinite.exists_le_maximal (show B∈fam from ht)
  let S := Finset.univ.filter (fun i : Fin k => H.Adj 0 i.succ)
  have mem (i : Fin k) : i∈S ↔ H.Adj 0 i.succ := by simp [S]
  refine ⟨P,S,hmP,fun e => avoid ((e.mono_right (compl_le_compl hBP)).trans
    ⟨(SimpleGraph.Embedding.complEquiv sub).toCopy⟩),?_,?_⟩
  · intro j notin
    have hne : (0 : Fin (k+1)) ≠ j.succ := Fin.ne_of_lt (Fin.succ_pos _)
    obtain ⟨z,zero,jz⟩ := saturation_witness hm hne (fun hj => notin ((mem j).mpr hj))
    refine Fin.cases ?_ (fun i z0 ji => ?_) z zero jz
    · exact fun h => (h.ne rfl).elim
    · exact ⟨i,(mem i).mpr z0, hBP (show B.Adj i j from ji.symm)⟩
  · ext x y
    revert y
    refine Fin.cases ?_ (fun i => ?_) x
    · intro y
      refine Fin.cases ?_ (fun j => ?_) y
      · simp
      · exact (mem j).symm.trans (extend_left P S j).symm
    · intro y
      refine Fin.cases ?_ (fun j => ?_) y
      · rw [H.adj_comm, (extend P S).adj_comm, extend_left, mem]
      · rw [extend_old]
        constructor
        · intro e
          exact ⟨hBP (show B.Adj i j from e), fun ⟨hi,hj⟩ =>
            (H.isIndepSet_neighborSet_of_triangleFree hm.1 0
              ((mem i).mp hi) ((mem j).mp hj) e.ne) e⟩
        · rintro ⟨e,ns⟩
          by_contra no
          obtain ⟨z,iz,jz⟩ := saturation_witness hm (fun h => e.ne (Fin.succ_injective _ h)) no
          refine Fin.cases ?_ (fun l il jl => ?_) z iz jz
          · exact fun h h' => ns ⟨(mem i).mpr h.symm,(mem j).mpr h'.symm⟩
          · exact P.isIndepSet_neighborSet_of_triangleFree hmP.1 l
              (hBP (show B.Adj l i from il.symm)) (hBP (show B.Adj l j from jl.symm)) e.ne e
end BBHExtension
#print axioms BBHExtension.parent
