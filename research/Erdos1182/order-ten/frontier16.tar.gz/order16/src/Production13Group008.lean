import Production13P0096
import Production13P0097
import Production13P0098
import Production13P0099
import Production13P0100
import Production13P0101
import Production13P0102
import Production13P0103
import Production13P0104
import Production13P0105
import Production13P0106
import Production13P0107
namespace Production13
open BBHExtension SimpleGraph
theorem Production13Group008 : selectedRows (decode 10 target) priorityRow (group008.map (decode 13)) (children.map (decode 14)) := by
  intro P mem S hS dom row
  simp only [group008,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact Production13P0096.complete _ (by simp [Production13P0096.p]) S hS dom row
  · exact Production13P0097.complete _ (by simp [Production13P0097.p]) S hS dom row
  · exact Production13P0098.complete _ (by simp [Production13P0098.p]) S hS dom row
  · exact Production13P0099.complete _ (by simp [Production13P0099.p]) S hS dom row
  · exact Production13P0100.complete _ (by simp [Production13P0100.p]) S hS dom row
  · exact Production13P0101.complete _ (by simp [Production13P0101.p]) S hS dom row
  · exact Production13P0102.complete _ (by simp [Production13P0102.p]) S hS dom row
  · exact Production13P0103.complete _ (by simp [Production13P0103.p]) S hS dom row
  · exact Production13P0104.complete _ (by simp [Production13P0104.p]) S hS dom row
  · exact Production13P0105.complete _ (by simp [Production13P0105.p]) S hS dom row
  · exact Production13P0106.complete _ (by simp [Production13P0106.p]) S hS dom row
  · exact Production13P0107.complete _ (by simp [Production13P0107.p]) S hS dom row
end Production13
#print axioms Production13.Production13Group008
