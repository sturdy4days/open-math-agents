"""Check the signed order-15 prefix and reproduce the grouped-source transformation."""
from pathlib import Path
import hashlib, json, tarfile

SNAPSHOT = '28fa9f0762a3d2e1e9d025fb0ef1de267547bd112147ae79d59707a50f0e61c6'
PREFIX = '254f5b3b01fddf843ec7cf1cfeb2bc6c6a72d9245dc497ce4e60f3fc1b0b75b6'
COMMIT = 'ab42a3bca3d1ad08f65c4deada552819a5e4e75b'
ALLOWED = {'propext','Classical.choice','Quot.sound'}

def require(test, what):
    if not test:
        raise ValueError(what)

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def sha(p):
    with p.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()

def imports(raw):
    return [n for line in raw.decode().splitlines() if line.startswith('import ') for n in line.split()[1:]]

def read_sources(path, expected, fields):
    require(sha(path) == expected, f'Archive fingerprint {path}')
    sources = {}; manifest = None
    with tarfile.open(path,'r|gz') as bundle:
        for member in bundle:
            parts=Path(member.name).parts
            if len(parts)==3 and parts[1]=='src' and parts[2].endswith('.lean'):
                name=parts[2][:-5]
                require(name not in sources, f'Duplicate module {name}')
                sources[name]=bundle.extractfile(member).read()
            elif len(parts)==2 and parts[1]=='manifest.json':
                require(manifest is None, 'Duplicate manifest')
                manifest=json.load(bundle.extractfile(member))
    meta={r['module']:r for r in manifest['modules']}
    require(len(meta)==len(manifest['modules']) and set(meta)==set(sources), 'Incomplete source archive')
    for name, raw in sources.items():
        require(digest(raw)==meta[name][fields], name+' source hash')
    return meta,sources

def joined(group, inputs):
    names = imports(group)
    require(set(names)==set(inputs) and len(names)==len(inputs), 'Group member order')
    bodies=[]; data=set()
    for name in names:
        lines=inputs[name].decode().splitlines()
        deps=imports(inputs[name]); require(len(deps)==1 and deps[0].endswith('Data'),name+' imports')
        data.update(deps)
        require(sum(l.startswith('#print axioms ') and l.endswith('.'+name+'.complete') for l in lines)==1,name+' absent audit')
        bodies.append('\n'.join(l for l in lines if not l.startswith('import ')))
    require(len(data)==1,'Inconsistent group data')
    bodies.append('\n'.join(l for l in group.decode().splitlines() if not l.startswith('import ')))
    return ('import '+next(iter(data))+'\n'+'\n'.join(bodies)+'\n').encode()

def milestone(n):
    return (f'import Reached{n-1}\nimport Production{n-1}\nimport ClassificationStep\n\n'
            'set_option maxRecDepth 30000\nset_option maxHeartbeats 8000000\nnamespace FiniteTen\n'
            'open SimpleGraph BBHExtension ExtensionBitmap\n'
            f'theorem complete{n} : level (decode 10 Terminal18.target) {n} Production{n-1}.children :=\n'
            f'  next_level (ps := Production{n-1}.parents) complete{n-1} Production{n-1}.all_parents\n'
            f'end FiniteTen\n#print axioms FiniteTen.complete{n}\n').encode()

def provenance(name, raw, prior, snapshot, group):
    if name in prior:
        require(raw==prior[name],name+' signed order-15 source')
    elif group:
        original=snapshot[name]
        require(group['group']==name and digest(original)==group['original'],name+' ungrouped source')
        refs={p:snapshot[p] for p in imports(original)}
        require({p:digest(v) for p,v in refs.items()}==group['parents'],name+' component hashes')
        require(raw==joined(original,refs) and digest(raw)==group['source'],name+' grouping output')
    elif name in snapshot:
        require(raw==snapshot[name],name+' snapshot source')
    else:
        require(name in {'Reached16','Reached17','Reached18'} and raw==milestone(int(name[-2:])),name+' new endpoint')

def audit(raw, log):
    lines=log.decode().splitlines()
    require(not any('warning:' in l or 'error:' in l for l in lines),'Kernel diagnostics')
    names=[l.split()[2] for l in raw.decode().splitlines() if l.startswith('#print axioms ')]
    found=[]
    for name in names:
        prefix="'"+name+"' depends on axioms: ["
        matches=[line for line in lines if line.startswith(prefix) and line.endswith(']')]
        require(len(matches)==1,name+' audit missing or duplicated')
        actual=matches[0][len(prefix):-1]
        require(not actual or set(actual.split(', '))<=ALLOWED,name+' unsupported axiom')
        found.extend(matches)
    return names,found

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('snapshot',type=Path);p.add_argument('signed_prefix',type=Path)
    args=p.parse_args(); root=Path(__file__).resolve().parent
    prior,psrc=read_sources(args.signed_prefix,PREFIX,'source'); _,snap=read_sources(args.snapshot,SNAPSHOT,'sha256')
    groups=json.loads((root/'groups.json').read_text()); rows=json.loads((root/'manifest.json').read_text())['modules']
    for r in rows:
        n=r['module']; b=(root/'src'/(n+'.lean')).read_bytes()
        require(digest(b)==r['source'],n+' manifest'); provenance(n,b,psrc,snap,groups.get(n))
        if n in prior: require(r['object']==prior[n]['object'],n+' prior object')
    certificates=json.loads((root/'kernel-receipts.json').read_text())
    objects={r['module']:r['object'] for r in rows}
    require(set(groups)<=set(objects) and set(certificates)<=set(objects),'Unmatched evidence')
    for r in rows:
        name=r['module']; want={i:objects[i] for i in r['imports']}
        if name in certificates:
            block=certificates[name]; rec=block['receipt']
            require(rec['inputs']=={'source':r['source'],'imports':want} and rec['output']==r['object'] and rec['module']==name,name+' archived receipt')
            source=(root/'src'/(name+'.lean')).read_bytes(); names,lines=audit(source,('\n'.join(block['audits'])+'\n').encode())
            require(names==r['audit'] and lines==block['audits'],name+' archived axiom checks')
        else:
            require(name in prior and prior[name]==r,name+' unreceipted source or object absent from signed prefix')
    print('Verified',len(rows),'source provenances,',len(certificates),'kernel receipts and',len(groups),'group reconstructions')
