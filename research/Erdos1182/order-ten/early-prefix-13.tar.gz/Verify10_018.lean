import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify10_018
private def masks : Array ℕ := #[130, 769, 896, 896, 896, 896, 896, 125, 126, 126]
private def tags : Array Witness := #[.undominated 0, .undominated 2, .undominated 3, .undominated 4, .undominated 5, .undominated 6, .permutes 4441923353837569 11575941018029121, .permutes 4441923622273025 362021926341697, .gap 1 9, .undominated 1, .undominated 8, .permutes 4485800215445504 9369015022652417, .gap 1 3, .gap 1 4, .gap 1 5, .gap 1 6, .gap 1 7, .gap 2 8, .undominated 9, .undominated 7, .gap 1 10, .permutes 8672534329294867 10425816387258369, .permutes 8672534329294867 10425816386242561, .permutes 4440897366261824 9368942977194146, .permutes 8672534329294867 10425816352720897, .permutes 4440897366261824 9368944050935938, .permutes 4440897366261824 9368944084490338, .permutes 4440897366261824 11540791002566753, .permutes 8672534329294867 10425815279011841, .permutes 4440897366261824 9368945124676738, .permutes 4440897366261824 9368945158231138, .permutes 4440897366261824 11540790969045089, .permutes 4440897366261824 9368945191784546, .permutes 4440897366261824 11540790935491681, .permutes 4440897366261824 11540790901937281, .permutes 8672534329294867 360851478644002, .permutes 8672534329294867 10425780919306241, .permutes 4440897366261824 9368946198385794, .permutes 4440897366261824 9368946231940194, .permutes 4440897366261824 11540789895336033, .permutes 4440897366261824 9368946265493602, .permutes 4440897366261824 11540789861782625, .permutes 4440897366261824 11540789828228225, .permutes 8672534329294867 360885838349602, .permutes 4440897366261824 9368946299015266, .permutes 4440897366261824 11540788788041825, .permutes 4440897366261824 11540788754487425, .permutes 8672534329294867 360886912058658, .permutes 4440897366261824 11540787680745633, .permutes 8672534329294867 360886945580322, .permutes 8672534329294867 360886946596130, .gap 8 9, .permutes 8672534329294867 11550616782473217, .permutes 8672534329294867 11550616781457409, .permutes 4440897366261824 9334858116733090, .permutes 8672534329294867 11550616747935745, .permutes 4440897366261824 9334859190474882, .permutes 4440897366261824 9334859224029282, .permutes 4440897366261824 10414925455462497, .permutes 8672534329294867 11550615674226689, .permutes 4440897366261824 9334860264215682, .permutes 4440897366261824 9334860297770082, .permutes 4440897366261824 10414925421940833, .permutes 4440897366261824 9334860331323490, .permutes 4440897366261824 10414925388387425, .permutes 4440897366261824 10414925354833025, .permutes 8672534329294867 325667106555202, .permutes 8672534329294867 11550581314521089, .permutes 4440897366261824 9334861337924738, .permutes 4440897366261824 9334861371479138, .permutes 4440897366261824 10414924348231777, .permutes 4440897366261824 9334861405032546, .permutes 4440897366261824 10414924314678369, .permutes 4440897366261824 10414924281123969, .permutes 8672534329294867 325701466260802, .permutes 4440897366261824 9334861438554210, .permutes 4440897366261824 10414923240937569, .permutes 4440897366261824 10414923207383169, .permutes 8672534329294867 325702539969858, .permutes 4440897366261824 10414922133641377, .permutes 8672534329294867 325702573491522, .permutes 8672534329294867 325702574507330, .gap 8 10, .permutes 8954302171217920 11584456899072097, .gap 2 3, .gap 2 4, .gap 2 5, .gap 2 6, .gap 2 7, .permutes 8954353171824641 11584462233144385, .embeds 71576909587719]
private def supply := witnessAt tags 0xb432a0c183460d1a3068c183860e1c3070c183460d1a3068c183c60f1e3078c183460d1a3068c183860e1c3070c183460d1a3068c1840610203080c183460d1a3068c183860e1c3070c183460d1a3068c183c60f1e3078c183460d1a3068c183860e1c3070c183460d1a3068c18206592222a00a822a80aa22a00a822b00ac22a00a822a80aa22a00a822b80ae22a00a822a80aa22a00a822b00ac22a00a822a80aa22a00a822c00b022a00a822a80aa22a00a822b00ac22a00a822a80aa22a00a822b80ae22a00a822a80aa22a00a822b00ac22a00a822a80aa22a00a84e980103088c183460d1a3068c183860e1c3070c183460d1a3068c183c60f1e3078c183460d1a3068c183860e1c3070c183460d1a3068c1840610203080c183460d1a3068c183860e1c3070c183460d1a3068c183c60f1e3078c183460d1a3068c183860e1c3070c183460d1a3068c185050a10529001052880105280010527801052700105268010526001052580105250010524801052400105238010523001052280105220010521801052100105208010520001051f801051f001051e801051e001051d801051d001051c801051c001051b801051b001051a801051a00104c500283088c183460d1a3068c183860e1c3070c183460d1a3068c183c60f1e3078c183460d1a3068c183860e1c3070c183460d1a3068c1840610203080c183460d1a3068c183860e1c3070c183460d1a3068c183c60f1e3078c183460d1a3068c183860e1c3070c183460d1a3068c1820912282198028219002821880282180028217802821700282168028216002821580282150028214802821400282138028213002821280282120028211802821100282108028210002820f802820f002820e802820e002820d802820d002820c802820c002820b802820b002820a80284c900103088918346091a3068918386091c3070918346091a30689183c6091e3078918346091a3068918386091c3070918346091a306891840609203080918346091a3068918386091c3070918346091a30689183c6091e3078918346091a3068918386091c3070918346091a30689182c509101c300020408004081000204080060c1800204080040810002040800810200020408004081000204080060c1800204080040810002040800a14280020408004081000204080060c1800204080040810002040800810200020408004081000204080060c180020408004081000204080 7
private def pass (s : ℕ) := fastWitness 10 10 Terminal18.target 8692739080193 words11 masks s (supply s)

private theorem run5 : span pass 0 32 = true := by decide +kernel
private theorem run6 : span pass 32 32 = true := by decide +kernel
private theorem run4 : span pass 0 64 = true := span_add (a:=32) (b:=32) run5 run6
private theorem run8 : span pass 64 32 = true := by decide +kernel
private theorem run9 : span pass 96 32 = true := by decide +kernel
private theorem run7 : span pass 64 64 = true := span_add (a:=32) (b:=32) run8 run9
private theorem run3 : span pass 0 128 = true := span_add (a:=64) (b:=64) run4 run7
private theorem run12 : span pass 128 32 = true := by decide +kernel
private theorem run13 : span pass 160 32 = true := by decide +kernel
private theorem run11 : span pass 128 64 = true := span_add (a:=32) (b:=32) run12 run13
private theorem run15 : span pass 192 32 = true := by decide +kernel
private theorem run16 : span pass 224 32 = true := by decide +kernel
private theorem run14 : span pass 192 64 = true := span_add (a:=32) (b:=32) run15 run16
private theorem run10 : span pass 128 128 = true := span_add (a:=64) (b:=64) run11 run14
private theorem run2 : span pass 0 256 = true := span_add (a:=128) (b:=128) run3 run10
private theorem run20 : span pass 256 32 = true := by decide +kernel
private theorem run21 : span pass 288 32 = true := by decide +kernel
private theorem run19 : span pass 256 64 = true := span_add (a:=32) (b:=32) run20 run21
private theorem run23 : span pass 320 32 = true := by decide +kernel
private theorem run24 : span pass 352 32 = true := by decide +kernel
private theorem run22 : span pass 320 64 = true := span_add (a:=32) (b:=32) run23 run24
private theorem run18 : span pass 256 128 = true := span_add (a:=64) (b:=64) run19 run22
private theorem run27 : span pass 384 32 = true := by decide +kernel
private theorem run28 : span pass 416 32 = true := by decide +kernel
private theorem run26 : span pass 384 64 = true := span_add (a:=32) (b:=32) run27 run28
private theorem run30 : span pass 448 32 = true := by decide +kernel
private theorem run31 : span pass 480 32 = true := by decide +kernel
private theorem run29 : span pass 448 64 = true := span_add (a:=32) (b:=32) run30 run31
private theorem run25 : span pass 384 128 = true := span_add (a:=64) (b:=64) run26 run29
private theorem run17 : span pass 256 256 = true := span_add (a:=128) (b:=128) run18 run25
private theorem run1 : span pass 0 512 = true := span_add (a:=256) (b:=256) run2 run17
private theorem run36 : span pass 512 32 = true := by decide +kernel
private theorem run37 : span pass 544 32 = true := by decide +kernel
private theorem run35 : span pass 512 64 = true := span_add (a:=32) (b:=32) run36 run37
private theorem run39 : span pass 576 32 = true := by decide +kernel
private theorem run40 : span pass 608 32 = true := by decide +kernel
private theorem run38 : span pass 576 64 = true := span_add (a:=32) (b:=32) run39 run40
private theorem run34 : span pass 512 128 = true := span_add (a:=64) (b:=64) run35 run38
private theorem run43 : span pass 640 32 = true := by decide +kernel
private theorem run44 : span pass 672 32 = true := by decide +kernel
private theorem run42 : span pass 640 64 = true := span_add (a:=32) (b:=32) run43 run44
private theorem run46 : span pass 704 32 = true := by decide +kernel
private theorem run47 : span pass 736 32 = true := by decide +kernel
private theorem run45 : span pass 704 64 = true := span_add (a:=32) (b:=32) run46 run47
private theorem run41 : span pass 640 128 = true := span_add (a:=64) (b:=64) run42 run45
private theorem run33 : span pass 512 256 = true := span_add (a:=128) (b:=128) run34 run41
private theorem run51 : span pass 768 32 = true := by decide +kernel
private theorem run52 : span pass 800 32 = true := by decide +kernel
private theorem run50 : span pass 768 64 = true := span_add (a:=32) (b:=32) run51 run52
private theorem run54 : span pass 832 32 = true := by decide +kernel
private theorem run55 : span pass 864 32 = true := by decide +kernel
private theorem run53 : span pass 832 64 = true := span_add (a:=32) (b:=32) run54 run55
private theorem run49 : span pass 768 128 = true := span_add (a:=64) (b:=64) run50 run53
private theorem run58 : span pass 896 32 = true := by decide +kernel
private theorem run59 : span pass 928 32 = true := by decide +kernel
private theorem run57 : span pass 896 64 = true := span_add (a:=32) (b:=32) run58 run59
private theorem run61 : span pass 960 32 = true := by decide +kernel
private theorem run62 : span pass 992 32 = true := by decide +kernel
private theorem run60 : span pass 960 64 = true := span_add (a:=32) (b:=32) run61 run62
private theorem run56 : span pass 896 128 = true := span_add (a:=64) (b:=64) run57 run60
private theorem run48 : span pass 768 256 = true := span_add (a:=128) (b:=128) run49 run56
private theorem run32 : span pass 512 512 = true := span_add (a:=256) (b:=256) run33 run48
private theorem run0 : span pass 0 1024 = true := span_add (a:=512) (b:=512) run1 run32

theorem checked : rowStep 10 8692739080193 words11 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify10_018
end EarlyRamsey
