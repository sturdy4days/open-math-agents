import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify3_000
private def masks : Array ℕ := #[4, 4, 3]
private def tags : Array Witness := #[.undominated 0, .undominated 1, .permutes 51 65633, .permutes 56 98369, .gap 1 2, .permutes 56 3137]
private def supply := witnessAt tags 0xb23408 3
private def pass (s : ℕ) := fastWitness 10 3 Terminal18.target 6 words4 masks s (supply s)

private theorem run0 : span pass 0 8 = true := by decide +kernel

theorem checked : rowStep 3 6 words4 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify3_000
end EarlyRamsey
