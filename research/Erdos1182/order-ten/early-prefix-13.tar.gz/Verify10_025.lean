import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify10_025
private def masks : Array ℕ := #[262, 521, 641, 386, 896, 896, 896, 124, 121, 118]
private def tags : Array Witness := #[.undominated 0, .undominated 3, .undominated 2, .undominated 4, .undominated 1, .undominated 5, .undominated 6, .permutes 4300635019149345 9368946303174753, .permutes 1095009688454144 10414919991366785, .gap 1 8, .permutes 1095009688454144 11540784498283618, .gap 2 8, .permutes 2187855526953985 11575937698305089, .undominated 9, .undominated 8, .permutes 2222632524316672 9334923517336773, .gap 3 4, .gap 1 10, .gap 2 9, .permutes 3878387695222920 9368980662914050, .permutes 3878387695222920 9334930162159617, .permutes 3878387695222920 11584462232065089, .permutes 3878387695222920 9368980630408194, .permutes 3878387695222920 9334930129653761, .permutes 3878387695222920 11584462198511681, .permutes 2783812118904960 10485218937083015, .permutes 2783812118904960 11575935578084455, .permutes 3878387695222920 10485224372739203, .permutes 3878387695222920 9368979557714946, .permutes 3878387695222920 9334929056960513, .permutes 3878387695222920 11584461124770881, .permutes 2783812118904960 10485218937115782, .permutes 2783812118904960 11575935578117222, .permutes 3878387695222920 10485225446480003, .permutes 2783812118904960 10485218937116805, .permutes 2783812118904960 11575935578118245, .permutes 3878387695222920 10485225480033411, .permutes 1105884292908032 11268937764508770, .permutes 1105884292908032 10144171695477889, .permutes 2222632524316672 361880256289989, .undominated 7, .gap 1 5, .permutes 2230329106235392 10493844203379909, .gap 1 4, .permutes 1105884292908032 10425676703405057, .gap 1 6, .gap 1 7, .gap 3 9, .permutes 4440897366261824 10425638109550755, .permutes 2230329106235392 11584593025146053, .gap 2 5, .gap 2 3, .permutes 1105884292908032 11550510351062018, .gap 2 6, .gap 2 7, .gap 4 10, .permutes 4440897366261824 11550404112521380, .gap 3 5, .permutes 2222632524316672 10493844235885765, .permutes 2222632524316672 11584593090157765, .permutes 1105884292908032 9368940768859267, .permutes 8672534329294867 11584462233144385, .embeds 71576909587719]
private def supply := witnessAt tags 0xfabce9cebca9ae9ce9ae9ca9a6ba6da6ba6daeda6daeda6db6bb69b6bb69ae9b69ae9b69a6ba6ea6ba6eaeea6eaeea6ebabba9babba9ae9ba9ae9ba9a6ba6da6ba6daeda6daeda6db6bb69b6bb69ae9b69ae9b69a6ba49a6ba4bac9a49af2a7d26b269cebca9ae9269ae9ca9a6ba6da6ba6daeda6daeda6db6bb69b6bb69ae9b69ae9b69a6ba6ea6ba6eaeea6eaeea6ebabba9babba9ae9ba9ae9ba9a6ba6da6ba6daeda6daeda6db6bb69b6bb69ae9b69ae9b69a6ba7ca6ba7bad1a7aa28a28489cc9cd0c80409cc9cf9c80c89cc9cf2d40c89cc9cf2d40d49cc9cf5c80d49cc9cf5c80c89cc9cf2d80c89cc9cf2d80d89cc9cf6c80d89cc9cf6c80c89cc9cf2d40c89cc9cf2d40d49cc9cf5c80d49cc9cf5c80c89cc9cf22c0c8ecceccee00251272ccbc80251041cf7040251275cf2d40251041cf2040251272cf5c80251041cf5040251276cf2d80251041cf2040251272cf6c80251041cf6040251275cf2d40251041cf2040251272cf5c80251041cf5040251274cf2c4024e041a2804046b2e942b2e9ae9404ae9bc4a6ba6da6ba6daeda44aeda44b6bb69b6bb69ae9b44ae9b44a6ba6ea6ba6eaeea44aeea44babba9babba9ae9b84ae9b84a6ba6da6ba6daeda44aeda44b6bb69b6bb69ae9b44ae9b44a6ba49a6b34dac9a44af034426b2692c2482ae9244ac2bc4a6ba6da42a42aeda44ac2a44b6bb69b42b42ae9b44ac2b44a6ba6ea42a42aeea44ac2a44babba9b82b82ae9b84ac2b84a6ba6da42a42aeda44ac2a44b6bb69b42b42ae9b44ac2b44a6ba6ca42342aeaa44a02a044492c94902c04494049e69404492c94902c04494049238804492c94902c04494048607c04492c94902c044940479d7004492c94902c04494046da6404492c94902c04494046175804492c94902c04494045544c04492c949034044e4043ce34024b24c2c22802480441c20400c30c30c20c00c30440c20401451451421401450441420400c30c30c20c00c30440c20401861861821801860441820400c30c30c20c00c30440c20401451451421401450441420400c30c30c20c00c30440c2040 6
private def pass (s : ℕ) := fastWitness 10 10 Terminal18.target 8141638991891 words11 masks s (supply s)

private theorem run5 : span pass 0 32 = true := by decide +kernel
private theorem run6 : span pass 32 32 = true := by decide +kernel
private theorem run4 : span pass 0 64 = true := span_add (a:=32) (b:=32) run5 run6
private theorem run8 : span pass 64 32 = true := by decide +kernel
private theorem run9 : span pass 96 32 = true := by decide +kernel
private theorem run7 : span pass 64 64 = true := span_add (a:=32) (b:=32) run8 run9
private theorem run3 : span pass 0 128 = true := span_add (a:=64) (b:=64) run4 run7
private theorem run12 : span pass 128 32 = true := by decide +kernel
private theorem run13 : span pass 160 32 = true := by decide +kernel
private theorem run11 : span pass 128 64 = true := span_add (a:=32) (b:=32) run12 run13
private theorem run15 : span pass 192 32 = true := by decide +kernel
private theorem run16 : span pass 224 32 = true := by decide +kernel
private theorem run14 : span pass 192 64 = true := span_add (a:=32) (b:=32) run15 run16
private theorem run10 : span pass 128 128 = true := span_add (a:=64) (b:=64) run11 run14
private theorem run2 : span pass 0 256 = true := span_add (a:=128) (b:=128) run3 run10
private theorem run20 : span pass 256 32 = true := by decide +kernel
private theorem run21 : span pass 288 32 = true := by decide +kernel
private theorem run19 : span pass 256 64 = true := span_add (a:=32) (b:=32) run20 run21
private theorem run23 : span pass 320 32 = true := by decide +kernel
private theorem run24 : span pass 352 32 = true := by decide +kernel
private theorem run22 : span pass 320 64 = true := span_add (a:=32) (b:=32) run23 run24
private theorem run18 : span pass 256 128 = true := span_add (a:=64) (b:=64) run19 run22
private theorem run27 : span pass 384 32 = true := by decide +kernel
private theorem run28 : span pass 416 32 = true := by decide +kernel
private theorem run26 : span pass 384 64 = true := span_add (a:=32) (b:=32) run27 run28
private theorem run30 : span pass 448 32 = true := by decide +kernel
private theorem run31 : span pass 480 32 = true := by decide +kernel
private theorem run29 : span pass 448 64 = true := span_add (a:=32) (b:=32) run30 run31
private theorem run25 : span pass 384 128 = true := span_add (a:=64) (b:=64) run26 run29
private theorem run17 : span pass 256 256 = true := span_add (a:=128) (b:=128) run18 run25
private theorem run1 : span pass 0 512 = true := span_add (a:=256) (b:=256) run2 run17
private theorem run36 : span pass 512 32 = true := by decide +kernel
private theorem run37 : span pass 544 32 = true := by decide +kernel
private theorem run35 : span pass 512 64 = true := span_add (a:=32) (b:=32) run36 run37
private theorem run39 : span pass 576 32 = true := by decide +kernel
private theorem run40 : span pass 608 32 = true := by decide +kernel
private theorem run38 : span pass 576 64 = true := span_add (a:=32) (b:=32) run39 run40
private theorem run34 : span pass 512 128 = true := span_add (a:=64) (b:=64) run35 run38
private theorem run43 : span pass 640 32 = true := by decide +kernel
private theorem run44 : span pass 672 32 = true := by decide +kernel
private theorem run42 : span pass 640 64 = true := span_add (a:=32) (b:=32) run43 run44
private theorem run46 : span pass 704 32 = true := by decide +kernel
private theorem run47 : span pass 736 32 = true := by decide +kernel
private theorem run45 : span pass 704 64 = true := span_add (a:=32) (b:=32) run46 run47
private theorem run41 : span pass 640 128 = true := span_add (a:=64) (b:=64) run42 run45
private theorem run33 : span pass 512 256 = true := span_add (a:=128) (b:=128) run34 run41
private theorem run51 : span pass 768 32 = true := by decide +kernel
private theorem run52 : span pass 800 32 = true := by decide +kernel
private theorem run50 : span pass 768 64 = true := span_add (a:=32) (b:=32) run51 run52
private theorem run54 : span pass 832 32 = true := by decide +kernel
private theorem run55 : span pass 864 32 = true := by decide +kernel
private theorem run53 : span pass 832 64 = true := span_add (a:=32) (b:=32) run54 run55
private theorem run49 : span pass 768 128 = true := span_add (a:=64) (b:=64) run50 run53
private theorem run58 : span pass 896 32 = true := by decide +kernel
private theorem run59 : span pass 928 32 = true := by decide +kernel
private theorem run57 : span pass 896 64 = true := span_add (a:=32) (b:=32) run58 run59
private theorem run61 : span pass 960 32 = true := by decide +kernel
private theorem run62 : span pass 992 32 = true := by decide +kernel
private theorem run60 : span pass 960 64 = true := span_add (a:=32) (b:=32) run61 run62
private theorem run56 : span pass 896 128 = true := span_add (a:=64) (b:=64) run57 run60
private theorem run48 : span pass 768 256 = true := span_add (a:=128) (b:=128) run49 run56
private theorem run32 : span pass 512 512 = true := span_add (a:=256) (b:=256) run33 run48
private theorem run0 : span pass 0 1024 = true := span_add (a:=512) (b:=512) run1 run32

theorem checked : rowStep 10 8141638991891 words11 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify10_025
end EarlyRamsey
