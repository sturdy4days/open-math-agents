import LastData
import Mathlib.Tactic.FinCases
import CubeCoverage

namespace Terminal18
open BBHExtension CubeCoverage CubeCoverage.Tree

private def tree0 : Tree := (branch 3 (branch 5 (branch 9 (branch 6 (branch 1 (leaf 62) (branch 14 (branch 12 (leaf 64) (leaf 20)) (leaf 27))) (branch 12 (branch 14 (leaf 64) (branch 17 (branch 0 (branch 10 (branch 4 (leaf 60) (leaf 4)) (leaf 15)) (leaf 3)) (leaf 40))) (leaf 22))) (branch 16 (branch 0 (branch 7 (branch 12 (branch 4 (branch 17 (leaf 50) (branch 8 (leaf 58) (leaf 12))) (leaf 10)) (branch 6 (branch 14 (leaf 61) (branch 1 (branch 2 (branch 17 (leaf 49) (leaf 43)) (leaf 21)) (leaf 20))) (leaf 22))) (leaf 11)) (leaf 9)) (leaf 35))) (branch 7 (branch 10 (branch 2 (branch 4 (branch 0 (branch 17 (branch 16 (leaf 48) (branch 12 (leaf 60) (leaf 38))) (branch 16 (branch 13 (branch 14 (branch 6 (leaf 61) (leaf 40)) (leaf 43)) (leaf 25)) (leaf 63))) (branch 13 (branch 15 (leaf 55) (leaf 31)) (leaf 23))) (leaf 2)) (leaf 1)) (leaf 14)) (leaf 6))) (branch 4 (branch 11 (branch 13 (branch 15 (branch 10 (branch 7 (leaf 55) (branch 17 (branch 9 (branch 2 (leaf 57) (branch 12 (branch 5 (branch 8 (branch 1 (branch 6 (leaf 59) (branch 0 (leaf 60) (leaf 3))) (leaf 5)) (leaf 7)) (leaf 1)) (leaf 21))) (leaf 11)) (leaf 41))) (branch 8 (branch 1 (branch 6 (branch 5 (leaf 59) (leaf 14)) (leaf 15)) (leaf 13)) (leaf 8))) (leaf 34)) (leaf 24)) (leaf 18)) (leaf 0)))
set_option maxRecDepth 4096 in
private theorem run0 : check data0 tree0 0 0 = true := by decide +kernel

private def path1_2 : Tree := (branch 3 (branch 6 (branch 4 (branch 0 (branch 7 (branch 5 (leaf 52) (branch 9 (leaf 67) (leaf 13))) (branch 2 (branch 8 (leaf 70) (branch 1 (branch 11 (branch 10 (leaf 61) (leaf 16)) (leaf 19)) (leaf 5))) (leaf 6))) (branch 11 (branch 10 (branch 1 (leaf 61) (branch 7 (leaf 73) (leaf 5))) (leaf 14)) (leaf 17))) (branch 12 (branch 7 (branch 5 (branch 8 (branch 0 (branch 2 (leaf 71) (branch 10 (leaf 74) (leaf 15))) (branch 10 (leaf 74) (leaf 14))) (leaf 10)) (leaf 1)) (leaf 7)) (leaf 21))) (branch 1 (branch 5 (branch 12 (branch 2 (branch 11 (branch 4 (leaf 69) (branch 13 (leaf 54) (leaf 25))) (branch 13 (leaf 54) (leaf 25))) (leaf 3)) (branch 2 (branch 4 (branch 11 (branch 10 (leaf 58) (branch 0 (branch 8 (branch 17 (branch 9 (leaf 49) (leaf 22)) (leaf 41)) (leaf 16)) (leaf 14))) (branch 0 (branch 17 (branch 8 (branch 9 (leaf 49) (leaf 22)) (branch 14 (branch 7 (branch 9 (leaf 65) (leaf 22)) (leaf 19)) (leaf 27))) (leaf 41)) (leaf 17))) (leaf 21)) (leaf 3))) (leaf 4)) (leaf 2))) (branch 2 (branch 8 (branch 9 (branch 11 (branch 13 (leaf 72) (leaf 24)) (branch 0 (branch 17 (branch 5 (branch 4 (leaf 49) (branch 7 (leaf 55) (leaf 7))) (leaf 18)) (leaf 40)) (leaf 17))) (leaf 12)) (leaf 9)) (leaf 0)))
set_option maxRecDepth 4096 in
private theorem run1_2 : check data1 path1_2 0 98304 = true := by decide +kernel

private def path1_3 : Tree := (branch 5 (branch 7 (branch 3 (branch 10 (branch 12 (branch 6 (leaf 74) (branch 1 (leaf 57) (leaf 2))) (branch 14 (branch 17 (branch 0 (branch 4 (branch 6 (leaf 60) (branch 9 (leaf 66) (leaf 22))) (leaf 21)) (leaf 20)) (leaf 43)) (leaf 29))) (leaf 32)) (branch 17 (branch 13 (branch 2 (branch 8 (branch 9 (branch 14 (branch 0 (leaf 47) (branch 11 (leaf 72) (leaf 17))) (leaf 34)) (leaf 12)) (leaf 9)) (leaf 0)) (leaf 24)) (leaf 40))) (leaf 31)) (leaf 30))
set_option maxRecDepth 4096 in
private theorem run1_3 : check data1 path1_3 32768 65536 = true := by decide +kernel

private def path1_1 : Tree := branch 15 path1_2 path1_3
set_option maxRecDepth 4096 in
private theorem run1_1 : check data1 path1_1 0 65536 = true := Bool.and_eq_true_iff.mpr ⟨run1_2,run1_3⟩

private def path1_4 : Tree := (branch 14 (branch 17 (branch 4 (branch 9 (branch 10 (branch 13 (branch 11 (branch 1 (branch 2 (leaf 46) (branch 3 (leaf 61) (leaf 0))) (branch 6 (branch 7 (branch 3 (leaf 73) (branch 8 (branch 2 (leaf 72) (leaf 0)) (leaf 8))) (leaf 5)) (leaf 2))) (branch 7 (branch 5 (branch 0 (branch 3 (leaf 66) (branch 2 (leaf 65) (leaf 0))) (leaf 17)) (leaf 18)) (leaf 19))) (leaf 38)) (leaf 37)) (leaf 36)) (leaf 35)) (leaf 45)) (leaf 39))
set_option maxRecDepth 4096 in
private theorem run1_4 : check data1 path1_4 65536 0 = true := by decide +kernel

private def tree1 : Tree := branch 16 path1_1 path1_4
set_option maxRecDepth 4096 in
private theorem run1 : check data1 tree1 0 0 = true := Bool.and_eq_true_iff.mpr ⟨run1_1,run1_4⟩

theorem cover0 (S : Finset (Fin 18)) :
    ∃ row ∈ rows 0, subset 18 row.1 ⊆ S ∧ Disjoint S (subset 18 row.2.1) :=
  CubeCoverage.covers _ tree0 run0 S

theorem cover1 (S : Finset (Fin 18)) :
    ∃ row ∈ rows 1, subset 18 row.1 ⊆ S ∧ Disjoint S (subset 18 row.2.1) :=
  CubeCoverage.covers _ tree1 run1 S

end Terminal18

#print axioms Terminal18.cover0
#print axioms Terminal18.cover1
