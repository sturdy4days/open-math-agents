import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify8_006
private def masks : Array ℕ := #[34, 193, 224, 224, 224, 29, 30, 30]
private def tags : Array Witness := #[.undominated 0, .undominated 2, .undominated 3, .undominated 4, .permutes 8116958209 9036817894465, .permutes 16233924755 5638226942017, .gap 1 7, .undominated 1, .undominated 6, .permutes 8530063360 6674619436033, .gap 1 3, .gap 1 4, .gap 1 5, .gap 2 6, .undominated 7, .undominated 5, .gap 1 8, .permutes 16221241363 9043225708545, .permutes 16221241363 9043224692737, .permutes 16221241363 6605797229794, .permutes 16221241363 9043191171073, .permutes 16221241363 6605830751458, .permutes 16221241363 6605831767266, .gap 6 7, .permutes 16221241363 7978073819137, .permutes 16221241363 7978072803329, .permutes 16221241363 6604723488002, .permutes 16221241363 7978039281665, .permutes 16221241363 6604757009666, .permutes 16221241363 6604758025474, .gap 6 8, .permutes 16773514304 9043055906913, .gap 2 3, .gap 2 4, .gap 2 5, .permutes 16775020545 9043059018817, .permutes 68451041280 282600803393]
private def supply := witnessAt tags 0x90a80a28b28b2ca2ca28c28c30a30a28b28b2ca2ca2862a334680080684084680080688088680080684084680080f7c018a34a28b28b2ca2ca28c28c30a30a28b28b2ca2ca2902081907801907401907001906c019068019064019060018f20040a34a28b28b2ca2ca28c28c30a30a28b28b2ca2ca28638e4065c04065804065404065004064c040648040644040f38018a34728b2872ca2c728c28730a30728b2872ca2c72892071851000410400820800410400c30c0041040082080041040 6
private def pass (s : ℕ) := fastWitness 10 8 Terminal18.target 63927297 words9 masks s (supply s)

private theorem run3 : span pass 0 32 = true := by decide +kernel
private theorem run4 : span pass 32 32 = true := by decide +kernel
private theorem run2 : span pass 0 64 = true := span_add (a:=32) (b:=32) run3 run4
private theorem run6 : span pass 64 32 = true := by decide +kernel
private theorem run7 : span pass 96 32 = true := by decide +kernel
private theorem run5 : span pass 64 64 = true := span_add (a:=32) (b:=32) run6 run7
private theorem run1 : span pass 0 128 = true := span_add (a:=64) (b:=64) run2 run5
private theorem run10 : span pass 128 32 = true := by decide +kernel
private theorem run11 : span pass 160 32 = true := by decide +kernel
private theorem run9 : span pass 128 64 = true := span_add (a:=32) (b:=32) run10 run11
private theorem run13 : span pass 192 32 = true := by decide +kernel
private theorem run14 : span pass 224 32 = true := by decide +kernel
private theorem run12 : span pass 192 64 = true := span_add (a:=32) (b:=32) run13 run14
private theorem run8 : span pass 128 128 = true := span_add (a:=64) (b:=64) run9 run12
private theorem run0 : span pass 0 256 = true := span_add (a:=128) (b:=128) run1 run8

theorem checked : rowStep 8 63927297 words9 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify8_006
end EarlyRamsey
