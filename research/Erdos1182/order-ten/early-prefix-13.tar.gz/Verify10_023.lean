import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify10_023
private def masks : Array ℕ := #[322, 641, 584, 388, 704, 448, 53, 58, 553, 278]
private def tags : Array Witness := #[.undominated 0, .undominated 2, .undominated 4, .undominated 5, .permutes 539959685722880 9114205151205444, .permutes 548181394510336 10382965494458497, .gap 1 8, .permutes 548181394510336 11545113885058146, .permutes 539959685722880 7956419408205921, .gap 3 8, .undominated 1, .undominated 3, .undominated 7, .undominated 8, .gap 1 5, .undominated 9, .permutes 1097781918090240 8242079056532577, .gap 1 3, .gap 2 7, .gap 3 6, .permutes 1097781918090240 9331659678685314, .gap 2 4, .undominated 6, .gap 2 6, .gap 4 5, .gap 7 9, .gap 1 4, .permutes 1097769268600832 10422376114493569, .permutes 33778794198908961 5921977451809857, .gap 6 10, .permutes 2783812118904960 10381874575705222, .gap 1 6, .permutes 2783812118904960 10418124098637862, .gap 1 10, .permutes 3878387695222920 8173013732201570, .gap 2 3, .permutes 33778794198908961 7037191512525889, .permutes 1097769268600832 11514224480392290, .gap 5 9, .permutes 2783812118904960 11509972463520837, .permutes 2783812118904960 11541823944132709, .gap 2 5, .permutes 3878387695222920 9264794384275585, .gap 2 9, .permutes 7474671440114307 289383230055489, .embeds 71576909587719]
private def supply := witnessAt tags 0xb518d145a45a69169144e44e39139145a45a69169145f45f7d17d145a45a69169144e44e39139145a45a69169144646649a8da8da55a6866a36866a9a5a8da8da55a6866a36866975da8da8da55a6866a36866a9a5a8da8d65566866a36966961918d145a45a69169144e44e39139145a45a69169145f45f7d17d145a45a69169144e44e39139145a45a69130c46130c19a8da19aada6a16a36a16ac19a8da19aada6a16a36a16a619a8da19aada6a16a36a169d19a8da196ad66a130c696316ad18d144e44e5518d144e44e3913914464553913914464575d18d144e44e5518d144e44e39139144645539139144646a4868c08c65405468c08c6a40a468c08c65405468c08c65c05c68c08c65405468c08c6a40a468c08d65405468c08d6a001918d144e44e1918d12cb2cb3913914634533913912cb2cb1918d144e44e1918d12cb2cb39139146346739130c2cb2cb1898c01a39801a68c02cb2c01898c01a39401a48c02cb2c00c30c00c30c00c30c02cb2c00c30c00c30c00c30c02cb2c085155145a45a69169144e44e39139145a45a69169145f45f7d17d145a45a69169144e44e39139145a45a69169144646285a55a85a55a68669704104185a55a85a55a68669704104185a55a85a55a68669804104185a55a8565566866a004104119148a45a44a69168a44e44a39138a45a44a69168a45f44a7d17ca45a44a69168a44e44a39138a45a44a69130a45e30a19a24a19a74a69d68a04104a08208a08208a08208a04104a19a24a19a70a69b68a04104a08208a08208a08208a04104a65155144e44e5515d144e44e3913914463cf3913914463cf5d155144e44e54d48d44d44d3913914463cf38d38d44d3cd4865404865405465c00410404865404863c05465c00410405c65405c654054d6000410405c65405d63c054d50004104019148a44e44a19148a2cb2ca39138a4533ca39138a2cb2ca19148a44e44a18d48a2cb2ca39138a4503ca38d30a2cb2ca1892401881c01851000410400820800820800820800410400c30c00c30c00c30c0041040082080082080082080041040 6
private def pass (s : ℕ) := fastWitness 10 10 Terminal18.target 19115143757857 words11 masks s (supply s)

private theorem run5 : span pass 0 32 = true := by decide +kernel
private theorem run6 : span pass 32 32 = true := by decide +kernel
private theorem run4 : span pass 0 64 = true := span_add (a:=32) (b:=32) run5 run6
private theorem run8 : span pass 64 32 = true := by decide +kernel
private theorem run9 : span pass 96 32 = true := by decide +kernel
private theorem run7 : span pass 64 64 = true := span_add (a:=32) (b:=32) run8 run9
private theorem run3 : span pass 0 128 = true := span_add (a:=64) (b:=64) run4 run7
private theorem run12 : span pass 128 32 = true := by decide +kernel
private theorem run13 : span pass 160 32 = true := by decide +kernel
private theorem run11 : span pass 128 64 = true := span_add (a:=32) (b:=32) run12 run13
private theorem run15 : span pass 192 32 = true := by decide +kernel
private theorem run16 : span pass 224 32 = true := by decide +kernel
private theorem run14 : span pass 192 64 = true := span_add (a:=32) (b:=32) run15 run16
private theorem run10 : span pass 128 128 = true := span_add (a:=64) (b:=64) run11 run14
private theorem run2 : span pass 0 256 = true := span_add (a:=128) (b:=128) run3 run10
private theorem run20 : span pass 256 32 = true := by decide +kernel
private theorem run21 : span pass 288 32 = true := by decide +kernel
private theorem run19 : span pass 256 64 = true := span_add (a:=32) (b:=32) run20 run21
private theorem run23 : span pass 320 32 = true := by decide +kernel
private theorem run24 : span pass 352 32 = true := by decide +kernel
private theorem run22 : span pass 320 64 = true := span_add (a:=32) (b:=32) run23 run24
private theorem run18 : span pass 256 128 = true := span_add (a:=64) (b:=64) run19 run22
private theorem run27 : span pass 384 32 = true := by decide +kernel
private theorem run28 : span pass 416 32 = true := by decide +kernel
private theorem run26 : span pass 384 64 = true := span_add (a:=32) (b:=32) run27 run28
private theorem run30 : span pass 448 32 = true := by decide +kernel
private theorem run31 : span pass 480 32 = true := by decide +kernel
private theorem run29 : span pass 448 64 = true := span_add (a:=32) (b:=32) run30 run31
private theorem run25 : span pass 384 128 = true := span_add (a:=64) (b:=64) run26 run29
private theorem run17 : span pass 256 256 = true := span_add (a:=128) (b:=128) run18 run25
private theorem run1 : span pass 0 512 = true := span_add (a:=256) (b:=256) run2 run17
private theorem run36 : span pass 512 32 = true := by decide +kernel
private theorem run37 : span pass 544 32 = true := by decide +kernel
private theorem run35 : span pass 512 64 = true := span_add (a:=32) (b:=32) run36 run37
private theorem run39 : span pass 576 32 = true := by decide +kernel
private theorem run40 : span pass 608 32 = true := by decide +kernel
private theorem run38 : span pass 576 64 = true := span_add (a:=32) (b:=32) run39 run40
private theorem run34 : span pass 512 128 = true := span_add (a:=64) (b:=64) run35 run38
private theorem run43 : span pass 640 32 = true := by decide +kernel
private theorem run44 : span pass 672 32 = true := by decide +kernel
private theorem run42 : span pass 640 64 = true := span_add (a:=32) (b:=32) run43 run44
private theorem run46 : span pass 704 32 = true := by decide +kernel
private theorem run47 : span pass 736 32 = true := by decide +kernel
private theorem run45 : span pass 704 64 = true := span_add (a:=32) (b:=32) run46 run47
private theorem run41 : span pass 640 128 = true := span_add (a:=64) (b:=64) run42 run45
private theorem run33 : span pass 512 256 = true := span_add (a:=128) (b:=128) run34 run41
private theorem run51 : span pass 768 32 = true := by decide +kernel
private theorem run52 : span pass 800 32 = true := by decide +kernel
private theorem run50 : span pass 768 64 = true := span_add (a:=32) (b:=32) run51 run52
private theorem run54 : span pass 832 32 = true := by decide +kernel
private theorem run55 : span pass 864 32 = true := by decide +kernel
private theorem run53 : span pass 832 64 = true := span_add (a:=32) (b:=32) run54 run55
private theorem run49 : span pass 768 128 = true := span_add (a:=64) (b:=64) run50 run53
private theorem run58 : span pass 896 32 = true := by decide +kernel
private theorem run59 : span pass 928 32 = true := by decide +kernel
private theorem run57 : span pass 896 64 = true := span_add (a:=32) (b:=32) run58 run59
private theorem run61 : span pass 960 32 = true := by decide +kernel
private theorem run62 : span pass 992 32 = true := by decide +kernel
private theorem run60 : span pass 960 64 = true := span_add (a:=32) (b:=32) run61 run62
private theorem run56 : span pass 896 128 = true := span_add (a:=64) (b:=64) run57 run60
private theorem run48 : span pass 768 256 = true := span_add (a:=128) (b:=128) run49 run56
private theorem run32 : span pass 512 512 = true := span_add (a:=256) (b:=256) run33 run48
private theorem run0 : span pass 0 1024 = true := span_add (a:=512) (b:=512) run1 run32

theorem checked : rowStep 10 19115143757857 words11 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify10_023
end EarlyRamsey
