import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify10_019
private def masks : Array ℕ := #[322, 641, 896, 896, 832, 832, 177, 78, 61, 62]
private def tags : Array Witness := #[.undominated 0, .undominated 2, .undominated 3, .undominated 4, .undominated 5, .permutes 4371415897802755 327899385332994, .permutes 4371415897802755 362020817963233, .gap 1 10, .undominated 1, .permutes 2079709988519968 11583630013957317, .permutes 3626182422323200 10390457997858977, .gap 1 8, .gap 5 8, .gap 6 8, .permutes 3626182422323200 11550410619981922, .permutes 2079709988519968 11584462233076867, .gap 3 7, .gap 4 7, .undominated 8, .undominated 9, .gap 2 7, .gap 7 10, .undominated 7, .undominated 6, .gap 1 3, .gap 1 4, .gap 2 9, .permutes 2783812118904960 11584697209588902, .permutes 2783812118904960 11584697209588933, .permutes 1660720287367168 11268045411588259, .permutes 2222913928429568 10492916493550789, .gap 1 5, .gap 1 6, .permutes 2225184465584128 10493981778711553, .permutes 3878387695222920 11584699424118945, .permutes 2783812118904960 10493979663666214, .permutes 3878387695222920 11584699424117953, .permutes 2783812118904960 10493979697220645, .permutes 7005507837231112 9368946303078498, .permutes 7005507837231112 359824981268642, .gap 2 5, .permutes 2783812118904960 10492915482825828, .permutes 2783812118904960 10492915482825859, .permutes 1660720287367168 10379741989312675, .gap 2 6, .permutes 2225184465584128 11584696239723584, .permutes 3878387695222920 10492920952033378, .permutes 2783812118904960 11583629978440772, .permutes 3878387695222920 10492920952032386, .permutes 2783812118904960 11583630011995203, .permutes 7005507837231112 8208962540345505, .permutes 7005507837231112 325706904047713, .permutes 2222913928429568 11584696108615811, .gap 2 3, .gap 2 4, .gap 7 9, .permutes 4440897366261824 11583634274261153, .permutes 4440897366261824 10493986104938594, .embeds 71576909587719]
private def supply := witnessAt tags 0xe98d5861961965865861f61f7d87d861961965865862062081881861961965865861f61f7d87d861961965865860b610518d58619619658658607628a18d5861961965865860762cb18d58619619658658607628a18d586196196586586076392d8a1861961965865861f61f7d87d861961965865862062081881861961965865861f61f7d87d8619619658658607638dd8a18619619658658607596a18b18619619658658607596b18a18619619658658607596a1769761761765765761759768bd75d4bdb6d8bd75d4ba28a0bd75d4bdb6d8bd75d4bb2cb0bd75d4bdb6d8bd75d4ba28a0bd75d4bdb6d8bd75d52512507d40d47d80d87d40d47a00a07d40d47d80d87d40d47b00b07d40d47d80d87d40d47a00a07d40d47d80d87d40d52d002c7a282c7a282c7a282c7a282c7b2c2c7b2c2c7b2c2c7b2c2c7a282c7a282c7a282c7a282c7cf22c7c702c7bee2d2b52687a00687a00687a00687580a07b00a07b00a07b00a07580b07a00b07a00b07a00b07580a17ac0a17a80a17a40a175801d851861961965865861f61f7d87d861961965865862062081881861961965865861f61f7d87d861961965865860b4d31d86986196196586586276261d86986196196586586256241d86986196196586586236221d86986196196586586214d32d868861960865864861f6087d87c861960865864862060881880861960865864861f6087d87c861960865864861e4c81d868861960865864861d5881d868861960865864861c5881d868861960865864861b5881d76886176086576486175881cb5151cb5101cb5111cb5101cb50c1cb5101cb5111cb5101cb50d1cb5101cb5111cb5101cb50c1cb5101cb5111d24d21d04001d14401d04001cf3800c30c00c30c00c30c00c30c01041001041001041001041000c30c00c30c00c30c00c30c02cc3080410480820880410482cd3480410480820880410482cc3080410480820880410482ca2480410480820880410481c61400410400820800410400c30c00410400820800410401041000410400820800410400c30c0041040082080041040 6
private def pass (s : ℕ) := fastWitness 10 10 Terminal18.target 4277147303937 words11 masks s (supply s)

private theorem run5 : span pass 0 32 = true := by decide +kernel
private theorem run6 : span pass 32 32 = true := by decide +kernel
private theorem run4 : span pass 0 64 = true := span_add (a:=32) (b:=32) run5 run6
private theorem run8 : span pass 64 32 = true := by decide +kernel
private theorem run9 : span pass 96 32 = true := by decide +kernel
private theorem run7 : span pass 64 64 = true := span_add (a:=32) (b:=32) run8 run9
private theorem run3 : span pass 0 128 = true := span_add (a:=64) (b:=64) run4 run7
private theorem run12 : span pass 128 32 = true := by decide +kernel
private theorem run13 : span pass 160 32 = true := by decide +kernel
private theorem run11 : span pass 128 64 = true := span_add (a:=32) (b:=32) run12 run13
private theorem run15 : span pass 192 32 = true := by decide +kernel
private theorem run16 : span pass 224 32 = true := by decide +kernel
private theorem run14 : span pass 192 64 = true := span_add (a:=32) (b:=32) run15 run16
private theorem run10 : span pass 128 128 = true := span_add (a:=64) (b:=64) run11 run14
private theorem run2 : span pass 0 256 = true := span_add (a:=128) (b:=128) run3 run10
private theorem run20 : span pass 256 32 = true := by decide +kernel
private theorem run21 : span pass 288 32 = true := by decide +kernel
private theorem run19 : span pass 256 64 = true := span_add (a:=32) (b:=32) run20 run21
private theorem run23 : span pass 320 32 = true := by decide +kernel
private theorem run24 : span pass 352 32 = true := by decide +kernel
private theorem run22 : span pass 320 64 = true := span_add (a:=32) (b:=32) run23 run24
private theorem run18 : span pass 256 128 = true := span_add (a:=64) (b:=64) run19 run22
private theorem run27 : span pass 384 32 = true := by decide +kernel
private theorem run28 : span pass 416 32 = true := by decide +kernel
private theorem run26 : span pass 384 64 = true := span_add (a:=32) (b:=32) run27 run28
private theorem run30 : span pass 448 32 = true := by decide +kernel
private theorem run31 : span pass 480 32 = true := by decide +kernel
private theorem run29 : span pass 448 64 = true := span_add (a:=32) (b:=32) run30 run31
private theorem run25 : span pass 384 128 = true := span_add (a:=64) (b:=64) run26 run29
private theorem run17 : span pass 256 256 = true := span_add (a:=128) (b:=128) run18 run25
private theorem run1 : span pass 0 512 = true := span_add (a:=256) (b:=256) run2 run17
private theorem run36 : span pass 512 32 = true := by decide +kernel
private theorem run37 : span pass 544 32 = true := by decide +kernel
private theorem run35 : span pass 512 64 = true := span_add (a:=32) (b:=32) run36 run37
private theorem run39 : span pass 576 32 = true := by decide +kernel
private theorem run40 : span pass 608 32 = true := by decide +kernel
private theorem run38 : span pass 576 64 = true := span_add (a:=32) (b:=32) run39 run40
private theorem run34 : span pass 512 128 = true := span_add (a:=64) (b:=64) run35 run38
private theorem run43 : span pass 640 32 = true := by decide +kernel
private theorem run44 : span pass 672 32 = true := by decide +kernel
private theorem run42 : span pass 640 64 = true := span_add (a:=32) (b:=32) run43 run44
private theorem run46 : span pass 704 32 = true := by decide +kernel
private theorem run47 : span pass 736 32 = true := by decide +kernel
private theorem run45 : span pass 704 64 = true := span_add (a:=32) (b:=32) run46 run47
private theorem run41 : span pass 640 128 = true := span_add (a:=64) (b:=64) run42 run45
private theorem run33 : span pass 512 256 = true := span_add (a:=128) (b:=128) run34 run41
private theorem run51 : span pass 768 32 = true := by decide +kernel
private theorem run52 : span pass 800 32 = true := by decide +kernel
private theorem run50 : span pass 768 64 = true := span_add (a:=32) (b:=32) run51 run52
private theorem run54 : span pass 832 32 = true := by decide +kernel
private theorem run55 : span pass 864 32 = true := by decide +kernel
private theorem run53 : span pass 832 64 = true := span_add (a:=32) (b:=32) run54 run55
private theorem run49 : span pass 768 128 = true := span_add (a:=64) (b:=64) run50 run53
private theorem run58 : span pass 896 32 = true := by decide +kernel
private theorem run59 : span pass 928 32 = true := by decide +kernel
private theorem run57 : span pass 896 64 = true := span_add (a:=32) (b:=32) run58 run59
private theorem run61 : span pass 960 32 = true := by decide +kernel
private theorem run62 : span pass 992 32 = true := by decide +kernel
private theorem run60 : span pass 960 64 = true := span_add (a:=32) (b:=32) run61 run62
private theorem run56 : span pass 896 128 = true := span_add (a:=64) (b:=64) run57 run60
private theorem run48 : span pass 768 256 = true := span_add (a:=128) (b:=128) run49 run56
private theorem run32 : span pass 512 512 = true := span_add (a:=256) (b:=256) run33 run48
private theorem run0 : span pass 0 1024 = true := span_add (a:=512) (b:=512) run1 run32

theorem checked : rowStep 10 4277147303937 words11 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify10_019
end EarlyRamsey
