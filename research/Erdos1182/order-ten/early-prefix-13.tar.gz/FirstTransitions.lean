import FirstMaps
import FirstCoverage

namespace Terminal18
open SimpleGraph BBHExtension

theorem from_cube_data (i : Fin 3) (S : Finset (Fin 18))
    (cover : ∃ m ∈ rows i, subset 18 m.1 ⊆ S ∧ Disjoint S (subset 18 m.2.1))
    (maps : (rows i).all (fun m => fastCube 10 18 target (parent i) m.1 m.2.1 m.2.2) = true) :
    decode 10 target ⊑ (extend (decode 18 (parent i)) S)ᶜ := by
  obtain ⟨m,hm,lo,hi⟩ := cover
  exact cube_covers (fastCube_sound (List.all_eq_true.mp maps m hm)) lo hi

theorem first (S : Finset (Fin 18)) : decode 10 target ⊑ (extend (decode 18 (parent 0)) S)ᶜ :=
  from_cube_data _ S (cover0 S) maps0

theorem second (S : Finset (Fin 18)) : decode 10 target ⊑ (extend (decode 18 (parent 1)) S)ᶜ :=
  from_cube_data _ S (cover1 S) maps1

end Terminal18
