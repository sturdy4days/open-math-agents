import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify0_000
private def masks : Array ℕ := #[]
private def tags : Array Witness := #[.permutes 0 0]
private def supply := witnessAt tags 0x0 1
private def pass (s : ℕ) := fastWitness 10 0 Terminal18.target 0 words1 masks s (supply s)

private theorem run0 : span pass 0 1 = true := by decide +kernel

theorem checked : rowStep 0 0 words1 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify0_000
end EarlyRamsey
