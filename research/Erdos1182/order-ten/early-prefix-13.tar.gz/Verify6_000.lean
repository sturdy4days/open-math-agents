import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify6_000
private def masks : Array ℕ := #[32, 32, 32, 32, 32, 31]
private def tags : Array Witness := #[.undominated 0, .undominated 1, .undominated 2, .undominated 3, .undominated 4, .permutes 1047552 206703681, .permutes 2064384 6447828033, .gap 1 2, .gap 1 3, .gap 1 4, .gap 1 5, .permutes 2064384 206703681]
private def supply := witnessAt tags 0xb77887799778877aa77887799778877650102010301020104010201030102010 4
private def pass (s : ℕ) := fastWitness 10 6 Terminal18.target 31744 words7 masks s (supply s)

private theorem run1 : span pass 0 32 = true := by decide +kernel
private theorem run2 : span pass 32 32 = true := by decide +kernel
private theorem run0 : span pass 0 64 = true := span_add (a:=32) (b:=32) run1 run2

theorem checked : rowStep 6 31744 words7 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify6_000
end EarlyRamsey
