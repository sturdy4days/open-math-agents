import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify8_004
private def masks : Array ℕ := #[192, 192, 88, 164, 164, 88, 39, 27]
private def tags : Array Witness := #[.undominated 0, .undominated 1, .undominated 2, .undominated 5, .undominated 4, .permutes 16221241363 249176394949, .undominated 3, .permutes 16221241363 249176427716, .permutes 4154330304 7872683641921, .gap 3 8, .permutes 4154330304 9005480185921, .permutes 16221241363 282462458019, .gap 4 7, .permutes 16221241363 282462459011, .gap 5 7, .gap 6 8, .undominated 7, .gap 1 6, .gap 1 3, .permutes 8530063360 7976962427969, .gap 2 3, .undominated 6, .gap 1 5, .gap 1 4, .gap 2 4, .permutes 8530063360 9043154473025, .permutes 14931206656 9043225706561, .gap 1 2, .permutes 68451041280 282600803393]
private def supply := witnessAt tags 0xe6f7296f77bef7296f76b6f7296f77bef7296f718ef7296f77bef7296f76b6f7296f77bef7296f7a65f174df17bdaf6bdaf6b5ed7b5ed7be2f9108427df174df15bdaf6bdaf5b5ed7b5ed518c63108424ca929465164a929465174a929465164a90946508ca32952538ca32318c68ca32210848ca30318c648020780207002068020600205802050020100204802040020380203002028020200201802010020 5
private def pass (s : ℕ) := fastWitness 10 8 Terminal18.target 57925920 words9 masks s (supply s)

private theorem run3 : span pass 0 32 = true := by decide +kernel
private theorem run4 : span pass 32 32 = true := by decide +kernel
private theorem run2 : span pass 0 64 = true := span_add (a:=32) (b:=32) run3 run4
private theorem run6 : span pass 64 32 = true := by decide +kernel
private theorem run7 : span pass 96 32 = true := by decide +kernel
private theorem run5 : span pass 64 64 = true := span_add (a:=32) (b:=32) run6 run7
private theorem run1 : span pass 0 128 = true := span_add (a:=64) (b:=64) run2 run5
private theorem run10 : span pass 128 32 = true := by decide +kernel
private theorem run11 : span pass 160 32 = true := by decide +kernel
private theorem run9 : span pass 128 64 = true := span_add (a:=32) (b:=32) run10 run11
private theorem run13 : span pass 192 32 = true := by decide +kernel
private theorem run14 : span pass 224 32 = true := by decide +kernel
private theorem run12 : span pass 192 64 = true := span_add (a:=32) (b:=32) run13 run14
private theorem run8 : span pass 128 128 = true := span_add (a:=64) (b:=64) run9 run12
private theorem run0 : span pass 0 256 = true := span_add (a:=128) (b:=128) run1 run8

theorem checked : rowStep 8 57925920 words9 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify8_004
end EarlyRamsey
