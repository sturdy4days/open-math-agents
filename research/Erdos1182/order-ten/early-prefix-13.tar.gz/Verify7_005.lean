import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify7_005
private def masks : Array ℕ := #[6, 25, 97, 98, 98, 28, 28]
private def tags : Array Witness := #[.undominated 0, .undominated 3, .undominated 2, .undominated 5, .undominated 1, .permutes 57925920 105402011649, .gap 1 4, .undominated 4, .gap 1 5, .permutes 127797387 176334833761, .gap 2 3, .permutes 63927297 176194558017, .gap 1 6, .undominated 6, .gap 1 7, .permutes 60117131 210693524545, .permutes 60117131 211766217793, .gap 2 6, .permutes 60117131 245019708481, .permutes 60117131 246092401729, .gap 2 7, .permutes 127797387 247132589121, .permutes 63927297 247027896417, .gap 3 4, .gap 3 5, .permutes 266338304 7722896449]
private def supply := witnessAt tags 0xc994c51a203214c323004194c41ae03314435aa06198e51a803218e322604198e41a403398418c60719cc51a20321cc32200419cc419e0331c46b5a06198b509203202130820418e7408e03142418820 5
private def pass (s : ℕ) := fastWitness 10 7 Terminal18.target 946323 words8 masks s (supply s)

private theorem run2 : span pass 0 32 = true := by decide +kernel
private theorem run3 : span pass 32 32 = true := by decide +kernel
private theorem run1 : span pass 0 64 = true := span_add (a:=32) (b:=32) run2 run3
private theorem run5 : span pass 64 32 = true := by decide +kernel
private theorem run6 : span pass 96 32 = true := by decide +kernel
private theorem run4 : span pass 64 64 = true := span_add (a:=32) (b:=32) run5 run6
private theorem run0 : span pass 0 128 = true := span_add (a:=64) (b:=64) run1 run4

theorem checked : rowStep 7 946323 words8 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify7_005
end EarlyRamsey
