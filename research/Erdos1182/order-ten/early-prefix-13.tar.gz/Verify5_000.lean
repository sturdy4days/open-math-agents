import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify5_000
private def masks : Array ℕ := #[16, 16, 16, 16, 15]
private def tags : Array Witness := #[.undominated 0, .undominated 1, .undominated 2, .undominated 3, .permutes 16320 5377089, .permutes 31744 167906369, .gap 1 2, .gap 1 3, .gap 1 4, .permutes 31744 5377089]
private def supply := witnessAt tags 0x96677668866776654010201030102010 4
private def pass (s : ℕ) := fastWitness 10 5 Terminal18.target 960 words6 masks s (supply s)

private theorem run0 : span pass 0 32 = true := by decide +kernel

theorem checked : rowStep 5 960 words6 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify5_000
end EarlyRamsey
