import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify10_007
private def masks : Array ℕ := #[576, 576, 896, 896, 896, 896, 387, 124, 124, 63]
private def tags : Array Witness := #[.undominated 0, .undominated 1, .undominated 2, .undominated 3, .undominated 4, .undominated 5, .permutes 2220978314772480 362021926341697, .permutes 2247624159526912 11505607707331649, .gap 1 8, .gap 2 8, .undominated 8, .permutes 2230329106235392 11550610236217508, .permutes 2230329106235392 11550610236250275, .permutes 2222913928429568 11575940884890755, .permutes 2230329106235392 11550610236283011, .permutes 2222913928429568 11575940884858019, .permutes 2222913928429568 11575940884825252, .permutes 4440897366261824 361982033301606, .permutes 2230329106235392 11550610236314755, .permutes 2222913928429568 11575940883809475, .permutes 2222913928429568 11575940883776708, .permutes 4440897366261824 361982033334373, .permutes 2222913928429568 11575940882728133, .permutes 4440897366261824 361982033335396, .permutes 4440897366261824 361982033335427, .gap 8 10, .undominated 9, .gap 1 9, .undominated 7, .permutes 2230329106235392 11584695096678564, .permutes 2230329106235392 11584695096711331, .permutes 2222913928429568 11540790872540291, .permutes 2230329106235392 11584695096744067, .permutes 2222913928429568 11540790872507555, .permutes 2222913928429568 11540790872474788, .permutes 4440897366261824 360882522722406, .permutes 2230329106235392 11584695096775811, .permutes 2222913928429568 11540790871459011, .permutes 2222913928429568 11540790871426244, .permutes 4440897366261824 360882522755173, .permutes 2222913928429568 11540790870377669, .permutes 4440897366261824 360882522756196, .permutes 4440897366261824 360882522756227, .gap 9 10, .permutes 7297406967742464 10425576839124099, .gap 3 7, .gap 4 7, .gap 5 7, .gap 6 7, .gap 7 10, .undominated 6, .gap 1 4, .gap 1 3, .gap 1 5, .gap 1 6, .gap 2 3, .permutes 4495317034598400 11515466770120769, .gap 1 2, .permutes 4485800215445504 11584695235120193, .embeds 71576909587719]
private def supply := witnessAt tags 0xef9e74d39e73cf9e74d39e75d79e74d39e73cf9e74d39e76db9e74d39e73cf9e74d39e75d79e74d39e73cf9e74d39e48b74df4d33d33cf4cf4d35d35d74d74d33d33cf4cf4d36d36db4db4d33d33cf4cf4d35d35d74d74d33d33cf4cf4d37d3a239e74d39e73cf9e74d39e75d79e74d39e73cf9e74d39e76db9e74d39e73cf9e74d39e75d79e74d39e73cf9e74d39e5bc74df4d33d33cf4cf4d35d35d74d74d33d33cf4cf4d36d36db4db4d33d33cf4cf4d35d35d74d74d33d33cf4cf471c71c6f9e74d39e73cf9e74d39e75d79e74d39e73cf9e74d39e76db9e74d39e73cf9e74d39e75d79e74d39e73cf9e74d39e48c74df4d33d33cf4cf4d35d35d74d74d33d33cf4cf4d36d36db4db4d33d33cf4cf4d35d35d74d74d33d33cf4cf428a28a239e74d39e73cf9e74d39e75d79e74d39e73cf9e74d39e76db9e74d39e73cf9e74d39e75d79e74d39e73cf9e74d39e78c74df2d33d32cf4cf2d35d32d74d72d33d32cf4cf2d36d32db4db2d33d32cf4cf2d35d32d74d72d33d32cf4cf271c732c48248b48248b88248b48248bc8248b48248b88248b48248c08248b48248b88248b48248bc8248b48248b88248b4825ab40040b80040b40040bc0040b40040b80040b40040c00040b40040b80040b40040bc0040b40040b80040b40040b0004021b21b21b21b21b21b21b21b21b21b21b21b21b21b21b21b21b21b21b21b21b21b21b21b21b21b21b21b21b21b21b21aac0040a80040a40040a000409c00409800409400409000408c00408800408400408000407c00407800407400407000406c86c86c86c86c86c86c86c86c86c86c86c86c86c86c86c86c86c86c86c86c86c86c86c86c86c86c86c86c86c86c86da6400406000405c00405800405400405000404c00404800404400404000403c00403800403400403000402c00402800402092070820820c30c30820821041040820820c30c30820821451450820820c30c30820821041040820820c30c30820821800400800400c00400800401000400800400c00400800401400400800400c00400800401000400800400c0040080040 6
private def pass (s : ℕ) := fastWitness 10 10 Terminal18.target 4362873176064 words11 masks s (supply s)

private theorem run5 : span pass 0 32 = true := by decide +kernel
private theorem run6 : span pass 32 32 = true := by decide +kernel
private theorem run4 : span pass 0 64 = true := span_add (a:=32) (b:=32) run5 run6
private theorem run8 : span pass 64 32 = true := by decide +kernel
private theorem run9 : span pass 96 32 = true := by decide +kernel
private theorem run7 : span pass 64 64 = true := span_add (a:=32) (b:=32) run8 run9
private theorem run3 : span pass 0 128 = true := span_add (a:=64) (b:=64) run4 run7
private theorem run12 : span pass 128 32 = true := by decide +kernel
private theorem run13 : span pass 160 32 = true := by decide +kernel
private theorem run11 : span pass 128 64 = true := span_add (a:=32) (b:=32) run12 run13
private theorem run15 : span pass 192 32 = true := by decide +kernel
private theorem run16 : span pass 224 32 = true := by decide +kernel
private theorem run14 : span pass 192 64 = true := span_add (a:=32) (b:=32) run15 run16
private theorem run10 : span pass 128 128 = true := span_add (a:=64) (b:=64) run11 run14
private theorem run2 : span pass 0 256 = true := span_add (a:=128) (b:=128) run3 run10
private theorem run20 : span pass 256 32 = true := by decide +kernel
private theorem run21 : span pass 288 32 = true := by decide +kernel
private theorem run19 : span pass 256 64 = true := span_add (a:=32) (b:=32) run20 run21
private theorem run23 : span pass 320 32 = true := by decide +kernel
private theorem run24 : span pass 352 32 = true := by decide +kernel
private theorem run22 : span pass 320 64 = true := span_add (a:=32) (b:=32) run23 run24
private theorem run18 : span pass 256 128 = true := span_add (a:=64) (b:=64) run19 run22
private theorem run27 : span pass 384 32 = true := by decide +kernel
private theorem run28 : span pass 416 32 = true := by decide +kernel
private theorem run26 : span pass 384 64 = true := span_add (a:=32) (b:=32) run27 run28
private theorem run30 : span pass 448 32 = true := by decide +kernel
private theorem run31 : span pass 480 32 = true := by decide +kernel
private theorem run29 : span pass 448 64 = true := span_add (a:=32) (b:=32) run30 run31
private theorem run25 : span pass 384 128 = true := span_add (a:=64) (b:=64) run26 run29
private theorem run17 : span pass 256 256 = true := span_add (a:=128) (b:=128) run18 run25
private theorem run1 : span pass 0 512 = true := span_add (a:=256) (b:=256) run2 run17
private theorem run36 : span pass 512 32 = true := by decide +kernel
private theorem run37 : span pass 544 32 = true := by decide +kernel
private theorem run35 : span pass 512 64 = true := span_add (a:=32) (b:=32) run36 run37
private theorem run39 : span pass 576 32 = true := by decide +kernel
private theorem run40 : span pass 608 32 = true := by decide +kernel
private theorem run38 : span pass 576 64 = true := span_add (a:=32) (b:=32) run39 run40
private theorem run34 : span pass 512 128 = true := span_add (a:=64) (b:=64) run35 run38
private theorem run43 : span pass 640 32 = true := by decide +kernel
private theorem run44 : span pass 672 32 = true := by decide +kernel
private theorem run42 : span pass 640 64 = true := span_add (a:=32) (b:=32) run43 run44
private theorem run46 : span pass 704 32 = true := by decide +kernel
private theorem run47 : span pass 736 32 = true := by decide +kernel
private theorem run45 : span pass 704 64 = true := span_add (a:=32) (b:=32) run46 run47
private theorem run41 : span pass 640 128 = true := span_add (a:=64) (b:=64) run42 run45
private theorem run33 : span pass 512 256 = true := span_add (a:=128) (b:=128) run34 run41
private theorem run51 : span pass 768 32 = true := by decide +kernel
private theorem run52 : span pass 800 32 = true := by decide +kernel
private theorem run50 : span pass 768 64 = true := span_add (a:=32) (b:=32) run51 run52
private theorem run54 : span pass 832 32 = true := by decide +kernel
private theorem run55 : span pass 864 32 = true := by decide +kernel
private theorem run53 : span pass 832 64 = true := span_add (a:=32) (b:=32) run54 run55
private theorem run49 : span pass 768 128 = true := span_add (a:=64) (b:=64) run50 run53
private theorem run58 : span pass 896 32 = true := by decide +kernel
private theorem run59 : span pass 928 32 = true := by decide +kernel
private theorem run57 : span pass 896 64 = true := span_add (a:=32) (b:=32) run58 run59
private theorem run61 : span pass 960 32 = true := by decide +kernel
private theorem run62 : span pass 992 32 = true := by decide +kernel
private theorem run60 : span pass 960 64 = true := span_add (a:=32) (b:=32) run61 run62
private theorem run56 : span pass 896 128 = true := span_add (a:=64) (b:=64) run57 run60
private theorem run48 : span pass 768 256 = true := span_add (a:=128) (b:=128) run49 run56
private theorem run32 : span pass 512 512 = true := span_add (a:=256) (b:=256) run33 run48
private theorem run0 : span pass 0 1024 = true := span_add (a:=512) (b:=512) run1 run32

theorem checked : rowStep 10 4362873176064 words11 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify10_007
end EarlyRamsey
