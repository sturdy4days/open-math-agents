import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify10_028
private def masks : Array ℕ := #[14, 49, 577, 385, 322, 642, 148, 104, 536, 292]
private def tags : Array Witness := #[.undominated 0, .undominated 4, .undominated 2, .undominated 6, .undominated 1, .undominated 3, .undominated 7, .permutes 7474671440114307 4611353184773349, .gap 1 5, .undominated 5, .undominated 9, .gap 1 6, .undominated 8, .permutes 7474671440114307 6932423271131363, .gap 2 3, .gap 1 7, .gap 1 8, .permutes 33778794198908961 216744763595841, .permutes 7474671440114307 8096812557962305, .gap 2 7, .gap 1 10, .permutes 7474671440114307 9186427474874433, .gap 2 8, .gap 1 9, .permutes 7474671440114307 10347514940330049, .gap 2 9, .permutes 7474671440114307 10381594437292129, .permutes 33778794198908961 324563435326626, .permutes 7474671440114307 9324962753124514, .permutes 33778794198908961 291476150129793, .gap 2 4, .gap 3 8, .permutes 7474671440114307 11439328880495681, .gap 2 10, .permutes 7474671440114307 11506392683911330, .permutes 33778794198908961 359680163746913, .permutes 7474671440114307 9361248750833761, .permutes 33778794198908961 292643271838914, .gap 3 9, .embeds 71576909587719]
private def supply := witnessAt tags 0x9c838f38879078838f3884c020b38f20b79020b38f20b5802c838f2c87902c838f2c84c020f38421078420f38421f7c03c83d03887903c83d438858020b3d020b79020b3d420b5802c83d02c87902c83d42c86402103c42107842143c422698040840f40841778838f3884c020b40f20b41720b38f20b8402c840f2c84172c838f2c84c020f40421740420f3842269803c83d74084173c83d438864020b3d70c30c320b3d40c30c02c83d72c84171861861861802173c40c30c41861840c30c05c85cf5c85d078838f3884c020b5cf20b5d020b38f20b5802c85cf2c85d02c838f2c84c020f5c42105c420f38421f7c03c83d05c85d03c83d438858020b04120b04120b04120b0402c83d02c85d02c83d42c894021004421004421404422404040840f4084137853853854c020b40f20b4212053852058402c840f2c84132c53852c54c020f4042234042053842058803c83d44084213c53c538584020b0410c30412050450c50402c83d42c84201851851851802140440c30441850440c504050850f38879050850f3884c020b50f20b79020b50f20b5802c850f2c87902c850f2c84c020f50421078420f50421f7c03c83d03827823c83d638258020b3d020278220b3d62025802c83d02c27822c83d92c26402103c420278421d3c420270040840f40841750850f3884c020b40f20b41720b50f20b6c02c82492c82492c82492c824020f24421724420f24421a2403c83d74024023c83d938264020b3d70c20c220b3d80c20c02c82492c22421862491822402172440c22441862440c22405c85cf5c85d050850f3884c020b5cf20b5d030c30c30c3002c85cf28a28a2c850f28a28020f5c428a28430c30430c3003c83d05c25c23c83d638258020b04120204230c0413020402c83d02822822c83d528228021004428204430c04430204040840f4084135055053854c020b40f20b4123053053053002c824928a2492c524528524020f24428a2443052443052403c83d14024023c53c538234020b0410c20423050450c20402c82492822421852451822402070440c20441850440c2040 6
private def pass (s : ℕ) := fastWitness 10 10 Terminal18.target 20072748419211 words11 masks s (supply s)

private theorem run5 : span pass 0 32 = true := by decide +kernel
private theorem run6 : span pass 32 32 = true := by decide +kernel
private theorem run4 : span pass 0 64 = true := span_add (a:=32) (b:=32) run5 run6
private theorem run8 : span pass 64 32 = true := by decide +kernel
private theorem run9 : span pass 96 32 = true := by decide +kernel
private theorem run7 : span pass 64 64 = true := span_add (a:=32) (b:=32) run8 run9
private theorem run3 : span pass 0 128 = true := span_add (a:=64) (b:=64) run4 run7
private theorem run12 : span pass 128 32 = true := by decide +kernel
private theorem run13 : span pass 160 32 = true := by decide +kernel
private theorem run11 : span pass 128 64 = true := span_add (a:=32) (b:=32) run12 run13
private theorem run15 : span pass 192 32 = true := by decide +kernel
private theorem run16 : span pass 224 32 = true := by decide +kernel
private theorem run14 : span pass 192 64 = true := span_add (a:=32) (b:=32) run15 run16
private theorem run10 : span pass 128 128 = true := span_add (a:=64) (b:=64) run11 run14
private theorem run2 : span pass 0 256 = true := span_add (a:=128) (b:=128) run3 run10
private theorem run20 : span pass 256 32 = true := by decide +kernel
private theorem run21 : span pass 288 32 = true := by decide +kernel
private theorem run19 : span pass 256 64 = true := span_add (a:=32) (b:=32) run20 run21
private theorem run23 : span pass 320 32 = true := by decide +kernel
private theorem run24 : span pass 352 32 = true := by decide +kernel
private theorem run22 : span pass 320 64 = true := span_add (a:=32) (b:=32) run23 run24
private theorem run18 : span pass 256 128 = true := span_add (a:=64) (b:=64) run19 run22
private theorem run27 : span pass 384 32 = true := by decide +kernel
private theorem run28 : span pass 416 32 = true := by decide +kernel
private theorem run26 : span pass 384 64 = true := span_add (a:=32) (b:=32) run27 run28
private theorem run30 : span pass 448 32 = true := by decide +kernel
private theorem run31 : span pass 480 32 = true := by decide +kernel
private theorem run29 : span pass 448 64 = true := span_add (a:=32) (b:=32) run30 run31
private theorem run25 : span pass 384 128 = true := span_add (a:=64) (b:=64) run26 run29
private theorem run17 : span pass 256 256 = true := span_add (a:=128) (b:=128) run18 run25
private theorem run1 : span pass 0 512 = true := span_add (a:=256) (b:=256) run2 run17
private theorem run36 : span pass 512 32 = true := by decide +kernel
private theorem run37 : span pass 544 32 = true := by decide +kernel
private theorem run35 : span pass 512 64 = true := span_add (a:=32) (b:=32) run36 run37
private theorem run39 : span pass 576 32 = true := by decide +kernel
private theorem run40 : span pass 608 32 = true := by decide +kernel
private theorem run38 : span pass 576 64 = true := span_add (a:=32) (b:=32) run39 run40
private theorem run34 : span pass 512 128 = true := span_add (a:=64) (b:=64) run35 run38
private theorem run43 : span pass 640 32 = true := by decide +kernel
private theorem run44 : span pass 672 32 = true := by decide +kernel
private theorem run42 : span pass 640 64 = true := span_add (a:=32) (b:=32) run43 run44
private theorem run46 : span pass 704 32 = true := by decide +kernel
private theorem run47 : span pass 736 32 = true := by decide +kernel
private theorem run45 : span pass 704 64 = true := span_add (a:=32) (b:=32) run46 run47
private theorem run41 : span pass 640 128 = true := span_add (a:=64) (b:=64) run42 run45
private theorem run33 : span pass 512 256 = true := span_add (a:=128) (b:=128) run34 run41
private theorem run51 : span pass 768 32 = true := by decide +kernel
private theorem run52 : span pass 800 32 = true := by decide +kernel
private theorem run50 : span pass 768 64 = true := span_add (a:=32) (b:=32) run51 run52
private theorem run54 : span pass 832 32 = true := by decide +kernel
private theorem run55 : span pass 864 32 = true := by decide +kernel
private theorem run53 : span pass 832 64 = true := span_add (a:=32) (b:=32) run54 run55
private theorem run49 : span pass 768 128 = true := span_add (a:=64) (b:=64) run50 run53
private theorem run58 : span pass 896 32 = true := by decide +kernel
private theorem run59 : span pass 928 32 = true := by decide +kernel
private theorem run57 : span pass 896 64 = true := span_add (a:=32) (b:=32) run58 run59
private theorem run61 : span pass 960 32 = true := by decide +kernel
private theorem run62 : span pass 992 32 = true := by decide +kernel
private theorem run60 : span pass 960 64 = true := span_add (a:=32) (b:=32) run61 run62
private theorem run56 : span pass 896 128 = true := span_add (a:=64) (b:=64) run57 run60
private theorem run48 : span pass 768 256 = true := span_add (a:=128) (b:=128) run49 run56
private theorem run32 : span pass 512 512 = true := span_add (a:=256) (b:=256) run33 run48
private theorem run0 : span pass 0 1024 = true := span_add (a:=512) (b:=512) run1 run32

theorem checked : rowStep 10 20072748419211 words11 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify10_028
end EarlyRamsey
