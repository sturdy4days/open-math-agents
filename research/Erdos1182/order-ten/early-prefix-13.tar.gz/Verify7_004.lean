import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify7_004
private def masks : Array ℕ := #[34, 65, 96, 96, 96, 29, 30]
private def tags : Array Witness := #[.undominated 0, .undominated 2, .undominated 3, .undominated 4, .permutes 63927297 6682709026, .permutes 63927297 7722896449, .gap 1 7, .undominated 1, .undominated 6, .permutes 66980864 213747108865, .gap 1 3, .gap 1 4, .gap 1 5, .gap 2 6, .permutes 66980864 246999550978, .undominated 5, .gap 2 3, .gap 2 4, .gap 2 5, .permutes 132022273 246965996609, .permutes 266338304 7722896449]
private def supply := witnessAt tags 0xa2a0a52d4b5a96a5314c6298a52d4b5a96a5195369a0081a2089a0081a4091a0081a2089a0083dc0329a752d475a967531476298752d475a967525073148008420108400842018c60084201084008420 5
private def pass (s : ℕ) := fastWitness 10 7 Terminal18.target 1012737 words8 masks s (supply s)

private theorem run2 : span pass 0 32 = true := by decide +kernel
private theorem run3 : span pass 32 32 = true := by decide +kernel
private theorem run1 : span pass 0 64 = true := span_add (a:=32) (b:=32) run2 run3
private theorem run5 : span pass 64 32 = true := by decide +kernel
private theorem run6 : span pass 96 32 = true := by decide +kernel
private theorem run4 : span pass 64 64 = true := span_add (a:=32) (b:=32) run5 run6
private theorem run0 : span pass 0 128 = true := span_add (a:=64) (b:=64) run1 run4

theorem checked : rowStep 7 1012737 words8 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify7_004
end EarlyRamsey
