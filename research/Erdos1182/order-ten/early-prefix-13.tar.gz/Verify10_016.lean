import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify10_016
private def masks : Array ℕ := #[768, 768, 312, 708, 708, 708, 312, 312, 199, 59]
private def tags : Array Witness := #[.undominated 0, .undominated 1, .undominated 2, .undominated 6, .undominated 4, .permutes 2089557274923264 11575941018029121, .undominated 3, .permutes 2089557274923264 11575941017013313, .undominated 5, .permutes 3626182422323200 327866135054371, .permutes 2089557274923264 11575940983491649, .permutes 3626182422323200 327832849057827, .permutes 3626182422323200 327798522873891, .permutes 1106375850487808 10144305947839553, .gap 3 10, .undominated 7, .permutes 2089557274923264 10485154681425985, .permutes 3626182422323200 362021826758692, .permutes 2089557274923264 10485153607685185, .permutes 3626182422323200 362021826725925, .permutes 3626182422323200 327866134923303, .permutes 2222913928429568 362020886154305, .permutes 2089557274923264 10485119247947841, .permutes 3626182422323200 362021825677350, .permutes 3626182422323200 327832848926759, .permutes 2222913928429568 362019813461057, .permutes 3626182422323200 327798522742823, .permutes 2222913928429568 362018739752001, .gap 7 10, .permutes 2089557274923264 10485154647904321, .permutes 3626182422323200 361988540762148, .permutes 2089557274923264 10485153574163521, .permutes 3626182422323200 361988540729381, .permutes 3626182422323200 327866133874728, .permutes 2222913928429568 361986559970369, .permutes 2089557274923264 10485119214426177, .permutes 3626182422323200 361988539680806, .permutes 3626182422323200 327832847878184, .permutes 2222913928429568 361985487277121, .permutes 3626182422323200 327798521694248, .permutes 2222913928429568 361984413568065, .gap 8 10, .permutes 1106375850487808 11269177174298689, .permutes 3626182422323200 361851236026404, .gap 4 9, .permutes 3626182422323200 361851235993637, .gap 5 9, .permutes 2222913928429568 327864021127233, .permutes 3626182422323200 361851234945062, .gap 6 9, .permutes 2222913928429568 327829694943297, .permutes 2222913928429568 327795335205953, .undominated 9, .gap 1 7, .gap 1 3, .permutes 2247624159526912 10491716054518849, .gap 2 3, .gap 1 8, .undominated 8, .gap 1 5, .gap 1 4, .gap 1 6, .gap 2 4, .permutes 2247624159526912 11584698256101441, .permutes 4214389649711616 11584701642932289, .gap 1 2, .embeds 71576909587719]
private def supply := witnessAt tags 0x85060b66d060bc79060b66d060bb77060b66d060bc79060b66d060bd7b060b66d060bc79060b66d060bb77060b66d060bc79060b66d060b56b060b66d060bc79060b66d060bb77060b66d060bc79060b66d060bd7b060b66d060bc79060b66d060bb77060b66d060bc79060b66d060b973060b66d060bc79060b66d060bb77060b66d060bc79060b66d060bd7b060b66d060bc79060b66d060bb77060b66d060bc79060b66d060b56b060b66d060bc79060b66d060bb77060b66d060bc79060b66d060bd7b060b66d060bc79060b66d060bb77060b66d060bc79060b66d060c058f1f3c1cf1f3c78ede3b78ede3b76f1dbc76f1dbc78f5e3d78f5e3d7af1ebc7af1ebc78ede3b78ede3b76f1dbc76f1dbc78f9e3f040810238f1f3c1cf1f3c78ede3b78ede3b76f1dbc76f1dbc78f5e3d78f5e3d7af1ebc7af1ebc78ede3b78ede3b76f1dbc76f1dbc060c183040810252f1f3c1cf1f3c78ede3b78ede3b76f1dbc76f1dbc78f5e3d78f5e3d7af1ebc7af1ebc78ede3b78ede3b76f1dbc76f1dbc1e3c78f040810238f1f3c1cf1f3a78ede3b78ede3a76f1dbc76f1dba78f5e3d78f5e3a7af1ebc7af1eba78ede3b78ede3a76f1dbc76f1dba060c18304081021cd9c366cd5b3558d9c366cd5b355cd9c366cd5b3558d9c366cd5b3562d9c366cd5b3558d9c366cd5b355cd9c366cd5b3558d9c346cd5b346ad9ab66ce5b396ad9ab66ce5b396ad9ab66ce5b396ad9ab66ce5b396ad9ab66ce5b396ad9ab66ce5b396ad9ab66ce5b396ad9ab46ce5b3472d9cb66cd5b3572d9cb66cd5b3572d9cb66cd5b3572d9cb66cd5b3572d9cb66cd5b3572d9cb66cd5b3572d9cb66cd5b3572d9cb46cd5b346ad9ab66ce1b376ad9ab60c183066ad9ab608102046ad9ab60c183066ad9ab610204086ad9ab60c183066ad9ab608102046ad9ab40c183061c0008038000805c000806600080580008064000806200080600008058000805e000805c000805a0008058000805600080540008004000801c00080520008050000804e000804c000804a00080480008046000804400080420008040000803e000803c000803a00080060008004000801c00080380008036000803400080320008030000802e000802c000802a00080280008026000802400080220008020000801e0008004000801c000801a0008018000800c000801600080080008014000800c00080120008010000800e000800c000800a00080080008006000800400080 7
private def pass (s : ℕ) := fastWitness 10 10 Terminal18.target 4107987063072 words11 masks s (supply s)

private theorem run5 : span pass 0 32 = true := by decide +kernel
private theorem run6 : span pass 32 32 = true := by decide +kernel
private theorem run4 : span pass 0 64 = true := span_add (a:=32) (b:=32) run5 run6
private theorem run8 : span pass 64 32 = true := by decide +kernel
private theorem run9 : span pass 96 32 = true := by decide +kernel
private theorem run7 : span pass 64 64 = true := span_add (a:=32) (b:=32) run8 run9
private theorem run3 : span pass 0 128 = true := span_add (a:=64) (b:=64) run4 run7
private theorem run12 : span pass 128 32 = true := by decide +kernel
private theorem run13 : span pass 160 32 = true := by decide +kernel
private theorem run11 : span pass 128 64 = true := span_add (a:=32) (b:=32) run12 run13
private theorem run15 : span pass 192 32 = true := by decide +kernel
private theorem run16 : span pass 224 32 = true := by decide +kernel
private theorem run14 : span pass 192 64 = true := span_add (a:=32) (b:=32) run15 run16
private theorem run10 : span pass 128 128 = true := span_add (a:=64) (b:=64) run11 run14
private theorem run2 : span pass 0 256 = true := span_add (a:=128) (b:=128) run3 run10
private theorem run20 : span pass 256 32 = true := by decide +kernel
private theorem run21 : span pass 288 32 = true := by decide +kernel
private theorem run19 : span pass 256 64 = true := span_add (a:=32) (b:=32) run20 run21
private theorem run23 : span pass 320 32 = true := by decide +kernel
private theorem run24 : span pass 352 32 = true := by decide +kernel
private theorem run22 : span pass 320 64 = true := span_add (a:=32) (b:=32) run23 run24
private theorem run18 : span pass 256 128 = true := span_add (a:=64) (b:=64) run19 run22
private theorem run27 : span pass 384 32 = true := by decide +kernel
private theorem run28 : span pass 416 32 = true := by decide +kernel
private theorem run26 : span pass 384 64 = true := span_add (a:=32) (b:=32) run27 run28
private theorem run30 : span pass 448 32 = true := by decide +kernel
private theorem run31 : span pass 480 32 = true := by decide +kernel
private theorem run29 : span pass 448 64 = true := span_add (a:=32) (b:=32) run30 run31
private theorem run25 : span pass 384 128 = true := span_add (a:=64) (b:=64) run26 run29
private theorem run17 : span pass 256 256 = true := span_add (a:=128) (b:=128) run18 run25
private theorem run1 : span pass 0 512 = true := span_add (a:=256) (b:=256) run2 run17
private theorem run36 : span pass 512 32 = true := by decide +kernel
private theorem run37 : span pass 544 32 = true := by decide +kernel
private theorem run35 : span pass 512 64 = true := span_add (a:=32) (b:=32) run36 run37
private theorem run39 : span pass 576 32 = true := by decide +kernel
private theorem run40 : span pass 608 32 = true := by decide +kernel
private theorem run38 : span pass 576 64 = true := span_add (a:=32) (b:=32) run39 run40
private theorem run34 : span pass 512 128 = true := span_add (a:=64) (b:=64) run35 run38
private theorem run43 : span pass 640 32 = true := by decide +kernel
private theorem run44 : span pass 672 32 = true := by decide +kernel
private theorem run42 : span pass 640 64 = true := span_add (a:=32) (b:=32) run43 run44
private theorem run46 : span pass 704 32 = true := by decide +kernel
private theorem run47 : span pass 736 32 = true := by decide +kernel
private theorem run45 : span pass 704 64 = true := span_add (a:=32) (b:=32) run46 run47
private theorem run41 : span pass 640 128 = true := span_add (a:=64) (b:=64) run42 run45
private theorem run33 : span pass 512 256 = true := span_add (a:=128) (b:=128) run34 run41
private theorem run51 : span pass 768 32 = true := by decide +kernel
private theorem run52 : span pass 800 32 = true := by decide +kernel
private theorem run50 : span pass 768 64 = true := span_add (a:=32) (b:=32) run51 run52
private theorem run54 : span pass 832 32 = true := by decide +kernel
private theorem run55 : span pass 864 32 = true := by decide +kernel
private theorem run53 : span pass 832 64 = true := span_add (a:=32) (b:=32) run54 run55
private theorem run49 : span pass 768 128 = true := span_add (a:=64) (b:=64) run50 run53
private theorem run58 : span pass 896 32 = true := by decide +kernel
private theorem run59 : span pass 928 32 = true := by decide +kernel
private theorem run57 : span pass 896 64 = true := span_add (a:=32) (b:=32) run58 run59
private theorem run61 : span pass 960 32 = true := by decide +kernel
private theorem run62 : span pass 992 32 = true := by decide +kernel
private theorem run60 : span pass 960 64 = true := span_add (a:=32) (b:=32) run61 run62
private theorem run56 : span pass 896 128 = true := span_add (a:=64) (b:=64) run57 run60
private theorem run48 : span pass 768 256 = true := span_add (a:=128) (b:=128) run49 run56
private theorem run32 : span pass 512 512 = true := span_add (a:=256) (b:=256) run33 run48
private theorem run0 : span pass 0 1024 = true := span_add (a:=512) (b:=512) run1 run32

theorem checked : rowStep 10 4107987063072 words11 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify10_016
end EarlyRamsey
