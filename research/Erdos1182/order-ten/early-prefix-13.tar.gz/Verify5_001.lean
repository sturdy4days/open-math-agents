import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify5_001
private def masks : Array ℕ := #[24, 24, 24, 7, 7]
private def tags : Array Witness := #[.undominated 0, .undominated 1, .undominated 2, .permutes 15243 102765697, .undominated 4, .permutes 15169 139560961, .permutes 15169 139559938, .permutes 15169 5309571, .permutes 15169 139527171, .permutes 15169 5342338, .permutes 15169 5343361, .gap 4 5, .undominated 3, .permutes 15169 172066817, .permutes 15169 172065794, .permutes 15169 4261027, .permutes 15169 172033027, .permutes 15169 4293794, .permutes 15169 4294817, .permutes 16320 171969601, .gap 1 2, .gap 1 3, .permutes 31744 5377089]
private def supply := witnessAt tags 0xb5295ad2935ca307b9ac5a928398a41802010020 5
private def pass (s : ℕ) := fastWitness 10 5 Terminal18.target 504 words6 masks s (supply s)

private theorem run0 : span pass 0 32 = true := by decide +kernel

theorem checked : rowStep 5 504 words6 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify5_001
end EarlyRamsey
