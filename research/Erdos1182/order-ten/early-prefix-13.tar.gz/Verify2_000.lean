import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify2_000
private def masks : Array ℕ := #[2, 1]
private def tags : Array Witness := #[.undominated 0, .permutes 6 1026, .permutes 6 2049, .permutes 6 65]
private def supply := witnessAt tags 0xe4 2
private def pass (s : ℕ) := fastWitness 10 2 Terminal18.target 1 words3 masks s (supply s)

private theorem run0 : span pass 0 4 = true := by decide +kernel

theorem checked : rowStep 2 1 words3 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify2_000
end EarlyRamsey
