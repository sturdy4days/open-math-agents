import Priority

namespace BBHExtension
open SimpleGraph

/-- There is an ordering in which deleting vertex zero leaves a maximal
triangle-free graph. Ranging over permutations permits every vertex deletion. -/
def hasPureDeletion {k} (H : SimpleGraph (Fin (k+1))) : Prop :=
  ∃ p : Equiv.Perm (Fin (k+1)), Maximal (fun D : SimpleGraph (Fin k) => D.CliqueFree 3)
    (H.comap (fun i : Fin k => p i.succ))

theorem pureDeletion_image {k} {H K : SimpleGraph (Fin (k+1))} (e : H ≃g K)
    (h : hasPureDeletion H) : hasPureDeletion K := by
  obtain ⟨p,maxP⟩ := h
  use p.trans e.toEquiv
  have eq : K.comap (fun i : Fin k => (p.trans e.toEquiv) i.succ) =
      H.comap (fun i : Fin k => p i.succ) := by
    ext i j
    exact e.map_rel_iff
  rwa [eq]

def independentRow {k} (P : SimpleGraph (Fin k)) (S : Finset (Fin k)) : Prop :=
  ∀ i∈S, ∀ j∈S, ¬P.Adj i j

theorem independentRow_image {k} {P Q : SimpleGraph (Fin k)} (e : P ≃g Q)
    (S : Finset (Fin k)) (s : independentRow P S) : independentRow Q (S.map e.toEquiv.toEmbedding) := by
  intro i hi j hj ij
  obtain ⟨a,ha,rfl⟩ := Finset.mem_map.mp hi
  obtain ⟨b,hb,rfl⟩ := Finset.mem_map.mp hj
  exact s a ha b hb (e.map_rel_iff.mp ij)

/-- A maximal pure deletion forces the saturated parent to equal the induced
parent, so there are no old edges inside the connector. -/
theorem pure_parent {k} {V : Type*} (G : SimpleGraph V) (H : SimpleGraph (Fin (k+1)))
    (hm : Maximal (fun D : SimpleGraph (Fin (k+1)) => D.CliqueFree 3) H) (avoid : ¬G ⊑ Hᶜ)
    (pure : hasPureDeletion H) : parentWith G H independentRow := by
  classical
  obtain ⟨p,maxB⟩ := pure
  let K := H.comap p
  let iso : K ≃g H := SimpleGraph.Iso.comap p H
  have noK : ¬G ⊑ Kᶜ := fun hit => avoid
    (hit.trans ⟨(SimpleGraph.Embedding.complEquiv iso.toEmbedding).toCopy⟩)
  obtain ⟨P,S,maxP,noP,dom,eq⟩ := parent G K (maximal_triangleFree_comap H hm p) noK
  let B := K.comap Fin.succ
  have maxB' : Maximal (fun D : SimpleGraph (Fin k) => D.CliqueFree 3) B := maxB
  have bp : B ≤ P := by
    intro i j ij
    change K.Adj i.succ j.succ at ij
    rw [eq,extend_old] at ij
    exact ij.1
  have pb := maxB'.2 maxP.1 bp
  refine ⟨P,S,maxP,noP,dom,?_,eq ▸ ⟨iso.symm⟩⟩
  intro i hi j hj ij
  have inK : K.Adj i.succ j.succ := pb ij
  rw [eq,extend_old] at inK
  exact inK.2 ⟨hi,hj⟩

/-- Twin deletion takes precedence. A twin-free child uses a pure deletion
whenever one exists and uses the minimum-degree rule otherwise. -/
def priorityRow {k} (P : SimpleGraph (Fin k)) (S : Finset (Fin k)) : Prop :=
  neighborRow P S ∨ ¬hasTwins (extend P S) ∧
    (independentRow P S ∨ ¬hasPureDeletion (extend P S) ∧ rootMinimum (extend P S))

theorem priority_parent {k} {V : Type*} (G : SimpleGraph V) (H : SimpleGraph (Fin (k+1)))
    (hm : Maximal (fun D : SimpleGraph (Fin (k+1)) => D.CliqueFree 3) H)
    (avoid : ¬G ⊑ Hᶜ) : parentWith G H priorityRow := by
  classical
  by_cases tw : hasTwins H
  · obtain ⟨u,v,ne,eq⟩ := tw
    obtain ⟨P,S,z,maxP,noP,row,dom,iso⟩ := twin_parent G H hm avoid u v ne eq
    exact ⟨P,S,maxP,noP,dom,Or.inl ⟨z,row⟩,iso⟩
  by_cases pure : hasPureDeletion H
  · obtain ⟨P,S,maxP,noP,dom,indep,⟨e⟩⟩ := pure_parent G H hm avoid pure
    exact ⟨P,S,maxP,noP,dom,Or.inr ⟨fun t => tw (twins_image e.symm t),Or.inl indep⟩,⟨e⟩⟩
  · obtain ⟨P,S,maxP,noP,dom,least,⟨e⟩⟩ := minimum_parent G H hm avoid
    exact ⟨P,S,maxP,noP,dom,Or.inr ⟨fun t => tw (twins_image e.symm t),
      Or.inr ⟨fun d => pure (pureDeletion_image e.symm d),least⟩⟩,⟨e⟩⟩

theorem priority_image {k} {P Q : SimpleGraph (Fin k)} (e : P ≃g Q) (S : Finset (Fin k))
    (row : priorityRow P S) : priorityRow Q (S.map e.toEquiv.toEmbedding) := by
  rcases row with old | ⟨no,h⟩
  · exact Or.inl (neighborRow_image e S old)
  · let j := renamedExtension e S
    refine Or.inr ⟨fun t => no (twins_image j.symm t), ?_⟩
    rcases h with indep | ⟨nd,least⟩
    · exact Or.inl (independentRow_image e S indep)
    · exact Or.inr ⟨fun d => nd (pureDeletion_image j.symm d),
        rootMinimum_image j (renamedExtension_zero e S) least⟩

private theorem map_back {k} {P Q : SimpleGraph (Fin k)} (e : P ≃g Q) (S : Finset (Fin k)) :
    (S.map e.toEquiv.toEmbedding).map e.symm.toEquiv.toEmbedding = S := by
  ext x
  calc
    _ ↔ e.symm (e x) ∈ (S.map e.toEquiv.toEmbedding).map e.symm.toEquiv.toEmbedding := by simp
    _ ↔ e x ∈ S.map e.toEquiv.toEmbedding := Finset.mem_map' ..
    _ ↔ _ := Finset.mem_map' ..

theorem twinMinimum_image_iff {k} {P Q : SimpleGraph (Fin k)} (e : P ≃g Q) (S : Finset (Fin k)) :
    twinMinimumRow Q (S.map e.toEquiv.toEmbedding) ↔ twinMinimumRow P S := by
  refine ⟨fun h => ?_,twinMinimum_image e S⟩
  simpa only [map_back] using twinMinimum_image e.symm _ h

theorem priority_image_iff {k} {P Q : SimpleGraph (Fin k)} (e : P ≃g Q) (S : Finset (Fin k)) :
    priorityRow Q (S.map e.toEquiv.toEmbedding) ↔ priorityRow P S := by
  refine ⟨fun h => ?_,priority_image e S⟩
  simpa only [map_back] using priority_image e.symm _ h

theorem priority_complement_covers {V : Type*} (G : SimpleGraph V) (N : ℕ)
    (atlas : (k : ℕ) → List (SimpleGraph (Fin k))) (init : ⊥ ∈ atlas 0)
    (rows : ∀ k<N, selectedRows G priorityRow (atlas k) (atlas (k+1))) (endRow : atlas N = []) :
    ∀ H : SimpleGraph (Fin N), H.CliqueFree 3 → G ⊑ Hᶜ :=
  cover_of_atlas_complete G N atlas endRow
    (selected_atlas_complete G N atlas init (fun _ => priorityRow)
      (fun _ => priority_parent G) (fun _ => priority_image) rows N le_rfl)

end BBHExtension

#print axioms BBHExtension.priority_image_iff
#print axioms BBHExtension.twinMinimum_image_iff
#print axioms BBHExtension.priority_complement_covers
