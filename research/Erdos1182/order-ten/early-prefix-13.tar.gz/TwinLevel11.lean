import TwinLevel11P0000
import TwinLevel11P0001
import TwinLevel11P0002
import TwinLevel11P0003
import TwinLevel11P0004
import TwinLevel11P0005
import TwinLevel11P0006
import TwinLevel11P0007
import TwinLevel11P0008
import TwinLevel11P0009
import TwinLevel11P0010
import TwinLevel11P0011
import TwinLevel11P0012
import TwinLevel11P0013
import TwinLevel11P0014
import TwinLevel11P0015
import TwinLevel11P0016
import TwinLevel11P0017
import TwinLevel11P0018
import TwinLevel11P0019
import TwinLevel11P0020
import TwinLevel11P0021
import TwinLevel11P0022
import TwinLevel11P0023
import TwinLevel11P0024
import TwinLevel11P0025
import TwinLevel11P0026
import TwinLevel11P0027
import TwinLevel11P0028
import TwinLevel11P0029
import TwinLevel11P0030
import TwinLevel11P0031
import TwinLevel11P0032
import TwinLevel11P0033
import TwinLevel11P0034
import TwinLevel11P0035
import TwinLevel11P0036
import TwinLevel11P0037
import TwinLevel11P0038
import TwinLevel11P0039
import TwinLevel11P0040
import TwinLevel11P0041
import TwinLevel11P0042
import TwinLevel11P0043
import TwinLevel11P0044
import TwinLevel11P0045
import TwinLevel11P0046
import TwinLevel11P0047
import TwinLevel11P0048
import TwinLevel11P0049
import TwinLevel11P0050
import TwinLevel11P0051
import TwinLevel11P0052
import TwinLevel11P0053
import TwinLevel11P0054
import TwinLevel11P0055
import TwinLevel11P0056
import TwinLevel11P0057
import TwinLevel11P0058
import TwinLevel11P0059
namespace TwinLevel11
open SimpleGraph BBHExtension
theorem all_parents : selectedRows (decode 10 target) priorityRow (parents.map (decode 11)) (children.map (decode 12)) := by
  intro P mem S hS dom prio
  simp only [parents,List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact TwinLevel11P0000.complete _ (by simp [TwinLevel11P0000.p]) S hS dom prio
  · exact TwinLevel11P0001.complete _ (by simp [TwinLevel11P0001.p]) S hS dom prio
  · exact TwinLevel11P0002.complete _ (by simp [TwinLevel11P0002.p]) S hS dom prio
  · exact TwinLevel11P0003.complete _ (by simp [TwinLevel11P0003.p]) S hS dom prio
  · exact TwinLevel11P0004.complete _ (by simp [TwinLevel11P0004.p]) S hS dom prio
  · exact TwinLevel11P0005.complete _ (by simp [TwinLevel11P0005.p]) S hS dom prio
  · exact TwinLevel11P0006.complete _ (by simp [TwinLevel11P0006.p]) S hS dom prio
  · exact TwinLevel11P0007.complete _ (by simp [TwinLevel11P0007.p]) S hS dom prio
  · exact TwinLevel11P0008.complete _ (by simp [TwinLevel11P0008.p]) S hS dom prio
  · exact TwinLevel11P0009.complete _ (by simp [TwinLevel11P0009.p]) S hS dom prio
  · exact TwinLevel11P0010.complete _ (by simp [TwinLevel11P0010.p]) S hS dom prio
  · exact TwinLevel11P0011.complete _ (by simp [TwinLevel11P0011.p]) S hS dom prio
  · exact TwinLevel11P0012.complete _ (by simp [TwinLevel11P0012.p]) S hS dom prio
  · exact TwinLevel11P0013.complete _ (by simp [TwinLevel11P0013.p]) S hS dom prio
  · exact TwinLevel11P0014.complete _ (by simp [TwinLevel11P0014.p]) S hS dom prio
  · exact TwinLevel11P0015.complete _ (by simp [TwinLevel11P0015.p]) S hS dom prio
  · exact TwinLevel11P0016.complete _ (by simp [TwinLevel11P0016.p]) S hS dom prio
  · exact TwinLevel11P0017.complete _ (by simp [TwinLevel11P0017.p]) S hS dom prio
  · exact TwinLevel11P0018.complete _ (by simp [TwinLevel11P0018.p]) S hS dom prio
  · exact TwinLevel11P0019.complete _ (by simp [TwinLevel11P0019.p]) S hS dom prio
  · exact TwinLevel11P0020.complete _ (by simp [TwinLevel11P0020.p]) S hS dom prio
  · exact TwinLevel11P0021.complete _ (by simp [TwinLevel11P0021.p]) S hS dom prio
  · exact TwinLevel11P0022.complete _ (by simp [TwinLevel11P0022.p]) S hS dom prio
  · exact TwinLevel11P0023.complete _ (by simp [TwinLevel11P0023.p]) S hS dom prio
  · exact TwinLevel11P0024.complete _ (by simp [TwinLevel11P0024.p]) S hS dom prio
  · exact TwinLevel11P0025.complete _ (by simp [TwinLevel11P0025.p]) S hS dom prio
  · exact TwinLevel11P0026.complete _ (by simp [TwinLevel11P0026.p]) S hS dom prio
  · exact TwinLevel11P0027.complete _ (by simp [TwinLevel11P0027.p]) S hS dom prio
  · exact TwinLevel11P0028.complete _ (by simp [TwinLevel11P0028.p]) S hS dom prio
  · exact TwinLevel11P0029.complete _ (by simp [TwinLevel11P0029.p]) S hS dom prio
  · exact TwinLevel11P0030.complete _ (by simp [TwinLevel11P0030.p]) S hS dom prio
  · exact TwinLevel11P0031.complete _ (by simp [TwinLevel11P0031.p]) S hS dom prio
  · exact TwinLevel11P0032.complete _ (by simp [TwinLevel11P0032.p]) S hS dom prio
  · exact TwinLevel11P0033.complete _ (by simp [TwinLevel11P0033.p]) S hS dom prio
  · exact TwinLevel11P0034.complete _ (by simp [TwinLevel11P0034.p]) S hS dom prio
  · exact TwinLevel11P0035.complete _ (by simp [TwinLevel11P0035.p]) S hS dom prio
  · exact TwinLevel11P0036.complete _ (by simp [TwinLevel11P0036.p]) S hS dom prio
  · exact TwinLevel11P0037.complete _ (by simp [TwinLevel11P0037.p]) S hS dom prio
  · exact TwinLevel11P0038.complete _ (by simp [TwinLevel11P0038.p]) S hS dom prio
  · exact TwinLevel11P0039.complete _ (by simp [TwinLevel11P0039.p]) S hS dom prio
  · exact TwinLevel11P0040.complete _ (by simp [TwinLevel11P0040.p]) S hS dom prio
  · exact TwinLevel11P0041.complete _ (by simp [TwinLevel11P0041.p]) S hS dom prio
  · exact TwinLevel11P0042.complete _ (by simp [TwinLevel11P0042.p]) S hS dom prio
  · exact TwinLevel11P0043.complete _ (by simp [TwinLevel11P0043.p]) S hS dom prio
  · exact TwinLevel11P0044.complete _ (by simp [TwinLevel11P0044.p]) S hS dom prio
  · exact TwinLevel11P0045.complete _ (by simp [TwinLevel11P0045.p]) S hS dom prio
  · exact TwinLevel11P0046.complete _ (by simp [TwinLevel11P0046.p]) S hS dom prio
  · exact TwinLevel11P0047.complete _ (by simp [TwinLevel11P0047.p]) S hS dom prio
  · exact TwinLevel11P0048.complete _ (by simp [TwinLevel11P0048.p]) S hS dom prio
  · exact TwinLevel11P0049.complete _ (by simp [TwinLevel11P0049.p]) S hS dom prio
  · exact TwinLevel11P0050.complete _ (by simp [TwinLevel11P0050.p]) S hS dom prio
  · exact TwinLevel11P0051.complete _ (by simp [TwinLevel11P0051.p]) S hS dom prio
  · exact TwinLevel11P0052.complete _ (by simp [TwinLevel11P0052.p]) S hS dom prio
  · exact TwinLevel11P0053.complete _ (by simp [TwinLevel11P0053.p]) S hS dom prio
  · exact TwinLevel11P0054.complete _ (by simp [TwinLevel11P0054.p]) S hS dom prio
  · exact TwinLevel11P0055.complete _ (by simp [TwinLevel11P0055.p]) S hS dom prio
  · exact TwinLevel11P0056.complete _ (by simp [TwinLevel11P0056.p]) S hS dom prio
  · exact TwinLevel11P0057.complete _ (by simp [TwinLevel11P0057.p]) S hS dom prio
  · exact TwinLevel11P0058.complete _ (by simp [TwinLevel11P0058.p]) S hS dom prio
  · exact TwinLevel11P0059.complete _ (by simp [TwinLevel11P0059.p]) S hS dom prio
end TwinLevel11
#print axioms TwinLevel11.all_parents
