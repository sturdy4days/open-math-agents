import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify4_001
private def masks : Array ℕ := #[6, 9, 9, 6]
private def tags : Array Witness := #[.undominated 0, .undominated 3, .undominated 2, .permutes 787 2228321, .undominated 1, .permutes 787 3276865, .permutes 504 3211393, .gap 1 4, .permutes 504 4227170, .permutes 787 4197441, .gap 2 3, .permutes 787 134209, .permutes 960 134209]
private def supply := witnessAt tags 0xc7aba98076543210 4
private def pass (s : ℕ) := fastWitness 10 4 Terminal18.target 51 words5 masks s (supply s)

private theorem run0 : span pass 0 16 = true := by decide +kernel

theorem checked : rowStep 4 51 words5 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify4_001
end EarlyRamsey
