import StackTerminal

namespace EarlyRamsey
open BBHExtension SimpleGraph

def lastWords : List ℕ := [Terminal18.parent 0,Terminal18.parent 1,Terminal18.parent 2]

abbrev codeStep (k : ℕ) (parentCodes childCodes : List ℕ) :=
  selectedRows (decode 10 Terminal18.target) priorityRow
    (parentCodes.map (decode k)) (childCodes.map (decode (k+1)))

/-- The five consecutive intermediate atlas transitions suffice together with
the order-thirteen frontier and the verified terminal proof. -/
theorem after_thirteen (L13 L14 L15 L16 L17 : List ℕ)
    (front : ∀ H : SimpleGraph (Fin 13),
      Maximal (fun D : SimpleGraph (Fin 13) => D.CliqueFree 3) H → (¬ decode 10 Terminal18.target ⊑ Hᶜ) →
      ∃ p ∈ L13, Nonempty (H ≃g decode 13 p))
    (h13 : codeStep 13 L13 L14) (h14 : codeStep 14 L14 L15) (h15 : codeStep 15 L15 L16)
    (h16 : codeStep 16 L16 L17) (h17 : codeStep 17 L17 lastWords) :
    ∀ H : SimpleGraph (Fin 19), H.CliqueFree 3 → decode 10 Terminal18.target ⊑ Hᶜ := by
  let C : ℕ → List ℕ
    | 13 => L13
    | 14 => L14
    | 15 => L15
    | 16 => L16
    | 17 => L17
    | 18 => lastWords
    | _ => []
  apply order19_of_remaining (base:=13) (by decide) (fun k => (C k).map (decode k))
  · intro H maxH avoid
    obtain ⟨p,mem,iso⟩ := front H maxH avoid
    exact ⟨decode 13 p,List.mem_map_of_mem mem,iso⟩
  · intro k lo hi
    have cases : k=13 ∨ k=14 ∨ k=15 ∨ k=16 ∨ k=17 := by omega
    rcases cases with rfl|rfl|rfl|rfl|rfl
    · exact h13
    · exact h14
    · exact h15
    · exact h16
    · exact h17
  · intro D mem
    obtain ⟨p,hp,rfl⟩ := List.mem_map.mp mem
    change p ∈ lastWords at hp
    simp only [lastWords,List.mem_cons,List.not_mem_nil,or_false] at hp
    rcases hp with rfl|rfl|rfl
    · exact ⟨0,⟨RelIso.refl _⟩⟩
    · exact ⟨1,⟨RelIso.refl _⟩⟩
    · exact ⟨2,⟨RelIso.refl _⟩⟩

end EarlyRamsey

#print axioms EarlyRamsey.after_thirteen
