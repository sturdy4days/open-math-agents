import LastData

namespace Terminal18
open SimpleGraph BBHExtension

/-- Every avoiding maximal graph on 18 vertices is one of the three extremal graphs. -/
def Classification : Prop :=
  ∀ P : SimpleGraph (Fin 18), Maximal (fun D : SimpleGraph (Fin 18) => D.CliqueFree 3) P →
    ¬ decode 10 target ⊑ Pᶜ → ∃ i : Fin 3, Nonempty (P ≃g decode 18 (parent i))

/-- If every augmentation of the three extremal graphs is good, their order-18
classification settles the full order-19 statement. -/
theorem universal_of_classification (catalog : Classification)
    (exts : ∀ (i : Fin 3) (S : Finset (Fin 18)),
      decode 10 target ⊑ (extend (decode 18 (parent i)) S)ᶜ) :
    ∀ H : SimpleGraph (Fin 19), H.CliqueFree 3 → decode 10 target ⊑ Hᶜ := by
  classical
  intro H tri
  obtain ⟨X,le,max⟩ := Finite.exists_le_maximal (p := fun D : SimpleGraph (Fin 19) => D.CliqueFree 3) tri
  suffices intermediate : decode 10 target ⊑ Xᶜ from
    intermediate.mono_right (compl_le_compl le)
  by_contra miss
  obtain ⟨P,S,maxP,missP,_,eq⟩ := BBHExtension.parent (decode 10 target) X max miss
  obtain ⟨i,⟨iso⟩⟩ := catalog P maxP missP
  let j := renamedExtension iso S
  apply miss
  rw [eq]
  exact (exts i (S.map iso.toEquiv.toEmbedding)).trans
    ⟨(SimpleGraph.Embedding.complEquiv j.symm.toEmbedding).toCopy⟩

end Terminal18
