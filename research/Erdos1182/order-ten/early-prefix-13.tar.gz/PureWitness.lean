import PurePriority

namespace BBHExtension
open SimpleGraph

private theorem old_labels {k} (p : Equiv.Perm (Fin (k+1))) (x : Fin (k+1))
    (hx : x ≠ p 0) : ∃ i : Fin k, p i.succ = x := by
  have ne : p.symm x ≠ 0 := fun eq => hx (p.symm_apply_eq.mp eq)
  obtain ⟨i,hi⟩ := Fin.exists_succ_eq_of_ne_zero ne
  exact ⟨i,p.eq_symm_apply.mp hi⟩

/-- For a triangle-free child, deleting a vertex leaves a maximal graph iff
every surviving nonedge has a surviving common neighbor. This criterion uses
only four vertex labels and requires no enumeration of label permutations. -/
theorem pureDeletion_iff_common_neighbors {k} (H : SimpleGraph (Fin (k+1))) (free : H.CliqueFree 3) :
    hasPureDeletion H ↔ ∃ u, ∀ i, i ≠ u → ∀ j, j ≠ u → i ≠ j → ¬H.Adj i j →
       ∃ w, w ≠ u ∧ H.Adj i w ∧ H.Adj j w := by
  classical
  constructor
  · rintro ⟨p,maxP⟩
    refine ⟨p 0, ?_⟩
    intro i hi j hj diff miss
    obtain ⟨a,rfl⟩ := old_labels p i hi
    obtain ⟨b,rfl⟩ := old_labels p j hj
    obtain ⟨c,ac,bc⟩ := saturation_witness maxP (i := a) (j := b)
      (fun eq => diff (congrArg (fun y : Fin k => p y.succ) eq)) miss
    exact ⟨p c.succ,p.injective.ne (Fin.ne_of_lt (Fin.succ_pos _)).symm,ac,bc⟩
  · rintro ⟨u,sat⟩
    let p := Equiv.swap 0 u
    have hp : p 0 = u := Equiv.swap_apply_left _ _
    let inc : Fin k ↪ Fin (k+1) := (⟨Fin.succ, Fin.succ_injective _⟩ : Fin k ↪ Fin (k+1)).trans p.toEmbedding
    refine ⟨p, maximal_of_saturation _ (free.comap ⟨(SimpleGraph.Embedding.comap inc H).toCopy⟩) ?_⟩
    intro i j ne no
    have nz (x : Fin k) : p x.succ ≠ u := by
      rw [←hp]
      exact p.injective.ne (Fin.ne_of_lt (Fin.succ_pos _)).symm
    obtain ⟨w,hw,iw,jw⟩ := sat (p i.succ) (nz i) (p j.succ) (nz j)
      (inc.injective.ne ne) no
    obtain ⟨c,hc⟩ := old_labels p w (by simpa only [hp] using hw)
    exact ⟨c, by simpa only [SimpleGraph.comap_adj, hc] using iw,
      by simpa only [SimpleGraph.comap_adj, hc] using jw⟩

end BBHExtension

#print axioms BBHExtension.pureDeletion_iff_common_neighbors
