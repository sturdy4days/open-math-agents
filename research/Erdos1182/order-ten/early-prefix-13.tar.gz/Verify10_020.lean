import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify10_020
private def masks : Array ℕ := #[66, 897, 960, 960, 960, 960, 61, 62, 62, 62]
private def tags : Array Witness := #[.undominated 0, .undominated 2, .undominated 3, .undominated 4, .undominated 5, .permutes 4371416900207765 6935822672896065, .permutes 4371416900241555 6935822772476993, .gap 1 8, .undominated 1, .undominated 7, .permutes 2247624159526912 7962981242637313, .gap 1 3, .gap 1 4, .gap 1 5, .gap 1 6, .gap 2 7, .undominated 8, .undominated 6, .gap 1 9, .permutes 2187855526953985 9264797508079617, .permutes 2187855526953985 9264798581820417, .permutes 4371415897802755 11583634278615041, .permutes 2187855526953985 9264799655529473, .permutes 4371415897802755 11583635352324097, .permutes 4371415897802755 11583635385845761, .permutes 1095009688454144 257597312732200, .permutes 2187855526953985 9264800728222721, .permutes 4371415897802755 11583636425017345, .permutes 4371415897802755 11583636458539009, .permutes 1095009688454144 257597280226344, .permutes 4371415897802755 11583636491044865, .permutes 1095009688454144 257597246704680, .permutes 1095009688454144 257597213151272, .gap 7 8, .permutes 2187855526953985 10390663055183873, .permutes 2187855526953985 10390664128924673, .permutes 4371415897802755 11548484266264577, .permutes 2187855526953985 10390665202633729, .permutes 4371415897802755 11548485339973633, .permutes 4371415897802755 11548485373495297, .permutes 1095009688454144 257562952993833, .permutes 2187855526953985 10390666275326977, .permutes 4371415897802755 11548486412666881, .permutes 4371415897802755 11548486446188545, .permutes 1095009688454144 257562920487977, .permutes 4371415897802755 11548486478694401, .permutes 1095009688454144 257562886966313, .permutes 1095009688454144 257562853412905, .gap 7 9, .undominated 9, .gap 1 10, .permutes 1095009688454144 8243313624911969, .permutes 1095009688454144 8243313624910977, .permutes 3626182422323200 7892369803579489, .permutes 1095009688454144 8243313624878241, .permutes 3626182422323200 7892369770026081, .permutes 3626182422323200 7892369736471681, .permutes 2230329106235392 359748918613123, .permutes 1095009688454144 8243313623829697, .permutes 3626182422323200 7892368696285281, .permutes 3626182422323200 7892368662730881, .permutes 2230329106235392 359714558875779, .permutes 3626182422323200 7892367588989089, .permutes 2230329106235392 359680199137443, .permutes 2230329106235392 359645839399076, .permutes 2187855526953985 11515463450398721, .permutes 2187855526953985 11515464524139521, .permutes 4371415897802755 10422618719160321, .permutes 2187855526953985 11515465597848577, .permutes 4371415897802755 10422619792869377, .permutes 4371415897802755 10422619826391041, .permutes 1095009688454144 256463441366058, .permutes 2187855526953985 11515466670541825, .permutes 4371415897802755 10422620865562625, .permutes 4371415897802755 10422620899084289, .permutes 1095009688454144 256463408860202, .permutes 4371415897802755 10422620931590145, .permutes 1095009688454144 256463375338538, .permutes 1095009688454144 256463341785130, .gap 7 10, .permutes 1095009688454144 8209228764450913, .permutes 1095009688454144 8209228764449921, .permutes 3626182422323200 7891270293000289, .permutes 1095009688454144 8209228764417185, .permutes 3626182422323200 7891270259446881, .permutes 3626182422323200 7891270225892481, .permutes 2230329106235392 324564580078723, .permutes 1095009688454144 8209228763368641, .permutes 3626182422323200 7891269185706081, .permutes 3626182422323200 7891269152151681, .permutes 2230329106235392 324530220341379, .permutes 3626182422323200 7891268078409889, .permutes 2230329106235392 324495860603043, .permutes 2230329106235392 324461500864676, .permutes 1095009688454144 8174078752100449, .permutes 1095009688454144 8174078752099457, .permutes 3626182422323200 7890170781405281, .permutes 1095009688454144 8174078752066721, .permutes 3626182422323200 7890170747851873, .permutes 3626182422323200 7890170714297473, .permutes 2230329106235392 289380209038467, .permutes 1095009688454144 8174078751018177, .permutes 3626182422323200 7890169674111073, .permutes 3626182422323200 7890169640556673, .permutes 2230329106235392 289345849301123, .permutes 3626182422323200 7890168566814881, .permutes 2230329106235392 289311489562787, .permutes 2230329106235392 289277129824420, .permutes 4441923425174528 11584695101984865, .gap 2 3, .gap 2 4, .gap 2 5, .gap 2 6, .permutes 4441923622273025 11584695235120193, .embeds 71576909587719]
private def supply := witnessAt tags 0xe42f68b163058c182c60b163458d1a2c68b163058c182c60b163858e1c2c70b163058c182c60b163458d1a2c68b163058c182c60b161c5f11e1f680da1f700dc1f680da1f780de1f680da1f700dc1f680da1f800e01f680da1f700dc1f680da1f780de1f680da1f700dc1f680da476000e2c78b163058c182c60b163458d1a2c68b163058c182c60b163858e1c2c70b163058c182c60b163458d1a2c68b163058c182c60b16484890e498000e4b5800e4b5000e4b4800e4b4000e4b3800e4b3000e4b2800e4b2000e4b1800e4b1000e4b0800e4b0000e4af800e4af000e44480242c78b163058c182c60b163458d1a2c68b163058c182c60b163858e1c2c70b163058c182c60b163458d1a2c68b163058c182c60b161c810241d080241ee80241ee00241ed80241ed00241ec80241ec00241eb80241eb00241ea80241ea00241e980241e900241e880241e80024448000e2c78b163058c182c60b163458d1a2c68b163058c182c60b163858e1c2c70b163058c182c60b163458d1a2c68b163058c182c60b16c84890eca7800eca7000eca6800eca6000eca5800eca5000eca4800eca4000eca3800eca3000eca2800eca2000eca1800eca1000eca0800e44480642c78b163058c182c60b163458d1a2c68b163058c182c60b163858e1c2c70b163058c182c60b163458d1a2c68b163058c182c60b161d8b1641d080641e000641df80641df00641de80641de00641dd80641dd00641dc80641dc00641db80641db00641da80641da00641d98064458800e2c78b163058c182c60b163458d1a2c68b163058c182c60b163858e1c2c70b163058c182c60b163458d1a2c68b163058c182c60b16484890e498000e497800e497000e496800e496000e495800e495000e494800e494000e493800e493000e492800e492000e491800e491000e44480242c78b163058c182c60b163458d1a2c68b163058c182c60b163858e1c2c70b163058c182c60b163458d1a2c68b163058c182c60b161c810241d080241d000241cf80241cf00241ce80241ce00241cd80241cd00241cc80241cc00241cb80241cb00241ca80241ca00241c98024448000e2c7881630588182c60816345881a2c6881630588182c60816385881c2c7081630588182c60816345881a2c6881630588182c60816284880e18280020408004081000204080060c1800204080040810002040800810200020408004081000204080060c180020408004081000204080 7
private def pass (s : ℕ) := fastWitness 10 10 Terminal18.target 4277382578177 words11 masks s (supply s)

private theorem run5 : span pass 0 32 = true := by decide +kernel
private theorem run6 : span pass 32 32 = true := by decide +kernel
private theorem run4 : span pass 0 64 = true := span_add (a:=32) (b:=32) run5 run6
private theorem run8 : span pass 64 32 = true := by decide +kernel
private theorem run9 : span pass 96 32 = true := by decide +kernel
private theorem run7 : span pass 64 64 = true := span_add (a:=32) (b:=32) run8 run9
private theorem run3 : span pass 0 128 = true := span_add (a:=64) (b:=64) run4 run7
private theorem run12 : span pass 128 32 = true := by decide +kernel
private theorem run13 : span pass 160 32 = true := by decide +kernel
private theorem run11 : span pass 128 64 = true := span_add (a:=32) (b:=32) run12 run13
private theorem run15 : span pass 192 32 = true := by decide +kernel
private theorem run16 : span pass 224 32 = true := by decide +kernel
private theorem run14 : span pass 192 64 = true := span_add (a:=32) (b:=32) run15 run16
private theorem run10 : span pass 128 128 = true := span_add (a:=64) (b:=64) run11 run14
private theorem run2 : span pass 0 256 = true := span_add (a:=128) (b:=128) run3 run10
private theorem run20 : span pass 256 32 = true := by decide +kernel
private theorem run21 : span pass 288 32 = true := by decide +kernel
private theorem run19 : span pass 256 64 = true := span_add (a:=32) (b:=32) run20 run21
private theorem run23 : span pass 320 32 = true := by decide +kernel
private theorem run24 : span pass 352 32 = true := by decide +kernel
private theorem run22 : span pass 320 64 = true := span_add (a:=32) (b:=32) run23 run24
private theorem run18 : span pass 256 128 = true := span_add (a:=64) (b:=64) run19 run22
private theorem run27 : span pass 384 32 = true := by decide +kernel
private theorem run28 : span pass 416 32 = true := by decide +kernel
private theorem run26 : span pass 384 64 = true := span_add (a:=32) (b:=32) run27 run28
private theorem run30 : span pass 448 32 = true := by decide +kernel
private theorem run31 : span pass 480 32 = true := by decide +kernel
private theorem run29 : span pass 448 64 = true := span_add (a:=32) (b:=32) run30 run31
private theorem run25 : span pass 384 128 = true := span_add (a:=64) (b:=64) run26 run29
private theorem run17 : span pass 256 256 = true := span_add (a:=128) (b:=128) run18 run25
private theorem run1 : span pass 0 512 = true := span_add (a:=256) (b:=256) run2 run17
private theorem run36 : span pass 512 32 = true := by decide +kernel
private theorem run37 : span pass 544 32 = true := by decide +kernel
private theorem run35 : span pass 512 64 = true := span_add (a:=32) (b:=32) run36 run37
private theorem run39 : span pass 576 32 = true := by decide +kernel
private theorem run40 : span pass 608 32 = true := by decide +kernel
private theorem run38 : span pass 576 64 = true := span_add (a:=32) (b:=32) run39 run40
private theorem run34 : span pass 512 128 = true := span_add (a:=64) (b:=64) run35 run38
private theorem run43 : span pass 640 32 = true := by decide +kernel
private theorem run44 : span pass 672 32 = true := by decide +kernel
private theorem run42 : span pass 640 64 = true := span_add (a:=32) (b:=32) run43 run44
private theorem run46 : span pass 704 32 = true := by decide +kernel
private theorem run47 : span pass 736 32 = true := by decide +kernel
private theorem run45 : span pass 704 64 = true := span_add (a:=32) (b:=32) run46 run47
private theorem run41 : span pass 640 128 = true := span_add (a:=64) (b:=64) run42 run45
private theorem run33 : span pass 512 256 = true := span_add (a:=128) (b:=128) run34 run41
private theorem run51 : span pass 768 32 = true := by decide +kernel
private theorem run52 : span pass 800 32 = true := by decide +kernel
private theorem run50 : span pass 768 64 = true := span_add (a:=32) (b:=32) run51 run52
private theorem run54 : span pass 832 32 = true := by decide +kernel
private theorem run55 : span pass 864 32 = true := by decide +kernel
private theorem run53 : span pass 832 64 = true := span_add (a:=32) (b:=32) run54 run55
private theorem run49 : span pass 768 128 = true := span_add (a:=64) (b:=64) run50 run53
private theorem run58 : span pass 896 32 = true := by decide +kernel
private theorem run59 : span pass 928 32 = true := by decide +kernel
private theorem run57 : span pass 896 64 = true := span_add (a:=32) (b:=32) run58 run59
private theorem run61 : span pass 960 32 = true := by decide +kernel
private theorem run62 : span pass 992 32 = true := by decide +kernel
private theorem run60 : span pass 960 64 = true := span_add (a:=32) (b:=32) run61 run62
private theorem run56 : span pass 896 128 = true := span_add (a:=64) (b:=64) run57 run60
private theorem run48 : span pass 768 256 = true := span_add (a:=128) (b:=128) run49 run56
private theorem run32 : span pass 512 512 = true := span_add (a:=256) (b:=256) run33 run48
private theorem run0 : span pass 0 1024 = true := span_add (a:=512) (b:=512) run1 run32

theorem checked : rowStep 10 4277382578177 words11 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify10_020
end EarlyRamsey
