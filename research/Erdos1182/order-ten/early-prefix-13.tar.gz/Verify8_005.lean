import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify8_005
private def masks : Array ℕ := #[66, 129, 192, 192, 192, 192, 61, 62]
private def tags : Array Witness := #[.undominated 0, .undominated 2, .undominated 3, .undominated 4, .undominated 5, .permutes 16775020545 249314806818, .permutes 16775020545 282600803393, .gap 1 8, .undominated 1, .undominated 7, .permutes 17171578880 7973813488641, .gap 1 3, .gap 1 4, .gap 1 5, .gap 1 6, .gap 2 7, .permutes 17171578880 9037891636226, .undominated 6, .gap 2 3, .gap 2 4, .gap 2 5, .gap 2 6, .permutes 34085011457 9036817894465, .permutes 68451041280 282600803393]
private def supply := witnessAt tags 0xbae4b5b16c62d8b5b56d6adab5b16c62d8b5b96e72dcb5b16c62d8b5b56d6adab5b16c62d8b59d7679e4091e6099e4091e80a1e4091e6099e4091ea0a9e4091e6099e4091e80a1e4091e6099e40946003ade85b16862d885b5686ada85b16862d885b96872dc85b16862d885b5686ada85b16862d885a928398a008420108400842018c600842010840084202108008420108400842018c60084201084008420 5
private def pass (s : ℕ) := fastWitness 10 8 Terminal18.target 132022273 words9 masks s (supply s)

private theorem run3 : span pass 0 32 = true := by decide +kernel
private theorem run4 : span pass 32 32 = true := by decide +kernel
private theorem run2 : span pass 0 64 = true := span_add (a:=32) (b:=32) run3 run4
private theorem run6 : span pass 64 32 = true := by decide +kernel
private theorem run7 : span pass 96 32 = true := by decide +kernel
private theorem run5 : span pass 64 64 = true := span_add (a:=32) (b:=32) run6 run7
private theorem run1 : span pass 0 128 = true := span_add (a:=64) (b:=64) run2 run5
private theorem run10 : span pass 128 32 = true := by decide +kernel
private theorem run11 : span pass 160 32 = true := by decide +kernel
private theorem run9 : span pass 128 64 = true := span_add (a:=32) (b:=32) run10 run11
private theorem run13 : span pass 192 32 = true := by decide +kernel
private theorem run14 : span pass 224 32 = true := by decide +kernel
private theorem run12 : span pass 192 64 = true := span_add (a:=32) (b:=32) run13 run14
private theorem run8 : span pass 128 128 = true := span_add (a:=64) (b:=64) run9 run12
private theorem run0 : span pass 0 256 = true := span_add (a:=128) (b:=128) run1 run8

theorem checked : rowStep 8 132022273 words9 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify8_005
end EarlyRamsey
