import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify6_003
private def masks : Array ℕ := #[14, 49, 49, 49, 14, 14]
private def tags : Array Witness := #[.undominated 0, .undominated 4, .undominated 2, .permutes 946323 6614517792, .undominated 1, .permutes 946323 6614486048, .undominated 3, .permutes 946323 3294789761, .permutes 946323 6613438496, .permutes 946323 4368531553, .permutes 946323 4402085953, .permutes 507840 4397734049, .gap 1 5, .undominated 5, .permutes 946323 4401960000, .permutes 946323 5406556354, .permutes 946323 4368405600, .permutes 946323 5406523587, .permutes 946323 3294658693, .permutes 514624 205687873, .permutes 946323 3294663808, .permutes 946323 5405475012, .permutes 946323 4368400485, .permutes 514624 204640321, .permutes 946323 4401954885, .permutes 514624 203591777, .gap 1 6, .permutes 946323 4400912448, .permutes 946323 6480298146, .permutes 946323 4367358048, .permutes 946323 6480265379, .permutes 946323 3293610118, .permutes 514624 172166209, .permutes 946323 3293616256, .permutes 946323 6479216804, .permutes 946323 4367351910, .permutes 514624 171118657, .permutes 946323 4400906310, .permutes 514624 170070113, .permutes 507840 6611275874, .permutes 946323 6614515746, .gap 2 3, .permutes 946323 6614482979, .permutes 514624 135370914, .gap 2 4, .permutes 946323 6613434404, .permutes 514624 101849250, .permutes 514624 68294819, .permutes 2064384 206703681]
private def supply := witnessAt tags 0xc0ca6fa6eb2db2ba6aa689c031a9a59238a181f79d71b04068c6585d65544d24503ce34030b2842422041c61440c2040 6
private def pass (s : ℕ) := fastWitness 10 6 Terminal18.target 15243 words7 masks s (supply s)

private theorem run1 : span pass 0 32 = true := by decide +kernel
private theorem run2 : span pass 32 32 = true := by decide +kernel
private theorem run0 : span pass 0 64 = true := span_add (a:=32) (b:=32) run1 run2

theorem checked : rowStep 6 15243 words7 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify6_003
end EarlyRamsey
