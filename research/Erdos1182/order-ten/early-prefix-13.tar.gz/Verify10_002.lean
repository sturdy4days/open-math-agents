import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify10_002
private def masks : Array ℕ := #[640, 640, 768, 768, 768, 768, 768, 259, 252, 127]
private def tags : Array Witness := #[.undominated 0, .undominated 1, .undominated 2, .undominated 3, .undominated 4, .undominated 5, .undominated 6, .permutes 8954302171217920 361809360097384, .permutes 4485800215445504 11269177273879617, .gap 1 9, .gap 2 9, .permutes 7868088096653312 10487150536758403, .gap 3 8, .gap 4 8, .gap 5 8, .gap 6 8, .gap 7 8, .undominated 9, .gap 8 10, .undominated 7, .undominated 8, .gap 1 4, .gap 1 3, .gap 1 5, .gap 1 6, .gap 1 7, .gap 2 3, .permutes 9006651377975296 11584701642932289, .gap 1 2, .permutes 9006925182140416 11584462233144385, .embeds 71576909587719]
private def supply := witnessAt tags 0xf7396b7395af396b7397bf396b7395af396b7398c7396b7395af396b7397bf396b7395af396b7399cf396b7395af396b7397bf396b7395af396b7398c7396b7395af396b7397bf396b7395af396b738965b56b56d5adab6b5ed7bdaf6b56d5adab6b62d8c5b16b56d5adab6b5ed7bdaf6b56d5adab6b66d9cdb36b56d5adab6b5ed7bdaf6b56d5adab6b62d8c5b16b56d5adab6b5ed7bdaf6b56d5adab6b6add4f396b7395af396b7397bf396b7395af396b7398c7396b7395af396b7397bf396b7395af396b7399cf396b7395af396b7397bf396b7395af396b7398c7396b7395af396b7397bf396b7395af396b739b95b53b56d3adab3b5ed3bdaf3b56d3adab3b62d3c5b13b56d3adab3b5ed3bdaf3b56d3adab3b66d3cdb33b56d3adab3b5ed3bdaf3b56d3adab3b62d3c5b13b56d3adab3b5ed3bdaf3b56d3adab3a529392549625496a5496254972549625496a549625497a549625496a5496254972549625496a5496254982549625496a5496254972549625496a549625497a549625496a5496254972549625496a5496255160020680206002070020600206802060020780206002068020600207002060020680206002080020600206802060020700206002068020600207802060020680206002070020600206802060020580204a9281084218c6310842210841084218c6310842294a51084218c6310842210841084218c6310842318c61084218c6310842210841084218c6310842294a51084218c6310842210841084218c63108423802010020180201002020020100201802010020280201002018020100202002010020180201002030020100201802010020200201002018020100202802010020180201002020020100201802010020 5
private def pass (s : ℕ) := fastWitness 10 10 Terminal18.target 8795025571840 words11 masks s (supply s)

private theorem run5 : span pass 0 32 = true := by decide +kernel
private theorem run6 : span pass 32 32 = true := by decide +kernel
private theorem run4 : span pass 0 64 = true := span_add (a:=32) (b:=32) run5 run6
private theorem run8 : span pass 64 32 = true := by decide +kernel
private theorem run9 : span pass 96 32 = true := by decide +kernel
private theorem run7 : span pass 64 64 = true := span_add (a:=32) (b:=32) run8 run9
private theorem run3 : span pass 0 128 = true := span_add (a:=64) (b:=64) run4 run7
private theorem run12 : span pass 128 32 = true := by decide +kernel
private theorem run13 : span pass 160 32 = true := by decide +kernel
private theorem run11 : span pass 128 64 = true := span_add (a:=32) (b:=32) run12 run13
private theorem run15 : span pass 192 32 = true := by decide +kernel
private theorem run16 : span pass 224 32 = true := by decide +kernel
private theorem run14 : span pass 192 64 = true := span_add (a:=32) (b:=32) run15 run16
private theorem run10 : span pass 128 128 = true := span_add (a:=64) (b:=64) run11 run14
private theorem run2 : span pass 0 256 = true := span_add (a:=128) (b:=128) run3 run10
private theorem run20 : span pass 256 32 = true := by decide +kernel
private theorem run21 : span pass 288 32 = true := by decide +kernel
private theorem run19 : span pass 256 64 = true := span_add (a:=32) (b:=32) run20 run21
private theorem run23 : span pass 320 32 = true := by decide +kernel
private theorem run24 : span pass 352 32 = true := by decide +kernel
private theorem run22 : span pass 320 64 = true := span_add (a:=32) (b:=32) run23 run24
private theorem run18 : span pass 256 128 = true := span_add (a:=64) (b:=64) run19 run22
private theorem run27 : span pass 384 32 = true := by decide +kernel
private theorem run28 : span pass 416 32 = true := by decide +kernel
private theorem run26 : span pass 384 64 = true := span_add (a:=32) (b:=32) run27 run28
private theorem run30 : span pass 448 32 = true := by decide +kernel
private theorem run31 : span pass 480 32 = true := by decide +kernel
private theorem run29 : span pass 448 64 = true := span_add (a:=32) (b:=32) run30 run31
private theorem run25 : span pass 384 128 = true := span_add (a:=64) (b:=64) run26 run29
private theorem run17 : span pass 256 256 = true := span_add (a:=128) (b:=128) run18 run25
private theorem run1 : span pass 0 512 = true := span_add (a:=256) (b:=256) run2 run17
private theorem run36 : span pass 512 32 = true := by decide +kernel
private theorem run37 : span pass 544 32 = true := by decide +kernel
private theorem run35 : span pass 512 64 = true := span_add (a:=32) (b:=32) run36 run37
private theorem run39 : span pass 576 32 = true := by decide +kernel
private theorem run40 : span pass 608 32 = true := by decide +kernel
private theorem run38 : span pass 576 64 = true := span_add (a:=32) (b:=32) run39 run40
private theorem run34 : span pass 512 128 = true := span_add (a:=64) (b:=64) run35 run38
private theorem run43 : span pass 640 32 = true := by decide +kernel
private theorem run44 : span pass 672 32 = true := by decide +kernel
private theorem run42 : span pass 640 64 = true := span_add (a:=32) (b:=32) run43 run44
private theorem run46 : span pass 704 32 = true := by decide +kernel
private theorem run47 : span pass 736 32 = true := by decide +kernel
private theorem run45 : span pass 704 64 = true := span_add (a:=32) (b:=32) run46 run47
private theorem run41 : span pass 640 128 = true := span_add (a:=64) (b:=64) run42 run45
private theorem run33 : span pass 512 256 = true := span_add (a:=128) (b:=128) run34 run41
private theorem run51 : span pass 768 32 = true := by decide +kernel
private theorem run52 : span pass 800 32 = true := by decide +kernel
private theorem run50 : span pass 768 64 = true := span_add (a:=32) (b:=32) run51 run52
private theorem run54 : span pass 832 32 = true := by decide +kernel
private theorem run55 : span pass 864 32 = true := by decide +kernel
private theorem run53 : span pass 832 64 = true := span_add (a:=32) (b:=32) run54 run55
private theorem run49 : span pass 768 128 = true := span_add (a:=64) (b:=64) run50 run53
private theorem run58 : span pass 896 32 = true := by decide +kernel
private theorem run59 : span pass 928 32 = true := by decide +kernel
private theorem run57 : span pass 896 64 = true := span_add (a:=32) (b:=32) run58 run59
private theorem run61 : span pass 960 32 = true := by decide +kernel
private theorem run62 : span pass 992 32 = true := by decide +kernel
private theorem run60 : span pass 960 64 = true := span_add (a:=32) (b:=32) run61 run62
private theorem run56 : span pass 896 128 = true := span_add (a:=64) (b:=64) run57 run60
private theorem run48 : span pass 768 256 = true := span_add (a:=128) (b:=128) run49 run56
private theorem run32 : span pass 512 512 = true := span_add (a:=256) (b:=256) run33 run48
private theorem run0 : span pass 0 1024 = true := span_add (a:=512) (b:=512) run1 run32

theorem checked : rowStep 10 8795025571840 words11 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify10_002
end EarlyRamsey
