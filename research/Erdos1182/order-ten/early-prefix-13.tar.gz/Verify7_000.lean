import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify7_000
private def masks : Array ℕ := #[64, 64, 64, 64, 64, 64, 63]
private def tags : Array Witness := #[.undominated 0, .undominated 1, .undominated 2, .undominated 3, .undominated 4, .undominated 5, .permutes 134184960 7722896449, .permutes 266338304 240724872257, .gap 1 2, .gap 1 3, .gap 1 4, .gap 1 5, .gap 1 6, .permutes 266338304 7722896449]
private def supply := witnessAt tags 0xd889988aa889988bb889988aa889988cc889988aa889988bb889988aa88998876010201030102010401020103010201050102010301020104010201030102010 4
private def pass (s : ℕ) := fastWitness 10 7 Terminal18.target 2064384 words8 masks s (supply s)

private theorem run2 : span pass 0 32 = true := by decide +kernel
private theorem run3 : span pass 32 32 = true := by decide +kernel
private theorem run1 : span pass 0 64 = true := span_add (a:=32) (b:=32) run2 run3
private theorem run5 : span pass 64 32 = true := by decide +kernel
private theorem run6 : span pass 96 32 = true := by decide +kernel
private theorem run4 : span pass 64 64 = true := span_add (a:=32) (b:=32) run5 run6
private theorem run0 : span pass 0 128 = true := span_add (a:=64) (b:=64) run1 run4

theorem checked : rowStep 7 2064384 words8 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify7_000
end EarlyRamsey
