import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify8_002
private def masks : Array ℕ := #[160, 160, 192, 192, 192, 67, 60, 31]
private def tags : Array Witness := #[.undominated 0, .undominated 1, .undominated 2, .undominated 3, .undominated 4, .permutes 16773514304 282462425190, .permutes 8530063360 9002491710529, .gap 1 7, .gap 2 7, .permutes 14931206656 7973613114499, .gap 3 6, .gap 4 6, .gap 5 6, .undominated 7, .gap 6 8, .undominated 5, .undominated 6, .gap 1 4, .gap 1 3, .gap 1 5, .gap 2 3, .permutes 17076617216 9043055906913, .gap 1 2, .permutes 17171578880 9043059018817, .permutes 68451041280 282600803393]
private def supply := witnessAt tags 0xc5ad295ad18dad295ad39dad295ad18dad295ac754a92946518ca3294e539ca72946518ca32952573dad295ad18dad295ad39dad295ad18dad295ad574a8f9464f8ca2f94e4f9ca6f9464f8ca2f8420f71d0751d0759d0751d0761d0751d0759d0751d0d50020580205002060020500205802050020480203a0e61084218c6310842210841084218c63108422802010020180201002020020100201802010020 5
private def pass (s : ℕ) := fastWitness 10 8 Terminal18.target 66980864 words9 masks s (supply s)

private theorem run3 : span pass 0 32 = true := by decide +kernel
private theorem run4 : span pass 32 32 = true := by decide +kernel
private theorem run2 : span pass 0 64 = true := span_add (a:=32) (b:=32) run3 run4
private theorem run6 : span pass 64 32 = true := by decide +kernel
private theorem run7 : span pass 96 32 = true := by decide +kernel
private theorem run5 : span pass 64 64 = true := span_add (a:=32) (b:=32) run6 run7
private theorem run1 : span pass 0 128 = true := span_add (a:=64) (b:=64) run2 run5
private theorem run10 : span pass 128 32 = true := by decide +kernel
private theorem run11 : span pass 160 32 = true := by decide +kernel
private theorem run9 : span pass 128 64 = true := span_add (a:=32) (b:=32) run10 run11
private theorem run13 : span pass 192 32 = true := by decide +kernel
private theorem run14 : span pass 224 32 = true := by decide +kernel
private theorem run12 : span pass 192 64 = true := span_add (a:=32) (b:=32) run13 run14
private theorem run8 : span pass 128 128 = true := span_add (a:=64) (b:=64) run9 run12
private theorem run0 : span pass 0 256 = true := span_add (a:=128) (b:=128) run1 run8

theorem checked : rowStep 8 66980864 words9 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify8_002
end EarlyRamsey
