import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify10_013
private def masks : Array ℕ := #[608, 672, 832, 832, 672, 275, 141, 338, 172, 31]
private def tags : Array Witness := #[.undominated 0, .undominated 1, .undominated 2, .undominated 3, .undominated 4, .permutes 17485535040021746 356350283752678, .undominated 7, .permutes 1097769268600832 11547078937384001, .gap 1 9, .permutes 1097769268600832 11547078937381025, .permutes 2079709988519968 360956705309858, .undominated 8, .permutes 1097769268600832 11583361714819169, .gap 1 8, .permutes 1097769268600832 11583361714818177, .permutes 2079709988519968 362020815996035, .undominated 9, .permutes 2783812118904960 8243253591804929, .permutes 2783812118904960 7116289574340609, .permutes 1097781918090240 11269176232676417, .permutes 2783812118904960 7116289541834753, .permutes 1097781918090240 11269176231628865, .permutes 7005507837231112 7116348630209601, .permutes 2783812118904960 362020814851298, .permutes 2783812118904960 8243253494287361, .permutes 7005507837231112 8243313721413729, .permutes 1097781918090240 11269176232578209, .permutes 2783812118904960 360956703180995, .permutes 1097781918090240 11269176231530657, .permutes 2783812118904960 360956669626564, .permutes 2783812118904960 362020714188005, .permutes 2225184465584128 362015414716615, .permutes 2089557274923264 9365780713211042, .gap 2 7, .gap 5 7, .permutes 3626182422323200 7116280079422529, .undominated 5, .gap 6 7, .permutes 2089557274923264 10492813416596611, .gap 3 6, .gap 4 6, .undominated 6, .permutes 3626182422323200 8243245105614945, .permutes 1660720287367168 11512204604117090, .gap 2 9, .gap 3 8, .gap 6 10, .gap 2 4, .gap 2 3, .gap 3 5, .gap 8 10, .gap 1 5, .gap 1 2, .gap 1 4, .gap 1 3, .permutes 2222913928429568 11512204742461441, .permutes 7005507837231112 9365956936635456, .permutes 2230329106235392 11547388006138018, .permutes 7005507837231112 10492920954130528, .permutes 2230329106235392 11583636488880259, .permutes 2224910120484864 11583636456342690, .permutes 1660720287367168 11584701472084066, .embeds 71576909587719]
private def supply := witnessAt tags 0xfb4d36db4d35d74d36db4d33cf4d36db4d35d74d36db4d0d9f6c36db5db5d76d76d8dd8dc76c36db5db5d76d76d8dd8d874d33c34d33bf4d33c34d33cf4d08cf4d08cf4d08cf4d08861c30c30befbefc30c30c71861c30c30befbefc30c30f7c374d36db4d35d74d36db4d33cf4d36db4d35d74d36db4d08376376db5db5d76d76db0db1376376db5db5d76d76db0dbb974d33c34d33bf4d33c29d29cf4d08cf4d08cf4d08ce9d299e7c30c30befbefc30c29c69c71c30c30befbefc30c29ea9234d36db4d35d74d36db4d33cf4d36db4d35d74d36db4d0d976c36db5db5d76d76d8dd8dc76c24db5da4d76d64d8dda4234d33234d33234d33234d33cf4d30cf4d2fcf4d30cf4d39861c30c30befbefc30c30c71861c24c30be4befc24c30e24374d36db4d35d74d36db4d33cf4d36db4d35d74d36db4d37376376db5db5d76d762cb2cb376364db5da4d76d642cb2e4234d33234d33234d33229d29cf4186cf4186cf4186ce91a9bb2c30c30befbefc302e92e9c711a4c301a4bef1a42e91a4b8d84d9cd84da0d84d9cd84d88d84d9cd84da0d84d9cd8509cd84db4d84d9cd84db4d84d9cd84db4d84d9cd84db4d850848b08848b08848b08848b08848b08848b08848b08848b108409c0840a008409c08408808409c0840a008409c0840ac034834834834834834834834834834834834834834834835036704136804136704136a0411040411040411040411040419489489c89c8a08a089e99e99489489c89c8a08a089e99e99c0040a000409c004098004010004010004010004010004020d20d20d20d20d20d20d20d20d20d20d20d20d20d20d21094d84d94d84d94d84d94d84d88d86488d86488d86488d8642212220820820c30c30820822212230820820c30c30820828408800800800c00c00800808408000800800c00c008008035f35e35d35c35b35a35935835735635535435335235135034f04134e04134c0412cb04110404110404110404110404120a2090820820c30c30820822071860820820c30c30820821400400800400c00400800401000400800400c0040080040 6
private def pass (s : ℕ) := fastWitness 10 10 Terminal18.target 2176647089152 words11 masks s (supply s)

private theorem run5 : span pass 0 32 = true := by decide +kernel
private theorem run6 : span pass 32 32 = true := by decide +kernel
private theorem run4 : span pass 0 64 = true := span_add (a:=32) (b:=32) run5 run6
private theorem run8 : span pass 64 32 = true := by decide +kernel
private theorem run9 : span pass 96 32 = true := by decide +kernel
private theorem run7 : span pass 64 64 = true := span_add (a:=32) (b:=32) run8 run9
private theorem run3 : span pass 0 128 = true := span_add (a:=64) (b:=64) run4 run7
private theorem run12 : span pass 128 32 = true := by decide +kernel
private theorem run13 : span pass 160 32 = true := by decide +kernel
private theorem run11 : span pass 128 64 = true := span_add (a:=32) (b:=32) run12 run13
private theorem run15 : span pass 192 32 = true := by decide +kernel
private theorem run16 : span pass 224 32 = true := by decide +kernel
private theorem run14 : span pass 192 64 = true := span_add (a:=32) (b:=32) run15 run16
private theorem run10 : span pass 128 128 = true := span_add (a:=64) (b:=64) run11 run14
private theorem run2 : span pass 0 256 = true := span_add (a:=128) (b:=128) run3 run10
private theorem run20 : span pass 256 32 = true := by decide +kernel
private theorem run21 : span pass 288 32 = true := by decide +kernel
private theorem run19 : span pass 256 64 = true := span_add (a:=32) (b:=32) run20 run21
private theorem run23 : span pass 320 32 = true := by decide +kernel
private theorem run24 : span pass 352 32 = true := by decide +kernel
private theorem run22 : span pass 320 64 = true := span_add (a:=32) (b:=32) run23 run24
private theorem run18 : span pass 256 128 = true := span_add (a:=64) (b:=64) run19 run22
private theorem run27 : span pass 384 32 = true := by decide +kernel
private theorem run28 : span pass 416 32 = true := by decide +kernel
private theorem run26 : span pass 384 64 = true := span_add (a:=32) (b:=32) run27 run28
private theorem run30 : span pass 448 32 = true := by decide +kernel
private theorem run31 : span pass 480 32 = true := by decide +kernel
private theorem run29 : span pass 448 64 = true := span_add (a:=32) (b:=32) run30 run31
private theorem run25 : span pass 384 128 = true := span_add (a:=64) (b:=64) run26 run29
private theorem run17 : span pass 256 256 = true := span_add (a:=128) (b:=128) run18 run25
private theorem run1 : span pass 0 512 = true := span_add (a:=256) (b:=256) run2 run17
private theorem run36 : span pass 512 32 = true := by decide +kernel
private theorem run37 : span pass 544 32 = true := by decide +kernel
private theorem run35 : span pass 512 64 = true := span_add (a:=32) (b:=32) run36 run37
private theorem run39 : span pass 576 32 = true := by decide +kernel
private theorem run40 : span pass 608 32 = true := by decide +kernel
private theorem run38 : span pass 576 64 = true := span_add (a:=32) (b:=32) run39 run40
private theorem run34 : span pass 512 128 = true := span_add (a:=64) (b:=64) run35 run38
private theorem run43 : span pass 640 32 = true := by decide +kernel
private theorem run44 : span pass 672 32 = true := by decide +kernel
private theorem run42 : span pass 640 64 = true := span_add (a:=32) (b:=32) run43 run44
private theorem run46 : span pass 704 32 = true := by decide +kernel
private theorem run47 : span pass 736 32 = true := by decide +kernel
private theorem run45 : span pass 704 64 = true := span_add (a:=32) (b:=32) run46 run47
private theorem run41 : span pass 640 128 = true := span_add (a:=64) (b:=64) run42 run45
private theorem run33 : span pass 512 256 = true := span_add (a:=128) (b:=128) run34 run41
private theorem run51 : span pass 768 32 = true := by decide +kernel
private theorem run52 : span pass 800 32 = true := by decide +kernel
private theorem run50 : span pass 768 64 = true := span_add (a:=32) (b:=32) run51 run52
private theorem run54 : span pass 832 32 = true := by decide +kernel
private theorem run55 : span pass 864 32 = true := by decide +kernel
private theorem run53 : span pass 832 64 = true := span_add (a:=32) (b:=32) run54 run55
private theorem run49 : span pass 768 128 = true := span_add (a:=64) (b:=64) run50 run53
private theorem run58 : span pass 896 32 = true := by decide +kernel
private theorem run59 : span pass 928 32 = true := by decide +kernel
private theorem run57 : span pass 896 64 = true := span_add (a:=32) (b:=32) run58 run59
private theorem run61 : span pass 960 32 = true := by decide +kernel
private theorem run62 : span pass 992 32 = true := by decide +kernel
private theorem run60 : span pass 960 64 = true := span_add (a:=32) (b:=32) run61 run62
private theorem run56 : span pass 896 128 = true := span_add (a:=64) (b:=64) run57 run60
private theorem run48 : span pass 768 256 = true := span_add (a:=128) (b:=128) run49 run56
private theorem run32 : span pass 512 512 = true := span_add (a:=256) (b:=256) run33 run48
private theorem run0 : span pass 0 1024 = true := span_add (a:=512) (b:=512) run1 run32

theorem checked : rowStep 10 2176647089152 words11 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify10_013
end EarlyRamsey
