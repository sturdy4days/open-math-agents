import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify7_001
private def masks : Array ℕ := #[96, 96, 96, 96, 96, 31, 31]
private def tags : Array Witness := #[.undominated 0, .undominated 1, .undominated 2, .undominated 3, .undominated 4, .permutes 66059264 7722896449, .undominated 6, .permutes 132022273 213846689793, .permutes 132022273 213846688770, .permutes 66980864 246965996609, .permutes 132022273 213846656003, .permutes 66980864 246965995617, .permutes 66980864 246965994594, .permutes 66980864 240722707620, .permutes 132022273 213845607428, .permutes 66980864 246965962881, .permutes 66980864 246965961858, .permutes 66980864 240723756195, .permutes 66980864 246965929091, .permutes 66980864 240723788962, .permutes 66980864 240723789985, .permutes 132022273 7653622981, .permutes 132022273 213812052997, .permutes 66980864 246964914337, .permutes 66980864 246964913314, .permutes 66980864 240724804739, .permutes 66980864 246964880547, .permutes 66980864 240724837506, .permutes 66980864 240724838529, .permutes 132022273 7687177412, .permutes 66980864 246963831972, .permutes 66980864 240724870242, .permutes 66980864 240724871265, .permutes 132022273 7688225987, .permutes 66980864 240724872257, .permutes 132022273 7688258754, .permutes 132022273 7688259777, .gap 6 7, .undominated 5, .permutes 132022273 247132686337, .permutes 132022273 247132685314, .permutes 66980864 213680000065, .permutes 132022273 247132652547, .permutes 66980864 213679999073, .permutes 66980864 213679998050, .permutes 66980864 206396523684, .permutes 132022273 247131603972, .permutes 66980864 213679966337, .permutes 66980864 213679965314, .permutes 66980864 206397572259, .permutes 66980864 213679932547, .permutes 66980864 206397605026, .permutes 66980864 206397606049, .permutes 132022273 6579881189, .permutes 132022273 247098049541, .permutes 66980864 213678917793, .permutes 66980864 213678916770, .permutes 66980864 206398620803, .permutes 66980864 213678884003, .permutes 66980864 206398653570, .permutes 66980864 206398654593, .permutes 132022273 6613435620, .permutes 66980864 213677835428, .permutes 66980864 206398686306, .permutes 66980864 206398687329, .permutes 132022273 6614484195, .permutes 66980864 206398688321, .permutes 132022273 6614516962, .permutes 132022273 6614517985, .permutes 134184960 246965996609, .gap 1 2, .gap 1 3, .gap 1 4, .gap 1 5, .permutes 266338304 7722896449]
private def supply := witnessAt tags 0x951a3478f1a348911a3478f1a349931a3478f1a348911a3478f1a3454b121c28301fbe7af1dba72e1bb66ad19b262c17ae5ab15aa52a13a64a911a24280f9e3a70d9a3260b962a50992224078e1a3058a12203860a000800400080060008004000800800080040008006000800400080 7
private def pass (s : ℕ) := fastWitness 10 7 Terminal18.target 1047552 words8 masks s (supply s)

private theorem run2 : span pass 0 32 = true := by decide +kernel
private theorem run3 : span pass 32 32 = true := by decide +kernel
private theorem run1 : span pass 0 64 = true := span_add (a:=32) (b:=32) run2 run3
private theorem run5 : span pass 64 32 = true := by decide +kernel
private theorem run6 : span pass 96 32 = true := by decide +kernel
private theorem run4 : span pass 64 64 = true := span_add (a:=32) (b:=32) run5 run6
private theorem run0 : span pass 0 128 = true := span_add (a:=64) (b:=64) run1 run4

theorem checked : rowStep 7 1047552 words8 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify7_001
end EarlyRamsey
