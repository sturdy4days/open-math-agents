import Complete13
import RemainingTransitions

namespace EarlyRamsey
open BBHExtension SimpleGraph

/-- Only the five transitions with parent orders thirteen through seventeen
are required to finish the order-nineteen result for this catalogue. -/
theorem order19_after_prefix (L14 L15 L16 L17 : List ℕ)
    (h13 : codeStep 13 (codes13 13) L14) (h14 : codeStep 14 L14 L15) (h15 : codeStep 15 L15 L16)
    (h16 : codeStep 16 L16 L17) (h17 : codeStep 17 L17 lastWords) :
    ∀ H : SimpleGraph (Fin 19), H.CliqueFree 3 → decode 10 Terminal18.target ⊑ Hᶜ :=
  after_thirteen _ _ _ _ _ (complete13_code 13 le_rfl) h13 h14 h15 h16 h17

end EarlyRamsey

#print axioms EarlyRamsey.order19_after_prefix
