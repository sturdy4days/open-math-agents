import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify10_022
private def masks : Array ℕ := #[578, 385, 368, 368, 652, 652, 141, 114, 526, 305]
private def tags : Array Witness := #[.undominated 0, .undominated 2, .undominated 3, .undominated 7, .undominated 9, .permutes 16216422964312896 4609469776598081, .undominated 5, .permutes 548181394510336 1310930460023872, .permutes 548181394510336 2438960670581792, .permutes 548181394510336 362021925325889, .permutes 548181394510336 1310931500211264, .permutes 548181394510336 2438961710769184, .permutes 548181394510336 362021924278337, .permutes 539959685722880 9324203412233378, .permutes 539959685722880 11505566836008097, .permutes 1097769268600832 292787052450881, .undominated 4, .permutes 548181394510336 1346114831064128, .permutes 548181394510336 2474145041622048, .permutes 548181394510336 362021891804225, .permutes 548181394510336 1346115871251520, .permutes 548181394510336 2474146081809440, .permutes 548181394510336 362021890756673, .permutes 539959685722880 9324203412200642, .permutes 539959685722880 11505566835975361, .permutes 1097769268600832 292787018897473, .undominated 8, .undominated 6, .permutes 16216422964312896 6931607226289217, .permutes 539959685722880 10414815936915554, .permutes 539959685722880 8233454660624481, .permutes 1097769268600832 324641686195265, .permutes 539959685722880 10414815936882818, .permutes 539959685722880 8233454660591745, .permutes 1097769268600832 324641652641857, .permutes 1660720287367168 359824879655075, .permutes 1660720287367168 291721763231907, .permutes 2224910120484864 292787053462659, .undominated 1, .gap 1 4, .gap 1 3, .gap 7 9, .gap 1 8, .permutes 4371415897802755 6939327393278017, .gap 3 8, .permutes 4371415897802755 4618292675388450, .gap 2 5, .gap 2 6, .gap 8 9, .gap 2 7, .gap 5 7, .gap 2 4, .gap 2 3, .gap 2 10, .permutes 4371415897802755 6941457764163618, .gap 3 10, .permutes 2187855526953985 10386167560277057, .permutes 2089557274923264 10415885314759682, .permutes 2088571737145378 10349985484047362, .permutes 4371415897802755 4620423046274113, .gap 1 5, .gap 1 6, .gap 7 10, .gap 1 9, .gap 5 9, .permutes 2089557274923264 11507629563355137, .permutes 2187855526953985 9363554000114753, .permutes 2088571737145378 11403284406634497, .permutes 2088571737145378 8098256537257985, .permutes 2088571737145378 9151555459843074, .permutes 3983689165845249 11550610374659137, .embeds 71576909587719]
private def supply := witnessAt tags 0x8ea1a28509d4274ea13a850f143c78a1e28509d4274ea13a850f543d7aa1ea8509d4274ea13a850f143c78a1e28509d4274ea13a850a944662f1a3c68f19bc66f1a3c68f173c78f5e3d78f5e3d78f5e3d78f5e3d7af1ebc7af1ebc7af1ebc7af1ebc78fde3478fde3378fde3478fde4554a1a28509d4274ea13a850f143c78a1e28509d4274ea13a850f543d7aa1ea8509d4274ea13a850f143c78a1e28509d4274ea13a850fd44452f1a3c68f19bc66f1a3c686da9b78f5e3d78f5e3d78f5e3d786de1b7af1ebc7af1ebc7af1ebc7a6de9b78fc18378fc18378fc183786c19b7ea1728509d4274ea13a850f143c78a1e28509d4274ea13a850f543d7aa1ea8509d4274ea13a850f143c78a1e28509d4274ea13a850a94437ef173c7ef173c7ef173c7ef173c78f5e3d78f5e3d78f5e3d78f5e3d7af1ebc7af1ebc7af1ebc7af1ebc78b9e4202040810408102020408154a1626509d4264ea13a650f142678a1e26509d4264ea13a650f54267aa1ea6509d4264ea13a650f142678a1e26509d4264ea13a651054267ef20267ef1f267ef1f267e6df2678f5e2678f5e2678f5e26786de267af1ea67af1ea67af1ea67a6dea678ec1a602040a6040812602040a66aa1a28509d4274ea13a850a942e5ca1a28509d4274ea13a850a942f5ea1a28509d4274ea13a850a942e5ca1a28509d4274ea13a850a943a62dda0068d198066cda0068d17005cb9a0068d198066cda0068d17805ebda0068d198066cda0068d17005cb9a0068d198066cda0068d1c8054a1a28509d4274ea13a850d143854a1a28509d4274ea13a8204081054a1a28509d4274ea13a80c1830654a1a28509d4274ea13a820408106adda0068d198066cda00686db006aa5a0068d198066cda0020408006aa5a0068d198066cda000c183006aa418068d018066cc180204080052a1728509d4274ea13a850a8d1a5ca17a8509d4274ea13a850a8d1a5ea1728509d4274ea13a850a8d1a5c1188450114044e113845010d1a62c970062c170062c170062c0d005cb97805cb97805cb97805cb8d005ebd7005ebd7005ebd7005ebcd005c1168002040800408100020408054a1626509d4264ea13a650acd2654a14a6509d4264ea13a6204082654a14a6509d4264ea13a60c1832654114a650114264e113a620408264a9118044850003e78e80386cd003260b802c54a00264888020408001e38680182c50012203800c183000a10180020408004081000204080 7
private def pass (s : ℕ) := fastWitness 10 10 Terminal18.target 20963438015233 words11 masks s (supply s)

private theorem run5 : span pass 0 32 = true := by decide +kernel
private theorem run6 : span pass 32 32 = true := by decide +kernel
private theorem run4 : span pass 0 64 = true := span_add (a:=32) (b:=32) run5 run6
private theorem run8 : span pass 64 32 = true := by decide +kernel
private theorem run9 : span pass 96 32 = true := by decide +kernel
private theorem run7 : span pass 64 64 = true := span_add (a:=32) (b:=32) run8 run9
private theorem run3 : span pass 0 128 = true := span_add (a:=64) (b:=64) run4 run7
private theorem run12 : span pass 128 32 = true := by decide +kernel
private theorem run13 : span pass 160 32 = true := by decide +kernel
private theorem run11 : span pass 128 64 = true := span_add (a:=32) (b:=32) run12 run13
private theorem run15 : span pass 192 32 = true := by decide +kernel
private theorem run16 : span pass 224 32 = true := by decide +kernel
private theorem run14 : span pass 192 64 = true := span_add (a:=32) (b:=32) run15 run16
private theorem run10 : span pass 128 128 = true := span_add (a:=64) (b:=64) run11 run14
private theorem run2 : span pass 0 256 = true := span_add (a:=128) (b:=128) run3 run10
private theorem run20 : span pass 256 32 = true := by decide +kernel
private theorem run21 : span pass 288 32 = true := by decide +kernel
private theorem run19 : span pass 256 64 = true := span_add (a:=32) (b:=32) run20 run21
private theorem run23 : span pass 320 32 = true := by decide +kernel
private theorem run24 : span pass 352 32 = true := by decide +kernel
private theorem run22 : span pass 320 64 = true := span_add (a:=32) (b:=32) run23 run24
private theorem run18 : span pass 256 128 = true := span_add (a:=64) (b:=64) run19 run22
private theorem run27 : span pass 384 32 = true := by decide +kernel
private theorem run28 : span pass 416 32 = true := by decide +kernel
private theorem run26 : span pass 384 64 = true := span_add (a:=32) (b:=32) run27 run28
private theorem run30 : span pass 448 32 = true := by decide +kernel
private theorem run31 : span pass 480 32 = true := by decide +kernel
private theorem run29 : span pass 448 64 = true := span_add (a:=32) (b:=32) run30 run31
private theorem run25 : span pass 384 128 = true := span_add (a:=64) (b:=64) run26 run29
private theorem run17 : span pass 256 256 = true := span_add (a:=128) (b:=128) run18 run25
private theorem run1 : span pass 0 512 = true := span_add (a:=256) (b:=256) run2 run17
private theorem run36 : span pass 512 32 = true := by decide +kernel
private theorem run37 : span pass 544 32 = true := by decide +kernel
private theorem run35 : span pass 512 64 = true := span_add (a:=32) (b:=32) run36 run37
private theorem run39 : span pass 576 32 = true := by decide +kernel
private theorem run40 : span pass 608 32 = true := by decide +kernel
private theorem run38 : span pass 576 64 = true := span_add (a:=32) (b:=32) run39 run40
private theorem run34 : span pass 512 128 = true := span_add (a:=64) (b:=64) run35 run38
private theorem run43 : span pass 640 32 = true := by decide +kernel
private theorem run44 : span pass 672 32 = true := by decide +kernel
private theorem run42 : span pass 640 64 = true := span_add (a:=32) (b:=32) run43 run44
private theorem run46 : span pass 704 32 = true := by decide +kernel
private theorem run47 : span pass 736 32 = true := by decide +kernel
private theorem run45 : span pass 704 64 = true := span_add (a:=32) (b:=32) run46 run47
private theorem run41 : span pass 640 128 = true := span_add (a:=64) (b:=64) run42 run45
private theorem run33 : span pass 512 256 = true := span_add (a:=128) (b:=128) run34 run41
private theorem run51 : span pass 768 32 = true := by decide +kernel
private theorem run52 : span pass 800 32 = true := by decide +kernel
private theorem run50 : span pass 768 64 = true := span_add (a:=32) (b:=32) run51 run52
private theorem run54 : span pass 832 32 = true := by decide +kernel
private theorem run55 : span pass 864 32 = true := by decide +kernel
private theorem run53 : span pass 832 64 = true := span_add (a:=32) (b:=32) run54 run55
private theorem run49 : span pass 768 128 = true := span_add (a:=64) (b:=64) run50 run53
private theorem run58 : span pass 896 32 = true := by decide +kernel
private theorem run59 : span pass 928 32 = true := by decide +kernel
private theorem run57 : span pass 896 64 = true := span_add (a:=32) (b:=32) run58 run59
private theorem run61 : span pass 960 32 = true := by decide +kernel
private theorem run62 : span pass 992 32 = true := by decide +kernel
private theorem run60 : span pass 960 64 = true := span_add (a:=32) (b:=32) run61 run62
private theorem run56 : span pass 896 128 = true := span_add (a:=64) (b:=64) run57 run60
private theorem run48 : span pass 768 256 = true := span_add (a:=128) (b:=128) run49 run56
private theorem run32 : span pass 512 512 = true := span_add (a:=256) (b:=256) run33 run48
private theorem run0 : span pass 0 1024 = true := span_add (a:=512) (b:=512) run1 run32

theorem checked : rowStep 10 20963438015233 words11 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify10_022
end EarlyRamsey
