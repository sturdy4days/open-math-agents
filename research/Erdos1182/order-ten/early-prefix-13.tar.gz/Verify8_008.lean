import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify8_008
private def masks : Array ℕ := #[14, 49, 193, 193, 194, 194, 60, 60]
private def tags : Array Witness := #[.undominated 0, .undominated 4, .undominated 2, .undominated 6, .undominated 1, .undominated 3, .gap 1 5, .permutes 4154330304 2481554920449, .undominated 5, .gap 1 6, .permutes 4154330304 1382112431106, .gap 2 3, .gap 2 4, .permutes 8116958209 6773264358465, .gap 1 7, .undominated 7, .permutes 16221241363 7973813358689, .permutes 16221241363 7973813357697, .gap 1 8, .permutes 16221241363 7972670412962, .permutes 4086633664 8872329942147, .permutes 4086633664 8865048598659, .permutes 16221241363 7972670411970, .permutes 4086633664 8872329910403, .permutes 4086633664 8865048630403, .gap 2 7, .permutes 16221241363 9038965248097, .permutes 16221241363 9038965247105, .permutes 16221241363 9037822302370, .permutes 4086633664 7773892056195, .permutes 4086633664 7765570525315, .permutes 16221241363 9037822301378, .permutes 4086633664 7773892024451, .permutes 4086633664 7765570557059, .gap 2 8, .permutes 16773514304 9037891506274, .permutes 16773514304 9038896044193, .gap 3 5, .gap 4 5, .gap 3 6, .permutes 68451041280 282600803393]
private def supply := witnessAt tags 0xa062ce2c63193062d92c66401892ce1893271892e51899c02462ce2463252462e724694018e2c41a63041a52c41a48c03863922c63223062e22c68801893921893211892e01897c024639224631e2462dd24670019238419b30419a2c40c30c048648e2c63193062d92c664018948e1893181892d718958024648e2463152462d42464c018e4841913041902c43cf3c038638d2c23023052c52c22801890411820421850451820402462082422022452052422001870441820441850440c2040 6
private def pass (s : ℕ) := fastWitness 10 8 Terminal18.target 127797387 words9 masks s (supply s)

private theorem run3 : span pass 0 32 = true := by decide +kernel
private theorem run4 : span pass 32 32 = true := by decide +kernel
private theorem run2 : span pass 0 64 = true := span_add (a:=32) (b:=32) run3 run4
private theorem run6 : span pass 64 32 = true := by decide +kernel
private theorem run7 : span pass 96 32 = true := by decide +kernel
private theorem run5 : span pass 64 64 = true := span_add (a:=32) (b:=32) run6 run7
private theorem run1 : span pass 0 128 = true := span_add (a:=64) (b:=64) run2 run5
private theorem run10 : span pass 128 32 = true := by decide +kernel
private theorem run11 : span pass 160 32 = true := by decide +kernel
private theorem run9 : span pass 128 64 = true := span_add (a:=32) (b:=32) run10 run11
private theorem run13 : span pass 192 32 = true := by decide +kernel
private theorem run14 : span pass 224 32 = true := by decide +kernel
private theorem run12 : span pass 192 64 = true := span_add (a:=32) (b:=32) run13 run14
private theorem run8 : span pass 128 128 = true := span_add (a:=64) (b:=64) run9 run12
private theorem run0 : span pass 0 256 = true := span_add (a:=128) (b:=128) run1 run8

theorem checked : rowStep 8 127797387 words9 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify8_008
end EarlyRamsey
