import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify10_015
private def masks : Array ℕ := #[896, 832, 344, 676, 676, 344, 166, 89, 39, 27]
private def tags : Array Witness := #[.undominated 0, .undominated 1, .undominated 2, .undominated 5, .undominated 4, .permutes 2117293422282827 2396014323442945, .undominated 3, .permutes 2117293422282827 2431164335793409, .permutes 17485535040021746 5776937515558113, .gap 3 10, .permutes 17485535040021746 6866587863787778, .permutes 2117293422282827 2399309637100801, .gap 4 9, .permutes 2117293422282827 2434459649451265, .gap 5 9, .gap 6 10, .permutes 539959685722880 7998158064001088, .gap 2 8, .permutes 548181394510336 10141144851716163, .permutes 548181394510336 10141143811528771, .permutes 4371415897802755 5777974507088162, .gap 3 8, .permutes 539959685722880 8103711180169280, .permutes 3983689165845249 327930621366343, .permutes 548181394510336 10141144851713094, .permutes 548181394510336 10141143811525702, .gap 6 8, .permutes 539959685722880 9158178297256992, .gap 1 7, .permutes 548181394510336 11268110949618724, .permutes 539959685722880 9193362669313056, .permutes 548181394510336 11268110949617701, .permutes 3983689165845249 361982163356712, .permutes 4371415897802755 6869822872986945, .permutes 548181394510336 11268107829056548, .gap 4 7, .permutes 548181394510336 11268107829055525, .gap 5 7, .undominated 8, .gap 7 10, .undominated 9, .undominated 7, .gap 1 6, .gap 1 3, .undominated 6, .permutes 16216422964312896 5781240973298753, .permutes 1095009688454144 10385035769351233, .gap 2 3, .permutes 2088571737145378 9221924169418784, .permutes 1097769268600832 10425714383881218, .permutes 539959685722880 11583363793163329, .permutes 1097769268600832 10425748710065154, .permutes 539959685722880 11583363793195073, .permutes 2088571737145378 10313770386595905, .permutes 2088571737145378 214656195265608, .gap 2 5, .gap 2 4, .permutes 16216422964312896 6871089024241729, .permutes 2088571737145378 8061972720649280, .permutes 1097769268600832 11515297153550337, .permutes 539959685722880 10493746663757858, .permutes 1097769268600832 11515400132102145, .permutes 539959685722880 10493746663853090, .permutes 2088571737145378 11473721835396130, .permutes 2088571737145378 180604653340711, .gap 1 5, .gap 1 4, .permutes 1095009688454144 11547184092844066, .gap 1 2, .gap 7 9, .permutes 3626182422323200 10492920890261569, .permutes 3626182422323200 11584700537733154, .embeds 71576909587719]
private def supply := witnessAt tags 0x911222b5712242851222b5712241831222b5712242851222b571222a551222b5712242851222b5712241831222b5712242851222b571221c391222b5712242851222b5712241831222b5712242851222b571222a551222b5712242851222b5712241831222b5712242851222b5712247231222b571222a711222b571222a6f1222b571222a711222b571222a551222b5712238551222b5712237551222b5712238551222b57122468b1222b571222a711222b571222a6f1222b571222a70a622956a6229551222b571162c551222b571162c551222b571162c54a622956a562c1909c422b09c4285061418506141830a0c2830a0c2847211c847211c3509c422b09c2685061418506126830a0c2830a0a6847211c84721263908e423908e4285061418506141830a0c2830a0c284e214304081023908e423908e2685061418506126830a0c2830a0a6060c18304081022245c382245c3870e1bb770e1bb76eddc386eddc3870e203f70e1f3d2245c382245c2670e1bb770e1ba66eddc386eddc2670e1e3b70e1d261831c381225c3870e1bb770e1bb76eddc386eddc3870a5ca904081021e3dc38122562c70e1bb770e162c6eddc386edd62c060c183040810212ad7ab56a95aa46ad7ab56a95aa4aad7ab56a95aa46ad7a856a95a854ad52b567159c54ad52b567159c54ad52b567159c54ad52856715a838ace2b56a95aa38ace2b56a95aa38ace2b56a95aa38ace2856a95a854ad52b56d95b554ad52b56d15b354ad52b56c95b154ad52856c15a822ad7ab56a95aa22ad7ab56a95aa22ad7ab56a95aa22ad7a856a95a854ad52b56bd5ae54ad52b0c1830654ad52b081020454ad5280c1830612ac4ab56a95aa18ac62b56a95aa1cac72b56a95aa18a462956a55a954ad52b56b562c54ad52b0c1830654ad52b081020454a55290c18306127089c2a7089c467089c4e7089c187089c4e7089c46708a84e708a8127089c2a708a64e7089c4e708a64e7089c4e708a64e708a84e708a63824081383c08138940813890081388c08138880813884081040808138240813880081387c08138780813874081386c081060c08104080812200a802200d0022007002200c8022006002200c002200b802200b002200a802200a0022009800c003002200900080020022008000c0030012000801e000801c000801a000801800080160008014000800400080120008010000800e000800c000800a00080080008006000800400080 7
private def pass (s : ℕ) := fastWitness 10 10 Terminal18.target 1866082771232 words11 masks s (supply s)

private theorem run5 : span pass 0 32 = true := by decide +kernel
private theorem run6 : span pass 32 32 = true := by decide +kernel
private theorem run4 : span pass 0 64 = true := span_add (a:=32) (b:=32) run5 run6
private theorem run8 : span pass 64 32 = true := by decide +kernel
private theorem run9 : span pass 96 32 = true := by decide +kernel
private theorem run7 : span pass 64 64 = true := span_add (a:=32) (b:=32) run8 run9
private theorem run3 : span pass 0 128 = true := span_add (a:=64) (b:=64) run4 run7
private theorem run12 : span pass 128 32 = true := by decide +kernel
private theorem run13 : span pass 160 32 = true := by decide +kernel
private theorem run11 : span pass 128 64 = true := span_add (a:=32) (b:=32) run12 run13
private theorem run15 : span pass 192 32 = true := by decide +kernel
private theorem run16 : span pass 224 32 = true := by decide +kernel
private theorem run14 : span pass 192 64 = true := span_add (a:=32) (b:=32) run15 run16
private theorem run10 : span pass 128 128 = true := span_add (a:=64) (b:=64) run11 run14
private theorem run2 : span pass 0 256 = true := span_add (a:=128) (b:=128) run3 run10
private theorem run20 : span pass 256 32 = true := by decide +kernel
private theorem run21 : span pass 288 32 = true := by decide +kernel
private theorem run19 : span pass 256 64 = true := span_add (a:=32) (b:=32) run20 run21
private theorem run23 : span pass 320 32 = true := by decide +kernel
private theorem run24 : span pass 352 32 = true := by decide +kernel
private theorem run22 : span pass 320 64 = true := span_add (a:=32) (b:=32) run23 run24
private theorem run18 : span pass 256 128 = true := span_add (a:=64) (b:=64) run19 run22
private theorem run27 : span pass 384 32 = true := by decide +kernel
private theorem run28 : span pass 416 32 = true := by decide +kernel
private theorem run26 : span pass 384 64 = true := span_add (a:=32) (b:=32) run27 run28
private theorem run30 : span pass 448 32 = true := by decide +kernel
private theorem run31 : span pass 480 32 = true := by decide +kernel
private theorem run29 : span pass 448 64 = true := span_add (a:=32) (b:=32) run30 run31
private theorem run25 : span pass 384 128 = true := span_add (a:=64) (b:=64) run26 run29
private theorem run17 : span pass 256 256 = true := span_add (a:=128) (b:=128) run18 run25
private theorem run1 : span pass 0 512 = true := span_add (a:=256) (b:=256) run2 run17
private theorem run36 : span pass 512 32 = true := by decide +kernel
private theorem run37 : span pass 544 32 = true := by decide +kernel
private theorem run35 : span pass 512 64 = true := span_add (a:=32) (b:=32) run36 run37
private theorem run39 : span pass 576 32 = true := by decide +kernel
private theorem run40 : span pass 608 32 = true := by decide +kernel
private theorem run38 : span pass 576 64 = true := span_add (a:=32) (b:=32) run39 run40
private theorem run34 : span pass 512 128 = true := span_add (a:=64) (b:=64) run35 run38
private theorem run43 : span pass 640 32 = true := by decide +kernel
private theorem run44 : span pass 672 32 = true := by decide +kernel
private theorem run42 : span pass 640 64 = true := span_add (a:=32) (b:=32) run43 run44
private theorem run46 : span pass 704 32 = true := by decide +kernel
private theorem run47 : span pass 736 32 = true := by decide +kernel
private theorem run45 : span pass 704 64 = true := span_add (a:=32) (b:=32) run46 run47
private theorem run41 : span pass 640 128 = true := span_add (a:=64) (b:=64) run42 run45
private theorem run33 : span pass 512 256 = true := span_add (a:=128) (b:=128) run34 run41
private theorem run51 : span pass 768 32 = true := by decide +kernel
private theorem run52 : span pass 800 32 = true := by decide +kernel
private theorem run50 : span pass 768 64 = true := span_add (a:=32) (b:=32) run51 run52
private theorem run54 : span pass 832 32 = true := by decide +kernel
private theorem run55 : span pass 864 32 = true := by decide +kernel
private theorem run53 : span pass 832 64 = true := span_add (a:=32) (b:=32) run54 run55
private theorem run49 : span pass 768 128 = true := span_add (a:=64) (b:=64) run50 run53
private theorem run58 : span pass 896 32 = true := by decide +kernel
private theorem run59 : span pass 928 32 = true := by decide +kernel
private theorem run57 : span pass 896 64 = true := span_add (a:=32) (b:=32) run58 run59
private theorem run61 : span pass 960 32 = true := by decide +kernel
private theorem run62 : span pass 992 32 = true := by decide +kernel
private theorem run60 : span pass 960 64 = true := span_add (a:=32) (b:=32) run61 run62
private theorem run56 : span pass 896 128 = true := span_add (a:=64) (b:=64) run57 run60
private theorem run48 : span pass 768 256 = true := span_add (a:=128) (b:=128) run49 run56
private theorem run32 : span pass 512 512 = true := span_add (a:=256) (b:=256) run33 run48
private theorem run0 : span pass 0 1024 = true := span_add (a:=512) (b:=512) run1 run32

theorem checked : rowStep 10 1866082771232 words11 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify10_015
end EarlyRamsey
