import FastCube
import LastData

namespace Terminal18
open BBHExtension
set_option maxRecDepth 10000

theorem maps0 : (rows 0).all (fun m => fastCube 10 18 target (parent 0) m.1 m.2.1 m.2.2) = true := by
  decide +kernel
theorem maps1 : (rows 1).all (fun m => fastCube 10 18 target (parent 1) m.1 m.2.1 m.2.2) = true := by
  decide +kernel

end Terminal18
