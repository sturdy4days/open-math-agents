import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify6_002
private def masks : Array ℕ := #[18, 33, 48, 48, 13, 14]
private def tags : Array Witness := #[.undominated 0, .undominated 2, .undominated 3, .permutes 946323 4395800610, .permutes 946323 4395832385, .gap 1 6, .undominated 1, .undominated 5, .permutes 514624 5572137057, .gap 1 3, .gap 1 4, .gap 2 5, .permutes 514624 6611275874, .undominated 4, .gap 2 3, .gap 2 4, .permutes 1012737 6610357313, .permutes 2064384 206703681]
private def supply := witnessAt tags 0x8a5c94a92a5254949530595c0715e0795c0735802a5664a926525464a0e629060084201084008420 5
private def pass (s : ℕ) := fastWitness 10 6 Terminal18.target 15169 words7 masks s (supply s)

private theorem run1 : span pass 0 32 = true := by decide +kernel
private theorem run2 : span pass 32 32 = true := by decide +kernel
private theorem run0 : span pass 0 64 = true := span_add (a:=32) (b:=32) run1 run2

theorem checked : rowStep 6 15169 words7 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify6_002
end EarlyRamsey
