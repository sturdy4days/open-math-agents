import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify10_011
private def masks : Array ℕ := #[896, 896, 672, 832, 608, 276, 152, 71, 43, 31]
private def tags : Array Witness := #[.undominated 0, .undominated 1, .undominated 2, .undominated 3, .undominated 4, .permutes 16216422964312896 357482217145574, .permutes 2088571737145378 11269109489736805, .gap 3 9, .gap 5 9, .permutes 2088571737145378 11268045411555461, .gap 4 8, .gap 5 8, .permutes 1097769268600832 11512204572529795, .permutes 7005507837231112 11550512464988195, .gap 1 7, .gap 2 7, .gap 3 7, .permutes 2783812118904960 11550580110591139, .undominated 5, .undominated 8, .gap 6 7, .undominated 9, .permutes 7005507837231112 11584562964695076, .gap 1 6, .gap 2 6, .gap 4 6, .undominated 6, .undominated 7, .permutes 2783812118904960 11584698256000164, .permutes 3878387695222920 9335027703840998, .gap 6 10, .permutes 7474671440114307 11584524443156675, .gap 1 5, .gap 2 5, .permutes 7474671440114307 325525374740675, .gap 3 4, .gap 3 5, .gap 4 5, .permutes 2224910120484864 11512204575771713, .gap 1 3, .permutes 2225184465584128 11550583392570501, .gap 2 3, .gap 1 4, .gap 2 4, .permutes 2225184465584128 11584701539029093, .permutes 2222632524316672 11584701642932289, .gap 1 2, .embeds 71576909587719]
private def supply := witnessAt tags 0xbeeba79eebaaaaeba79eeba082eba79eebaaaaeba79eeb975eeba79eebaaaaeba79eeba082eba79eebaaaaeba79eeb8e3aeba79eebaaaaeba79eeba082eba79eebaaaaeba79eeb975eeba79eebaaaaeba79eeba082eba79eebaaaaeba79eebad2aaaea8eaaeaaa0aa0aa0aa082a82a82a82aa97a97a97a975ea5ea5ea5eaaa0aa0aa0aa082a82a82a82aaabaa3aabaac52aaea8eaadbaa0aa0aa0a9b82a82a82a81b69a69a69a69a5ea5ea5ea5dbaa0aa0aa0a9b82a82a82a81b69a69a69a69a1e7a679e09e08e7a679e09e08278279ce9ce8278279ce9ce527a679e09e08e7a539e09d38278274924928278134924923a73a79e09e03a73a79e09e08278279e99e38278279e99e83a73a79e09e03a73939e09d38278274924928278134924921e08608e08608e08609208608218248218238218238218262a08608e08608e08539608538218254924928218134924921e08608e085b8e086092085b82182482181b69a69a69a69a7a08608e085b8e08538a085b82181f49249269a69a4924927976174176176576174176172d76174176176576174176155ce5ce5ce5ce5ce5ce5ce5ce5ce5ce5ce5ce5ce5ce5ce5d53973973973973973973973973973973973973973973973955d85d05d85d95d85d05d85dd1041041041041041041041042976171d76176576171d76172976171d76176576171d76155d85d90820825d85cb0820825d85d90820825d85dc0820825176171d761b6576171d761b2176171d761b69a69a69a69a5d85d90820825d85d60820821041040820821041040820821ce3ce40e3ce1ce3ce40e3ce1ce3ce40e3ce1ce3ce40e3d550e3ce40e3ce28e3d340e3d32ce3ce49249228e3d349249238f39038f3880c30c30c30c338f39038f3910c30c30c30c338f39038f38d0c30c30c30c31041041041040c30c30c30c31c00402800401c00402c00401c00402800401c00403000402800400800402c00400800402800400800402400400800401c00402000400c00400c00401c00401800400c00400c00401400400800400c00400800401000400800400c0040080040 6
private def pass (s : ℕ) := fastWitness 10 10 Terminal18.target 2141996208128 words11 masks s (supply s)

private theorem run5 : span pass 0 32 = true := by decide +kernel
private theorem run6 : span pass 32 32 = true := by decide +kernel
private theorem run4 : span pass 0 64 = true := span_add (a:=32) (b:=32) run5 run6
private theorem run8 : span pass 64 32 = true := by decide +kernel
private theorem run9 : span pass 96 32 = true := by decide +kernel
private theorem run7 : span pass 64 64 = true := span_add (a:=32) (b:=32) run8 run9
private theorem run3 : span pass 0 128 = true := span_add (a:=64) (b:=64) run4 run7
private theorem run12 : span pass 128 32 = true := by decide +kernel
private theorem run13 : span pass 160 32 = true := by decide +kernel
private theorem run11 : span pass 128 64 = true := span_add (a:=32) (b:=32) run12 run13
private theorem run15 : span pass 192 32 = true := by decide +kernel
private theorem run16 : span pass 224 32 = true := by decide +kernel
private theorem run14 : span pass 192 64 = true := span_add (a:=32) (b:=32) run15 run16
private theorem run10 : span pass 128 128 = true := span_add (a:=64) (b:=64) run11 run14
private theorem run2 : span pass 0 256 = true := span_add (a:=128) (b:=128) run3 run10
private theorem run20 : span pass 256 32 = true := by decide +kernel
private theorem run21 : span pass 288 32 = true := by decide +kernel
private theorem run19 : span pass 256 64 = true := span_add (a:=32) (b:=32) run20 run21
private theorem run23 : span pass 320 32 = true := by decide +kernel
private theorem run24 : span pass 352 32 = true := by decide +kernel
private theorem run22 : span pass 320 64 = true := span_add (a:=32) (b:=32) run23 run24
private theorem run18 : span pass 256 128 = true := span_add (a:=64) (b:=64) run19 run22
private theorem run27 : span pass 384 32 = true := by decide +kernel
private theorem run28 : span pass 416 32 = true := by decide +kernel
private theorem run26 : span pass 384 64 = true := span_add (a:=32) (b:=32) run27 run28
private theorem run30 : span pass 448 32 = true := by decide +kernel
private theorem run31 : span pass 480 32 = true := by decide +kernel
private theorem run29 : span pass 448 64 = true := span_add (a:=32) (b:=32) run30 run31
private theorem run25 : span pass 384 128 = true := span_add (a:=64) (b:=64) run26 run29
private theorem run17 : span pass 256 256 = true := span_add (a:=128) (b:=128) run18 run25
private theorem run1 : span pass 0 512 = true := span_add (a:=256) (b:=256) run2 run17
private theorem run36 : span pass 512 32 = true := by decide +kernel
private theorem run37 : span pass 544 32 = true := by decide +kernel
private theorem run35 : span pass 512 64 = true := span_add (a:=32) (b:=32) run36 run37
private theorem run39 : span pass 576 32 = true := by decide +kernel
private theorem run40 : span pass 608 32 = true := by decide +kernel
private theorem run38 : span pass 576 64 = true := span_add (a:=32) (b:=32) run39 run40
private theorem run34 : span pass 512 128 = true := span_add (a:=64) (b:=64) run35 run38
private theorem run43 : span pass 640 32 = true := by decide +kernel
private theorem run44 : span pass 672 32 = true := by decide +kernel
private theorem run42 : span pass 640 64 = true := span_add (a:=32) (b:=32) run43 run44
private theorem run46 : span pass 704 32 = true := by decide +kernel
private theorem run47 : span pass 736 32 = true := by decide +kernel
private theorem run45 : span pass 704 64 = true := span_add (a:=32) (b:=32) run46 run47
private theorem run41 : span pass 640 128 = true := span_add (a:=64) (b:=64) run42 run45
private theorem run33 : span pass 512 256 = true := span_add (a:=128) (b:=128) run34 run41
private theorem run51 : span pass 768 32 = true := by decide +kernel
private theorem run52 : span pass 800 32 = true := by decide +kernel
private theorem run50 : span pass 768 64 = true := span_add (a:=32) (b:=32) run51 run52
private theorem run54 : span pass 832 32 = true := by decide +kernel
private theorem run55 : span pass 864 32 = true := by decide +kernel
private theorem run53 : span pass 832 64 = true := span_add (a:=32) (b:=32) run54 run55
private theorem run49 : span pass 768 128 = true := span_add (a:=64) (b:=64) run50 run53
private theorem run58 : span pass 896 32 = true := by decide +kernel
private theorem run59 : span pass 928 32 = true := by decide +kernel
private theorem run57 : span pass 896 64 = true := span_add (a:=32) (b:=32) run58 run59
private theorem run61 : span pass 960 32 = true := by decide +kernel
private theorem run62 : span pass 992 32 = true := by decide +kernel
private theorem run60 : span pass 960 64 = true := span_add (a:=32) (b:=32) run61 run62
private theorem run56 : span pass 896 128 = true := span_add (a:=64) (b:=64) run57 run60
private theorem run48 : span pass 768 256 = true := span_add (a:=128) (b:=128) run49 run56
private theorem run32 : span pass 512 512 = true := span_add (a:=256) (b:=256) run33 run48
private theorem run0 : span pass 0 1024 = true := span_add (a:=512) (b:=512) run1 run32

theorem checked : rowStep 10 2141996208128 words11 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify10_011
end EarlyRamsey
