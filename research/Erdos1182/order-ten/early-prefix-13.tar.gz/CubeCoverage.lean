import Records

namespace CubeCoverage
open BBHExtension

/-- A leaf selects a cube by row number. A branch tests membership of vertex
`v`, with its absent and present children listed in that order. -/
inductive Tree where
  | leaf (row : ℕ)
  | branch (v : ℕ) (absent present : Tree)

def check (rows : List (ℕ × ℕ × ℕ)) : Tree → ℕ → ℕ → Bool
  | .leaf i, pos, neg =>
    match rows[i]? with
    | none => false
    | some (l,u,_) => (l &&& pos == l) && (u &&& neg == u)
  | .branch v absent present, pos, neg =>
    check rows absent pos (neg ||| 2^v) && check rows present (pos ||| 2^v) neg

private theorem mask_subset (k : ℕ) {a b : ℕ} (h : a &&& b = a) :
    subset k a ⊆ subset k b := by
  intro i hi
  have bit := congrArg (fun w : ℕ => w.testBit i.val) h
  simp only [subset,Finset.mem_filter,Finset.mem_univ,true_and] at hi ⊢
  simpa [Nat.testBit_and,hi] using bit

private theorem mem_insert_bit {k : ℕ} (x : Fin k) (a v : ℕ) :
    x ∈ subset k (a ||| 2^v) ↔ x ∈ subset k a ∨ x.val = v := by
  simp only [subset, Finset.mem_filter, Finset.mem_univ, true_and, Nat.testBit_or,
    Nat.testBit_two_pow, Bool.or_eq_true, decide_eq_true_eq]
  exact or_congr_right eq_comm

/-- A successful branch-tree check certifies all sets extending its accumulated
positive and negative choices, including both possible choices at every branch. -/
theorem check_sound {k : ℕ} (rows : List (ℕ × ℕ × ℕ)) (tree : Tree) (S : Finset (Fin k))
    {pos neg : ℕ} (hp : subset k pos ⊆ S) (hn : Disjoint S (subset k neg))
    (run : check rows tree pos neg = true) :
    ∃ row ∈ rows, subset k row.1 ⊆ S ∧ Disjoint S (subset k row.2.1) := by
  induction tree generalizing pos neg with
  | leaf i =>
    cases h : rows[i]? with
    | none => simp [check,h] at run
    | some row =>
      rcases row with ⟨l,u,index⟩
      have good : l &&& pos = l ∧ u &&& neg = u := by simpa [check,h] using run
      exact ⟨(l,u,index),List.mem_of_getElem? h,
        (mask_subset k good.1).trans hp, hn.mono_right (mask_subset k good.2)⟩
  | branch v absent present no yes =>
    obtain ⟨left,right⟩ := Bool.and_eq_true_iff.mp run
    by_cases mem : ∃ x ∈ S, x.val = v
    · apply yes _ hn right
      intro x hx
      rcases (mem_insert_bit x pos v).mp hx with old | eq
      · exact hp old
      · obtain ⟨y,hy,vy⟩ := mem
        exact Fin.ext (eq.trans vy.symm) ▸ hy
    · apply no hp _ left
      apply Finset.disjoint_left.mpr
      intro x hx target
      rcases (mem_insert_bit x neg v).mp target with old | eq
      · exact Finset.disjoint_left.mp hn hx old
      · exact mem ⟨x,hx,eq⟩

theorem covers {k : ℕ} (rows : List (ℕ × ℕ × ℕ)) (tree : Tree)
    (run : check rows tree 0 0 = true) (S : Finset (Fin k)) :
    ∃ row ∈ rows, subset k row.1 ⊆ S ∧ Disjoint S (subset k row.2.1) := by
  have empty : subset k 0 = ∅ := by ext i; simp [subset]
  exact check_sound rows tree S (pos:=0) (neg:=0) (by simp [empty]) (by simp [empty]) run

end CubeCoverage
