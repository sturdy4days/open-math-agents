import FastWitness

namespace ExtensionBitmap
open SimpleGraph BBHExtension

/-- Old twins stay indistinguishable either outside the connector, with
identical parent rows, or inside, with all row differences erased. -/
theorem old_twins_iff {k} (P : SimpleGraph (Fin k)) (S : Finset (Fin k)) (x y : Fin k) :
    (∀ w, (extend P S).Adj x.succ w ↔ (extend P S).Adj y.succ w) ↔
      (x ∉ S ∧ y ∉ S ∧ ∀ z, P.Adj x z ↔ P.Adj y z) ∨
      (x ∈ S ∧ y ∈ S ∧ ∀ z, z ∉ S → (P.Adj x z ↔ P.Adj y z)) := by
  have h0 (a : Fin k) : (extend P S).Adj a.succ 0 ↔ a ∈ S :=
    ((extend P S).adj_comm ..).trans (extend_left P S a)
  constructor
  · intro h
    have eq : x∈S ↔ y∈S := (h0 x).symm.trans ((h 0).trans (h0 y))
    by_cases hx : x∈S
    · have hy := eq.mp hx
      exact Or.inr ⟨hx,hy,fun z nz => by simpa [extend_old,nz] using h z.succ⟩
    · have hy := mt eq.mpr hx
      exact Or.inl ⟨hx,hy,fun z => by simpa [extend_old,hx,hy] using h z.succ⟩
  · rintro (⟨hx,hy,old⟩|⟨hx,hy,old⟩) w
    · refine Fin.cases (by simp [h0,hx,hy]) (fun z => ?_) w
      simpa [extend_old,hx,hy] using old z
    · refine Fin.cases (by simp [h0,hx,hy]) (fun z => ?_) w
      by_cases hz : z∈S
      · simp [extend_old,hx,hy,hz]
      · simpa [extend_old,hz] using old z hz

def twinCube (k : ℕ) (masks : Array ℕ) (l u x y : ℕ) : Bool :=
  let a := masks[x]?.getD 0
  let b := masks[y]?.getD 0
  let d := a ^^^ b
  decide (x<k ∧ y<k ∧ x≠y) &&
    ((u.testBit x && u.testBit y && (a == b)) ||
     (l.testBit x && l.testBit y && ((d &&& l) == d)))

theorem twinCube_sound {k p l u x y : ℕ} {masks : Array ℕ}
    (rows : masksMatch k p masks = true) (pass : twinCube k masks l u x y = true)
    (S : Finset (Fin k)) (lo : subset k l ⊆ S) (hi : Disjoint S (subset k u)) :
    hasTwins (extend (decode k p) S) := by
  let a := masks[x]?.getD 0
  let b := masks[y]?.getD 0
  have bits := of_decide_eq_true rows
  obtain ⟨⟨hx,hy,ne⟩,cases⟩ : (x<k ∧ y<k ∧ x≠y) ∧
      (((u.testBit x=true ∧ u.testBit y=true) ∧ a=b) ∨
       ((l.testBit x=true ∧ l.testBit y=true) ∧ (a ^^^ b) &&& l = a ^^^ b)) := by
    simpa [twinCube,a,b] using pass
  let i : Fin k := ⟨x,hx⟩
  let j : Fin k := ⟨y,hy⟩
  refine ⟨i.succ,j.succ,fun eq => ne (congrArg Fin.val (Fin.succ_inj.mp eq)),(old_twins_iff _ _ i j).mpr ?_⟩
  have inp (v : Fin k) (h : l.testBit v.val=true) := lo (show v∈subset k l by simpa [subset] using h)
  have out (v : Fin k) (h : u.testBit v.val=true) : v∉S :=
    fun hS => Finset.disjoint_left.mp hi hS (by simpa [subset] using h)
  have edges (v : Fin k) (eq : a.testBit v.val = b.testBit v.val) :
      (decode k p).Adj i v ↔ (decode k p).Adj j v := by
    have e := (bits i v).symm.trans (eq.trans (bits j v))
    exact iff_of_eq (congrArg (fun z : Bool => z = true) e)
  rcases cases with ⟨⟨bx,by'⟩,eq⟩|⟨⟨bx,by'⟩,d⟩
  · exact Or.inl ⟨out i bx,out j by',fun v => edges v (congrArg (fun z : ℕ => z.testBit v.val) eq)⟩
  · refine Or.inr ⟨inp i bx,inp j by',fun v hv => edges v ?_⟩
    have off : l.testBit v.val=false := Bool.eq_false_iff.mpr (fun lit => hv (inp v lit))
    have fact := congrArg (fun z : ℕ => z.testBit v.val) d
    change ((a ^^^ b) &&& l).testBit v.val = (a ^^^ b).testBit v.val at fact
    simp only [Nat.testBit_and,Nat.testBit_xor,off,Bool.and_false] at fact
    cases ha : a.testBit v.val <;> cases hb : b.testBit v.val <;>
      simp [ha,hb] at fact ⊢

/-- Every priority connector in a twin cube is one of the parent's k
neighborhoods. Those exceptional singleton masks can be checked separately. -/
theorem twinCube_priority {k p l u x y : ℕ} {masks : Array ℕ}
    (rows : masksMatch k p masks=true) (pass : twinCube k masks l u x y=true)
    (S : Finset (Fin k)) (lo : subset k l ⊆ S) (hi : Disjoint S (subset k u))
    (priority : priorityRow (decode k p) S) :
    ∃ z : Fin k, S = subset k (masks[z.val]?.getD 0) := by
  rcases priority with ⟨z,row⟩|⟨no,_⟩
  · refine ⟨z,?_⟩
    ext j
    have bit := of_decide_eq_true rows z j
    simpa [subset,bit,decode] using row j
  · exact (no (twinCube_sound rows pass S lo hi)).elim
end ExtensionBitmap
#print axioms ExtensionBitmap.twinCube_priority
