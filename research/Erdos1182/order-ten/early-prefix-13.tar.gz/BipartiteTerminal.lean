import LastData
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Finset.Sort
import Mathlib.Tactic

namespace Terminal18
open SimpleGraph BBHExtension Finset

private abbrev G := decode 10 target
private abbrev P := decode 18 (parent 2)
private abbrev Role := Option (Fin 5 ⊕ Fin 4)

private def label : Fin 10 → Role :=
  ![none,some (.inr 0),some (.inr 1),some (.inl 0),some (.inr 2),some (.inr 3),
    some (.inl 1),some (.inl 2),some (.inl 3),some (.inl 4)]

private def allowed : Role → Role → Bool
  | none, some (.inl _) | some (.inl _), none | some _, some _ => true
  | _, _ => false

private theorem independent_side (S V : Finset (Fin 18)) (nv : V.card = 9)
    (independent : ∀ a ∈ V, ∀ b ∈ V, ¬P.Adj a b)
    (enough : 5 ≤ (V \ S).card) : G ⊑ (extend P S)ᶜ := by
  classical
  obtain ⟨A,sub,cardA⟩ := exists_subset_card_eq enough
  have av : A ⊆ V := fun _ hi => (mem_sdiff.mp (sub hi)).1
  let B := V \ A
  have cardB : B.card=4 := by simp [B,card_sdiff_of_subset av,nv,cardA]
  let pick : (Fin 5 ⊕ Fin 4) → Fin 18 := Sum.elim (A.orderEmbOfFin cardA) (B.orderEmbOfFin cardB)
  have aA (a : Fin 5) : pick (.inl a) ∈ A := orderEmbOfFin_mem A cardA a
  have bB (b : Fin 4) : pick (.inr b) ∈ B := orderEmbOfFin_mem B cardB b
  have pickInj : Function.Injective pick := by
    rintro (a|a) (b|b) h
    · exact congrArg Sum.inl ((A.orderEmbOfFin cardA).injective h)
    · exact False.elim ((mem_sdiff.mp (bB b)).2 (h ▸ aA a))
    · exact False.elim ((mem_sdiff.mp (bB _)).2 (h.symm ▸ aA b))
    · exact congrArg Sum.inr ((B.orderEmbOfFin cardB).injective h)
  have pickV (z) : pick z ∈ V := by
    rcases z with a|b
    · exact av (aA a)
    · exact (mem_sdiff.mp (bB b)).1
  let loc : Role → Fin 19 := Option.elim' 0 (fun z => (pick z).succ)
  have locInj : Function.Injective loc := by
    rintro (_|a) (_|b) h
    · rfl
    · exact False.elim ((Fin.succ_ne_zero _ ) h.symm)
    · exact False.elim ((Fin.succ_ne_zero _ ) h)
    · exact congrArg some (pickInj (Fin.succ_injective _ h))
  have labInj : Function.Injective label := by decide
  have rules : ∀ i j, G.Adj i j → allowed (label i) (label j) = true := by decide +kernel
  have blue (u v : Role) (rule : allowed u v=true) : ¬(extend P S).Adj (loc u) (loc v) := by
    cases u with
    | none =>
      cases v with
      | none => exact fun h => h.ne rfl
      | some v =>
        rcases v with a|b
        · exact fun h => (mem_sdiff.mp (sub (aA a))).2 ((extend_left P S _).mp h)
        · contradiction
    | some u =>
      cases v with
      | none =>
        rcases u with a|b
        · exact fun h => (mem_sdiff.mp (sub (aA a))).2 ((extend_left P S _).mp h.symm)
        · contradiction
      | some v => exact fun h => independent _ (pickV u) _ (pickV v) ((extend_old P S _ _).mp h).1
  let f : G →g (extend P S)ᶜ :=
    { toFun := fun i => loc (label i)
      map_rel' := fun {i j} h => ⟨(locInj.comp labInj).ne h.ne,blue _ _ (rules i j h)⟩ }
  exact ⟨f.toCopy (locInj.comp labInj)⟩

set_option maxHeartbeats 1500000 in
/-- Every extension of the balanced complete bipartite order-18 host contains
the target in blue. Either the erased neighborhood contains a blue ten-clique,
or the new vertex has five blue neighbors in one blue nine-clique. -/
theorem bipartite_terminal (S : Finset (Fin 18)) :
    decode 10 target ⊑ (extend (decode 18 (parent 2)) S)ᶜ := by
  classical
  by_cases large : 10 ≤ S.card
  · obtain ⟨A,sub,size⟩ := exists_subset_card_eq large
    let e := A.orderEmbOfFin size
    let f : G →g (extend P S)ᶜ :=
      { toFun := fun i => (e i).succ
        map_rel' := fun {i j} h => ⟨(Fin.succ_injective _ |>.comp e.injective).ne h.ne,
          fun edge => ((extend_old P S _ _).mp edge).2
            ⟨sub (orderEmbOfFin_mem A size i),sub (orderEmbOfFin_mem A size j)⟩⟩ }
    exact ⟨f.toCopy ((Fin.succ_injective _) |>.comp e.injective)⟩
  · let L : Finset (Fin 18) := {0,10,11,12,13,14,15,16,17}
    let R := Lᶜ
    have l9 : L.card=9 := by decide
    have r9 : R.card=9 := by decide
    have il : ∀ a ∈ L, ∀ b ∈ L, ¬P.Adj a b := by decide +kernel
    have ir : ∀ a ∈ R, ∀ b ∈ R, ¬P.Adj a b := by decide +kernel
    by_cases en : 5 ≤ (L \ S).card
    · exact independent_side S L l9 il en
    · apply independent_side S R r9 ir
      have d : Disjoint (L \ S) (R \ S) := by
        apply Finset.disjoint_left.mpr
        intro a ha hb
        exact (mem_compl.mp (mem_sdiff.mp hb).1) (mem_sdiff.mp ha).1
      have partition : (L \ S) ∪ (R \ S) = Sᶜ := by
        ext a
        simp only [R,mem_union,mem_sdiff,mem_compl]
        tauto
      have ct := congrArg Finset.card partition
      rw [card_union_of_disjoint d,card_compl] at ct
      simp only [Fintype.card_fin] at ct
      omega

end Terminal18
#print axioms Terminal18.bipartite_terminal
