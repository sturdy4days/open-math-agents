import Orbit

namespace BBHExtension
open SimpleGraph

/-- Binary graph code, triangular order 01,02,12,03,13,23,... . -/
def adjacent (word x y : ℕ) : Bool :=
  (x != y) && word.testBit (max x y * (max x y-1)/2 + min x y)

def decode (k word : ℕ) : SimpleGraph (Fin k) where
  Adj x y := adjacent word x.val y.val = true
  symm := ⟨fun {x y} h => by
    rw [adjacent,max_comm y.val x.val,min_comm y.val x.val,bne_comm]
    exact h⟩
  loopless := ⟨fun x => by simp [adjacent]⟩

instance (k word : ℕ) : DecidableRel (decode k word).Adj :=
  fun x y => inferInstanceAs (Decidable (adjacent word x.val y.val = true))

def subset (k word : ℕ) : Finset (Fin k) :=
  Finset.univ.filter (fun x => word.testBit x.val)

theorem subset_surj {k : ℕ} (S : Finset (Fin k)) : ∃ word < 2^k, subset k word = S := by
  induction S using Finset.induction_on with
  | empty => exact ⟨0,Nat.two_pow_pos _,by ext; simp [subset]⟩
  | @insert a S fresh ih =>
    obtain ⟨w,_,ew⟩ := ih
    refine ⟨(w ||| 2^a.val)%2^k,Nat.mod_lt _ (Nat.two_pow_pos _),?_⟩
    ext x
    simp only [subset, Finset.mem_filter, Finset.mem_univ,true_and, Nat.testBit_mod_two_pow,
      decide_eq_true x.isLt,Bool.true_and, Nat.testBit_or, Nat.testBit_two_pow,
      Bool.or_eq_true, decide_eq_true_eq, Finset.mem_insert]
    rw [←ew]
    simp only [subset, Finset.mem_filter, Finset.mem_univ, true_and, Fin.ext_iff]
    aesop

instance {A : Type*} [DecidableEq A] (P : SimpleGraph A) [DecidableRel P.Adj] (S : Finset A) :
    DecidableRel (joinGraph P S).Adj := fun x y =>
  match x,y with
  | none,none => isFalse id
  | some i,none | none,some i => inferInstanceAs (Decidable (i∈S))
  | some i,some j => inferInstanceAs (Decidable (P.Adj i j ∧ ¬(i∈S ∧ j∈S)))

instance {k : ℕ} (P : SimpleGraph (Fin k)) [DecidableRel P.Adj] (S : Finset (Fin k)) :
    DecidableRel (extend P S).Adj :=
  fun i j => inferInstanceAs (Decidable ((joinGraph P S).Adj (finSuccEquiv k i) (finSuccEquiv k j)))

/-- Entries of a packed five-bit vertex map. -/
def vertex (k code i : ℕ) : Fin (k+1) :=
  ⟨((code >>> (5*i)) % 32) % (k+1), Nat.mod_lt _ (by omega)⟩

inductive Witness where
  | undominated (vertex : ℕ)
  | gap (first second : ℕ)
  | embeds (code : ℕ)
  | permutes (target code : ℕ)

/-- A row checks a named vertex, nonedge, injection, or permutation. -/
def check {n k : ℕ} (target parent : ℕ) (children : List ℕ)
    (word : ℕ) (tag : Witness) : Bool :=
  let S := subset k word
  let P := decode k parent
  let H := extend P S
  match tag with
  | .undominated a =>
    if ha : a<k then
      let v : Fin k := ⟨a,ha⟩
      decide (v∉S ∧ ∀ x : Fin k, x∈S → ¬ P.Adj x v)
    else false
  | .gap a b =>
    let u := vertex k a 0
    let v := vertex k b 0
    decide (u≠v ∧ ¬H.Adj u v ∧ ∀ w, ¬(H.Adj u w ∧ H.Adj v w))
  | .embeds code =>
    let f (i : Fin n) := vertex k code i.val
    decide ((∀ x y, f x = f y → x=y) ∧
      ∀ x y, (decode n target).Adj x y → (Hᶜ).Adj (f x) (f y))
  | .permutes b code =>
    let f (i : Fin (k+1)) := vertex k code i.val
    decide (b ∈ children ∧ (∀ x y,f x=f y → x=y) ∧
      ∀ x y,(decode (k+1) b).Adj (f x) (f y) ↔ H.Adj x y)

theorem checked_row {n k t p w : ℕ} {cs : List ℕ} (tag : Witness)
    (valid : check (n:=n) (k:=k) t p cs w tag = true)
    (dom : ∀ y, y ∉ subset k w → ∃ x ∈ subset k w,(decode k p).Adj x y) :
    let H := extend (decode k p) (subset k w)
    defect H ∨ decode n t ⊑ Hᶜ ∨ ∃ b ∈ cs, Nonempty (H ≃g decode (k+1) b) := by
  dsimp only
  cases tag with
  | undominated a =>
    simp only [check] at valid
    split at valid
    · have h := of_decide_eq_true valid
      obtain ⟨x,hx,e⟩ := dom _ h.1
      exact (h.2 x hx e).elim
    · contradiction
  | gap a b =>
    exact Or.inl ⟨_,_,of_decide_eq_true valid⟩
  | embeds c =>
    obtain ⟨inj,pres⟩ := of_decide_eq_true valid
    let f : decode n t →g (extend (decode k p) (subset k w))ᶜ :=
      { toFun := fun x => vertex k c x.val
        map_rel' := fun h => pres _ _ h }
    exact Or.inr (Or.inl ⟨f.toCopy inj⟩)
  | permutes b c =>
    obtain ⟨hb,inj,pres⟩ := of_decide_eq_true valid
    let f (x : Fin (k+1)) := vertex k c x.val
    let e := Equiv.ofBijective f (Finite.injective_iff_bijective.mp inj)
    exact Or.inr (Or.inr ⟨b,hb,⟨{toEquiv := e, map_rel_iff' := fun {x y} => pres x y}⟩⟩)

theorem certified_codes {n k t : ℕ} (ps cs : List ℕ) (supply : ℕ → ℕ → Witness)
    (tests : ∀ p∈ps, ∀ w : Fin (2^k), check (n:=n) (k:=k) t p cs w (supply p w) = true) :
    certifiedRows (decode n t) (ps.map (decode k)) (cs.map (decode (k+1))) := by
  intro P hP S _ dom
  obtain ⟨p,hp,rfl⟩ := List.mem_map.mp hP
  obtain ⟨w,hw,rfl⟩ := subset_surj S
  rcases checked_row (supply p w) (tests p hp ⟨w,hw⟩) dom with bad|hit|⟨b,hb,iso⟩
  · exact Or.inl bad
  · exact Or.inr (Or.inl hit)
  · exact Or.inr (Or.inr ⟨_,List.mem_map_of_mem hb,iso⟩)

/-- A checked empty final layer proves complementary containment for every
triangle-free host at the specified order. All data and checks are finite. -/
theorem complete_codes {n t : ℕ} (N : ℕ) (atlas : ℕ → List ℕ)
    (supply : ℕ → ℕ → ℕ → Witness) (init : 0∈atlas 0) (finalRow : atlas N=[])
    (tests : ∀ k<N, ∀ p∈atlas k, ∀ w : Fin (2^k),
      check (n:=n) (k:=k) t p (atlas (k+1)) w (supply k p w) = true) :
    ∀ C : SimpleGraph (Fin N), C.CliqueFree 3 → decode n t ⊑ Cᶜ := by
  apply complement_covers (decode n t) N (fun k => (atlas k).map (decode k))
  · exact List.mem_map.mpr ⟨0,init,Subsingleton.elim _ _⟩
  · exact fun k lim => certified_codes _ _ _ (tests k lim)
  · simp [finalRow]

end BBHExtension
#print axioms BBHExtension.complete_codes
