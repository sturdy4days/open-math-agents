import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify10_024
private def masks : Array ℕ := #[194, 769, 328, 644, 960, 960, 53, 57, 54, 58]
private def tags : Array Witness := #[.undominated 0, .undominated 2, .undominated 4, .undominated 5, .permutes 16216422964312896 6942601061080194, .permutes 16216422964312896 6940468610868353, .gap 1 9, .permutes 16216422964312896 6941468297011298, .permutes 16216422964312896 6939335846799457, .gap 3 8, .undominated 1, .undominated 3, .undominated 9, .undominated 7, .undominated 8, .permutes 1097769268600832 8024554029088865, .gap 1 3, .gap 2 7, .permutes 548181394510336 8167483934703713, .permutes 548181394510336 8167483968225377, .gap 7 10, .permutes 1097769268600832 9115302816284801, .gap 1 4, .undominated 6, .gap 2 8, .permutes 548181394510336 9257134316519553, .permutes 548181394510336 9257134350041217, .gap 8 9, .permutes 2079709988519968 9256042350382081, .gap 1 5, .gap 1 6, .gap 1 10, .permutes 1097769268600832 10275187692044386, .gap 2 3, .permutes 548181394510336 10489582697250914, .permutes 548181394510336 10489582730772578, .permutes 2079709988519968 10384140206670851, .gap 3 5, .gap 3 6, .permutes 33778794198908961 7117421166070849, .permutes 33778794198908961 5991521260276801, .permutes 7474671440114307 359751973183553, .permutes 1097769268600832 11365936479240322, .gap 2 4, .permutes 548181394510336 11579233079066754, .permutes 548181394510336 11579233112588418, .permutes 33778794198908961 7117421328600129, .permutes 33778794198908961 5991521455311937, .permutes 7474671440114307 325667080248385, .permutes 2079709988519968 11544089540494340, .gap 4 5, .gap 4 6, .permutes 2079709988519968 11577040529656834, .gap 2 5, .gap 2 6, .permutes 4300635019149345 11584695235120193, .embeds 71576909587719]
private def supply := witnessAt tags 0xe1085041641659059041d41d75075041641659059041e41e79079041641659059041d41d750750416416590590406437456856856ad65865a15865b5d56856856ad65865a15865b6d96856856ad65865a15865b5d56856857ad75865a159759761085040642bad0850406435d5085040642bad0850406436d9085040642bad0850406435d5085040642bacd84d40d40d446840846ac0ac6840846d40d46840846ac0ac6840846d80d86840846ac0ac6840846d40d46840857ac0acd840857d00190ad041641659059041d41d75075041641659059041e41e79079041641659059041d41d75075041638e59059041f38e196ad6196ad659f5b2041041196ad6196ad659f5b3041041196ad6196ad659f5b2041041196ad619739759f5b1041041190ad041f42b19045041f430190ad041f42b19045041f42f190ad041f42b19045041f42e190ad041f38e18d44d40d38d19fac019fac019f50004104019fac019fac019fb4004104019fac019fac019fb0004104019fac019738018da800410407d085041641659059041d41d75075041641659059041e41e79079041641659059041d41d75075041641659030c40630c7d68567d66165865a15865a97d68567d66165865a15865a87d68567d66165865a15865a77d68567d761758630c5973177d08504064257d08502cb2cb7d08504064267d08502cb2cb7d08504064257d08502cb2cb7d08504064247cd30d2cb2cb7c68407c66c07c68402cb2c07c68407c68c07c68402cb2c07c68407c68807c68402cb2c07c68407d78007cd3002cb2c019044a41640a59058a41d40a75074a41640a59058a41e40a79078a41640a59058a41d40a75074a41638a59030a41c38a19660a19660a59b58a04104a19660a19660a59a58a04104a19660a19660a59958a04104a19660a19738a59530a04104a19044a41440a19044a2cb2ca19044a41340a19044a2cb2ca19044a41240a19044a2cb2ca19044a40f38a18d30a2cb2ca1892401881c01851000410400820800820800820800410400c30c00c30c00c30c0041040082080082080082080041040 6
private def pass (s : ℕ) := fastWitness 10 10 Terminal18.target 4000346439713 words11 masks s (supply s)

private theorem run5 : span pass 0 32 = true := by decide +kernel
private theorem run6 : span pass 32 32 = true := by decide +kernel
private theorem run4 : span pass 0 64 = true := span_add (a:=32) (b:=32) run5 run6
private theorem run8 : span pass 64 32 = true := by decide +kernel
private theorem run9 : span pass 96 32 = true := by decide +kernel
private theorem run7 : span pass 64 64 = true := span_add (a:=32) (b:=32) run8 run9
private theorem run3 : span pass 0 128 = true := span_add (a:=64) (b:=64) run4 run7
private theorem run12 : span pass 128 32 = true := by decide +kernel
private theorem run13 : span pass 160 32 = true := by decide +kernel
private theorem run11 : span pass 128 64 = true := span_add (a:=32) (b:=32) run12 run13
private theorem run15 : span pass 192 32 = true := by decide +kernel
private theorem run16 : span pass 224 32 = true := by decide +kernel
private theorem run14 : span pass 192 64 = true := span_add (a:=32) (b:=32) run15 run16
private theorem run10 : span pass 128 128 = true := span_add (a:=64) (b:=64) run11 run14
private theorem run2 : span pass 0 256 = true := span_add (a:=128) (b:=128) run3 run10
private theorem run20 : span pass 256 32 = true := by decide +kernel
private theorem run21 : span pass 288 32 = true := by decide +kernel
private theorem run19 : span pass 256 64 = true := span_add (a:=32) (b:=32) run20 run21
private theorem run23 : span pass 320 32 = true := by decide +kernel
private theorem run24 : span pass 352 32 = true := by decide +kernel
private theorem run22 : span pass 320 64 = true := span_add (a:=32) (b:=32) run23 run24
private theorem run18 : span pass 256 128 = true := span_add (a:=64) (b:=64) run19 run22
private theorem run27 : span pass 384 32 = true := by decide +kernel
private theorem run28 : span pass 416 32 = true := by decide +kernel
private theorem run26 : span pass 384 64 = true := span_add (a:=32) (b:=32) run27 run28
private theorem run30 : span pass 448 32 = true := by decide +kernel
private theorem run31 : span pass 480 32 = true := by decide +kernel
private theorem run29 : span pass 448 64 = true := span_add (a:=32) (b:=32) run30 run31
private theorem run25 : span pass 384 128 = true := span_add (a:=64) (b:=64) run26 run29
private theorem run17 : span pass 256 256 = true := span_add (a:=128) (b:=128) run18 run25
private theorem run1 : span pass 0 512 = true := span_add (a:=256) (b:=256) run2 run17
private theorem run36 : span pass 512 32 = true := by decide +kernel
private theorem run37 : span pass 544 32 = true := by decide +kernel
private theorem run35 : span pass 512 64 = true := span_add (a:=32) (b:=32) run36 run37
private theorem run39 : span pass 576 32 = true := by decide +kernel
private theorem run40 : span pass 608 32 = true := by decide +kernel
private theorem run38 : span pass 576 64 = true := span_add (a:=32) (b:=32) run39 run40
private theorem run34 : span pass 512 128 = true := span_add (a:=64) (b:=64) run35 run38
private theorem run43 : span pass 640 32 = true := by decide +kernel
private theorem run44 : span pass 672 32 = true := by decide +kernel
private theorem run42 : span pass 640 64 = true := span_add (a:=32) (b:=32) run43 run44
private theorem run46 : span pass 704 32 = true := by decide +kernel
private theorem run47 : span pass 736 32 = true := by decide +kernel
private theorem run45 : span pass 704 64 = true := span_add (a:=32) (b:=32) run46 run47
private theorem run41 : span pass 640 128 = true := span_add (a:=64) (b:=64) run42 run45
private theorem run33 : span pass 512 256 = true := span_add (a:=128) (b:=128) run34 run41
private theorem run51 : span pass 768 32 = true := by decide +kernel
private theorem run52 : span pass 800 32 = true := by decide +kernel
private theorem run50 : span pass 768 64 = true := span_add (a:=32) (b:=32) run51 run52
private theorem run54 : span pass 832 32 = true := by decide +kernel
private theorem run55 : span pass 864 32 = true := by decide +kernel
private theorem run53 : span pass 832 64 = true := span_add (a:=32) (b:=32) run54 run55
private theorem run49 : span pass 768 128 = true := span_add (a:=64) (b:=64) run50 run53
private theorem run58 : span pass 896 32 = true := by decide +kernel
private theorem run59 : span pass 928 32 = true := by decide +kernel
private theorem run57 : span pass 896 64 = true := span_add (a:=32) (b:=32) run58 run59
private theorem run61 : span pass 960 32 = true := by decide +kernel
private theorem run62 : span pass 992 32 = true := by decide +kernel
private theorem run60 : span pass 960 64 = true := span_add (a:=32) (b:=32) run61 run62
private theorem run56 : span pass 896 128 = true := span_add (a:=64) (b:=64) run57 run60
private theorem run48 : span pass 768 256 = true := span_add (a:=128) (b:=128) run49 run56
private theorem run32 : span pass 512 512 = true := span_add (a:=256) (b:=256) run33 run48
private theorem run0 : span pass 0 1024 = true := span_add (a:=512) (b:=512) run1 run32

theorem checked : rowStep 10 4000346439713 words11 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify10_024
end EarlyRamsey
