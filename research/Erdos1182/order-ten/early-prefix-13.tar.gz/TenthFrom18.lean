import FirstTransitions
import BipartiteTerminal
import TerminalReduction
import Mathlib.Tactic.FinCases

namespace Terminal18
open SimpleGraph BBHExtension
theorem extensions (i : Fin 3) (S : Finset (Fin 18)) :
    decode 10 target ⊑ (extend (decode 18 (parent i)) S)ᶜ := by
  fin_cases i
  · exact first S
  · exact second S
  · exact bipartite_terminal S

theorem order19 (catalog : Classification) (H : SimpleGraph (Fin 19)) (tri : H.CliqueFree 3) :
    decode 10 target ⊑ Hᶜ :=
  universal_of_classification catalog extensions H tri
end Terminal18
#print axioms Terminal18.extensions
#print axioms Terminal18.order19
