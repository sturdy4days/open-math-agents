import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify8_000
private def masks : Array ℕ := #[128, 128, 128, 128, 128, 128, 128, 127]
private def tags : Array Witness := #[.undominated 0, .undominated 1, .undominated 2, .undominated 3, .undominated 4, .undominated 5, .undominated 6, .permutes 34357641216 282600803393, .permutes 68451041280 8803815918657, .gap 1 2, .gap 1 3, .gap 1 4, .gap 1 5, .gap 1 6, .gap 1 7, .permutes 68451041280 282600803393]
private def supply := witnessAt tags 0xf99aa99bb99aa99cc99aa99bb99aa99dd99aa99bb99aa99cc99aa99bb99aa99ee99aa99bb99aa99cc99aa99bb99aa99dd99aa99bb99aa99cc99aa99bb99aa99870102010301020104010201030102010501020103010201040102010301020106010201030102010401020103010201050102010301020104010201030102010 4
private def pass (s : ℕ) := fastWitness 10 8 Terminal18.target 266338304 words9 masks s (supply s)

private theorem run3 : span pass 0 32 = true := by decide +kernel
private theorem run4 : span pass 32 32 = true := by decide +kernel
private theorem run2 : span pass 0 64 = true := span_add (a:=32) (b:=32) run3 run4
private theorem run6 : span pass 64 32 = true := by decide +kernel
private theorem run7 : span pass 96 32 = true := by decide +kernel
private theorem run5 : span pass 64 64 = true := span_add (a:=32) (b:=32) run6 run7
private theorem run1 : span pass 0 128 = true := span_add (a:=64) (b:=64) run2 run5
private theorem run10 : span pass 128 32 = true := by decide +kernel
private theorem run11 : span pass 160 32 = true := by decide +kernel
private theorem run9 : span pass 128 64 = true := span_add (a:=32) (b:=32) run10 run11
private theorem run13 : span pass 192 32 = true := by decide +kernel
private theorem run14 : span pass 224 32 = true := by decide +kernel
private theorem run12 : span pass 192 64 = true := span_add (a:=32) (b:=32) run13 run14
private theorem run8 : span pass 128 128 = true := span_add (a:=64) (b:=64) run9 run12
private theorem run0 : span pass 0 256 = true := span_add (a:=128) (b:=128) run1 run8

theorem checked : rowStep 8 266338304 words9 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify8_000
end EarlyRamsey
