import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify10_012
private def masks : Array ℕ := #[224, 896, 896, 896, 896, 769, 769, 31, 126, 126]
private def tags : Array Witness := #[.undominated 0, .undominated 1, .undominated 2, .undominated 3, .undominated 4, .permutes 2220978314772480 11575934540941542, .undominated 6, .gap 6 8, .undominated 5, .gap 7 8, .permutes 4441923425174528 362021926341697, .gap 1 9, .undominated 8, .gap 1 3, .gap 1 2, .gap 1 4, .gap 1 5, .permutes 7297406967742464 11584701472084066, .undominated 9, .permutes 4440897366261824 10493781052919906, .permutes 4440897366261824 10493781052919875, .permutes 2222913928429568 11584488978188452, .permutes 4440897366261824 10493781052918852, .permutes 2222913928429568 11584489011742883, .permutes 2222913928429568 11584489011743906, .permutes 2230329106235392 11267839426203746, .permutes 4440897366261824 10493781052886085, .permutes 2222913928429568 11584489045297283, .permutes 2222913928429568 11584489045298306, .permutes 2230329106235392 11267839426172002, .permutes 2222913928429568 11584489045299298, .permutes 2230329106235392 11267839426139266, .permutes 2230329106235392 11267839426106499, .gap 8 9, .undominated 7, .permutes 2222632524316672 11584489078723715, .permutes 2222632524316672 11584489078756482, .permutes 2225184465584128 11540784459452615, .permutes 2222632524316672 11584489078789218, .permutes 2225184465584128 11540784493006023, .permutes 2225184465584128 11540784494053575, .permutes 2222632524316672 11267839426203746, .permutes 2222632524316672 11584489078820962, .permutes 2225184465584128 11540784526527687, .permutes 2225184465584128 11540784527575239, .permutes 2222632524316672 11267839426172002, .permutes 2225184465584128 11540784528591047, .permutes 2222632524316672 11267839426139266, .permutes 2222632524316672 11267839426106499, .permutes 2222632524316672 11584489111229571, .permutes 2222632524316672 11584489111262338, .permutes 2225184465584128 11540784459452646, .permutes 2222632524316672 11584489111295074, .permutes 2225184465584128 11540784493006054, .permutes 2225184465584128 11540784494053606, .permutes 2222632524316672 11267839393697890, .permutes 2222632524316672 11584489111326818, .permutes 2225184465584128 11540784526527718, .permutes 2225184465584128 11540784527575270, .permutes 2222632524316672 11267839393666146, .permutes 2225184465584128 11540784528591078, .permutes 2222632524316672 11267839393633410, .permutes 2222632524316672 11267839393600643, .gap 1 10, .permutes 8672534329294867 11550545846213825, .permutes 8672534329294867 11550545846212833, .permutes 4440897366261824 11584496587673698, .permutes 4440897366261824 11584496587673667, .permutes 2222913928429568 10493773443434660, .permutes 4440897366261824 11584496587672644, .permutes 2222913928429568 10493773476989091, .permutes 2222913928429568 10493773476990114, .permutes 2230329106235392 10141940593102946, .permutes 4440897366261824 11584496587639877, .permutes 2222913928429568 10493773510543491, .permutes 2222913928429568 10493773510544514, .permutes 2230329106235392 10141940593071202, .permutes 2222913928429568 10493773510545506, .permutes 2230329106235392 10141940593038466, .permutes 2230329106235392 10141940593005699, .gap 8 10, .permutes 2222632524316672 10493773543969923, .permutes 2222632524316672 10493773544002690, .permutes 2225184465584128 10414918912348359, .permutes 2222632524316672 10493773544035426, .permutes 2225184465584128 10414918945901767, .permutes 2225184465584128 10414918946949319, .permutes 2222632524316672 10141940593102946, .permutes 2222632524316672 10493773544067170, .permutes 2225184465584128 10414918979423431, .permutes 2225184465584128 10414918980470983, .permutes 2222632524316672 10141940593071202, .permutes 2225184465584128 10414918981486791, .permutes 2222632524316672 10141940593038466, .permutes 2222632524316672 10141940593005699, .permutes 2222632524316672 10493773576475779, .permutes 2222632524316672 10493773576508546, .permutes 2225184465584128 10414918912348390, .permutes 2222632524316672 10493773576541282, .permutes 2225184465584128 10414918945901798, .permutes 2225184465584128 10414918946949350, .permutes 2222632524316672 10141940560597090, .permutes 2222632524316672 10493773576573026, .permutes 2225184465584128 10414918979423462, .permutes 2225184465584128 10414918980471014, .permutes 2222632524316672 10141940560565346, .permutes 2225184465584128 10414918981486822, .permutes 2222632524316672 10141940560532610, .permutes 2222632524316672 10141940560499843, .permutes 8672534329294867 10425745450998977, .permutes 8672534329294867 10425745450997985, .permutes 4477181249978368 11584489111326818, .gap 2 6, .gap 3 6, .gap 4 6, .gap 5 6, .gap 2 7, .permutes 8954302171217920 11584701476244545, .embeds 71576909587719]
private def supply := witnessAt tags 0xec3870d1a3870f1e3870d1a38710203870d1a3870f1e3870d1a3870be03870d1a3870f1e3870d1a38710203870d1a3870f1e3870d1a38774e83870d1a3870f1e3870d1a38710203870d1a3870f1e3870d1a38770e03870d1a3870f1e3870d1a38710203870d1a3870f1e3870d1a387750e2f80be22f80be42f80be22f80be62f80be22f80be42f80be22f822e1c3a74e1c3a74e1c3a74e1c3a74e1c3a74e1c3a74e1c3a74e1c3a22e9d3870e9d3870e9d3870e9d3870e9d3870e9d3870e9d3870e9d3822e003880e003900e003880e003980e003880e003900e003880e003780163870d1a3870f1e3870d1a38710203870d1a3870f1e3870d1a3873f0e3870d1a3870f1e3870d1a38710203870d1a3870f1e3870d1a3876e123870d1a3870f1e3870d1a38710203870d1a3870f1e3870d1a3876d0e3870d1a3870f1e3870d1a38710203870d1a3870f1e3870d1a3860c16fc5bf16fc5bf16fc5bf16fc5bf16fc5bf16fc5bf16fc5bf16fc5a213404ec13ac4ea13a44e8139c4e613944e4138c4e213844e0137c4a20f403de0f743dc0f6c3da0f643d80f5c3d60f543d40f4c3d20f443a2a0027809c026809802580940248090023808c02280880218084006007e3870d1a3870f1e3870d1a38710203870d1a3870f1e3870d1a3870b0e3870d1a3870f1e3870d1a38710203870d1a3870f1e3870d1a38741123870d1a3870f1e3870d1a38710203870d1a3870f1e3870d1a387400e3870d1a3870f1e3870d1a38710203870d1a3870f1e3870d1a389127e2df8b7e2df8b7e2df8b7e2df8b7e2df8b7e2df8b7e2df8b7e2dfa212844be12f44bc12ec4ba12e44b812dc4b612d44b412cc4b212c44a20e843b00ebc3ae0eb43ac0eac3aa0ea43a80e9c3a60e943a40e8c3a242010003e00f003a00e003600d003200c002e00b002a00a002600900163870d1a3870f1e3870d1a38710203870d1a3870f1e3870d1a387110e207081a207081e207081a2070820207081a207081e207081a2070812187061a187061e187061a1870620187061a187061e187061a187060e207081a207081e207081a2070820207081a207081e207081a2060816280810408081060c081040808108100810408081060c081040808112200810408081060c081040808108100810408081060c08104080810e180810408081060c081040808108100810408081060c08104080810a000800400080060008004000800800080040008006000800400080 7
private def pass (s : ℕ) := fastWitness 10 10 Terminal18.target 8692541981696 words11 masks s (supply s)

private theorem run5 : span pass 0 32 = true := by decide +kernel
private theorem run6 : span pass 32 32 = true := by decide +kernel
private theorem run4 : span pass 0 64 = true := span_add (a:=32) (b:=32) run5 run6
private theorem run8 : span pass 64 32 = true := by decide +kernel
private theorem run9 : span pass 96 32 = true := by decide +kernel
private theorem run7 : span pass 64 64 = true := span_add (a:=32) (b:=32) run8 run9
private theorem run3 : span pass 0 128 = true := span_add (a:=64) (b:=64) run4 run7
private theorem run12 : span pass 128 32 = true := by decide +kernel
private theorem run13 : span pass 160 32 = true := by decide +kernel
private theorem run11 : span pass 128 64 = true := span_add (a:=32) (b:=32) run12 run13
private theorem run15 : span pass 192 32 = true := by decide +kernel
private theorem run16 : span pass 224 32 = true := by decide +kernel
private theorem run14 : span pass 192 64 = true := span_add (a:=32) (b:=32) run15 run16
private theorem run10 : span pass 128 128 = true := span_add (a:=64) (b:=64) run11 run14
private theorem run2 : span pass 0 256 = true := span_add (a:=128) (b:=128) run3 run10
private theorem run20 : span pass 256 32 = true := by decide +kernel
private theorem run21 : span pass 288 32 = true := by decide +kernel
private theorem run19 : span pass 256 64 = true := span_add (a:=32) (b:=32) run20 run21
private theorem run23 : span pass 320 32 = true := by decide +kernel
private theorem run24 : span pass 352 32 = true := by decide +kernel
private theorem run22 : span pass 320 64 = true := span_add (a:=32) (b:=32) run23 run24
private theorem run18 : span pass 256 128 = true := span_add (a:=64) (b:=64) run19 run22
private theorem run27 : span pass 384 32 = true := by decide +kernel
private theorem run28 : span pass 416 32 = true := by decide +kernel
private theorem run26 : span pass 384 64 = true := span_add (a:=32) (b:=32) run27 run28
private theorem run30 : span pass 448 32 = true := by decide +kernel
private theorem run31 : span pass 480 32 = true := by decide +kernel
private theorem run29 : span pass 448 64 = true := span_add (a:=32) (b:=32) run30 run31
private theorem run25 : span pass 384 128 = true := span_add (a:=64) (b:=64) run26 run29
private theorem run17 : span pass 256 256 = true := span_add (a:=128) (b:=128) run18 run25
private theorem run1 : span pass 0 512 = true := span_add (a:=256) (b:=256) run2 run17
private theorem run36 : span pass 512 32 = true := by decide +kernel
private theorem run37 : span pass 544 32 = true := by decide +kernel
private theorem run35 : span pass 512 64 = true := span_add (a:=32) (b:=32) run36 run37
private theorem run39 : span pass 576 32 = true := by decide +kernel
private theorem run40 : span pass 608 32 = true := by decide +kernel
private theorem run38 : span pass 576 64 = true := span_add (a:=32) (b:=32) run39 run40
private theorem run34 : span pass 512 128 = true := span_add (a:=64) (b:=64) run35 run38
private theorem run43 : span pass 640 32 = true := by decide +kernel
private theorem run44 : span pass 672 32 = true := by decide +kernel
private theorem run42 : span pass 640 64 = true := span_add (a:=32) (b:=32) run43 run44
private theorem run46 : span pass 704 32 = true := by decide +kernel
private theorem run47 : span pass 736 32 = true := by decide +kernel
private theorem run45 : span pass 704 64 = true := span_add (a:=32) (b:=32) run46 run47
private theorem run41 : span pass 640 128 = true := span_add (a:=64) (b:=64) run42 run45
private theorem run33 : span pass 512 256 = true := span_add (a:=128) (b:=128) run34 run41
private theorem run51 : span pass 768 32 = true := by decide +kernel
private theorem run52 : span pass 800 32 = true := by decide +kernel
private theorem run50 : span pass 768 64 = true := span_add (a:=32) (b:=32) run51 run52
private theorem run54 : span pass 832 32 = true := by decide +kernel
private theorem run55 : span pass 864 32 = true := by decide +kernel
private theorem run53 : span pass 832 64 = true := span_add (a:=32) (b:=32) run54 run55
private theorem run49 : span pass 768 128 = true := span_add (a:=64) (b:=64) run50 run53
private theorem run58 : span pass 896 32 = true := by decide +kernel
private theorem run59 : span pass 928 32 = true := by decide +kernel
private theorem run57 : span pass 896 64 = true := span_add (a:=32) (b:=32) run58 run59
private theorem run61 : span pass 960 32 = true := by decide +kernel
private theorem run62 : span pass 992 32 = true := by decide +kernel
private theorem run60 : span pass 960 64 = true := span_add (a:=32) (b:=32) run61 run62
private theorem run56 : span pass 896 128 = true := span_add (a:=64) (b:=64) run57 run60
private theorem run48 : span pass 768 256 = true := span_add (a:=128) (b:=128) run49 run56
private theorem run32 : span pass 512 512 = true := span_add (a:=256) (b:=256) run33 run48
private theorem run0 : span pass 0 1024 = true := span_add (a:=512) (b:=512) run1 run32

theorem checked : rowStep 10 8692541981696 words11 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify10_012
end EarlyRamsey
