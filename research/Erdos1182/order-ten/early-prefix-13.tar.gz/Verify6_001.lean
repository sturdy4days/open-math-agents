import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify6_001
private def masks : Array ℕ := #[48, 48, 48, 48, 15, 15]
private def tags : Array Witness := #[.undominated 0, .undominated 1, .undominated 2, .undominated 3, .permutes 507840 206703681, .undominated 5, .permutes 1012737 5574330369, .permutes 1012737 5574329346, .permutes 514624 6610292833, .permutes 1012737 5574296579, .permutes 514624 6610325569, .permutes 514624 6447828033, .permutes 1012737 204539044, .permutes 1012737 5573248004, .permutes 514624 6610357313, .permutes 514624 6447796289, .permutes 1012737 205587619, .permutes 514624 6447763553, .permutes 1012737 205620386, .permutes 1012737 205621409, .gap 5 6, .undominated 4, .permutes 1012737 6614517761, .permutes 1012737 6614516738, .permutes 514624 5570105441, .permutes 1012737 6614483971, .permutes 514624 5570138177, .permutes 514624 5375134785, .permutes 1012737 170984644, .permutes 1012737 6613435396, .permutes 514624 5570169921, .permutes 514624 5375103041, .permutes 1012737 172033219, .permutes 514624 5375070305, .permutes 1012737 172065986, .permutes 1012737 172067009, .permutes 1047552 6610357313, .gap 1 2, .gap 1 3, .gap 1 4, .permutes 2064384 206703681]
private def supply := witnessAt tags 0xa259669a59679e59669a59645238a181f79d71b69961759551349140f38d30b2892071851000400800400c0040080040 6
private def pass (s : ℕ) := fastWitness 10 6 Terminal18.target 16320 words7 masks s (supply s)

private theorem run1 : span pass 0 32 = true := by decide +kernel
private theorem run2 : span pass 32 32 = true := by decide +kernel
private theorem run0 : span pass 0 64 = true := span_add (a:=32) (b:=32) run1 run2

theorem checked : rowStep 6 16320 words7 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify6_001
end EarlyRamsey
