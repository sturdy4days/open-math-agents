#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
export LEAN_PATH="$PWD${LEAN_PATH:+:$LEAN_PATH}"
while IFS= read -r module
do
  lean -j1 -M4200 -DElab.async=false -o "$module.olean" "$module.lean"
done < build-order.txt
