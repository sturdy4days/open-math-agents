import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify10_009
private def masks : Array ℕ := #[768, 768, 768, 768, 352, 656, 656, 352, 159, 111]
private def tags : Array Witness := #[.undominated 0, .undominated 1, .undominated 2, .undominated 3, .undominated 4, .undominated 7, .undominated 6, .permutes 8672534329294867 10485083611010311, .undominated 5, .permutes 8672534329294867 10485083611043078, .permutes 7297406967742464 361986559970369, .gap 5 10, .permutes 7297406967742464 327934953000001, .permutes 8672534329294867 11575799145830629, .gap 6 9, .permutes 8672534329294867 11575799145831621, .gap 7 9, .gap 8 10, .undominated 9, .gap 1 8, .gap 1 5, .permutes 4495864626151424 10492845896109121, .gap 2 5, .gap 3 5, .gap 4 5, .undominated 8, .gap 1 7, .gap 1 6, .gap 2 6, .gap 3 6, .gap 4 6, .permutes 4495864626151424 11584626550246465, .permutes 7868088096653312 11584701638773825, .gap 1 2, .gap 1 3, .gap 1 4, .embeds 71576909587719]
private def supply := witnessAt tags 0x9218628a18638e18628a18545218628a18638e18628a185b6e18628a18638e18628a18545218628a18638e18628a185a6a18628a18638e18628a18545218628a18638e18628a185b6e18628a18638e18628a18545218628a18638e18628a18534e18628a18638e18628a18545218628a18638e18628a185b6e18628a18638e18628a18545218628a18638e18628a185a6a18628a18638e18628a18545218628a18638e18628a185b6e18628a18638e18628a18545218628a18638e18628a186039b71b75b71b79b71b75b71b2db71b75b71b79b71b75b71b6da6da6da6da6da6da6da6da6da6da6da6da6da6da6da6da69b69b69b69b69b69b69b69b69b69b69b69b69b69b69b69b6dc6dd6dc6de6dc6dd6dc6df10410410410410410410410445b71b75b71b79b71b75b71b2db71b75b71b79b71b75b7196da6da6da6da6da6da6da6da6da6da6da6da6da6da6da6d969b69b69b69b69b69b69b69b69b69b69b69b69b69b69b6991451451451451451451451451041041041041041041041042d45945d45946145945d45945135135135135135135135133945945d45946145945d45945135135135135135135135134145945d45946145945d45945135135135135135135135133945945d45946145945d45925135135135135135135135124d44d44d44d44d44d44d44d45165175165185165175165154d44d44d44d44d44d44d44d42082082082082082082082084d44d44d44d44d44d44d44d41861861861861861861861864d44d44d44d44d44d44d44d22082082082082082082082082c00400800400c00400800404400400800400c00400800404000400800400c00400800403c00400800400c00400800403800400800400c00400800403400400800400c00400800403000400800400c00400800401000400800400c00400800402c00400800400c00400800402800400800400c00400800402400400800400c00400800402000400800400c00400800401c00400800400c00400800401800400800400c00400800401400400800400c00400800401000400800400c0040080040 6
private def pass (s : ℕ) := fastWitness 10 10 Terminal18.target 7670745022464 words11 masks s (supply s)

private theorem run5 : span pass 0 32 = true := by decide +kernel
private theorem run6 : span pass 32 32 = true := by decide +kernel
private theorem run4 : span pass 0 64 = true := span_add (a:=32) (b:=32) run5 run6
private theorem run8 : span pass 64 32 = true := by decide +kernel
private theorem run9 : span pass 96 32 = true := by decide +kernel
private theorem run7 : span pass 64 64 = true := span_add (a:=32) (b:=32) run8 run9
private theorem run3 : span pass 0 128 = true := span_add (a:=64) (b:=64) run4 run7
private theorem run12 : span pass 128 32 = true := by decide +kernel
private theorem run13 : span pass 160 32 = true := by decide +kernel
private theorem run11 : span pass 128 64 = true := span_add (a:=32) (b:=32) run12 run13
private theorem run15 : span pass 192 32 = true := by decide +kernel
private theorem run16 : span pass 224 32 = true := by decide +kernel
private theorem run14 : span pass 192 64 = true := span_add (a:=32) (b:=32) run15 run16
private theorem run10 : span pass 128 128 = true := span_add (a:=64) (b:=64) run11 run14
private theorem run2 : span pass 0 256 = true := span_add (a:=128) (b:=128) run3 run10
private theorem run20 : span pass 256 32 = true := by decide +kernel
private theorem run21 : span pass 288 32 = true := by decide +kernel
private theorem run19 : span pass 256 64 = true := span_add (a:=32) (b:=32) run20 run21
private theorem run23 : span pass 320 32 = true := by decide +kernel
private theorem run24 : span pass 352 32 = true := by decide +kernel
private theorem run22 : span pass 320 64 = true := span_add (a:=32) (b:=32) run23 run24
private theorem run18 : span pass 256 128 = true := span_add (a:=64) (b:=64) run19 run22
private theorem run27 : span pass 384 32 = true := by decide +kernel
private theorem run28 : span pass 416 32 = true := by decide +kernel
private theorem run26 : span pass 384 64 = true := span_add (a:=32) (b:=32) run27 run28
private theorem run30 : span pass 448 32 = true := by decide +kernel
private theorem run31 : span pass 480 32 = true := by decide +kernel
private theorem run29 : span pass 448 64 = true := span_add (a:=32) (b:=32) run30 run31
private theorem run25 : span pass 384 128 = true := span_add (a:=64) (b:=64) run26 run29
private theorem run17 : span pass 256 256 = true := span_add (a:=128) (b:=128) run18 run25
private theorem run1 : span pass 0 512 = true := span_add (a:=256) (b:=256) run2 run17
private theorem run36 : span pass 512 32 = true := by decide +kernel
private theorem run37 : span pass 544 32 = true := by decide +kernel
private theorem run35 : span pass 512 64 = true := span_add (a:=32) (b:=32) run36 run37
private theorem run39 : span pass 576 32 = true := by decide +kernel
private theorem run40 : span pass 608 32 = true := by decide +kernel
private theorem run38 : span pass 576 64 = true := span_add (a:=32) (b:=32) run39 run40
private theorem run34 : span pass 512 128 = true := span_add (a:=64) (b:=64) run35 run38
private theorem run43 : span pass 640 32 = true := by decide +kernel
private theorem run44 : span pass 672 32 = true := by decide +kernel
private theorem run42 : span pass 640 64 = true := span_add (a:=32) (b:=32) run43 run44
private theorem run46 : span pass 704 32 = true := by decide +kernel
private theorem run47 : span pass 736 32 = true := by decide +kernel
private theorem run45 : span pass 704 64 = true := span_add (a:=32) (b:=32) run46 run47
private theorem run41 : span pass 640 128 = true := span_add (a:=64) (b:=64) run42 run45
private theorem run33 : span pass 512 256 = true := span_add (a:=128) (b:=128) run34 run41
private theorem run51 : span pass 768 32 = true := by decide +kernel
private theorem run52 : span pass 800 32 = true := by decide +kernel
private theorem run50 : span pass 768 64 = true := span_add (a:=32) (b:=32) run51 run52
private theorem run54 : span pass 832 32 = true := by decide +kernel
private theorem run55 : span pass 864 32 = true := by decide +kernel
private theorem run53 : span pass 832 64 = true := span_add (a:=32) (b:=32) run54 run55
private theorem run49 : span pass 768 128 = true := span_add (a:=64) (b:=64) run50 run53
private theorem run58 : span pass 896 32 = true := by decide +kernel
private theorem run59 : span pass 928 32 = true := by decide +kernel
private theorem run57 : span pass 896 64 = true := span_add (a:=32) (b:=32) run58 run59
private theorem run61 : span pass 960 32 = true := by decide +kernel
private theorem run62 : span pass 992 32 = true := by decide +kernel
private theorem run60 : span pass 960 64 = true := span_add (a:=32) (b:=32) run61 run62
private theorem run56 : span pass 896 128 = true := span_add (a:=64) (b:=64) run57 run60
private theorem run48 : span pass 768 256 = true := span_add (a:=128) (b:=128) run49 run56
private theorem run32 : span pass 512 512 = true := span_add (a:=256) (b:=256) run33 run48
private theorem run0 : span pass 0 1024 = true := span_add (a:=512) (b:=512) run1 run32

theorem checked : rowStep 10 7670745022464 words11 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify10_009
end EarlyRamsey
