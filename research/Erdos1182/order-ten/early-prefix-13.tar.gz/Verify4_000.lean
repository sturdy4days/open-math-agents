import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify4_000
private def masks : Array ℕ := #[8, 8, 8, 7]
private def tags : Array Witness := #[.undominated 0, .undominated 1, .undominated 2, .permutes 504 134209, .permutes 960 4197441, .gap 1 2, .gap 1 3, .permutes 960 134209]
private def supply := witnessAt tags 0xf6ed6c608408 3
private def pass (s : ℕ) := fastWitness 10 4 Terminal18.target 56 words5 masks s (supply s)

private theorem run0 : span pass 0 16 = true := by decide +kernel

theorem checked : rowStep 4 56 words5 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify4_000
end EarlyRamsey
