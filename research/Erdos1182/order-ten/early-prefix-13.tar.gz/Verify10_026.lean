import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify10_026
private def masks : Array ℕ := #[134, 265, 577, 578, 448, 448, 60, 561, 562, 396]
private def tags : Array Witness := #[.undominated 0, .undominated 3, .undominated 2, .undominated 4, .undominated 1, .undominated 5, .undominated 9, .permutes 539959685722880 2541318397264001, .gap 1 4, .permutes 539959685722880 1450603936219234, .gap 1 9, .permutes 3983689165845249 9328370673261633, .gap 1 7, .undominated 8, .undominated 7, .gap 2 3, .gap 2 7, .undominated 6, .permutes 1660720287367168 9327400143820961, .gap 1 5, .gap 1 6, .gap 2 8, .permutes 2783812118904960 9263465058472992, .gap 1 10, .permutes 1660720287367168 10419214115412130, .gap 2 5, .gap 2 6, .permutes 2783812118904960 10388231061443648, .permutes 2079709988519968 10422411390420165, .permutes 1105884292908032 8207100568343683, .permutes 2088571737145378 11475844459694180, .permutes 2088571737145378 11475845534450819, .gap 3 9, .gap 4 8, .permutes 7005507837231112 11506673932894308, .permutes 7005507837231112 11507806730485891, .gap 3 5, .gap 3 6, .permutes 7474671440114307 8206966656601153, .permutes 7474671440114307 8206966321384513, .gap 2 10, .embeds 71576909587719]
private def supply := witnessAt tags 0xa483d33c86532133d32136534c84d44c84d42144d42144d45085135085132135132135134c84cc4c84d020c4cc20a4e03083133c86532133132136534c84d44c84d42144d42144d45085135085132135132135134c84d74c84e820a4d74514515483cc3c864020c3cc20a6406483cc3c868020c3cc20a6806883cc3c864020c3cc20a6406483cc3c840020c3cc20a8003083193c864020a31920a64030831a3c868020a31a20a6803083193c864020a31920a6403083283c8a0020a3274514402883d32884132133c42135444c84d44c84d42144c42144c45085135085132135042135044c84cc4c84d020c4c42214c43083132885532133042135444c84d44c84d42144c42144c45085135085132135042135044c84d74c84e62174c44514442883cc28840020c3c42249002883cc28840020c3c42259402883cc28840020c3c42249002883cc28840020c3c422388030832028884022030421f7800c30c30c30c00c30c40c30c01451451451401451441451400c30c30c30c00c30c40c30c05c85d33c86532135d32136534c84d44c84d42144d42144d45085135085132135132135134c84cc4c84d020c4cc20a4dd3083133c26422130412020424c84d44c24c22140412020425085135025022130412020424c84dc4c24c220a0414420425483cc3c864020c3cc20a6406483cc3c868020c3cc20a6806883cc3c864020c3cc20a64064e3ce3ce40020e3ce20e6c03083193c264020a04120204030831a3c268020a0412020403083193c264020a04120204030e30e3c260020e0414420402885d32884132135c42135444c84d44c84d42144c42144c45085135085132135042135044c834d4c834d20c3442163443083132825422130442020444c84d44c24c22140442020445085135025022130442020444c834d4c23422120444420442883cc28840020c3c41861802883cc28840020c3c41861802883cc28840020c3c418618028e34e28e34020e34418e34030830b2822402070441820400c30c30c20c00c30440c20401451451421401450441420400c30c30c20c00c30440c2040 6
private def pass (s : ℕ) := fastWitness 10 10 Terminal18.target 27226439286803 words11 masks s (supply s)

private theorem run5 : span pass 0 32 = true := by decide +kernel
private theorem run6 : span pass 32 32 = true := by decide +kernel
private theorem run4 : span pass 0 64 = true := span_add (a:=32) (b:=32) run5 run6
private theorem run8 : span pass 64 32 = true := by decide +kernel
private theorem run9 : span pass 96 32 = true := by decide +kernel
private theorem run7 : span pass 64 64 = true := span_add (a:=32) (b:=32) run8 run9
private theorem run3 : span pass 0 128 = true := span_add (a:=64) (b:=64) run4 run7
private theorem run12 : span pass 128 32 = true := by decide +kernel
private theorem run13 : span pass 160 32 = true := by decide +kernel
private theorem run11 : span pass 128 64 = true := span_add (a:=32) (b:=32) run12 run13
private theorem run15 : span pass 192 32 = true := by decide +kernel
private theorem run16 : span pass 224 32 = true := by decide +kernel
private theorem run14 : span pass 192 64 = true := span_add (a:=32) (b:=32) run15 run16
private theorem run10 : span pass 128 128 = true := span_add (a:=64) (b:=64) run11 run14
private theorem run2 : span pass 0 256 = true := span_add (a:=128) (b:=128) run3 run10
private theorem run20 : span pass 256 32 = true := by decide +kernel
private theorem run21 : span pass 288 32 = true := by decide +kernel
private theorem run19 : span pass 256 64 = true := span_add (a:=32) (b:=32) run20 run21
private theorem run23 : span pass 320 32 = true := by decide +kernel
private theorem run24 : span pass 352 32 = true := by decide +kernel
private theorem run22 : span pass 320 64 = true := span_add (a:=32) (b:=32) run23 run24
private theorem run18 : span pass 256 128 = true := span_add (a:=64) (b:=64) run19 run22
private theorem run27 : span pass 384 32 = true := by decide +kernel
private theorem run28 : span pass 416 32 = true := by decide +kernel
private theorem run26 : span pass 384 64 = true := span_add (a:=32) (b:=32) run27 run28
private theorem run30 : span pass 448 32 = true := by decide +kernel
private theorem run31 : span pass 480 32 = true := by decide +kernel
private theorem run29 : span pass 448 64 = true := span_add (a:=32) (b:=32) run30 run31
private theorem run25 : span pass 384 128 = true := span_add (a:=64) (b:=64) run26 run29
private theorem run17 : span pass 256 256 = true := span_add (a:=128) (b:=128) run18 run25
private theorem run1 : span pass 0 512 = true := span_add (a:=256) (b:=256) run2 run17
private theorem run36 : span pass 512 32 = true := by decide +kernel
private theorem run37 : span pass 544 32 = true := by decide +kernel
private theorem run35 : span pass 512 64 = true := span_add (a:=32) (b:=32) run36 run37
private theorem run39 : span pass 576 32 = true := by decide +kernel
private theorem run40 : span pass 608 32 = true := by decide +kernel
private theorem run38 : span pass 576 64 = true := span_add (a:=32) (b:=32) run39 run40
private theorem run34 : span pass 512 128 = true := span_add (a:=64) (b:=64) run35 run38
private theorem run43 : span pass 640 32 = true := by decide +kernel
private theorem run44 : span pass 672 32 = true := by decide +kernel
private theorem run42 : span pass 640 64 = true := span_add (a:=32) (b:=32) run43 run44
private theorem run46 : span pass 704 32 = true := by decide +kernel
private theorem run47 : span pass 736 32 = true := by decide +kernel
private theorem run45 : span pass 704 64 = true := span_add (a:=32) (b:=32) run46 run47
private theorem run41 : span pass 640 128 = true := span_add (a:=64) (b:=64) run42 run45
private theorem run33 : span pass 512 256 = true := span_add (a:=128) (b:=128) run34 run41
private theorem run51 : span pass 768 32 = true := by decide +kernel
private theorem run52 : span pass 800 32 = true := by decide +kernel
private theorem run50 : span pass 768 64 = true := span_add (a:=32) (b:=32) run51 run52
private theorem run54 : span pass 832 32 = true := by decide +kernel
private theorem run55 : span pass 864 32 = true := by decide +kernel
private theorem run53 : span pass 832 64 = true := span_add (a:=32) (b:=32) run54 run55
private theorem run49 : span pass 768 128 = true := span_add (a:=64) (b:=64) run50 run53
private theorem run58 : span pass 896 32 = true := by decide +kernel
private theorem run59 : span pass 928 32 = true := by decide +kernel
private theorem run57 : span pass 896 64 = true := span_add (a:=32) (b:=32) run58 run59
private theorem run61 : span pass 960 32 = true := by decide +kernel
private theorem run62 : span pass 992 32 = true := by decide +kernel
private theorem run60 : span pass 960 64 = true := span_add (a:=32) (b:=32) run61 run62
private theorem run56 : span pass 896 128 = true := span_add (a:=64) (b:=64) run57 run60
private theorem run48 : span pass 768 256 = true := span_add (a:=128) (b:=128) run49 run56
private theorem run32 : span pass 512 512 = true := span_add (a:=256) (b:=256) run33 run48
private theorem run0 : span pass 0 1024 = true := span_add (a:=512) (b:=512) run1 run32

theorem checked : rowStep 10 27226439286803 words11 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify10_026
end EarlyRamsey
