import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify1_000
private def masks : Array ℕ := #[0]
private def tags : Array Witness := #[.undominated 0, .permutes 1 1]
private def supply := witnessAt tags 0x2 1
private def pass (s : ℕ) := fastWitness 10 1 Terminal18.target 0 words2 masks s (supply s)

private theorem run0 : span pass 0 2 = true := by decide +kernel

theorem checked : rowStep 1 0 words2 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify1_000
end EarlyRamsey
