import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify7_002
private def masks : Array ℕ := #[80, 96, 96, 80, 41, 22, 15]
private def tags : Array Witness := #[.undominated 0, .undominated 1, .undominated 2, .undominated 3, .permutes 127797387 7619085509, .permutes 57925920 179415746689, .gap 1 6, .gap 4 6, .permutes 57925920 213809005666, .gap 2 5, .gap 3 5, .undominated 6, .gap 5 7, .undominated 4, .undominated 5, .gap 1 3, .gap 1 2, .gap 2 4, .permutes 66980864 246088336482, .gap 1 4, .permutes 66980864 247128492161, .permutes 266338304 7722896449]
private def supply := witnessAt tags 0xac20f7c2139c20f7c2064c20f7c2118c20f7c2143420f7c2139c20f7c2126420f7c1ce8b60d7b5cd6192651926399265192b4814048100180601806031c2110821314211082120020100201802010020 5
private def pass (s : ℕ) := fastWitness 10 7 Terminal18.target 514624 words8 masks s (supply s)

private theorem run2 : span pass 0 32 = true := by decide +kernel
private theorem run3 : span pass 32 32 = true := by decide +kernel
private theorem run1 : span pass 0 64 = true := span_add (a:=32) (b:=32) run2 run3
private theorem run5 : span pass 64 32 = true := by decide +kernel
private theorem run6 : span pass 96 32 = true := by decide +kernel
private theorem run4 : span pass 64 64 = true := span_add (a:=32) (b:=32) run5 run6
private theorem run0 : span pass 0 128 = true := span_add (a:=64) (b:=64) run1 run4

theorem checked : rowStep 7 514624 words8 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify7_002
end EarlyRamsey
