import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify5_002
private def masks : Array ℕ := #[6, 9, 17, 18, 12]
private def tags : Array Witness := #[.undominated 0, .undominated 3, .undominated 2, .undominated 4, .undominated 1, .permutes 15169 102761636, .gap 1 4, .permutes 15169 135268515, .gap 2 3, .permutes 15169 137368641, .gap 1 5, .permutes 15169 168823938, .permutes 15169 169873505, .gap 2 5, .permutes 31744 5377089]
private def supply := witnessAt tags 0xe68a86d06a846cb0a6a9827065143210 4
private def pass (s : ℕ) := fastWitness 10 5 Terminal18.target 787 words6 masks s (supply s)

private theorem run0 : span pass 0 32 = true := by decide +kernel

theorem checked : rowStep 5 787 words6 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify5_002
end EarlyRamsey
