import EarlyCatalogue

namespace EarlyRamsey
open BBHExtension SimpleGraph

namespace Verify8_007
private def masks : Array ℕ := #[14, 81, 161, 193, 162, 84, 42, 28]
private def tags : Array Witness := #[.undominated 0, .undominated 4, .undominated 2, .undominated 5, .undominated 1, .undominated 3, .gap 1 5, .permutes 16221241363 4503274496197, .undominated 6, .gap 2 3, .gap 1 6, .permutes 4086633664 5638259474626, .gap 1 7, .permutes 16221241363 3441351132386, .undominated 7, .permutes 4086633664 6736698376355, .permutes 16221241363 2342912165123, .gap 1 8, .permutes 4086633664 1314435203202, .gap 2 8, .permutes 4086633664 4576390422753, .permutes 4086633664 249211000993, .permutes 4086633664 3544493261057, .permutes 16221241363 7869456062723, .permutes 16221241363 5741304088705, .gap 2 4, .gap 4 6, .gap 3 7, .gap 2 6, .permutes 4086633664 2480448635105, .permutes 16221241363 9003328476386, .permutes 16221241363 6874100632705, .gap 3 4, .gap 4 5, .permutes 16221241363 1348624025797, .permutes 4086633664 8872531072131, .permutes 4086633664 7808419371138, .permutes 4086633664 144050462818, .permutes 68451041280 282600803393]
private def supply := witnessAt tags 0x98624a24665c64624a24670018a24a18c65b18a24a19b6c02862912466532862932464c018c29118c6611a52a41a388030624a3064d380624a2464c018a2441a180418a24419f7802862913064d32862082462001912840c30c419d2040c30c044644a24665c64624a24670018a44a18c65b18a24a38e38028629a2426422862982425c018c04118204219604138204030644a3065544c524524548018a4441903c418524438538028628d3022c22852052422001870440c20441850440c2040 6
private def pass (s : ℕ) := fastWitness 10 8 Terminal18.target 60117131 words9 masks s (supply s)

private theorem run3 : span pass 0 32 = true := by decide +kernel
private theorem run4 : span pass 32 32 = true := by decide +kernel
private theorem run2 : span pass 0 64 = true := span_add (a:=32) (b:=32) run3 run4
private theorem run6 : span pass 64 32 = true := by decide +kernel
private theorem run7 : span pass 96 32 = true := by decide +kernel
private theorem run5 : span pass 64 64 = true := span_add (a:=32) (b:=32) run6 run7
private theorem run1 : span pass 0 128 = true := span_add (a:=64) (b:=64) run2 run5
private theorem run10 : span pass 128 32 = true := by decide +kernel
private theorem run11 : span pass 160 32 = true := by decide +kernel
private theorem run9 : span pass 128 64 = true := span_add (a:=32) (b:=32) run10 run11
private theorem run13 : span pass 192 32 = true := by decide +kernel
private theorem run14 : span pass 224 32 = true := by decide +kernel
private theorem run12 : span pass 192 64 = true := span_add (a:=32) (b:=32) run13 run14
private theorem run8 : span pass 128 128 = true := span_add (a:=64) (b:=64) run9 run12
private theorem run0 : span pass 0 256 = true := span_add (a:=128) (b:=128) run1 run8

theorem checked : rowStep 8 60117131 words9 := by
  apply parent_step _ masks supply
  · decide +kernel
  · intro s hs
    exact span_sound run0 (Nat.zero_le s) hs

end Verify8_007
end EarlyRamsey
