import Frontier
import TenthFrom18

namespace EarlyRamsey

open BBHExtension SimpleGraph

/-- Once the middle transitions are certified, the separate terminal proof
applies immediately; earlier levels never have to be enumerated again. -/
theorem order19_of_remaining {base : ℕ} (small : base ≤ 18)
    (catalogue : ∀ k, List (SimpleGraph (Fin k)))
    (frontier : ∀ H : SimpleGraph (Fin base),
      Maximal (fun D : SimpleGraph (Fin base) => D.CliqueFree 3) H → (¬ decode 10 Terminal18.target ⊑ Hᶜ) →
      ∃ D ∈ catalogue base, Nonempty (H ≃g D))
    (rows : ∀ k, base ≤ k → k < 18 →
      selectedRows (decode 10 Terminal18.target) priorityRow (catalogue k) (catalogue (k+1)))
    (last : ∀ D ∈ catalogue 18, ∃ i : Fin 3, Nonempty (D ≃g decode 18 (Terminal18.parent i))) :
    ∀ H : SimpleGraph (Fin 19), H.CliqueFree 3 → decode 10 Terminal18.target ⊑ Hᶜ := by
  apply Terminal18.order19
  intro P maxP avoid
  obtain ⟨D,hD,⟨f⟩⟩ := continue_from catalogue frontier rows 18 small le_rfl P maxP avoid
  obtain ⟨i,⟨g⟩⟩ := last D hD
  exact ⟨i,⟨f.trans g⟩⟩

end EarlyRamsey

#print axioms EarlyRamsey.order19_of_remaining
