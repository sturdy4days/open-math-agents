import Atlas
import Mathlib.Data.Fin.SuccPred

namespace BBHExtension

open SimpleGraph

/-- A triangle-free graph is maximal if every missing edge already has a
common neighbor. -/
theorem maximal_of_saturation {A : Type*} (P : SimpleGraph A) (free : P.CliqueFree 3)
    (sat : ∀ i j, i ≠ j → ¬P.Adj i j → ∃ w, P.Adj i w ∧ P.Adj j w) :
    Maximal (fun D : SimpleGraph A => D.CliqueFree 3) P := by
  refine ⟨free, ?_⟩
  intro Q freeQ hPQ i j edge
  by_contra miss
  obtain ⟨w,iw,jw⟩ := sat i j edge.ne miss
  exact Q.isIndepSet_neighborSet_of_triangleFree freeQ w
    (hPQ iw.symm) (hPQ jw.symm) edge.ne edge

/-- The common neighbor certifying a missing edge survives deletion. If its
only known witness is the deleted vertex, its twin supplies a new one. -/
theorem maximal_delete_twin {A : Type*} [DecidableEq A] (H : SimpleGraph A)
    (hm : Maximal (fun D : SimpleGraph A => D.CliqueFree 3) H) (u v : A) (ne : u ≠ v)
    (twins : ∀ w, H.Adj u w ↔ H.Adj v w) :
    Maximal (fun D : SimpleGraph {w : A // w ≠ u} => D.CliqueFree 3)
      (H.comap (fun w : {w : A // w ≠ u} => w.val)) := by
  let emb := SimpleGraph.Embedding.comap (Function.Embedding.subtype (fun w => w ≠ u)) H
  apply maximal_of_saturation _ (hm.1.comap ⟨emb.toCopy⟩)
  intro i j diff miss
  obtain ⟨w,iw,jw⟩ := saturation_witness hm (fun h => diff (Subtype.ext h)) miss
  by_cases wu : w = u
  · subst w
    exact ⟨⟨v,ne.symm⟩, ((twins i.val).mp iw.symm).symm, ((twins j.val).mp jw.symm).symm⟩
  · exact ⟨⟨w,wu⟩,iw,jw⟩

/-- With the deleted vertex numbered zero, the atlas parent is exactly the
induced graph; its extension row is the neighborhood of the surviving twin. -/
theorem twin_parent_zero {k : ℕ} {V : Type*} (G : SimpleGraph V) (H : SimpleGraph (Fin (k+1)))
    (hm : Maximal (fun D : SimpleGraph (Fin (k+1)) => D.CliqueFree 3) H)
    (avoid : ¬ G ⊑ Hᶜ) (z : Fin k) (twins : ∀ w, H.Adj 0 w ↔ H.Adj z.succ w) :
    let B := H.comap Fin.succ
    ∃ S : Finset (Fin k), Maximal (fun D : SimpleGraph (Fin k) => D.CliqueFree 3) B ∧
      (¬ G ⊑ Bᶜ) ∧ (∀ j, j ∈ S ↔ B.Adj z j) ∧
      (∀ j, j ∉ S → ∃ i ∈ S, B.Adj i j) ∧ H = extend B S := by
  classical
  obtain ⟨P,S,hP,avoidP,dom,eq⟩ := parent G H hm avoid
  have mem (i : Fin k) : i ∈ S ↔ H.Adj 0 i.succ := by rw [eq,extend_left]
  have zi (i : Fin k) (hi : i ∈ S) : P.Adj z i := by
    have h := (twins i.succ).mp ((mem i).mp hi)
    rw [eq,extend_old] at h
    exact h.1
  have old : H.comap Fin.succ = P := by
    ext i j
    change H.Adj i.succ j.succ ↔ P.Adj i j
    rw [eq, extend_old]
    refine ⟨And.left, fun ij => ⟨ij, ?_⟩⟩
    rintro ⟨hi,hj⟩
    exact P.isIndepSet_neighborSet_of_triangleFree hP.1 z (zi i hi) (zi j hj) ij.ne ij
  dsimp only
  rw [old]
  refine ⟨S,hP,avoidP,?_,dom,eq⟩
  intro i
  rw [mem,twins,←old]
  rfl

/-- Relabeling preserves the saturation witnesses for maximal triangle-free graphs. -/
theorem maximal_triangleFree_comap {A B : Type*} [DecidableEq B] (H : SimpleGraph B)
    (hm : Maximal (fun D : SimpleGraph B => D.CliqueFree 3) H) (e : A ≃ B) :
    Maximal (fun D : SimpleGraph A => D.CliqueFree 3) (H.comap e) := by
  let f := SimpleGraph.Iso.comap e H
  apply maximal_of_saturation _ (hm.1.comap ⟨f.toEmbedding.toCopy⟩)
  intro i j ne miss
  obtain ⟨w,iw,jw⟩ := saturation_witness hm (e.injective.ne ne) miss
  refine ⟨e.symm w, ?_, ?_⟩ <;>
    simpa only [comap_adj,Equiv.apply_symm_apply] using ‹H.Adj (e _) w›

/-- An arbitrary twin pair gives an atlas extension using an old vertex's
neighborhood. The parent is simultaneously maximal and target-avoiding. -/
theorem twin_parent {k : ℕ} {V : Type*} (G : SimpleGraph V) (H : SimpleGraph (Fin (k+1)))
    (hm : Maximal (fun D : SimpleGraph (Fin (k+1)) => D.CliqueFree 3) H)
    (avoid : ¬ G ⊑ Hᶜ) (u v : Fin (k+1)) (ne : u ≠ v) (twins : ∀ w, H.Adj u w ↔ H.Adj v w) :
    ∃ (B : SimpleGraph (Fin k)) (S : Finset (Fin k)) (z : Fin k),
      Maximal (fun D : SimpleGraph (Fin k) => D.CliqueFree 3) B ∧
      (¬ G ⊑ Bᶜ) ∧ (∀ j, j ∈ S ↔ B.Adj z j) ∧
      (∀ j, j ∉ S → ∃ i ∈ S, B.Adj i j) ∧ Nonempty (H ≃g extend B S) := by
  classical
  let e := Equiv.swap 0 u
  let K := H.comap e
  let iso : K ≃g H := SimpleGraph.Iso.comap e H
  have h0 : e 0 = u := Equiv.swap_apply_left _ _
  have nz : e.symm v ≠ 0 := fun eq => ne (h0.symm.trans (e.symm_apply_eq.mp eq).symm)
  obtain ⟨z,hz⟩ := Fin.exists_succ_eq_of_ne_zero nz
  have ez : e z.succ = v := e.eq_symm_apply.mp hz
  have tw (w : Fin (k+1)) : K.Adj 0 w ↔ K.Adj z.succ w := by
    change H.Adj (e 0) (e w) ↔ H.Adj (e z.succ) (e w)
    rw [h0,ez]; exact twins _
  have noK : ¬ G ⊑ Kᶜ := fun h => avoid
    (h.trans ⟨(SimpleGraph.Embedding.complEquiv iso.toEmbedding).toCopy⟩)
  obtain ⟨S,hmB,noB,exact_row,dom,extend_eq⟩ :=
    twin_parent_zero G K (maximal_triangleFree_comap H hm e) noK z tw
  exact ⟨K.comap Fin.succ,S,z,hmB,noB,exact_row,dom,extend_eq ▸ ⟨iso.symm⟩⟩

/-- A twin extension still uses an actual neighbor row after the parent is
relabelled to its stored atlas representative. -/
theorem twin_row_image {A B : Type*} {P : SimpleGraph A} {Q : SimpleGraph B}
    (e : P ≃g Q) (S : Finset A) (z : A) (row : ∀ j, j ∈ S ↔ P.Adj z j) :
    ∀ j, j ∈ S.map e.toEquiv.toEmbedding ↔ Q.Adj (e z) j := by
  intro j
  obtain ⟨i,rfl⟩ := e.surjective j
  exact (Finset.mem_map' ..).trans ((row i).trans e.map_rel_iff.symm)

end BBHExtension

#print axioms BBHExtension.maximal_delete_twin
#print axioms BBHExtension.twin_parent_zero
#print axioms BBHExtension.twin_parent
