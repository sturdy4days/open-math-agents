#!/usr/bin/env python3
"""Recompile the terminal and predecessor proofs against the verified prior library."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
p = argparse.ArgumentParser()
p.add_argument('--prior-lib', required=True, type=Path, help="build/lib from the pinned Results supplement")
p.add_argument('--build', required=True, type=Path, help="new or empty local output directory")
p.add_argument('--lean', default='lean')
p.add_argument('--memory-mib', default=8200, type=int)
args = p.parse_args()
manifest = json.loads((root/'manifest.json').read_text())
for name, digest in manifest['files'].items():
    if sha((root/name).read_bytes()) != digest:
        sys.exit(f'File hash mismatch: {name}')
version = subprocess.check_output([args.lean, '--version'], text=True)
if 'version 4.33.1,' not in version:
    sys.exit('Expected Lean 4.33.1: '+version)
prior = args.prior_lib.resolve()
receipt = hashlib.sha256()
for name in manifest['priorObjects']:
    val = (prior/(name.replace('.', '/')+'.olean')).read_bytes()
    receipt.update((name+' '+sha(val)+'\n').encode())
if receipt.hexdigest() != manifest['priorFingerprint']:
    sys.exit('Prior object set did not match the signed source-archive manifests')
build = args.build.resolve()
build.mkdir(exist_ok=True, parents=True)
if list(build.iterdir()):
    sys.exit('Please name a fresh, empty output directory')
lib, logs = build/'lib', build/'logs'
lib.mkdir(); logs.mkdir()
env = dict(os.environ, LEAN_NUM_THREADS='1')
paths = [str(Path(t).resolve()) for t in os.environ.get('LEAN_PATH','').split(os.pathsep) if t]
env['LEAN_PATH'] = os.pathsep.join([str(lib),str(prior),*paths])
record = []
for name in manifest['order']:
    start=time.monotonic()
    r=subprocess.run([args.lean,'-j1',f'-M{args.memory_mib}','-o',str(lib/(name+'.olean')),name+'.lean'],
                     cwd=root/'src',env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    (logs/(name+'.log')).write_text(r.stdout)
    if r.returncode or 'warning:' in r.stdout:
        print(r.stdout);sys.exit(f'Failed replay of {name}')
    if name=='PriorityTerminalAudit':
        lines = r.stdout.strip().splitlines()
        if len(lines)!=len(manifest['audit']) or any(
            not any(line.startswith("'"+constant+"' depends on axioms:") and
                    set(line.split('[',1)[1].rstrip(']').split(', '))<=
                    {'propext','Classical.choice','Quot.sound'} for line in lines)
            for constant in manifest['audit']):
            sys.exit('Unexpected axiom report: '+r.stdout)
    seconds=round(time.monotonic()-start,2)
    record.append({'name':name,'seconds':seconds,'objectSHA256':sha((lib/(name+'.olean')).read_bytes())})
    print(name,seconds,flush=True)
(build/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
print(f"Verified {len(record)} modules and {len(manifest['audit'])} audited declarations.",flush=True)
