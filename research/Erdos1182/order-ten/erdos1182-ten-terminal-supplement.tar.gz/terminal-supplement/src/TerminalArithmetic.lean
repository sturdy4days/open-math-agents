import TenthFrom18
import Results

/-! The three explicit order-18 hosts suffice for both sharp extrema at order ten. -/

namespace Terminal18
open SimpleGraph BBHExtension Erdos1182

theorem target_identity : decode 10 target = BBHRange.template 10 72057645653176374 := by
  ext i j
  revert i j
  decide +kernel

/-- Exhaustiveness of the three explicit 18-vertex extremal graphs produces a
literal R2 host certificate for the secondary 10-vertex mask. -/
theorem exact_certificate (catalog : Classification) : BBHRange.Cert 10 72057645653176374 := by
  apply BBHFinite.certificate_of_universal (by decide)
  intro C tri
  rw [← target_identity]
  exact order19 catalog C tri

theorem ten_values (catalog : Classification) : F 10 = 18 ∧ f 10 = 33 :=
  BBHRange.ten_values_from_secondary (exact_certificate catalog)

end Terminal18
#print axioms Terminal18.exact_certificate
#print axioms Terminal18.ten_values
