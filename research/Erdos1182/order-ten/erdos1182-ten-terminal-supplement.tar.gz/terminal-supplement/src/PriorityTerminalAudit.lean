import BitPriorityRows
import FastIso
import TerminalArithmetic

/-! Independent axiom audit for the priority recursion and the terminal reduction. -/

#print axioms BBHExtension.parent
#print axioms BBHExtension.maximal_delete_twin
#print axioms BBHExtension.minimum_complement_covers
#print axioms BBHExtension.twinMinimum_complement_covers
#print axioms BBHExtension.priority_complement_covers
#print axioms BBHExtension.pureDeletion_iff_common_neighbors
#print axioms BBHExtension.checkPriority_iff
#print axioms BBHExtension.certified_priority_codes
#print axioms BBHExtension.fastIso_sound
#print axioms BBHExtension.cube_covers
#print axioms BBHExtension.fastCube_sound
#print axioms Terminal18.first
#print axioms Terminal18.second
#print axioms Terminal18.bipartite_terminal
#print axioms Terminal18.extensions
#print axioms Terminal18.order19
#print axioms Terminal18.exact_certificate
#print axioms Terminal18.ten_values
