# The three extremal 18-vertex hosts for Erdős 1182

Lean proves that every one-vertex extension of each of the three explicit 18-vertex graphs contains the secondary ten-vertex template in its complement. This applies to every neighborhood for the new vertex, including extensions which are not maximal. For the first two parents, 65 and 75 embedding witnesses cover the possible neighborhoods. The third parent is K₉,₉. Its proof uses the independent parts and a degree-five vertex of the template.

`Terminal18.ten_values` proves **F(10) = 18 and f(10) = 33**, conditional on the precise order-18 classification in `Terminal18.Classification`. That premise says that every maximal triangle-free 18-vertex graph avoiding the template in its complement is isomorphic to one of the three specified graphs. The terminal embeddings themselves are unconditional. The arithmetic proof uses the published-project definitions and the previously verified range supplement.

The package also proves the three-stage generation rule for certifying the remaining classification. Prefer deletion of a vertex with a twin. In a twin-free graph, prefer a deletion that preserves maximality. If neither is available, use a vertex of minimum degree. Every avoiding maximal host has a predecessor meeting this rule. `PurePriority.lean` and `BitPriority.lean` give the mathematical and executable forms. The independent C++ census and its witnesses are furnished separately.

## Replay

Use Lean 4.33.1 with Mathlib at `0df444a360eaa60ab8c11dca51a86af692955474` and Formal Conjectures at `9097e2f90e66d2f6244209cb1c07f7120d17ec53`. Build the prior range supplement with its documented `--target Results` option. Its README lists the exact pinned upper-bound source archive, toolchain and build commands. [Signed range supplement](https://raw.githubusercontent.com/sturdy4days/open-math-agents/b1e130f453ffe24b58be7c92f713224e57ddf67b/research/Erdos1182/erdos1182-range-supplement.tar.gz) · [Signed upper-bound archive](https://raw.githubusercontent.com/sturdy4days/open-math-agents/1a08bcf2ca9c68ffebb9cc7e1e1b8c7fa721cc15/research/Erdos1182/erdos1182-upper-sources.tar.gz)

From the pinned Formal Conjectures Lake environment, run

    lake env python3 /absolute/path/terminal-supplement/replay.py --prior-lib /absolute/path/range-build/lib --build /absolute/path/terminal-build

The runner verifies every relevant prior object against the combined fingerprint derived from the two signed manifests, recompiles the local sources into a fresh directory, and checks the independent axiom audit. The arithmetic module can require about 7 GiB of memory. Machine-specific replay records are written under the build directory.

The finite template and Ramsey computation originate in work of Stephan Brandt, Gunnar Brinkmann and Thomas Harmuth. The three host graphs were independently regenerated with the public Triangleramsey program by Gunnar Brinkmann, Jan Goedgebeur and Jan-Christoph Schlage-Puchta, then encoded directly in the proof. The prior supplement retains the credits for all other imported source results. [BBH paper](https://www.combinatorics.org/ojs/index.php/eljc/article/download/v5i1r7/pdf) · [Triangleramsey](https://caagt.ugent.be/triangleramsey/)
