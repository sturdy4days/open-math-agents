import LastData
import TwinParent

namespace Terminal18
open SimpleGraph BBHExtension

private theorem maximal_from_table (h : ℕ)
    (tri : ∀ i j w : Fin 18, adjacent h i j = true → adjacent h i w = true → adjacent h j w = false)
    (sat : ∀ i j : Fin 18, i ≠ j → adjacent h i j = false →
      ∃ w : Fin 18, adjacent h i w = true ∧ adjacent h j w = true) :
    Maximal (fun D : SimpleGraph (Fin 18) => D.CliqueFree 3) (decode 18 h) := by
  apply maximal_of_saturation
  · intro T triple
    obtain ⟨i,j,w,ij,iw,jw,_⟩ := SimpleGraph.is3Clique_iff.mp triple
    exact Bool.noConfusion ((tri i j w ij iw).symm.trans jw)
  · intro i j ne no
    apply sat i j ne
    cases eq : adjacent h i.val j.val
    · rfl
    · exact (no eq).elim

set_option maxRecDepth 32768 in
set_option maxHeartbeats 0 in
private theorem parent_checks : ∀ z : Fin 3,
    (∀ i j w : Fin 18, adjacent (parent z) i j = true → adjacent (parent z) i w = true → adjacent (parent z) j w = false) ∧
    (∀ i j : Fin 18, i ≠ j → adjacent (parent z) i j = false →
      ∃ w : Fin 18, adjacent (parent z) i w = true ∧ adjacent (parent z) j w = true) := by decide +kernel

theorem maximal_parent (z : Fin 3) :
    Maximal (fun D : SimpleGraph (Fin 18) => D.CliqueFree 3) (decode 18 (parent z)) :=
  maximal_from_table _ (parent_checks z).1 (parent_checks z).2

end Terminal18
#print axioms Terminal18.maximal_parent
