import LastData
import Mathlib.Combinatorics.SimpleGraph.Finite

namespace Terminal18
open BBHExtension SimpleGraph

set_option maxHeartbeats 0 in
set_option maxRecDepth 32768 in
private theorem neighbor_counts :
    Fintype.card ((decode 10 target).neighborSet (8 : Fin 10)) = 9 ∧
    ∀ v : Fin 18, Fintype.card ((decode 18 (parent 2))ᶜ.neighborSet v) = 8 := by decide +kernel

/-- The target has a vertex of degree nine, whereas this complement is 8-regular. -/
theorem avoids_third : ¬ (decode 10 target ⊑ (decode 18 (parent 2))ᶜ) := by
  rintro ⟨f⟩
  have h := Fintype.card_le_of_embedding (f.mapNeighborSet (8 : Fin 10))
  rw [neighbor_counts.1, neighbor_counts.2] at h
  omega

set_option maxHeartbeats 0 in
set_option maxRecDepth 32768 in
private theorem distinguish_counts : ∀ i j : Fin 3, i ≠ j →
    (decode 18 (parent i)).edgeFinset.card ≠ (decode 18 (parent j)).edgeFinset.card := by
  decide +kernel

/-- The three order-18 maximal triangle-free graphs are pairwise nonisomorphic. -/
theorem parents_nonisomorphic {i j : Fin 3} (hne : i ≠ j) :
    ¬ Nonempty (decode 18 (parent i) ≃g decode 18 (parent j)) := by
  rintro ⟨f⟩
  exact distinguish_counts i j hne f.card_edgeFinset_eq

end Terminal18

#print axioms Terminal18.avoids_third
#print axioms Terminal18.parents_nonisomorphic
