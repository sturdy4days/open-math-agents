import LastData

namespace Hall18
open SimpleGraph BBHExtension Terminal18

/-- Bit masks use the native parent labels 0 through 17. Each domain is the
set of images still allowed for a not-yet-assigned target vertex. -/
def Fits (avail : ℕ) (D : ℕ → ℕ) (f : Fin 10 → Fin 18) : Prop :=
  ∀ i, avail.testBit i.val = true → (D i.val).testBit (f i).val = true

def blueRows (p : ℕ) (R : Array ℕ) : Prop :=
  ∀ u v : Fin 18, (R[u.val]?.getD 0).testBit v.val = true ↔ (decode 18 p)ᶜ.Adj u v

def dropBit (w i : ℕ) := w ^^^ (w &&& 2^i)

theorem test_dropBit (w i j : ℕ) : (dropBit w i).testBit j = true ↔ w.testBit j = true ∧ j ≠ i := by
  by_cases h : j=i
  · subst j; simp [dropBit,Nat.testBit_xor,Nat.testBit_and]
  · cases h' : w.testBit j <;> simp [dropBit,Nat.testBit_xor,Nat.testBit_and,h,h',Ne.symm h]

def next (R : Array ℕ) (i v : ℕ) (D : ℕ → ℕ) (j : ℕ) : ℕ :=
  let a := if adjacent target i j then D j &&& R[v]?.getD 0 else D j
  dropBit a v

theorem step_fits {p : ℕ} {R : Array ℕ} (r : blueRows p R)
    (f : Copy (decode 10 target) (decode 18 p)ᶜ) (avail : ℕ) (D : ℕ → ℕ) (old : Fits avail D f)
    (i : Fin 10) : Fits (dropBit avail i.val) (next R i.val (f i).val D) f := by
  intro j jlive
  obtain ⟨live,ne⟩ := (test_dropBit ..).mp jlive
  have domain := old j live
  have diff : (f j).val ≠ (f i).val := fun eq => ne (congrArg Fin.val (f.injective (Fin.ext eq)))
  unfold next
  apply (test_dropBit ..).mpr
  refine ⟨?_,diff⟩
  split
  · rename_i red
    have blue := (r (f i) (f j)).mpr (f.toHom.map_adj (show (decode 10 target).Adj i j from red))
    simp [Nat.testBit_and,blue,domain]
  · exact domain

/-- A declared family of source vertices all maps into a smaller set of host
vertices. All comparisons are checked on finite masks. -/
def hallTest (avail : ℕ) (D : ℕ → ℕ) (family union : ℕ) : Bool :=
  decide (family &&& avail = family ∧ (subset 18 union).card < (subset 10 family).card ∧
    ∀ i : Fin 10, family.testBit i.val = true → D i.val &&& union = D i.val)

private theorem bit_inside {a b : ℕ} (h : a &&& b = a) (i : ℕ) (hit : a.testBit i = true) : b.testBit i = true := by
  have eq := congrArg (fun w => Nat.testBit w i) h
  simpa [Nat.testBit_and,hit] using eq

theorem hall_sound {avail : ℕ} {D : ℕ → ℕ} {family union : ℕ} (pass : hallTest avail D family union = true)
    (f : Fin 10 → Fin 18) (inj : Function.Injective f) : ¬Fits avail D f := by
  intro fits
  obtain ⟨live,small,contained⟩ := of_decide_eq_true pass
  have subsetImage : (subset 10 family).image f ⊆ subset 18 union := by
    intro v hv
    obtain ⟨i,hi,rfl⟩ := Finset.mem_image.mp hv
    have member : family.testBit i.val = true := by simpa [subset] using hi
    have ok := fits i (bit_inside live i.val member)
    simpa [subset] using bit_inside (contained i member) (f i).val ok
  have le := Finset.card_le_card subsetImage
  rw [Finset.card_image_of_injective _ inj] at le
  exact (Nat.not_lt_of_ge le) small

/-- Table entries below bit 10 specify Hall leaves. An entry with bit 10 set
stores its source vertex in bits 0..9 and the branch addresses in successive
13-bit fields starting at bit 11, one field for each possible host image. -/
def check (R A : Array ℕ) : ℕ → ℕ → ℕ → (ℕ → ℕ) → Bool
  | 0, addr, avail, D =>
    let entry := A[addr]?.getD 0
    !entry.testBit 10 && hallTest avail D (entry%1024) (entry >>> 11)
  | fuel+1, addr, avail, D =>
    let entry := A[addr]?.getD 0
    let x := entry%1024
    if entry.testBit 10 then
      decide (x<10) && avail.testBit x &&
      decide (∀ v : Fin 18, (D x).testBit v.val = true →
        check R A fuel ((entry >>> (11+13*v.val)) % 8192) (dropBit avail x) (next R x v.val D) = true)
    else hallTest avail D x (entry >>> 11)

theorem check_sound {p : ℕ} {R : Array ℕ} (r : blueRows p R) (A : Array ℕ) (fuel addr avail : ℕ)
    (D : ℕ → ℕ) (verified : check R A fuel addr avail D = true)
    (f : Copy (decode 10 target) (decode 18 p)ᶜ) : ¬ Fits avail D f := by
  induction fuel generalizing addr avail D with
  | zero =>
    simp only [check,Bool.and_eq_true] at verified
    exact hall_sound verified.2 f f.injective
  | succ fuel ih =>
    simp only [check] at verified
    split at verified
    · simp only [Bool.and_eq_true,decide_eq_true_eq] at verified
      obtain ⟨⟨bound,live⟩,all⟩ := verified
      let i : Fin 10 := ⟨_,bound⟩
      intro fits
      have hit := fits i live
      exact ih _ _ _ (all (f i) hit) (step_fits r f avail D fits i)
    · exact hall_sound verified f f.injective

end Hall18
#print axioms Hall18.check_sound
