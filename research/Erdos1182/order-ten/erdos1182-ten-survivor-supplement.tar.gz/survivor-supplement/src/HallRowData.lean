import HallStart

namespace Hall18
open SimpleGraph BBHExtension Terminal18

def R0 : Array ℕ := #[218558,207741,208603,218855,245127,252747,125870,128349,129267,195694,195229,178038,184249,118742,112617,163824,25087,40511]

theorem r0 : blueRows (parent 0) R0 := by
  unfold blueRows
  decide +kernel

def R1 : Array ℕ := #[246780,261180,244531,122099,192079,226703,122777,227177,244453,191957,162554,112478,110062,155574,141051,72543,39407,26551]

theorem r1 : blueRows (parent 1) R1 := by
  unfold blueRows
  decide +kernel

end Hall18
#print axioms Hall18.r0
#print axioms Hall18.r1
