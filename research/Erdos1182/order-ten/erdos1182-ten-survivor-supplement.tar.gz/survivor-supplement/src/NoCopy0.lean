import Mathlib.Tactic.FinCases
import HallBranch0x0
import HallBranch0x1
import HallBranch0x2
import HallBranch0x3
import HallBranch0x4
import HallBranch0x5
import HallBranch0x6
import HallBranch0x7
import HallBranch0x8
import HallBranch0x9
import HallBranch0x10
import HallBranch0x11
import HallBranch0x12
import HallBranch0x13
import HallBranch0x14
import HallBranch0x15
import HallBranch0x16
import HallBranch0x17

namespace Hall18
open SimpleGraph BBHExtension Terminal18

theorem avoid_parent0 : ¬ decode 10 target ⊑ (decode 18 (parent 0))ᶜ := by
  apply first_branches r0 8
  intro v
  fin_cases v <;> first
    | exact dead0x0
    | exact dead0x1
    | exact dead0x2
    | exact dead0x3
    | exact dead0x4
    | exact dead0x5
    | exact dead0x6
    | exact dead0x7
    | exact dead0x8
    | exact dead0x9
    | exact dead0x10
    | exact dead0x11
    | exact dead0x12
    | exact dead0x13
    | exact dead0x14
    | exact dead0x15
    | exact dead0x16
    | exact dead0x17

end Hall18
#print axioms Hall18.avoid_parent0
