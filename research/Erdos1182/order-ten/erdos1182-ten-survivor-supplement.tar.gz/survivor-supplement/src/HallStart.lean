import Hall

namespace Hall18
open SimpleGraph BBHExtension Terminal18

theorem first_branches {p : ℕ} {R : Array ℕ} (rows : blueRows p R) (i : Fin 10)
    (dead : ∀ v : Fin 18, ∀ f : Copy (decode 10 target) (decode 18 p)ᶜ,
      ¬ Fits (dropBit 1023 i.val) (next R i.val v.val (fun _ => 262143)) f) :
    ¬ decode 10 target ⊑ (decode 18 p)ᶜ := by
  rintro ⟨f⟩
  have all : Fits 1023 (fun _ => 262143) f := by
    intro j _
    exact (show ∀ v : Fin 18, (262143 : ℕ).testBit v.val = true by decide +kernel) (f j)
  exact dead (f i) f (step_fits rows f _ _ all i)

/-- A standalone subtree may store its initial domains as constants; only the
ten source coordinates need to be compared with the computed first split. -/
theorem checked_first {p : ℕ} {R : Array ℕ} (rows : blueRows p R) (i : Fin 10) (v : Fin 18)
    (A : Array ℕ) (fuel addr avail : ℕ) (D : ℕ → ℕ) (sameA : avail = dropBit 1023 i.val)
    (sameD : ∀ j : Fin 10, avail.testBit j.val = true → D j.val = next R i.val v.val (fun _ => 262143) j.val)
    (verified : check R A fuel addr avail D = true) (f : Copy (decode 10 target) (decode 18 p)ᶜ) :
    ¬Fits (dropBit 1023 i.val) (next R i.val v.val (fun _ => 262143)) f := by
  intro poss
  apply check_sound rows A fuel addr avail D verified f
  intro j live
  rw [sameD j live]
  exact poss j (sameA ▸ live)

end Hall18
#print axioms Hall18.first_branches
#print axioms Hall18.checked_first
