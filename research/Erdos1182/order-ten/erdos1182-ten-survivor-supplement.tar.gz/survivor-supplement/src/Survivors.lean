import NoCopy0
import NoCopy1
import MaximalParents
import SurvivorInvariants
import Mathlib.Tactic.FinCases

namespace Terminal18
open SimpleGraph BBHExtension

/-- The three stored parents really are pairwise nonisomorphic maximal
triangle-free graphs whose complements all avoid the prescribed target. -/
theorem avoidance (i : Fin 3) : ¬decode 10 target ⊑ (decode 18 (parent i))ᶜ := by
  fin_cases i
  · exact Hall18.avoid_parent0
  · exact Hall18.avoid_parent1
  · exact avoids_third

theorem three_obstructions :
    (∀ i : Fin 3, Maximal (fun D : SimpleGraph (Fin 18) => D.CliqueFree 3) (decode 18 (parent i)) ∧
      ¬decode 10 target ⊑ (decode 18 (parent i))ᶜ) ∧
    ∀ i j : Fin 3, i ≠ j → ¬Nonempty (decode 18 (parent i) ≃g decode 18 (parent j)) :=
  ⟨fun i => ⟨maximal_parent i,avoidance i⟩,fun _ _ => parents_nonisomorphic⟩

end Terminal18
#print axioms Terminal18.avoidance
#print axioms Terminal18.three_obstructions
