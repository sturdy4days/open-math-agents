import Mathlib.Tactic.FinCases
import HallBranch1x0
import HallBranch1x1
import HallBranch1x2
import HallBranch1x3
import HallBranch1x4
import HallBranch1x5
import HallBranch1x6
import HallBranch1x7
import HallBranch1x8
import HallBranch1x9
import HallBranch1x10
import HallBranch1x11
import HallBranch1x12
import HallBranch1x13
import HallBranch1x14
import HallBranch1x15
import HallBranch1x16
import HallBranch1x17

namespace Hall18
open SimpleGraph BBHExtension Terminal18

theorem avoid_parent1 : ¬ decode 10 target ⊑ (decode 18 (parent 1))ᶜ := by
  apply first_branches r1 8
  intro v
  fin_cases v <;> first
    | exact dead1x0
    | exact dead1x1
    | exact dead1x2
    | exact dead1x3
    | exact dead1x4
    | exact dead1x5
    | exact dead1x6
    | exact dead1x7
    | exact dead1x8
    | exact dead1x9
    | exact dead1x10
    | exact dead1x11
    | exact dead1x12
    | exact dead1x13
    | exact dead1x14
    | exact dead1x15
    | exact dead1x16
    | exact dead1x17

end Hall18
#print axioms Hall18.avoid_parent1
