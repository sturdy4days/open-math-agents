# Three explicit 18-vertex obstructions for Erdős 1182

`Terminal18.three_obstructions` proves that each graph in `Terminal18.parent` is maximal triangle-free, that its complement contains no copy of the 33-edge, ten-vertex graph `Terminal18.target`, and that the three parents are pairwise nonisomorphic. The shorter endpoint `Terminal18.avoidance` gives just the complementary noncontainment for an arbitrary index `i : Fin 3`.

The graph codes store unordered pairs in the order 01, 02, 12, 03, 13, 23, and so on. The third host is the complete bipartite graph K₉,₉. Its complement is 8-regular and the target has a vertex of degree nine. For each of the other parents, the certificate splits on the image of target vertex 8. Successive splits remove occupied host vertices and enforce required adjacencies. At a leaf, a specified set of target vertices has fewer available images than its cardinality. The checker verifies that inequality, the image inclusions and every branch. There are 36 independently checked first-level subtrees and 4,358 entries in their tables. Every final theorem uses only `propext`, `Classical.choice` and `Quot.sound`.

The result establishes existence and nonisomorphism of these three hosts. The question whether they exhaust the possible 18-vertex hosts requires a separate completeness proof.

## Reproduce

Use Python 3.11 or later with Lean `v4.33.1` and Mathlib commit `0df444a360eaa60ab8c11dca51a86af692955474`. The corresponding Formal Conjectures revision is `9097e2f90e66d2f6244209cb1c07f7120d17ec53`. From that project's built Lake environment run

```
lake env python3 /path/to/survivor-supplement/replay.py --build /path/to/new-empty-directory --regenerate
```

The runner checks the source and data hashes, regenerates the certificate and concrete proof files from `graphs/18.g6` when `--regenerate` is present, and uses Lean to recompile every bundled module. It rejects diagnostics and checks the exact axiom lists for both aggregate theorems. The build directory receives the object files, compilation logs and `report.json`. The proof uses neither a compiled certificate generator nor an external graph database during Lean verification. Regeneration uses only the Python standard library.

## Provenance

Stephan Brandt, Gunnar Brinkmann and Thomas Harmuth studied the underlying finite Ramsey computations. The three graphs were independently regenerated with Triangleramsey by Gunnar Brinkmann, Jan Goedgebeur and Jan-Christoph Schlage-Puchta. The input `graphs/18.g6` stores the three resulting labeled graphs. [BBH paper](https://www.combinatorics.org/ojs/index.php/eljc/article/download/v5i1r7/pdf) · [Triangleramsey](https://caagt.ugent.be/triangleramsey/)

The six modules `Extension`, `Atlas`, `Orbit`, `Records`, `TwinParent` and `LastData` are included byte-for-byte from `erdos1182-ten-terminal-supplement.tar.gz` (SHA-256 `58e612117baf96d7d3002db4daa65a09c438b5c49e5ceba5dc32a40053f3c9be`). They supply the same graph coding and data and allow this supplement to build directly against Mathlib. The Hall checker, certificates, verified maximality and aggregate theorem were constructed for this supplement by the @sturdy4days contribution. The Python search is a source of witnesses; its correctness is checked in Lean for these concrete graphs.
