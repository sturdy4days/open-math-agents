#!/usr/bin/env python3
"""Recompile the complete local proof closure in a pinned Lean/Mathlib environment."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--build', required=True, type=Path)
parser.add_argument('--lean', default='lean')
parser.add_argument('--memory-mib', default=3600, type=int)
parser.add_argument('--regenerate', action='store_true')
args = parser.parse_args()
manifest = json.loads((root / 'manifest.json').read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

for name, digest in manifest['files'].items():
    if sha(root/name) != digest:
        sys.exit(f'Source hash mismatch for {name}')
version = subprocess.check_output([args.lean, '--version'], text=True).strip()
if 'version 4.33.1,' not in version:
    sys.exit(f'Expected Lean 4.33.1, received {version}')
build = args.build.resolve()
build.mkdir(parents=True, exist_ok=True)
if list(build.iterdir()):
    sys.exit(f'Choose an empty output directory: {build}')
if args.regenerate:
    regen = build/'regenerated'/'avoid18'
    graphs = regen.parent/'mtf'/'canonical'
    graphs.mkdir(parents=True)
    regen.mkdir()
    shutil.copy(root/'graphs'/'18.g6', graphs/'18.g6')
    for src in (root/'generator').glob('*.py'):
        shutil.copy(src, regen/src.name)
    for script in ['tree.py', 'pack_trees.py', 'gen_hall.py']:
        subprocess.run([sys.executable, str(regen/script)], cwd=regen, check=True)
    for name in manifest['regenerated']:
        if sha(regen/Path(name).name) != manifest['files'][name]:
            sys.exit(f'Generator output mismatch for {name}')
    print('Reconstructed all recorded graphs-to-certificate outputs', flush=True)
lib = build/'lib'
logs = build/'logs'
lib.mkdir()
logs.mkdir()
paths = [str(Path(s).resolve()) for s in os.environ.get('LEAN_PATH','').split(os.pathsep) if s]
env = dict(os.environ, LEAN_NUM_THREADS='1', LEAN_PATH=os.pathsep.join([str(lib), *paths]))
records = []
for mod in manifest['buildOrder']:
    start = time.monotonic()
    with (logs/f'{mod}.log').open('w') as out:
        result = subprocess.run([args.lean, '-j1', f'-M{args.memory_mib}', '-DElab.async=false', '-o',str(lib/f'{mod}.olean'), f'{mod}.lean'], cwd=root/'src', env=env, stdout=out, stderr=subprocess.STDOUT)
    output = (logs/f'{mod}.log').read_text()
    if result.returncode or re.search(r'(?:^|:\d+:\d+: )(?:warning|error)(?:\(|:)', output, re.M):
        sys.exit(f'{mod} failed\n{output}')
    if 'sorryAx' in output:
        sys.exit(f'Unapproved axiom in {mod}')
    records.append({'module':mod, 'seconds':round(time.monotonic()-start, 2), 'objectSha256':sha(lib/f'{mod}.olean')})
    print(f'{mod} passed in {records[-1]["seconds"]:.2f}s', flush=True)
reported = {n:sorted(a.split(', ')) for n,a in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",(logs/'Survivors.log').read_text())}
for n in ['Terminal18.avoidance','Terminal18.three_obstructions']:
    if reported.get(n) != sorted(['propext','Classical.choice','Quot.sound']):
        sys.exit(f'Axiom list differed for {n}: {reported.get(n)}')
report = {'lean':version, 'mathlib':manifest['mathlib'], 'regenerated':args.regenerate,'axioms':reported,'compilations':records}
(build/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print('Both aggregate endpoints passed their complete axiom audits.', flush=True)
