import itertools,collections
from pathlib import Path
raw=(Path(__file__).resolve().parent.parent/'mtf/canonical/18.g6').read_bytes().splitlines()
H={(i,j) for j in range(10) for i in range(j) if (35184366705032>>(j*(j-1)//2+i))&1}
def matching(xs,ys,dom):
 taken={}
 def dfs(i,seen):
  for j in dom[i]&ys-seen:
   seen.add(j)
   if j not in taken or dfs(taken[j],seen):
    taken[j]=i;return True
  return False
 return all(dfs(i,set()) for i in xs)
def refine(S,T,dom):
 for r in range(12):
  if not matching(set(S),set(T),dom):return ('hall',r)
  new={i:{v for v in dom[i] if matching(S[i],T[v],dom)} for i in S}
  if new==dom:return ('pass',r)
  dom=new
def neigh(V,E):
 return {v:{u for u in V if tuple(sorted([u,v])) in E} for v in V}
def host(g):
 return {(i,j) for j in range(18) for i in range(j) if not ((g[1+(k:=j*(j-1)//2+i)//6]-63)>>(5-k%6))&1}
def main():
 t=neigh(range(8),H)
 for g in raw:
  B=host(g);b=neigh(range(18),B)
  cnt=collections.Counter()
  for a,c in B:
   V=b[a]&b[c]
   for p in itertools.combinations(V,8):
    z=neigh(p,B)
    d={i:{v for v in z if len(z[v])>=len(t[i])} for i in t}
    cnt[refine(t,z,d)]+=1
  print(cnt)
if __name__=='__main__':main()
