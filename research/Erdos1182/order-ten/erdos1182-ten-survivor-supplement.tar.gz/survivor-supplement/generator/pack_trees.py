"""Encode each subtree starting after the first host image in the Hall checker format."""
from functools import reduce
from operator import or_
from pathlib import Path
import json
from sim import H, host, neigh, raw

here = Path(__file__).resolve().parent
source = neigh(range(10), H)

def members(word):
    return [v for v in range(word.bit_length()) if (word >> v) & 1]

def encode(parent):
    neighbors = [sum(1 << u for u in us) for us in neigh(range(18), host(raw[parent])).values()]
    kind, root, children = json.loads((here / f"parent-{parent}.json").read_text())
    assert kind == "B" and len(children) == 18
    def step(dom, i, v):
        return [d & ~(1 << v) & (neighbors[v] if j in source[i] else -1) for j, d in enumerate(dom)]
    def visit(tree, avail, dom, entries):
        addr = len(entries)
        entries.append(0)
        tag, key, *rest = tree
        if tag == "H":
            assert key & ~avail == 0
            union = reduce(or_, (dom[j] for j in members(key)), 0)
            assert union.bit_count() < key.bit_count()
            entries[addr] = key + (union << 11)
        else:
            assert tag == "B" and (1 << key) & avail
            word = 1024 + key
            for v, child in zip(members(dom[key]), rest[0], strict=True):
                child_addr = visit(child, avail ^ (1 << key), step(dom, key, v), entries)
                assert child_addr < 8192
                word += child_addr << (11 + 13*v)
            entries[addr] = word
        return addr
    cases = []
    for v, child in enumerate(children):
        dom = step([(1 << 18)-1] * 10, root, v)
        avail = 1023 ^ (1 << root)
        entries = []
        assert visit(child, avail, dom, entries) == 0
        cases.append(dict(v=v, avail=avail, domains=dom, A=entries))
    return dict(parent=parent, root=root, R=neighbors, cases=cases)

if __name__ == "__main__":
    results = [encode(i) for i in range(2)]
    (here / "packed-parents.json").write_text(json.dumps(results, separators=(",", ":")) + "\n")
    for row in results:
        print(row["parent"], row["root"], sum(len(case["A"]) for case in row["cases"]))
