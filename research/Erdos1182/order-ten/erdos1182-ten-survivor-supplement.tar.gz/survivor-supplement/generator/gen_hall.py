import json,pathlib,sys
w=pathlib.Path(__file__).resolve().parent
objs=json.loads((w/'packed-parents.json').read_text())
def ar(v):return '#['+','.join(str(a) for a in v)+']'
def pre(imports):return imports+'\n\nnamespace Hall18\nopen SimpleGraph BBHExtension Terminal18\n\n'
row=pre('import HallStart');ids=[]
for p in objs:
 h=p['parent'];rt=p['root'];r=f'R{h}'
 row+=f'def {r} : Array ℕ := {ar(p["R"])}\n\ntheorem r{h} : blueRows (parent {h}) {r} := by\n  unfold blueRows\n  decide +kernel\n\n'
 for case in p['cases']:
  v=case['v'];label=f'{h}x{v}';name='HallBranch'+label;ids.append(name)
  out=pre('import HallRowData')+f'private def A{label} : Array ℕ := {ar(case["A"])}\n\nprivate def d{label} (i : ℕ) : ℕ := ({ar(case["domains"])} : Array ℕ)[i]?.getD 0\n\n'
  out+=f'''set_option maxRecDepth 32768 in
set_option maxHeartbeats 0 in
theorem dead{label} (f : Copy (decode 10 target) (decode 18 (parent {h}))ᶜ) :
    ¬Fits (dropBit 1023 {rt}) (next {r} {rt} {v} (fun _ => 262143)) f := by
  exact checked_first r{h} {rt} {v} A{label} 5 0 {case['avail']} d{label}
    (by decide +kernel) (by decide +kernel) (by decide +kernel) f

end Hall18
'''
  (w/(name+'.lean')).write_text(out)
(w/'HallRowData.lean').write_text(row+'end Hall18\n#print axioms Hall18.r0\n#print axioms Hall18.r1\n')
for p in objs:
 h=p['parent'];rt=p['root'];out=pre('import Mathlib.Tactic.FinCases\n'+'\n'.join(f'import HallBranch{h}x{v}' for v in range(18)))
 out+=f'''theorem avoid_parent{h} : ¬ decode 10 target ⊑ (decode 18 (parent {h}))ᶜ := by
  apply first_branches r{h} {rt}
  intro v
  fin_cases v <;> first
'''+''.join(f'    | exact dead{h}x{v}\n' for v in range(18))+'\nend Hall18\n'+f'#print axioms Hall18.avoid_parent{h}\n';(w/f'NoCopy{h}.lean').write_text(out)
(w/'branch_names.txt').write_text('\n'.join(ids)+'\n')
