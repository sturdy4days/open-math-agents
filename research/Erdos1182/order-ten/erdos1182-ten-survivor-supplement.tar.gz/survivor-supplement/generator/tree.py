"""Construct a certificate for absence of an injective copy from local disjoint-domain bounds."""
from sim import H,host,raw,neigh
from itertools import combinations
from collections import Counter
from pathlib import Path
import json
w=Path(__file__).resolve().parent
N,M=10,18
G=neigh(range(N),H)
toMask=lambda vals:sum(1<<v for v in vals)
def bits(m):
 while m:
  b=m&-m
  yield b.bit_length()-1
  m-=b

def obstruction(dom,avail):
 # Collect the union for each selected source subset, shortest and smallest domains first.
 ordered=sorted(bits(avail),key=lambda i:dom[i].bit_count())
 for k in range(1,len(ordered)+1):
  eligible=[i for i in ordered if dom[i].bit_count()<k]
  for family in combinations(eligible,k):
   union=0
   for i in family:union|=dom[i]
   if union.bit_count()<k:return toMask(family)
 return None

def build(g):
 B=neigh(range(M),host(g)); nei=[toMask(B[j]) for j in range(M)]
 stats=Counter()
 def rec(dom,avail,depth):
  hall=obstruction(dom,avail)
  if hall is not None:
   stats['leaves']+=1
   return ['H',hall]
  if not avail:raise ValueError('embedding')
  # A successful map must send every source vertex to an image of at least its degree.
  i=min(bits(avail),key=lambda i:(dom[i].bit_count(),-len(G[i])))
  stats['branches']+=1
  stats['maxDepth']=max(stats['maxDepth'],depth+1)
  branches=[]
  for v in bits(dom[i]):
   nd=[(d & ~(1<<v)) & (nei[v] if j in G[i] else -1) for j,d in enumerate(dom)]
   branches.append(rec(nd,avail^(1<<i),depth+1))
  return ['B',i,branches]
 degree=[toMask(v for v in B if len(G[i])<=len(B[v])) for i in range(N)]
 ans=rec(degree,(1<<N)-1,0)
 return ans,stats
for idx,g in enumerate(raw):
 cert,metrics=build(g)
 (w/f'parent-{idx}.json').write_text(json.dumps(cert,separators=(',',':'))+'\n')
 print(idx,dict(metrics),(w/f'parent-{idx}.json').stat().st_size)
