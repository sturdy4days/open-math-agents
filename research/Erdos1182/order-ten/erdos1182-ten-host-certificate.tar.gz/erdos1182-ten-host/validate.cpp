// Independent graph6 validity, maximality and direct prescribed embedding checks.
#include <array>
#include <cstdint>
#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <stdexcept>
using namespace std;
using U=uint32_t;
constexpr uint64_t missing=72057645653176374ULL;
int hosts=0, n;
array<U,20> g;
array<int,10> order;
bool needs(int i,int j){
    if(i>j)swap(i,j);
    int p=10*i+j;
    return i!=j && (p>=64 || !((missing>>p)&1));
}
bool embed(int d,U used,array<U,10> domain){
    if(d==10)return true;
    U a=domain[d]&~used;
    while(a){
        int v=__builtin_ctz(a);a&=a-1;
        array<U,10> nd=domain;bool ok=true;
        for(int k=d+1;k<10;k++){
            if(needs(order[d],order[k]))nd[k]&=~g[v];
            if(!(nd[k]&~(used|(1u<<v)))){ok=false;break;}
        }
        if(ok&&embed(d+1,used|(1u<<v),nd))return true;
    }
    return false;
}
int main(){
    for(int i=0;i<10;i++)order[i]=i;
    auto deg=[](int i){int d=0;for(int j=0;j<10;j++)d+=needs(i,j);return d;};
    stable_sort(order.begin(),order.end(),[&](int i,int j){return deg(i)>deg(j);});
    string line;
    while(getline(cin,line)){
        n=line[0]-63;if(n<0||n>19||int(line.size())!=1+(n*(n-1)/2+5)/6)throw runtime_error("graph6");
        g.fill(0);
        for(int j=1,k=0;j<n;j++)for(int i=0;i<j;i++,k++)
            if((line[1+k/6]-63)&(32>>(k%6))){g[i]|=1u<<j;g[j]|=1u<<i;}
        for(int i=0;i<n;i++)for(int j=0;j<i;j++){
            bool adj=(g[i]>>j)&1;
            bool common=(g[i]&g[j])!=0;
            if(adj==common)throw runtime_error("triangle or unsaturated non-edge");
        }
        array<U,10> dom;dom.fill((1u<<n)-1);
        if(n>=10&&embed(0,0,dom))throw runtime_error("has prescribed blue graph");
        hosts++;
    }
    cout<<"Verified "<<hosts<<" simple, maximal triangle-free, template-avoiding hosts.\n";
}
