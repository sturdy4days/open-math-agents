# An order-19 host certificate for the secondary ten-vertex Erdős 1182 template

The ten-vertex graph H has the labeled graph6 string `ICXmt~~~w`. For 0 ≤ i < j < 10, ij is an edge of H precisely when bit 10i+j of the integer 72057645653176374 is zero, with bit 0 least significant. H has 33 edges. The certificate verifies that every triangle-free graph on 19 vertices contains H in its complement (ordinary, not induced, containment). An included triangle-free graph on 18 vertices has no such copy. These are the upper and lower directions of R(K₃,H)=19.

This value was tabulated by Gunnar Brinkmann, Jan Goedgebeur and Jan-Christoph Schlage-Puchta in *Ramsey numbers R(K3,G) for graphs of order 10*, Electronic Journal of Combinatorics 19(4), 2012. The generation run used the authors' `triangleramsey` software and nauty for canonical labels. The supplied 33-edge pattern agrees byte-for-byte with row 10,101,689 of the House of Graphs file `connected10-R19.g6.gz`. Its SHA-256 and the generation receipts are in `catalogue.json`. [Authors' software and paper reference](https://caagt.ugent.be/triangleramsey/) · [House of Graphs Ramsey catalogue](https://houseofgraphs.org/meta-directory/ramsey-numbers)

## Replay

Use a C++17 compiler and a POSIX shell. From the unpacked directory run:

```sh
sha256sum -c SHA256SUMS
c++ -O3 -std=c++17 -Wall -Wextra certcheck.cpp -o certcheck
./certcheck
./certcheck --compare-atlas
c++ -O3 -std=c++17 validate.cpp -o validate
./validate < canonical/18.g6
```

The first `certcheck` run needs only the source and `extension-cert.bin`. It reconstructs the full atlas in memory and checks all maps without a graph generator, canonical labeler, SAT solver, network service, or external library. The optional second run also compares every reconstructed slot to the supplied canonical graph6 lists. The separate `validate` invocation checks the lower bound by exhaustive search for an injection on each of the three 18-vertex hosts. The upper checker prints `Verified every priority extension: 133340 admissible of 240151183 assignments.` An initial upper replay including atlas comparison took 5.1 seconds with 6.1 MiB peak resident memory. Timings depend on the machine.

## Why checking extensions suffices

Adding red edges until a triangle-free graph is maximal cannot create a blue copy of H. Hence it suffices at order 19 to rule out an H-avoiding maximal red graph. For a maximal red graph F and deleted vertex v, saturate F−v to a maximal triangle-free parent P. All edges added in saturation have both endpoints in S=N(v): a nonedge with some other common neighbor already has a surviving witness in F−v. Recover F by erasing every edge of P internal to S, then adding v adjacent to S. A blue H in P would survive in F, so an avoiding F has an avoiding parent.

The following priority rule further restricts the extensions needed by induction.

1. If F has twins (equal open neighborhoods), delete one of them. Every remaining nonedge still has a common neighbor: its former twin witness can be replaced by the surviving twin. Thus the parent needs no added edges and S is the neighborhood of a parent vertex.
2. Otherwise, if some vertex deletion is already maximal triangle-free, choose one. Its neighbor set S is independent in P.
3. Otherwise, choose a minimum-degree vertex. The child is twin-free, no vertex deletion is maximal, and the new vertex has minimum degree.

For each parent, the checker iterates every subset S. For the last branch, |S| can exceed the minimum old degree by at most one because no old vertex gains more than one incident edge. Domination of unselected vertices by S follows from maximality of the child. The checker tests maximality by checking that each nonedge has a common neighbor, and that adjacent vertices have none. In a maximal child, deleting v fails maximality precisely if some pair of non-neighbors has v as its sole common neighbor.

Every retained extension has one of two witnesses. A ten-label injection places each required edge in the blue complement; its conditions on S are two masks of mandatory and forbidden labels. Such an injection can certify many rows. Alternatively, a permutation identifies the red child with the graph at a specified next-level slot. The first incoming permutation constructs that slot, and every later incoming permutation is checked against it. The order-zero atlas contains its unique empty graph, every next-level slot is reached, and the order-19 atlas is empty. Induction on the order proves the claimed upper bound.

## Data layout and verification status

`extension-cert.bin` is 382,805 bytes. It contains 34,487 embedded copies of H that cover 116,011 surviving neighborhoods and 17,329 explicit isomorphisms. No separate atlas input is required. The file begins with the eight bytes `MTF10v1\0`. Blocks are grouped by parent order n and then parent index. Two little-endian 16-bit integers give the number of blue cubes and isomorphisms. A blue injection is a base-(n+1) integer with ten image digits in target order, most significant first. An isomorphism stores the n-bit neighborhood, next-level slot, and lexicographic rank of the permutation from its target labels to the extended parent. Each integer uses the smallest fixed byte width sufficient for its field, least-significant byte first. In the child the new vertex has label n. The independent checker defines every field and bound in executable form. The reference atlas has 100,091 bytes, concatenated SHA-256 `e2d81a9b58c3e7acf2625c6741b9afe83bcbf61aec6e51d82018fc5011485a04`.

`priorities.tsv` records the numbers of parent graphs, vanilla minimum-degree extensions, twin-priority extensions, three-tier extensions, and the three disjoint branches for each order. In `cert-stats.txt` the per-order columns are parent order, parent count, distinct children up to isomorphism, blue-positive assignments, listed assignments, distinct blue cube witnesses, and bytes. The first byte count includes the eight-byte header. `canonical/00.g6` through `canonical/19.g6` provide the reference lists. Canonical labeling and the known catalogue were useful for *generating* assignments; upper verification uses no canonicalization.

The full finite row coverage in this archive was checked in C++17. The abstract priority-extension induction separately passed Lean 4.33.1 as `BBHExtension.priority_complement_covers`. A prior Lean result, `ten_values_from_secondary`, derives F(10)=18 and f(10)=33 from the corresponding finite host certificate in Erdős 1182. Applying those formal results to this particular full atlas still requires a kernel-checked bridge for the row data.
