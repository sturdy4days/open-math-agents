// Standalone C++17 replay. Its only data input is extension-cert.bin.
// Checks every injection and permutation, then independently enumerates every priority row.
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <numeric>
#include <string>
#include <vector>
using std::array;using std::ifstream;using std::string;using std::vector;
using U=uint32_t;using W=uint64_t;using Graph=array<U,20>;
constexpr W missing=72057645653176374ULL;
static void ck(bool test,const char* reason){if(!test){std::cerr<<reason<<'\n';std::exit(1);}}
static int pop(U x){return __builtin_popcount(x);}
static int first(U x){return __builtin_ctz(x);}
static int width(W x){int b=0;while(x){x>>=8;b++;}return b;}
static W number(ifstream& in,int bytes){
    W v=0;
    for(int i=0;i<bytes;i++){int b=in.get();ck(b>=0,"truncated certificate");v|=W(b)<<(8*i);}
    return v;
}
static bool red(const Graph& p,int x,int y){return p[x]&(1u<<y);}
static bool pattern(int i,int j){
    int pos=10*i+j;
    return pos>=64||!(missing&(W(1)<<pos));
}
static Graph extend(const Graph& p,int n,U s){
    Graph h=p;
    for(int x=0;x<n;x++)if(s&(1u<<x))h[x]=(h[x]&~s)|(1u<<n);
    h[n]=s;
    return h;
}
static vector<Graph> decode_atlas(int n){
    char name[64];snprintf(name,sizeof(name),"canonical/%02d.g6",n);
    ifstream in(name);ck(in.good(),"missing atlas");vector<Graph> list;string line;
    while(getline(in,line)){
        ck(line.size()==size_t(1+(n*(n-1)/2+5)/6)&&line[0]==63+n,"bad graph6 size");
        Graph g{};
        for(int j=1,k=0;j<n;j++)for(int i=0;i<j;i++,k++)
            if((line[1+k/6]-63)&(32>>(k%6))){g[i]|=1u<<j;g[j]|=1u<<i;}
        list.push_back(g);
    }
    return list;
}
static void read_cube(ifstream& in,int widthCode,const Graph& p,int n,U all,vector<uint8_t>& covered){
    W code=number(in,widthCode);int image[10];U used=0,required=0,excluded=0;
    for(int i=9;i>=0;i--){
        image[i]=code%(n+1);code/=n+1;
        ck(!(used&(1u<<image[i])),"noninjective blue map");used|=1u<<image[i];
    }
    ck(code==0,"out-of-range blue map");
    for(int i=0;i<10;i++)for(int j=i+1;j<10;j++)if(pattern(i,j)){
        int x=std::min(image[i],image[j]),y=std::max(image[i],image[j]);
        if(y==n)excluded|=1u<<x;
        else if(red(p,x,y))required|=(1u<<x)|(1u<<y);
    }
    ck(!(required&excluded),"inconsistent cube");
    U free=all&~(required|excluded);
    for(U sub=free;;sub=(sub-1)&free){covered[sub|required]=1;if(!sub)break;}
}
static void read_iso(ifstream& in,int n,U all,const Graph& p,vector<Graph>& targets,vector<bool>& present,const array<W,20>& fact,vector<uint8_t>& covered){
    U s=number(in,width(all));ck(s<=all,"out-of-range row");
    ck(!targets.empty(),"empty target inventory");
    const auto dst=number(in,width(targets.size()-1));ck(dst<targets.size(),"wrong destination");
    W rank=number(in,width(fact[n+1]-1));ck(rank<fact[n+1],"out-of-range permutation");
    U left=(1u<<(n+1))-1;int image[20];
    for(int i=0;i<=n;i++){
        W size=fact[n-i], idx=rank/size;rank%=size;
        U choices=left;
        for(W k=0;k<idx;k++)choices&=choices-1;
        ck(choices,"invalid permutation");image[i]=first(choices);left^=1u<<image[i];
    }
    Graph h=extend(p,n,s);
    Graph reached{};
    for(int j=1;j<=n;j++)for(int i=0;i<j;i++)if(red(h,image[i],image[j])){
        reached[i]|=1u<<j;reached[j]|=1u<<i;
    }
    if(present[dst])ck(targets[dst]==reached,"inconsistent graph isomorphism");
    else{targets[dst]=reached;present[dst]=true;}
    covered[s]=1;
}
// Full independent test on the explicit child. A deletion preserves saturation iff
// its vertex is never the sole common neighbor of a pair of distinct non-neighbors.
static bool priority(const Graph& p,int n,U s,bool independent,bool clone){
    Graph h=extend(p,n,s);bool twins=false,minimal=true;U essential=0;
    const int d=pop(s);
    for(int j=0;j<=n;j++){
        if(pop(h[j])<d)minimal=false;
        for(int i=0;i<j;i++){
            if(h[i]==h[j])twins=true;
            U common=h[i]&h[j];
            if(red(h,i,j)){ck(!common,"extension triangle");continue;}
            if(!common)return false;
            if(!(common&(common-1)))essential|=common;
        }
    }
    return clone||(!twins&&(independent||(minimal&&essential==(1u<<(n+1))-1)));
}
int main(int argc,char**argv){
    bool compare=argc==2&&string(argv[1])=="--compare-atlas";
    ck(argc==1||compare,"optional --compare-atlas");
    constexpr array<int,20> counts{1,1,1,1,2,3,4,6,10,16,31,60,138,310,728,1461,1716,487,3,0};
    array<vector<Graph>,20> atlas;
    // The zeroth row is the unique empty graph. Each later list is built on its first incoming map.
    atlas[0].resize(1);
    ifstream in("extension-cert.bin",std::ios::binary);char magic[8];in.read(magic,8);
    ck(in&&string(magic,8)==string("MTF10v1\0",8),"wrong magic");
    array<W,20> fact;fact[0]=1;for(int i=1;i<20;i++)fact[i]=i*fact[i-1];
    W total=0,totalRaw=0;
    for(int n=0;n<19;n++){
        if(compare)ck(atlas[n]==decode_atlas(n),"rebuilt atlas disagrees with comparison data");
        atlas[n+1].resize(counts[n+1]);vector<bool> present(counts[n+1],false);
        U all=(1u<<n)-1;W power=1;for(int k=0;k<10;k++)power*=n+1;
        W retained=0;
        for(const auto& p:atlas[n]){
            U cubeCount=number(in,2),isoCount=number(in,2);vector<uint8_t> covered(all+1),ind(all+1),dup(all+1);
            for(U i=0;i<cubeCount;i++)read_cube(in,width(power-1),p,n,all,covered);
            for(U i=0;i<isoCount;i++)read_iso(in,n,all,p,atlas[n+1],present,fact,covered);
            int low=n;for(int i=0;i<n;i++){dup[p[i]]=1;low=std::min(low,pop(p[i]));}
            ind[0]=1;
            for(U s=0;s<=all;s++){
                if(s){U t=s&(s-1);ind[s]=ind[t]&&!(p[first(s)]&t);}
                // A minimum root degree is at most the smallest old degree plus one.
                if(!dup[s]&&!ind[s]&&pop(s)>low+1)continue;
                // Non-neighbors of the new vertex need some neighbor of it in common.
                bool dom=true;
                for(U z=all&~s;z;z&=z-1)if(!(s&p[first(z)])){dom=false;break;}
                if(!dom)continue;
                if(priority(p,n,s,ind[s],dup[s])){ck(covered[s],"unclassified priority extension");retained++;}
            }
            totalRaw+=all+1;
        }
        ck(std::all_of(present.begin(),present.end(),[](bool b){return b;}),"unreached inventory index");
        total+=retained;std::cout<<n<<' '<<atlas[n].size()<<' '<<retained<<'\n';
    }
    ck(in.peek()==EOF,"trailing certificate");
    std::cout<<"Verified every priority extension: "<<total<<" admissible of "<<totalRaw<<" assignments.\n";
}
