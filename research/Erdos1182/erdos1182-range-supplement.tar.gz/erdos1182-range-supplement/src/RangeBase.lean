import Residual

/-! Order-specific consequences of the BBH sparse placements and host certificates. -/
open SimpleGraph Erdos1182
namespace BBHRange

def template (n m : ℕ) : SimpleGraph (Fin n) :=
  { Adj := fun i j => i ≠ j ∧ m.testBit ((min i j).val*n+(max i j).val) = false
    symm := ⟨fun i j h => ⟨h.1.symm,by simpa [min_comm j i,max_comm j i] using h.2⟩⟩
    loopless := ⟨by simp⟩ }

instance decAdj (n m : ℕ) : DecidableRel (template n m).Adj :=
  fun _ _ => inferInstanceAs (Decidable (_ ∧ _))

theorem sizing (n m : ℕ) {q : ℕ} (h : (template n m).edgeFinset.card=q) :
    (template n m).edgeSet.ncard=q := (Set.ncard_eq_toFinset_card' _).trans h

/-- One row of H2, stripped of its quantifiers over other orders and masks. -/
def Cert (n m : ℕ) : Prop :=
  let N := 2*n-1
  let G := template n m
  let edge := fun (p i j : ℕ) => i≠j ∧ p.testBit (max i j * (max i j-1)/2+min i j)=true
  ∃ A : ℕ → List ℕ, 0 ∈ A 0 ∧ A N=[] ∧ ∀ k<N, ∀ p∈A k, ∀ s : Fin (2^k),
    let S := fun i : ℕ => s.val.testBit i = true
    let E := fun i j : Fin (k+1) =>
      if i.val=0 then j.val≠0 ∧ S (j.val-1) else if j.val=0 then S (i.val-1)
      else edge p (i.val-1) (j.val-1) ∧ ¬(S (i.val-1) ∧ S (j.val-1))
    (∃ v : Fin k, ¬S v.val ∧ ∀ u : Fin k, S u.val → ¬edge p u.val v.val) ∨
    (∃ x y, x≠y ∧ ¬E x y ∧ ∀ z, ¬(E x z ∧ E y z)) ∨
    (∃ f : Fin n ↪ Fin (k+1), ∀ x y, G.Adj x y → ¬E (f x) (f y)) ∨
    ∃ b∈A (k+1), ∃ f : Fin (k+1) ≃ Fin (k+1), ∀ x y, E x y ↔ edge b (f x).val (f y).val

theorem cert_iff_good {n m : ℕ} (hn : 2 ≤ n) (conn : (template n m).Connected) :
    Cert n m ↔ IsTriangleGood (template n m) :=
  ⟨fun h => (SmallTable.Dense.good_iff hn conn).2 (BBHFinite.covers _ _ h),
   fun h => BBHFinite.certificate_of_universal (by omega) _ ((SmallTable.Dense.good_iff hn conn).1 h)⟩

theorem lower_F {n q : ℕ} (hn : 2 ≤ n) (hq : q ≤ n.choose 2) (masks : List ℕ)
    (placement : ∀ G : SimpleGraph (Fin n), G.Connected → G.edgeSet.ncard=q →
      ∃ m∈masks, ∃ e : Fin n ↪ Fin n, ∀ i j, G.Adj i j →
        m.testBit ((min (e i) (e j)).val*n+(max (e i) (e j)).val)=false)
    (hosts : ∀ m∈masks, Cert n m) : q ≤ F n := by
  apply Erdos1182.le_F hq
  intro G hc le
  obtain ⟨D, sub, size⟩ := SmallTable.Sparse.enlarge G le hq
  obtain ⟨m, member, e, he⟩ := placement D (hc.mono sub) size
  have place : G ⊑ template n m :=
    ⟨⟨⟨e, fun h => ⟨e.injective.ne h.ne,he _ _ (sub h)⟩⟩,e.injective⟩⟩
  apply SmallTable.Sparse.sufficient hn _ hc
  intro C ht
  exact place.trans (BBHFinite.covers _ _ (hosts m member) C ht)

theorem lower_f {n m q : ℕ} [Nonempty (Fin n)] (hn : 2 ≤ n)
    (paths : ∀ i j, i=j ∨ (template n m).Adj i j ∨ ∃ v, (template n m).Adj i v ∧ (template n m).Adj v j)
    (size : (template n m).edgeSet.ncard=q) (cert : Cert n m) : q ≤ f n := by
  classical
  have conn : (template n m).Connected := ⟨fun i j => by
    rcases paths i j with rfl | h | ⟨v,a,b⟩
    · exact Reachable.refl _
    · exact h.reachable
    · exact a.reachable.trans b.reachable⟩
  unfold f
  apply le_csSup
  · refine ⟨n.choose 2, ?_⟩
    rintro z ⟨B,_,rfl,_⟩
    rw [Set.ncard_eq_toFinset_card']
    change B.edgeFinset.card ≤ n.choose 2
    simpa only [Fintype.card_fin] using B.card_edgeFinset_le_card_choose_two
  · exact ⟨_,conn,size,(cert_iff_good hn conn).1 cert⟩

theorem nine (cert : Cert 9 2251801971660822) : F 9 = 16 ∧ 27 ≤ f 9 := by
  obtain ⟨paths,count⟩ := SmallTable.Witness.sizes_and_paths 5
  refine ⟨le_antisymm SmallTable.Sparse.upper9 (lower_F (by decide) (by decide) _
    SmallNine.nine_sparse (by simpa using cert)),lower_f (by decide) paths ?_ cert⟩
  exact sizing 9 2251801971660822 count

theorem ten_dense (primary : Cert 10 618970019714747783169716278) : f 10 = 33 := by
  obtain ⟨paths,count⟩ := SmallTable.Witness.sizes_and_paths 6
  apply le_antisymm OMA.R_Erdos1182_erdos_1182_variants_small_values_R2.upper_ten
  exact lower_f (by decide) paths (sizing 10 618970019714747783169716278 count) primary

end BBHRange
