import Pendant

/-! At every order at least two, the maximum gains at least one edge at the next order. -/
open SimpleGraph Erdos1182
namespace BBHPendant

def counts (n : ℕ) : Set ℕ :=
  {q | ∃ G : SimpleGraph (Fin n), G.Connected ∧ G.edgeSet.ncard=q ∧ IsTriangleGood G}

theorem bounded (n : ℕ) : BddAbove (counts n) := by
  classical
  refine ⟨n.choose 2, ?_⟩
  rintro z ⟨G,_,rfl,_⟩
  rw [Set.ncard_eq_toFinset_card']
  change G.edgeFinset.card ≤ n.choose 2
  simpa only [Fintype.card_fin] using G.card_edgeFinset_le_card_choose_two

theorem f_succ {n : ℕ} (hn : 2 ≤ n) : f n + 1 ≤ f (n+1) := by
  let : Nonempty (Fin n) := ⟨⟨0,by omega⟩⟩
  obtain ⟨T,_,hT⟩ := (connected_top : (⊤ : SimpleGraph (Fin n)).Connected).exists_isTree_le
  have start : (counts n).Nonempty :=
    ⟨T.edgeSet.ncard,T,hT.connected,rfl,OMA.tree_triangle_good n hn T hT⟩
  have top : f n ∈ counts n := Nat.sSup_mem start (bounded n)
  exact le_csSup (bounded (n+1)) (witness_succ hn top)

theorem f_growth {n : ℕ} (hn : 2 ≤ n) (k : ℕ) : f n + k ≤ f (n+k) := by
  induction k with
  | zero => simp
  | succ k ih =>
    have step := f_succ (n := n+k) (by omega)
    exact (Nat.add_le_add_right ih 1).trans step

end BBHPendant
