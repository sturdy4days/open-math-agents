import RangeBase
import RedTransports

/-! Every triangle-free host whose complement contains the secondary ten-vertex
template also contains each of the seventeen terminal complements from the sparse
census. Only two triangles in the red missing-edge mask need to be considered. -/
open SimpleGraph Erdos1182

namespace SmallTenResidual

private def cuts : Fin 5 → (Fin 10 × Fin 10) × (Fin 10 × Fin 10) :=
  ![((0,2),(2,3)),((0,1),(2,3)),((0,2),(1,3)),((0,1),(1,3)),((1,2),(1,2))]

private def samePair (x y : Fin 10) (v : Fin 10 × Fin 10) : Prop :=
  (x=v.1 ∧ y=v.2) ∨ (x=v.2 ∧ y=v.1)

private instance (x y : Fin 10) (v : Fin 10 × Fin 10) : Decidable (samePair x y v) := by
  unfold samePair
  infer_instance

private theorem masks (k : Fin 5) (x y : Fin 10) :
    (72057645653176374 : ℕ).testBit ((min x y).val*10+(max x y).val)=true →
    samePair x y (cuts k).1 ∨ samePair x y (cuts k).2 ∨ triEdge (candidates k) x y=true := by
  revert k x y
  decide +kernel

private theorem red_shape {V : Type*} (C : SimpleGraph V) (ht : C.CliqueFree 3)
    (u : (BBHRange.template 10 72057645653176374).Copy Cᶜ) :
    ∃ k : Fin 5, ∀ x y : Fin 10, C.Adj (u x) (u y) → triEdge (candidates k) x y=true := by
  classical
  have miss (x y) (h : C.Adj (u x) (u y)) :
      (72057645653176374 : ℕ).testBit ((min x y).val*10+(max x y).val)=true := by
    cases b : (72057645653176374 : ℕ).testBit ((min x y).val*10+(max x y).val)
    · exact False.elim ((u.toHom.map_adj ⟨fun eq => h.ne (congrArg u eq), b⟩).2 h)
    · rfl
  have swap {a b i j : Fin 10} (notRed : ¬C.Adj (u a) (u b)) (pr : samePair i j (a,b)) :
      ¬C.Adj (u i) (u j) := by
    rcases pr with ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩
    · exact notRed
    · exact fun h => notRed h.symm
  have select (k : Fin 5) (d₁ : ¬C.Adj (u (cuts k).1.1) (u (cuts k).1.2))
      (d₂ : ¬C.Adj (u (cuts k).2.1) (u (cuts k).2.2)) :
      ∀ x y : Fin 10, C.Adj (u x) (u y) → triEdge (candidates k) x y=true := by
    intro x y h
    rcases masks k x y (miss x y h) with a | b | good
    · exact (swap d₁ a h).elim
    · exact (swap d₂ b h).elim
    · exact good
  by_cases shared : C.Adj (u 1) (u 2)
  · have avoid (i : Fin 10) : ¬C.Adj (u i) (u 1) ∨ ¬C.Adj (u i) (u 2) := by
      by_contra! both
      exact C.isIndepSet_neighborSet_of_triangleFree ht _ both.1 both.2 shared.ne shared
    rcases avoid 0 with no01 | no02 <;> rcases avoid 3 with no31 | no32
    · exact ⟨3,select 3 no01 (fun h => no31 h.symm)⟩
    · exact ⟨1,select 1 no01 (fun h => no32 h.symm)⟩
    · exact ⟨2,select 2 no02 (fun h => no31 h.symm)⟩
    · exact ⟨0,select 0 no02 (fun h => no32 h.symm)⟩
  · exact ⟨4,select 4 shared shared⟩

theorem forces_terminals {V : Type*} (C : SimpleGraph V) (ht : C.CliqueFree 3)
    (secondary : BBHRange.template 10 72057645653176374 ⊑ Cᶜ) :
    ∀ m ∈ terminals, terminalGraph m ⊑ Cᶜ := by
  obtain ⟨u⟩ := secondary
  obtain ⟨k,shape⟩ := red_shape C ht u
  intro m hm
  obtain ⟨e,moves⟩ := red_maps hm k
  let b := e.symm.toEmbedding.trans u.toEmbedding
  refine ⟨⟨⟨b,?_⟩,b.injective⟩⟩
  intro x y adj
  refine ⟨b.injective.ne adj.ne,?_⟩
  intro forbidden
  have edge := moves _ _ (shape (e.symm x) (e.symm y) forbidden)
  simp only [e.apply_symm_apply] at edge
  exact Bool.noConfusion (adj.2.symm.trans edge)

end SmallTenResidual

theorem BBHRange.ten_secondary_exact (h : BBHRange.Cert 10 72057645653176374) :
    Erdos1182.F 10 = 18 := by
  refine le_antisymm SmallTable.Sparse.upper10 (Erdos1182.le_F (by decide) ?_)
  intro G conn size
  apply SmallTable.Sparse.sufficient (by decide) _ conn
  intro C ht
  have primary := BBHFinite.covers (BBHRange.template 10 72057645653176374) 19 h C ht
  rcases SmallTenResidual.census G size with ⟨e,place⟩ | ⟨m,hm,f,repr⟩
  · have into : G ⊑ BBHRange.template 10 72057645653176374 :=
      ⟨⟨⟨e,fun a => ⟨e.injective.ne a.ne,place _ _ a⟩⟩,e.injective⟩⟩
    exact into.trans primary
  · exact (SmallTenResidual.iso_of_repr f repr).symm.isContained.trans
      (SmallTenResidual.forces_terminals C ht primary m hm)

#print axioms SmallTenResidual.red_maps
#print axioms SmallTenResidual.forces_terminals
#print axioms BBHRange.ten_secondary_exact
