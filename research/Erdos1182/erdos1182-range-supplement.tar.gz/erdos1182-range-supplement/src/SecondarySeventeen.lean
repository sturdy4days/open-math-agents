import TerminalGeometry
import RangeBase

/-! At orders up to seventeen edges the secondary ten-vertex template alone suffices
for every connected graph. The census has seventeen terminal complements; each
terminal graph with at most seventeen edges has a nontrivial cut without any edges. -/
open SimpleGraph

namespace SmallTenResidual

theorem terminal_cut : ∀ m ∈ terminals,
    17 < (terminalGraph m).edgeFinset.card ∨ ∃ k : Fin 2, ∀ i j,
      (terminalGraph m).Adj i j → decide (i.val < 8+k.val) = decide (j.val < 8+k.val) := by
  decide +kernel

theorem only_secondary (G : SimpleGraph (Fin 10)) (conn : G.Connected)
    (edges : G.edgeSet.ncard ≤ 17) : Placement G := by
  rcases census G (by omega) with yes | ⟨m,hm,f,hf⟩
  · exact yes
  let iso := iso_of_repr f hf
  rcases terminal_cut m hm with large | ⟨k,cut⟩
  · classical
    have eq : (terminalGraph m).edgeSet.ncard = G.edgeSet.ncard := by
      simpa only [SimpleGraph.edgeFinset_card,Set.fintypeCard_eq_ncard] using iso.card_edgeFinset_eq
    simp only [SimpleGraph.edgeFinset_card,Set.fintypeCard_eq_ncard] at large
    omega
  · let color (i : Fin 10) := decide (i.val < 8+k.val)
    have low : ∃ i, color i = true := ⟨0,by simp [color]⟩
    have high : ∃ i, color i = false := ⟨9,by
      change decide (9 < 8+k.val) = false
      have := k.isLt
      simp [show ¬ 9 < 8+k.val by omega]⟩
    obtain ⟨i,j,e,diff⟩ := SmallCover.Seven.seven_connected_cut (iso.connected_iff.mpr conn) color high low
    exact False.elim (diff (cut i j e))

end SmallTenResidual

theorem BBHRange.ten_secondary_seventeen (onlyMask : BBHRange.Cert 10 72057645653176374) :
    17 ≤ Erdos1182.F 10 := by
  apply BBHRange.lower_F (by decide) (by decide) [72057645653176374]
  · intro G conn size
    exact ⟨_,by decide,SmallTenResidual.only_secondary G conn size.le⟩
  · simpa using onlyMask

#print axioms SmallTenResidual.census
#print axioms SmallTenResidual.only_secondary
#print axioms BBHRange.ten_secondary_seventeen
