import NineExact

/-! Each of the last three dense maxima can use either of two extremal BBH templates. -/
open SimpleGraph Erdos1182
namespace BBHRange

private theorem from_one {n q : ℕ} [Nonempty (Fin n)] (hn : 2 ≤ n) (m : Fin 2 → ℕ)
    (geometry : ∀ i,
      (∀ x y, x=y ∨ (template n (m i)).Adj x y ∨
        ∃ v, (template n (m i)).Adj x v ∧ (template n (m i)).Adj v y) ∧
        (template n (m i)).edgeFinset.card=q)
    (cert : Cert n (m 0) ∨ Cert n (m 1)) : q ≤ f n := by
  have use (i : Fin 2) (c : Cert n (m i)) :=
    lower_f hn (geometry i).1 (sizing n (m i) (geometry i).2) c
  exact cert.elim (use 0) (use 1)

theorem ten_either (h : Cert 10 618970019714747783169716278 ∨ Cert 10 72057645653176374) :
    f 10 = 33 := by
  apply le_antisymm (E1182Complete.upper_table 6)
  exact from_one (by decide) ![618970019714747783169716278,72057645653176374] (by decide) h

theorem eleven_either (h : Cert 11 158495020111019088292975255562 ∨ Cert 11 9444734656926049394710) :
    f 11 = 41 := by
  apply le_antisymm (E1182Complete.upper_table 7)
  exact from_one (by decide) ![158495020111019088292975255562,9444734656926049394710] (by decide) h

theorem twelve_either (h : Cert 12 14855280693082744087392632874 ∨ Cert 12 4951760378943817067685560330) :
    f 12 = 49 := by
  apply le_antisymm (E1182Complete.upper_table 8)
  exact from_one (by decide) ![14855280693082744087392632874,4951760378943817067685560330] (by decide) h

theorem twelve_secondary
    (h : Cert 12 604831853708092460023990 ∨ Cert 12 40564825856395375891792278241302) :
    48 ≤ f 12 ∧ f 12 ≤ 49 :=
  ⟨from_one (by decide) ![604831853708092460023990,40564825856395375891792278241302] (by decide) h,
    E1182Complete.upper_table 8⟩

end BBHRange
