import Growth
import AlternativeMasks

/-! Sharp dense certificates at one order also give unconditional-in-later-orders lower bounds. -/
open Erdos1182
namespace BBHRange

theorem carry_nine (c : Cert 9 2251801971660822) (k : ℕ) : 27+k ≤ f (9+k) :=
  (Nat.add_le_add_right (nine c).2 k).trans (BBHPendant.f_growth (by decide) k)

theorem carry_ten (c : Cert 10 618970019714747783169716278 ∨ Cert 10 72057645653176374)
    (k : ℕ) : 33+k ≤ f (10+k) := by
  simpa only [ten_either c] using BBHPendant.f_growth (n := 10) (by decide) k

end BBHRange
