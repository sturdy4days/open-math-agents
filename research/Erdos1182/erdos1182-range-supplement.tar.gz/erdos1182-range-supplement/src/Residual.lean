import OMAReductions.R_Erdos1182_erdos_1182_variants_small_values_R2
import Mathlib.Data.Nat.Bitwise
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Data.List.FinRange
import Mathlib.Combinatorics.Colex
import Mathlib.Combinatorics.SimpleGraph.DeleteEdges
import Mathlib.Combinatorics.SimpleGraph.DegreeSum
import Mathlib.Logic.Equiv.Fintype
import Mathlib.Tactic.FinCases

/-! # The sparse covering cases at orders nine through twelve

The dense templates are those of Brandt, Brinkmann and Harmuth (1998).
Their bit encodings follow @physbuzz's published sparse-threshold reduction (PR #8892).
The order-nine proof uses minimum-degree vertex deletion and kernel-checked
extension tables to cover every connected nine-vertex graph with 16 edges.
-/

namespace SmallNine

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_2_0 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 1 1 [0] [1] t = true := by
  refine ⟨[([],[(1,0,16)])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_3_0 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 2 2 [1] [6,7] t = true := by
  refine ⟨[([],[(1,0,33),(2,0,288),(3,1,528)])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_4_0 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 3 4 [6,7] [58,30,62,63] t = true := by
  refine ⟨[([],[(3,1,12816),(5,0,8976),(6,0,8961),(7,2,12816)]),([],[(1,0,561),(2,0,4656),(4,0,8496),(3,2,4146),(5,2,8241),(6,2,8496),(7,3,12816)])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_5_0 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 4 6 [58,30,62,63] [984,504,1016,978,474,986,490,874,1002,1018,478,990,1022,1023] t = true := by
  refine ⟨[([],[(3,4,213520),(5,6,213520),(6,4,213010),(9,0,196930),(10,3,213520),(12,0,205120),(7,10,135235),(11,5,213520),(13,8,213520),(14,5,213010),(15,9,274960)]),([],[(3,1,66610),(5,4,144400),(6,4,144385),(9,4,205840),(10,4,205825),(12,1,205840),(7,10,274960),(11,10,271120),(13,10,266290),(14,10,262450),(15,11,274960)]),([],[(1,6,4930),(2,6,66370),(4,0,144400),(8,0,205840),(3,10,213520),(5,5,144400),(6,5,144385),(9,5,205840),(10,5,205825),(12,2,205840),(7,11,148240),(11,11,213520),(13,9,205840),(14,9,205825),(15,12,274960)]),([],[(0,7,205120),(1,8,12865),(2,8,78400),(4,8,143680),(8,8,205120),(3,9,66370),(5,9,131905),(6,9,136000),(9,9,197185),(10,9,201280),(12,9,205120),(7,12,135235),(11,12,200770),(13,12,204865),(14,12,205120),(15,13,274960)])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_6_0 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 5 9 [984,504,1016,978,474,986,490,874] [32704,32200,32456,16328,32712,31960,32088,15832,24024,32216,16088,28376,30424,32472,16216,31576,32600,32728,7672,15864,28152,32248,32760,32082,15826,24018,28114,30162,32210,16338,32722,15770,32154,14810,15834,28122,32218,32730,15850,24042,32234,16234,30570,32618,32746,32762,15838,24030,30174,32222,16350,32734,32766,32767] t = true := by
  refine ⟨[([],[(7,7,4534800),(11,10,4534800),(13,14,4534800),(14,14,4534785),(19,5,4534800),(21,6,4534800),(22,6,4534785),(25,2,4411920),(26,2,4411905),(28,1,4399365),(15,20,3490320),(23,9,4534800),(27,13,4534800),(29,16,4534800),(30,16,4534785),(31,17,5517840)]),([],[(7,18,5517840),(11,7,3428880),(13,7,3428640),(14,7,3428385),(19,7,4411920),(21,7,4411680),(22,7,4411425),(25,3,4411920),(26,3,4411905),(28,3,4411650),(15,19,5517840),(23,19,5456400),(27,20,5517840),(29,20,5517600),(30,20,5517345),(31,21,5517840)]),([],[(3,8,4411920),(5,8,4411680),(6,8,4411425),(9,1,3428880),(10,1,3428865),(12,1,3428610),(17,1,4411920),(18,1,4411905),(20,1,4411650),(24,0,4411920),(7,19,4534800),(11,9,3428880),(13,9,3428640),(14,9,3428385),(19,9,4411920),(21,9,4411680),(22,9,4411425),(25,4,4411920),(26,4,4411905),(28,4,4411650),(15,21,3490320),(23,21,4534800),(27,17,4411920),(29,17,4411680),(30,17,4411425),(31,22,5517840)]),([],[(7,24,4534800),(11,24,4530945),(13,24,4526640),(14,24,4522785),(19,6,4260645),(21,23,4534800),(22,6,4268805),(25,6,4207125),(26,23,4530945),(28,6,4399365),(15,29,5517840),(23,28,4534800),(27,28,4530945),(29,28,4526640),(30,28,4522785),(31,30,5517840)]),([],[(7,7,74580),(11,24,75075),(13,31,87090),(14,33,5517840),(19,14,82725),(21,27,4199730),(22,31,4411410),(25,14,4391205),(26,24,4400385),(28,7,4399440),(15,34,5517840),(23,38,75060),(27,35,5517840),(29,38,4400400),(30,34,5247540),(31,36,5517840)]),([],[(3,14,83235),(5,26,4199730),(6,31,4534800),(9,15,4391205),(10,26,4400385),(12,14,3294480),(17,1,4199715),(18,6,4261155),(20,6,4338960),(24,1,4400400),(7,34,4534800),(11,35,3428880),(13,35,282915),(14,34,4522275),(19,9,4198995),(21,28,4199730),(22,32,4534800),(25,16,4391205),(26,28,4400385),(28,9,4399440),(15,46,3280980),(23,36,4534800),(27,40,4199715),(29,40,4400400),(30,36,4522275),(31,37,5517840)]),([],[(7,8,2102100),(11,31,78930),(13,25,2102595),(14,31,2176080),(19,26,4199250),(21,12,4325685),(22,26,4330320),(25,10,4391250),(26,24,4395600),(28,10,4399440),(15,38,5517840),(23,39,5517840),(27,35,336180),(29,41,4411920),(30,35,2425140),(31,40,5517840)]),([],[(7,25,2102355),(11,25,3150930),(13,11,3277140),(14,25,3282000),(19,25,4199250),(21,11,4325715),(22,25,4330320),(25,11,4391250),(26,25,4395600),(28,11,4399440),(15,41,5517840),(23,41,5456400),(27,41,5391120),(29,42,5517840),(30,41,5260050),(31,43,5517840)])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_6_1 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 5 9 [1002,1018,478,990,1022,1023] [32704,32200,32456,16328,32712,31960,32088,15832,24024,32216,16088,28376,30424,32472,16216,31576,32600,32728,7672,15864,28152,32248,32760,32082,15826,24018,28114,30162,32210,16338,32722,15770,32154,14810,15834,28122,32218,32730,15850,24042,32234,16234,30570,32618,32746,32762,15838,24030,30174,32222,16350,32734,32766,32767] t = true := by
  refine ⟨[([],[(3,27,4199250),(5,12,4325715),(6,27,4330320),(9,12,4391250),(10,27,4395600),(12,12,4399440),(17,2,4206930),(18,23,4411920),(20,2,4338000),(24,2,4399440),(7,38,4534800),(11,38,4530960),(13,41,4534800),(14,38,4522770),(19,28,4199250),(21,13,4325715),(22,28,4330320),(25,13,4391250),(26,28,4395600),(28,13,4399440),(15,47,3280980),(23,40,4534800),(27,40,4530960),(29,43,4534800),(30,40,4522770),(31,44,5517840)]),([],[(1,12,275730),(2,25,4411920),(4,12,2372880),(8,2,3417360),(16,2,4400400),(3,38,74835),(5,39,4411920),(6,38,2163795),(9,16,3408210),(10,28,3428880),(12,16,3416400),(17,16,4391250),(18,28,4411920),(20,16,4399440),(24,4,4400400),(7,48,2380560),(11,36,3428880),(13,40,3428880),(14,36,3428370),(19,36,4411920),(21,40,4411920),(22,36,4411410),(25,17,4391250),(26,30,4411920),(28,17,4399440),(15,49,3280980),(23,49,4329555),(27,37,4411920),(29,44,4411920),(30,37,4411410),(31,45,5517840)]),([],[(3,3,1066290),(5,14,74580),(6,14,1057620),(9,24,87090),(10,24,1070130),(12,7,2311440),(17,14,82770),(18,14,1065810),(20,8,4338960),(24,7,4400400),(7,20,2163540),(11,29,1070130),(13,34,2311440),(14,34,2311425),(19,20,4260690),(21,38,87090),(22,38,1070130),(25,34,4400400),(26,34,4400385),(28,19,4400400),(15,46,5517840),(23,47,5517840),(27,46,4400400),(29,48,5517840),(30,48,5517825),(31,49,5517840)]),([],[(1,10,83250),(2,10,1066290),(4,10,2311440),(8,10,3294480),(16,5,4400400),(3,20,4261170),(5,35,4338960),(6,35,4338945),(9,35,4400400),(10,35,4400385),(12,20,4400400),(17,9,4199730),(18,9,4261170),(20,9,4338960),(24,9,4400400),(7,46,4534800),(11,46,4530960),(13,46,4526130),(14,46,4522290),(19,21,4261170),(21,36,4338960),(22,36,4338945),(25,36,4400400),(26,36,4400385),(28,21,4400400),(15,50,5517840),(23,49,4534800),(27,49,4530960),(29,49,4526130),(30,49,4522290),(31,51,5517840)]),([],[(0,11,4400400),(1,41,82770),(2,41,1065810),(4,13,2372880),(8,13,3417360),(16,13,4400400),(3,47,4411920),(5,40,2102355),(6,40,2163795),(9,40,3150930),(10,40,3212370),(12,17,3294480),(17,40,4199250),(18,40,4260690),(20,17,4338960),(24,17,4400400),(7,49,2380560),(11,49,3428880),(13,37,3294480),(14,37,3294465),(19,49,4411920),(21,37,4338960),(22,37,4338945),(25,37,4400400),(26,37,4400385),(28,22,4400400),(15,51,3298320),(23,51,4346640),(27,51,4411920),(29,45,4400400),(30,45,4400385),(31,52,5517840)]),([],[(0,42,4399440),(1,43,275025),(2,43,1323600),(4,43,2371920),(8,43,3416400),(16,43,4399440),(3,44,1065810),(5,44,2114385),(6,44,2179920),(9,44,3162705),(10,44,3228240),(12,44,3293520),(17,44,4207185),(18,44,4272720),(20,44,4338000),(24,44,4399440),(7,45,2163795),(11,45,3212370),(13,45,3277905),(14,45,3282000),(19,45,4260690),(21,45,4326225),(22,45,4330320),(25,45,4391505),(26,45,4395600),(28,45,4399440),(15,52,3280980),(23,52,4329555),(27,52,4395090),(29,52,4399185),(30,52,4399440),(31,53,5517840)])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_7_0 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 6 12 [32704,32200,32456,16328] [2096192,2079936,2088128,2094272,1047744,2096320,2072000,2076096,1031616,1555904,2080192,1039808,1826240,1957312,2088384,1043904,2026944,2092480,2096576,507840,1032128,1818560,2080704,2097088,2079880,2092168,1047688,2096264,2071752,2075848,2078920,2084040,2086088,1948872,2047176,1563848,1957064,2022600,1043656,1961160,2092232,2076040,2090376,1043848,1961352,2026888,2090568,1031752,1556040,1818184,1949256,2080328,1044040,1961544,2027080,2092616,1048136,2096712,2026952,1810120,2006728,2039496,1945288,1816264,1961672,912600,1961176,2070872,2013528,915800,765400,1961688,991064,2074962,1027410,1551698,2075986,962002,1682898,898514,1914322,2029418] t = true := by
  refine ⟨[([],[(7,9,88486416),(11,9,88482576),(13,9,88478496),(14,9,88474401),(19,1,72757776),(21,1,72757536),(22,1,72757281),(25,1,72753456),(26,1,72753201),(28,1,72749106),(35,1,88486416),(37,1,88486176),(38,1,88485921),(41,1,88482096),(42,1,88481841),(44,1,88477746),(49,0,88486416),(50,0,88486401),(52,0,88486146),(56,0,88482051),(15,20,90452496),(23,10,72757776),(27,10,72753936),(29,10,72749856),(30,10,72745761),(39,10,88486416),(43,10,88482576),(45,10,88478496),(46,10,88474401),(51,5,88486416),(53,5,88486176),(54,5,88485921),(57,5,88482096),(58,5,88481841),(60,5,88477746),(31,22,73740816),(47,22,90452496),(55,18,88486416),(59,18,88482576),(61,18,88478496),(62,18,88474401),(63,23,106181136)]),([(6,50734161),(11,37838901),(13,21127221),(51,50484756),(53,50419236),(58,3298836),(60,3233316)],[(19,35,88486416),(21,35,88486176),(25,49,88302096),(26,34,88281606),(28,34,88285446),(35,28,88486416),(37,28,88486176),(41,42,84173331),(42,30,88474131),(44,30,88473891),(49,3,88088886),(50,24,88302081),(52,24,88301826),(56,1,88285536),(57,51,88302096)]),([(5,39931956),(11,38887476),(12,39932676),(22,50488341)],[(19,33,72757776),(25,50,72757776),(26,33,72745491),(35,29,88486416),(38,41,88486416),(41,31,87036516),(42,29,88474131),(49,2,88088931),(50,25,88486416),(52,24,88224096),(56,2,88285536),(51,40,88486416),(57,55,88486416),(58,40,88474131)]),([(5,39931956),(3,23220276),(12,39932676),(22,50668641),(10,23220996),(38,50603361)],[(25,47,72757776),(41,47,88486416),(49,4,88088931),(50,26,88486416),(52,26,88486176),(56,4,88285536),(57,56,88486416)])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_7_1 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 6 12 [32712,31960,32088,15832] [2096192,2079936,2088128,2094272,1047744,2096320,2072000,2076096,1031616,1555904,2080192,1039808,1826240,1957312,2088384,1043904,2026944,2092480,2096576,507840,1032128,1818560,2080704,2097088,2079880,2092168,1047688,2096264,2071752,2075848,2078920,2084040,2086088,1948872,2047176,1563848,1957064,2022600,1043656,1961160,2092232,2076040,2090376,1043848,1961352,2026888,2090568,1031752,1556040,1818184,1949256,2080328,1044040,1961544,2027080,2092616,1048136,2096712,2026952,1810120,2006728,2039496,1945288,1816264,1961672,912600,1961176,2070872,2013528,915800,765400,1961688,991064,2074962,1027410,1551698,2075986,962002,1682898,898514,1914322,2029418] t = true := by
  refine ⟨[([(3,23220276),(5,39931956),(6,50734161),(10,23220996),(12,39932676)],[(9,48,88486416),(17,3,72360291),(18,24,72757776),(20,24,72757536),(24,3,72556896),(33,3,88088931),(34,24,88486416),(36,24,88486176),(40,3,88285536),(48,0,88302096),(25,51,72757776),(41,51,88486416),(49,5,88088931),(50,27,88486416),(52,27,88486176),(56,5,88285536),(57,57,88486416)]),([(5,39927891),(11,39064416),(6,39862611),(19,38999136),(25,38879331),(26,38814051),(12,40112976),(20,40047696)],[(35,6,84944451),(41,29,87319056),(42,29,87319041),(49,29,88302096),(50,29,88302081),(56,6,88286736)]),([(3,69604656),(5,51782976),(14,67265301),(22,50422821),(41,37834851),(49,20074596),(58,37770771),(60,19944996)],[(25,63,88302096),(26,61,88281606),(28,61,87302406),(38,67,90452496),(42,41,87319041),(44,30,87318786),(50,30,88302081),(52,41,88301826),(56,7,88285536)]),([(4,103028016),(11,37838901),(19,86185056),(25,38879331),(26,38814051),(35,37838931),(41,37834851),(42,37769571),(49,20074596),(50,3297636)],[(56,8,88286736)])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_7_2 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 6 12 [24024,32216,16088,28376] [2096192,2079936,2088128,2094272,1047744,2096320,2072000,2076096,1031616,1555904,2080192,1039808,1826240,1957312,2088384,1043904,2026944,2092480,2096576,507840,1032128,1818560,2080704,2097088,2079880,2092168,1047688,2096264,2071752,2075848,2078920,2084040,2086088,1948872,2047176,1563848,1957064,2022600,1043656,1961160,2092232,2076040,2090376,1043848,1961352,2026888,2090568,1031752,1556040,1818184,1949256,2080328,1044040,1961544,2027080,2092616,1048136,2096712,2026952,1810120,2006728,2039496,1945288,1816264,1961672,912600,1961176,2070872,2013528,915800,765400,1961688,991064,2074962,1027410,1551698,2075986,962002,1682898,898514,1914322,2029418] t = true := by
  refine ⟨[([(4,102962256),(19,86185056),(25,38879331),(26,38814051),(35,69408096),(41,37834851),(42,37769571),(49,20074596),(50,3297636)],[(11,70,90452496),(56,9,88286736)]),([(3,69604656),(4,102962256),(25,38879331),(26,38814051),(41,37834851),(42,37769571),(49,20074596),(50,3297636)],[(9,59,88302096),(10,59,88302081),(17,35,72573456),(18,35,72573441),(24,15,70607376),(33,28,88302096),(34,28,88302081),(40,7,88286736),(48,1,88302096),(56,10,88286736)]),([(5,39931956),(6,39866676),(25,38879331),(26,38814051),(12,40178496),(3,39195456),(20,40178736)],[(41,33,55861776),(42,33,55861761),(49,38,88302096),(50,38,88302081),(56,11,88286736)]),([(5,39931971),(6,39866691),(12,40178496),(20,40178736)],[(11,62,51401316),(19,62,68178531),(25,39,70607376),(26,39,70607361),(35,62,84951651),(41,39,87319056),(42,39,87319041),(49,39,88302096),(50,39,88302081),(56,12,88286736),(27,66,70668816),(43,66,87441936),(51,66,88486416),(57,64,88302096),(58,64,88302081),(59,71,106181136)])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_7_3 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 6 12 [30424,32472,16216,31576] [2096192,2079936,2088128,2094272,1047744,2096320,2072000,2076096,1031616,1555904,2080192,1039808,1826240,1957312,2088384,1043904,2026944,2092480,2096576,507840,1032128,1818560,2080704,2097088,2079880,2092168,1047688,2096264,2071752,2075848,2078920,2084040,2086088,1948872,2047176,1563848,1957064,2022600,1043656,1961160,2092232,2076040,2090376,1043848,1961352,2026888,2090568,1031752,1556040,1818184,1949256,2080328,1044040,1961544,2027080,2092616,1048136,2096712,2026952,1810120,2006728,2039496,1945288,1816264,1961672,912600,1961176,2070872,2013528,915800,765400,1961688,991064,2074962,1027410,1551698,2075986,962002,1682898,898514,1914322,2029418] t = true := by
  refine ⟨[([(4,102843651),(25,38879331),(3,39195456),(58,38815251)],[(26,44,70607361),(41,36,55579236),(42,33,55640676),(49,36,72356451),(50,33,72417891),(56,13,88285536)]),([(3,39195456),(4,103028016),(25,38879331),(26,38814051)],[(9,36,55861776),(10,36,55861761),(17,36,72573456),(18,36,72573441),(24,13,88286736),(33,31,88302096),(34,31,88302081),(40,2,87303696),(48,2,88286736),(41,40,87319056),(42,40,87319041),(49,40,88302096),(50,40,88302081),(56,14,88286736)]),([(13,22175796),(2,101864196),(21,20259936),(37,51651936),(41,37834851),(49,20074596),(60,19944996)],[(25,60,55861536),(28,61,55861506),(44,34,87163236),(52,43,88301826),(56,15,88285536)]),([(13,85091076),(14,67265301),(19,86074371),(22,50422821),(35,69231891),(37,51406116)],[(7,72,90452496),(11,68,55984416),(21,68,72757776),(25,45,70607376),(26,35,70328421),(28,35,54661221),(38,68,88486401),(41,35,87040356),(42,45,87319041),(44,35,55705956),(49,35,88085091),(50,35,72417891),(52,45,88301826),(56,16,88285446),(57,58,70582806),(58,58,87298566),(60,58,88285446)])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_7_4 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 6 12 [32600,32728,7672,15864] [2096192,2079936,2088128,2094272,1047744,2096320,2072000,2076096,1031616,1555904,2080192,1039808,1826240,1957312,2088384,1043904,2026944,2092480,2096576,507840,1032128,1818560,2080704,2097088,2079880,2092168,1047688,2096264,2071752,2075848,2078920,2084040,2086088,1948872,2047176,1563848,1957064,2022600,1043656,1961160,2092232,2076040,2090376,1043848,1961352,2026888,2090568,1031752,1556040,1818184,1949256,2080328,1044040,1961544,2027080,2092616,1048136,2096712,2026952,1810120,2006728,2039496,1945288,1816264,1961672,912600,1961176,2070872,2013528,915800,765400,1961688,991064,2074962,1027410,1551698,2075986,962002,1682898,898514,1914322,2029418] t = true := by
  refine ⟨[([(2,101864196),(4,102847491),(41,37834851),(49,20074596)],[(9,37,87040356),(17,37,88085091),(24,16,88285536),(33,32,88302096),(40,3,87318816),(48,3,88302096),(25,58,70607376),(56,17,88285536)]),([(1,100815636),(2,101864196),(4,103093296)],[(8,13,55861776),(16,2,72573456),(32,2,88302096),(24,17,72558096),(40,17,88286736),(48,5,88302096),(56,18,88286736)]),([(11,86250336),(13,85205856),(14,84157281),(19,86185056),(21,85140576),(22,84092001),(25,38879331),(26,38814051),(28,22037091),(35,69408096),(37,68363616),(38,67315041),(41,37834851),(42,37769571),(44,20992611),(49,36786276),(50,36720996),(52,19944036)],[(7,19,34628931),(56,19,88302096)]),([(4,103027536),(1,100934481),(2,101983056)],[(24,8,54878736),(40,9,87319056),(48,8,88302096),(56,20,88302096)])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_7_5 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 6 12 [28152,32248,32760,32082] [2096192,2079936,2088128,2094272,1047744,2096320,2072000,2076096,1031616,1555904,2080192,1039808,1826240,1957312,2088384,1043904,2026944,2092480,2096576,507840,1032128,1818560,2080704,2097088,2079880,2092168,1047688,2096264,2071752,2075848,2078920,2084040,2086088,1948872,2047176,1563848,1957064,2022600,1043656,1961160,2092232,2076040,2090376,1043848,1961352,2026888,2090568,1031752,1556040,1818184,1949256,2080328,1044040,1961544,2027080,2092616,1048136,2096712,2026952,1810120,2006728,2039496,1945288,1816264,1961672,912600,1961176,2070872,2013528,915800,765400,1961688,991064,2074962,1027410,1551698,2075986,962002,1682898,898514,1914322,2029418] t = true := by
  refine ⟨[([(1,100812051),(2,101860611),(4,103027536)],[(24,4,70607376),(40,15,54863376),(48,15,70592016),(56,21,88286736)]),([(1,100934481),(2,101983056),(4,103027536)],[(8,11,54878736),(16,11,70607376),(32,6,88302096),(24,21,88302096),(40,10,87319056),(48,10,88302096),(56,22,88302096)]),([(1,101000001),(2,102048576),(4,103093056)],[(0,12,88302096),(8,14,55861776),(16,14,72573456),(32,14,88302096),(24,18,70607376),(40,18,87319056),(48,18,88302096),(56,23,88302096)]),([(5,51782976),(17,51791136),(20,51791106)],[(11,74,90452496),(14,74,90451986),(26,74,90320916),(35,41,83968866),(38,41,86066016),(41,41,84099426),(42,73,90452496),(44,41,86196576),(50,41,88154976),(56,41,88285536),(43,76,90452496),(46,76,90451986),(58,76,90320916)])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_7_6 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 6 12 [15826,24018,28114,30162] [2096192,2079936,2088128,2094272,1047744,2096320,2072000,2076096,1031616,1555904,2080192,1039808,1826240,1957312,2088384,1043904,2026944,2092480,2096576,507840,1032128,1818560,2080704,2097088,2079880,2092168,1047688,2096264,2071752,2075848,2078920,2084040,2086088,1948872,2047176,1563848,1957064,2022600,1043656,1961160,2092232,2076040,2090376,1043848,1961352,2026888,2090568,1031752,1556040,1818184,1949256,2080328,1044040,1961544,2027080,2092616,1048136,2096712,2026952,1810120,2006728,2039496,1945288,1816264,1961672,912600,1961176,2070872,2013528,915800,765400,1961688,991064,2074962,1027410,1551698,2075986,962002,1682898,898514,1914322,2029418] t = true := by
  refine ⟨[([(7,55664676),(9,56709156),(21,51717216),(12,56709636),(37,51651936),(49,51733506),(52,51733536),(56,33842481)],[(19,69,72418086),(22,69,72426246),(26,80,22295136),(35,61,84943716),(38,61,85066596),(42,74,88482561),(50,43,88154976)]),([(5,51782736),(9,56709156),(12,56709636),(17,51791136),(20,51791106),(33,51794976),(36,51794946),(56,33776721)],[(26,75,72558081),(42,75,88286721),(50,44,88154976)]),([(7,55664676),(11,37773621),(24,33965331),(36,51794946),(49,51529056),(50,33772641)],[(13,79,90452496),(14,79,73736961),(19,59,67187301),(21,75,67330341),(22,68,72486966),(35,59,84943716),(41,68,88277286),(42,75,85090356)]),([(7,55664676),(13,21192741),(17,20333856),(20,20333826),(33,51794976),(36,51794946),(50,33772641),(56,33637731)],[(11,77,90452496),(14,77,90451986),(26,74,70410261),(42,74,85090356)])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_7_7 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 6 12 [32210,16338,32722,15770] [2096192,2079936,2088128,2094272,1047744,2096320,2072000,2076096,1031616,1555904,2080192,1039808,1826240,1957312,2088384,1043904,2026944,2092480,2096576,507840,1032128,1818560,2080704,2097088,2079880,2092168,1047688,2096264,2071752,2075848,2078920,2084040,2086088,1948872,2047176,1563848,1957064,2022600,1043656,1961160,2092232,2076040,2090376,1043848,1961352,2026888,2090568,1031752,1556040,1818184,1949256,2080328,1044040,1961544,2027080,2092616,1048136,2096712,2026952,1810120,2006728,2039496,1945288,1816264,1961672,912600,1961176,2070872,2013528,915800,765400,1961688,991064,2074962,1027410,1551698,2075986,962002,1682898,898514,1914322,2029418] t = true := by
  refine ⟨[([(5,51782736),(9,56709156),(12,56709636),(17,51791136),(20,51791106),(24,33965331),(33,51794976),(36,51794946),(50,33772641)],[(3,60,84943716),(6,60,85066596),(10,75,88482561),(18,45,88154976),(34,42,88155696),(40,41,88286736),(48,24,88286736),(42,76,88482561)]),([(3,23285796),(6,39866676),(9,56709156),(12,56709636),(21,51717216),(26,33895521),(37,51651936),(42,33830241),(49,51733506),(50,33907731),(52,51733536),(56,33907761)],[(5,70,36705876),(10,70,52495956),(17,43,72365601),(18,43,72427056),(20,43,72496641),(24,43,72558096),(33,43,88094241),(34,43,88155696),(36,43,88225281),(40,43,88286736),(48,26,88286736)]),([(3,23285796),(5,51782736),(6,39866676),(9,56709156),(10,33961041),(12,56709636),(17,51791136),(18,33965361),(20,51791106),(24,33965331),(33,51794976),(34,33969201),(36,51794946),(40,33969171)],[(1,44,88094241),(2,44,88155696),(4,44,88225281),(8,44,88286736),(16,25,72558096),(32,25,88286736),(48,27,88286736)]),([(3,69604656),(12,68564226),(37,21189216),(38,50603361),(41,69292131),(42,37769571),(49,20209746),(50,3297636),(52,50418276),(56,33842001)],[(21,79,88086066),(22,80,86050356),(25,72,88277286),(26,79,88286721)])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_7_8 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 6 12 [32154,14810,15834,28122] [2096192,2079936,2088128,2094272,1047744,2096320,2072000,2076096,1031616,1555904,2080192,1039808,1826240,1957312,2088384,1043904,2026944,2092480,2096576,507840,1032128,1818560,2080704,2097088,2079880,2092168,1047688,2096264,2071752,2075848,2078920,2084040,2086088,1948872,2047176,1563848,1957064,2022600,1043656,1961160,2092232,2076040,2090376,1043848,1961352,2026888,2090568,1031752,1556040,1818184,1949256,2080328,1044040,1961544,2027080,2092616,1048136,2096712,2026952,1810120,2006728,2039496,1945288,1816264,1961672,912600,1961176,2070872,2013528,915800,765400,1961688,991064,2074962,1027410,1551698,2075986,962002,1682898,898514,1914322,2029418] t = true := by
  refine ⟨[([(3,69604656),(6,50734401),(12,68564226),(17,51791136),(24,33965331),(37,20205666),(41,69292131),(42,37769571),(50,3297636),(52,50418276)],[(5,68,86049891),(9,68,87294306),(10,68,87167076),(18,68,88085091),(20,68,88285536),(33,30,84162081),(34,30,85079616),(36,30,86197761),(40,30,87295506),(48,30,88286736)]),([(7,87121956),(11,39064416),(13,21311586),(14,4350261),(19,86185056),(22,50668641),(25,86065251),(26,38814051),(28,22241856),(35,37773651),(37,21189216),(38,3417441),(41,68309856),(44,68171106),(49,20275266),(50,3297636),(52,50418276),(56,33842001)],[(21,77,70391376),(42,77,88286721)]),([(3,69604656),(4,103028016),(8,103895076),(48,20336676)],[(17,61,4535841),(18,69,88147491),(33,34,83961396),(34,61,84944436)]),([(3,38147376),(4,102842451),(24,33965331),(41,69292131),(42,37769571),(49,51529056),(50,33772641)],[(9,63,3413541),(10,78,87319056),(17,49,67188261),(18,63,68171301),(33,35,5318196),(34,59,84944436),(40,59,87303696),(48,35,72558096)])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_7_9 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 6 12 [32218,32730,15850,24042] [2096192,2079936,2088128,2094272,1047744,2096320,2072000,2076096,1031616,1555904,2080192,1039808,1826240,1957312,2088384,1043904,2026944,2092480,2096576,507840,1032128,1818560,2080704,2097088,2079880,2092168,1047688,2096264,2071752,2075848,2078920,2084040,2086088,1948872,2047176,1563848,1957064,2022600,1043656,1961160,2092232,2076040,2090376,1043848,1961352,2026888,2090568,1031752,1556040,1818184,1949256,2080328,1044040,1961544,2027080,2092616,1048136,2096712,2026952,1810120,2006728,2039496,1945288,1816264,1961672,912600,1961176,2070872,2013528,915800,765400,1961688,991064,2074962,1027410,1551698,2075986,962002,1682898,898514,1914322,2029418] t = true := by
  refine ⟨[([(2,101930016),(4,102842451),(8,103895076),(17,51791136),(33,51794976),(48,20336676)],[(1,33,83961396),(16,33,88286736),(32,29,88286736)]),([(1,100815636),(2,101864256),(4,102846531),(8,103895076),(48,20336676)],[(0,39,88286736),(16,40,72558096),(32,40,88286736)]),([(2,101983536),(5,68560176),(8,103895076),(33,21385776),(36,21385266)],[(17,60,4535826),(20,60,38090256),(48,47,88286736)]),([(2,101917776),(8,103895076),(21,85140576),(37,68363616),(49,52514916),(52,50418276)],[(5,48,33642036),(17,37,67245621),(20,37,69211701),(33,37,84022836),(36,37,85988916),(48,48,88286736)])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_7_10 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 6 12 [32234,16234,30570,32618] [2096192,2079936,2088128,2094272,1047744,2096320,2072000,2076096,1031616,1555904,2080192,1039808,1826240,1957312,2088384,1043904,2026944,2092480,2096576,507840,1032128,1818560,2080704,2097088,2079880,2092168,1047688,2096264,2071752,2075848,2078920,2084040,2086088,1948872,2047176,1563848,1957064,2022600,1043656,1961160,2092232,2076040,2090376,1043848,1961352,2026888,2090568,1031752,1556040,1818184,1949256,2080328,1044040,1961544,2027080,2092616,1048136,2096712,2026952,1810120,2006728,2039496,1945288,1816264,1961672,912600,1961176,2070872,2013528,915800,765400,1961688,991064,2074962,1027410,1551698,2075986,962002,1682898,898514,1914322,2029418] t = true := by
  refine ⟨[([(2,101930016),(8,103895076),(5,68560176),(33,21385776),(36,21385266)],[(1,36,84022836),(4,36,85988916),(16,50,88286736),(32,31,85988916),(17,58,84160866),(20,58,86258016),(48,51,88286736)]),([(5,22422336),(9,22426176),(12,22425666),(17,22430256),(20,22429746),(24,22429731),(2,101987616)],[(33,50,5517666),(36,50,39072096),(40,50,55845216),(48,52,88285536)]),([(3,23412786),(6,23413296),(10,23413536),(18,23409696),(34,23344416)],[(5,53,33898851),(9,53,50676066),(12,53,52773216),(17,53,67449186),(20,53,69546336),(24,53,70590816),(33,53,84160866),(36,53,86258016),(40,53,87302496),(48,53,88285536),(13,64,52449636),(21,64,69226851),(25,64,70275426),(28,64,70406496),(37,64,85999971),(41,64,87048546),(44,64,87179616),(49,64,88093026),(52,64,88224096),(56,64,88285536),(29,71,70386021),(45,71,87163236),(53,71,88211811),(57,71,88277346),(60,71,88285536),(61,81,106181136)]),([(2,101987616),(5,22422336),(9,22426176),(12,22425666),(17,22430256),(20,22429746),(24,22429731)],[(1,54,84160866),(4,54,86258016),(8,54,87302496),(16,54,88285536),(32,46,88286736),(33,55,84160866),(36,55,86258016),(40,55,87302496),(48,55,88285536)])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_7_11 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 6 12 [32746,32762,15838,24030] [2096192,2079936,2088128,2094272,1047744,2096320,2072000,2076096,1031616,1555904,2080192,1039808,1826240,1957312,2088384,1043904,2026944,2092480,2096576,507840,1032128,1818560,2080704,2097088,2079880,2092168,1047688,2096264,2071752,2075848,2078920,2084040,2086088,1948872,2047176,1563848,1957064,2022600,1043656,1961160,2092232,2076040,2090376,1043848,1961352,2026888,2090568,1031752,1556040,1818184,1949256,2080328,1044040,1961544,2027080,2092616,1048136,2096712,2026952,1810120,2006728,2039496,1945288,1816264,1961672,912600,1961176,2070872,2013528,915800,765400,1961688,991064,2074962,1027410,1551698,2075986,962002,1682898,898514,1914322,2029418] t = true := by
  refine ⟨[([(1,100749876),(2,102052896),(4,102846516),(8,103895076)],[(0,53,88286736),(16,55,72558096),(32,55,88286736),(48,57,88286736)]),([(1,100749891),(2,102056736),(4,102846531),(8,103895076),(16,104943651),(32,105988131)],[(0,64,88286736)]),([(4,103028016),(8,103895076),(16,104935506),(32,106107456),(3,55972416)],[(1,38,1394226),(2,38,17122866)]),([(4,102962256),(8,103895106),(16,105058896),(32,106107456)],[(1,52,1394226),(2,52,17122866),(3,56,17122866)])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_7_12 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 6 12 [30174,32222,16350,32734] [2096192,2079936,2088128,2094272,1047744,2096320,2072000,2076096,1031616,1555904,2080192,1039808,1826240,1957312,2088384,1043904,2026944,2092480,2096576,507840,1032128,1818560,2080704,2097088,2079880,2092168,1047688,2096264,2071752,2075848,2078920,2084040,2086088,1948872,2047176,1563848,1957064,2022600,1043656,1961160,2092232,2076040,2090376,1043848,1961352,2026888,2090568,1031752,1556040,1818184,1949256,2080328,1044040,1961544,2027080,2092616,1048136,2096712,2026952,1810120,2006728,2039496,1945288,1816264,1961672,912600,1961176,2070872,2013528,915800,765400,1961688,991064,2074962,1027410,1551698,2075986,962002,1682898,898514,1914322,2029418] t = true := by
  refine ⟨[([(1,100880961),(2,101929536),(4,102842451),(8,103891026),(16,104935506),(32,106107456)],[]),([(1,100880961),(2,101929536),(4,102842451),(8,103895106),(16,104935506),(32,106107456)],[(0,62,84952626)]),([(1,100880916),(2,101929476),(4,102846516),(8,103895076),(16,104935506),(32,105984066)],[(0,65,88286736)]),([(1,100880961),(2,101929536),(4,102846531),(8,103895106),(16,104935506),(32,105984066)],[(0,66,88286736)])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_7_13 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 6 12 [32766,32767] [2096192,2079936,2088128,2094272,1047744,2096320,2072000,2076096,1031616,1555904,2080192,1039808,1826240,1957312,2088384,1043904,2026944,2092480,2096576,507840,1032128,1818560,2080704,2097088,2079880,2092168,1047688,2096264,2071752,2075848,2078920,2084040,2086088,1948872,2047176,1563848,1957064,2022600,1043656,1961160,2092232,2076040,2090376,1043848,1961352,2026888,2090568,1031752,1556040,1818184,1949256,2080328,1044040,1961544,2027080,2092616,1048136,2096712,2026952,1810120,2006728,2039496,1945288,1816264,1961672,912600,1961176,2070872,2013528,915800,765400,1961688,991064,2074962,1027410,1551698,2075986,962002,1682898,898514,1914322,2029418] t = true := by
  refine ⟨[([(1,100946481),(2,101995056),(4,102846531),(8,103895106),(16,104943666),(32,105988146)],[(0,71,88286736)]),([(1,101007666),(2,102055986),(4,103104561),(8,104153121),(16,105197601),(32,106180641)],[(0,81,88285536)])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_8_0 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 7 16 [2096192,2079936,2088128,2094272] [268409856,267369472,267893760,268155904,268418048,133168128,233831424,267385856,268434432,268420160,31965120,268406920,247125330,97430994,97367506] t = true := by
  refine ⟨[([(5,40984645),(3,24272965),(20,40985605),(6,67577185),(9,57761861),(18,24273925),(10,67581281),(12,67581282),(24,57762821)],[(113,9,1702113808)]),([(9,57757796),(49,39932020),(10,57692516),(67,38891620),(4,119805280),(50,39866740),(24,58004576)],[]),([(9,57761876),(35,39940180),(10,57696596),(67,38891620),(4,119936320),(49,39932020),(50,39866740),(24,58070096)],[]),([(5,40984660),(9,57761876),(2,118645765),(24,57828357),(12,67581282),(81,38887540),(20,41116677)],[])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_8_1 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 7 16 [1047744,2096320,2072000,2076096] [268409856,267369472,267893760,268155904,268418048,133168128,233831424,267385856,268434432,268420160,31965120,268406920,247125330,97430994,97367506] t = true := by
  refine ⟨[([(3,24272965),(49,39932020),(50,39866740),(81,38887540),(82,38822260),(9,57761861),(10,57696581),(4,119936320),(24,58070096)],[]),([(3,24272965),(4,119936320),(49,39932020),(50,39866740),(81,38887540),(82,38822260),(97,21127285),(98,4350325),(8,120984896)],[(112,0,1698899728)]),([(5,40980580),(9,57757796),(6,40915300),(3,24268900),(10,57692516),(12,57692772),(49,39932020),(50,39866740),(52,23089780),(24,58004576)],[]),([(9,57757796),(49,39932020),(10,57692516),(4,119870560),(67,55668836),(50,39866740),(24,58004576)],[])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_8_2 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 7 16 [1031616,1555904,2080192,1039808] [268409856,267369472,267893760,268155904,268418048,133168128,233831424,267385856,268434432,268420160,31965120,268406920,247125330,97430994,97367506] t = true := by
  refine ⟨[([(4,119870560),(3,86447200),(49,39932020),(50,39866740),(81,38887540),(82,38822260),(97,21127285),(98,4350325),(24,58004576)],[]),([(4,119805280),(19,103093360),(35,37843030),(49,39932020),(50,39866740),(67,37843045),(81,38887540),(82,38822260),(8,120853856)],[]),([(5,40980580),(6,40915300),(3,24268900),(49,39932020),(50,39866740),(52,23089780),(81,38887540),(82,38822260),(84,22045300),(97,21127285),(98,4350325),(100,4285045),(8,120853856)],[(112,1,1698918928)]),([(5,40984645),(9,57761861),(6,40919365),(35,39940180),(50,39866740),(52,23089780),(67,38891620),(82,38822260),(84,22045300),(10,57696581),(12,57696837),(49,39932020),(24,58070096)],[])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_8_3 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 7 16 [1826240,1957312,2088384,1043904] [268409856,267369472,267893760,268155904,268418048,133168128,233831424,267385856,268434432,268420160,31965120,268406920,247125330,97430994,97367506] t = true := by
  refine ⟨[([(5,40984660),(9,57761876),(6,40919380),(3,24272980),(10,57696596),(12,57696852),(49,39932020),(50,39866740),(52,23089780),(24,58070096)],[]),([(9,57761876),(10,57696596),(4,119936080),(3,24268900),(49,56709236),(50,56643956),(24,58070096)],[]),([(5,40984660),(9,57761876),(6,40919380),(3,24272980),(10,57696596),(12,57696852),(49,39932020),(50,39866740),(52,23089780),(24,58070096),(81,38887540),(82,38822260),(84,22045300),(97,37838965),(98,37773685),(100,20996725),(40,58070336)],[(112,2,1698918928)]),([(9,57761861),(35,39940180),(50,39866740),(4,119936080),(67,55668836),(82,55599476),(10,57696581),(49,39932020),(24,58070096)],[])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_8_4 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 7 16 [2026944,2092480,2096576,507840] [268409856,267369472,267893760,268155904,268418048,133168128,233831424,267385856,268434432,268420160,31965120,268406920,247125330,97430994,97367506] t = true := by
  refine ⟨[([(2,118711301),(4,119759877),(49,39932020),(8,120743172)],[]),([(3,24272980),(4,119936080),(49,39932020),(50,39866740),(81,55664756),(82,55599476),(97,37838965),(98,37773685),(8,120984896)],[(112,3,1698899728)]),([(1,117843025),(2,118891600),(4,119936080),(8,120984896)],[(48,3,1447260688),(80,3,1698918928),(96,0,1699164688),(112,4,1698918928)]),([(19,103093360),(21,102048880),(22,101000305),(35,103028080),(37,101983600),(38,100935025),(49,39932020),(50,39866740),(52,23089780),(67,86251120),(69,85206640),(70,84158065),(81,38887540),(82,38822260),(84,22045300),(97,37838965),(98,37773685),(100,20996725),(56,23090036)],[(15,10,1985229328)])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_8_5 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 7 16 [1032128,1818560,2080704,2097088] [268409856,267369472,267893760,268155904,268418048,133168128,233831424,267385856,268434432,268420160,31965120,268406920,247125330,97430994,97367506] t = true := by
  refine ⟨[([(4,119870560),(8,120919136),(2,118826080),(49,39932020),(81,38887540),(97,37838965)],[(112,5,1699164688)]),([(3,24268900),(5,40980580),(6,40915300),(49,23220340),(50,6443380),(52,6378100),(8,120919136),(81,38887540),(82,38822260),(84,22045300),(97,37838965),(98,37773685),(100,20996725)],[(112,6,1698918928)]),([(1,117777505),(2,118826080),(4,119870560),(8,120919136)],[(48,6,1699164688),(80,1,1683436048),(96,1,1699164688),(112,7,1699164688)]),([(1,117843025),(2,118891600),(4,119936080),(8,120984656)],[(16,2,1180119568),(32,2,1447506448),(64,2,1699164688),(48,4,1416049168),(80,4,1683436048),(96,4,1699164688),(112,8,1699164688)])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_8_6 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 7 16 [2079880,2092168,1047688,2096264] [268409856,267369472,267893760,268155904,268418048,133168128,233831424,267385856,268434432,268420160,31965120,268406920,247125330,97430994,97367506] t = true := by
  refine ⟨[([(5,40984629),(17,74539061),(3,24272949),(12,40985349),(6,50799969),(65,68642096),(10,24273669),(112,50623841)],[]),([(5,40984629),(17,74539061),(6,40919365),(3,24404021),(10,57696581),(12,40985349),(65,68642096),(66,50816321),(20,40920085),(24,74539781)],[]),([(3,24272949),(5,40984629),(6,40919365),(17,74539061),(10,57696581),(12,40985349),(104,68580656),(112,50754881)],[]),([(3,24272949),(5,40984629),(6,40919365),(17,74539061),(10,57696581),(12,40985349),(9,68629856),(18,50808161),(20,40920085),(24,74539781),(65,68642096),(66,50816321),(104,68580656),(112,50754881)],[(100,11,1702113808)])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_8_7 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 7 16 [2071752,2075848,2078920,2084040] [268409856,267369472,267893760,268155904,268418048,133168128,233831424,267385856,268434432,268420160,31965120,268406920,247125330,97430994,97367506] t = true := by
  refine ⟨[([(8,120672356),(5,40980580),(49,103895156),(6,40915300),(67,38891620),(50,39866740),(20,41227360)],[]),([(8,120672356),(5,40980580),(16,121724981),(96,21454901)],[]),([(13,21131318),(19,87126086),(22,55734598),(38,4354390),(41,21327926),(21,87191622),(26,39022918),(44,67269462),(67,87126116),(70,4354405),(73,21323891),(88,22311776),(97,21327971),(74,4419941),(82,38822260),(112,50689121)],[]),([(8,120676436),(5,40984660),(35,103903316),(6,40919380),(19,103903301),(49,103895156),(50,39866740),(20,41116752)],[])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_8_8 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 7 16 [2086088,1948872,2047176,1563848] [268409856,267369472,267893760,268155904,268418048,133168128,233831424,267385856,268434432,268420160,31965120,268406920,247125330,97430994,97367506] t = true := by
  refine ⟨[([(8,120676436),(5,40984660),(2,118711376),(81,38887540),(20,41116752)],[]),([(8,120672356),(5,40980580),(16,121724981),(96,21454901)],[]),([(6,40915300),(25,22429811),(41,21385331),(49,103895156),(10,57692516),(12,41182032),(67,38826340),(81,85156976),(97,21393491),(50,39866740),(112,50689121)],[]),([(8,120676436),(5,40984660),(35,103903316),(6,40919380),(81,38887540),(50,39866740),(20,41292880)],[])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_8_9 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 7 16 [1957064,2022600,1043656,1961160] [268409856,267369472,267893760,268155904,268418048,133168128,233831424,267385856,268434432,268420160,31965120,268406920,247125330,97430994,97367506] t = true := by
  refine ⟨[([(8,120676436),(5,40984660),(35,103903316),(6,40919380),(67,38891620),(49,103895156),(50,56643956),(20,41116752)],[]),([(8,120672356),(5,40980580),(2,118711376),(49,103895156),(20,41116752)],[]),([(3,24526931),(5,41304147),(8,120676421),(16,121724981),(96,21454901)],[]),([(3,24526931),(5,41304147),(40,21450851),(16,121724981),(72,21454931),(96,21454901)],[])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_8_10 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 7 16 [2092232,2076040,2090376,1043848] [268409856,267369472,267893760,268155904,268418048,133168128,233831424,267385856,268434432,268420160,31965120,268406920,247125330,97430994,97367506] t = true := by
  refine ⟨[([(3,24526931),(5,41304147),(8,120676436),(16,121724981),(6,40919380),(96,21454901)],[]),([(5,40984629),(17,74539061),(22,5402950),(11,39940149),(42,37974358),(12,40985349),(82,5398900),(70,5402980),(65,68642096),(112,50623841)],[]),([(3,24404021),(5,41181237),(10,24404741),(6,5710945),(25,23359541),(12,41181957),(65,21456176),(98,50427236),(100,50492772),(104,21394736)],[]),([(17,74539061),(3,24404021),(10,57696581),(104,68580656),(82,5398900),(4,119563285)],[])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_8_11 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 7 16 [1961352,2026888,2090568,1031752] [268409856,267369472,267893760,268155904,268418048,133168128,233831424,267385856,268434432,268420160,31965120,268406920,247125330,97430994,97367506] t = true := by
  refine ⟨[([(17,74539061),(3,24404021),(10,57696581),(65,68642096),(98,37773685),(4,119563285),(24,74539781)],[]),([(3,24404021),(5,41181237),(10,24404741),(38,50492692),(25,40136757),(12,41181957),(66,50816321),(65,68642096),(100,50492772),(104,68580656)],[]),([(3,24531011),(5,41308227),(24,23543891),(40,23547971),(48,23547956),(10,24531776),(18,24532016),(34,24528176)],[]),([(5,40984629),(24,22495331),(3,24272949),(12,40985349),(48,23547956),(80,22503476),(38,50734449),(72,22503491)],[])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_8_12 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 7 16 [1556040,1818184,1949256,2080328] [268409856,267369472,267893760,268155904,268418048,133168128,233831424,267385856,268434432,268420160,31965120,268406920,247125330,97430994,97367506] t = true := by
  refine ⟨[([(5,40984629),(16,121724981),(12,40985349),(2,118764896),(97,70344821)],[]),([(3,24469571),(5,41246787),(10,24531716),(48,23547956),(18,24470531),(72,22503491),(6,50799969)],[]),([(5,41246787),(24,22495331),(48,23547956),(80,22503476),(2,118777136),(72,22503491)],[]),([(16,121724981),(2,118777136),(41,101987696),(72,22503491),(97,70344821),(4,119825712)],[])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_8_13 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 7 16 [1044040,1961544,2027080,2092616] [268409856,267369472,267893760,268155904,268418048,133168128,233831424,267385856,268434432,268420160,31965120,268406920,247125330,97430994,97367506] t = true := by
  refine ⟨[([(5,41304147),(24,23543891),(40,23547971),(48,23547956),(72,22503491),(80,22503476),(2,118900016)],[]),([(5,41308227),(24,23543891),(40,23547971),(48,23547956),(72,22503491),(80,22503476),(2,118900016)],[]),([(5,41308227),(24,40321107),(40,40325187),(48,40325172),(72,22503491),(80,22503476),(2,118900016)],[]),([(5,41308227),(8,120676421),(16,121724981),(2,118900016),(97,70344821),(36,41305392)],[])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_8_14 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 7 16 [1048136,2096712,2026952,1810120] [268409856,267369472,267893760,268155904,268418048,133168128,233831424,267385856,268434432,268420160,31965120,268406920,247125330,97430994,97367506] t = true := by
  refine ⟨[([(8,120676421),(16,121724981),(2,118900016),(97,70344821),(4,119948592)],[]),([(2,118900016),(8,120676421),(16,121724981),(33,23548736),(4,119948592),(65,22504256)],[(96,9,1698918928)]),([(8,120741972),(2,118711376),(49,103895156),(4,119759952),(81,87187572),(96,21454901)],[]),([(5,40980580),(8,120672356),(49,39932020),(6,40915300),(67,38891620),(50,39866740),(20,41227360)],[])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_8_15 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 7 16 [2006728,2039496,1945288,1816264] [268409856,267369472,267893760,268155904,268418048,133168128,233831424,267385856,268434432,268420160,31965120,268406920,247125330,97430994,97367506] t = true := by
  refine ⟨[([(5,40980580),(24,22495331),(40,21450851),(49,103895156),(2,118842416),(80,22503476)],[]),([(6,40915300),(25,22429811),(41,21385331),(49,103895156),(10,57692516),(12,41247552),(65,85419056),(50,39866740),(20,41247792),(56,23425856)],[]),([(3,24469571),(5,41246787),(24,22495331),(40,21450851),(48,23547956),(64,123818036)],[]),([(5,41246787),(48,23547956),(2,118842371),(72,39280707)],[])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_8_16 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 7 16 [1961672,912600,1961176,2070872] [268409856,267369472,267893760,268155904,268418048,133168128,233831424,267385856,268434432,268420160,31965120,268406920,247125330,97430994,97367506] t = true := by
  refine ⟨[([(3,24531011),(5,41308227),(8,120676436),(16,121724981),(32,122773556),(64,123818036)],[]),([(5,40976467),(24,23543891),(3,24526931),(32,122765411),(64,123813971)],[]),([(5,40976467),(3,24526931),(8,120676436),(16,121725011),(32,122765411),(64,123813971)],[]),([(11,37842998),(21,20082758),(26,39088438),(38,3305814),(41,38105142),(49,20279366),(28,22245958),(67,37843043),(73,37838963),(74,38822259),(70,3305829),(69,20082788),(100,4285045),(98,3301749),(88,85226336)],[])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_8_17 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 7 16 [2013528,915800,765400,1961688] [268409856,267369472,267893760,268155904,268418048,133168128,233831424,267385856,268434432,268420160,31965120,268406920,247125330,97430994,97367506] t = true := by
  refine ⟨[([(14,67269397),(21,20082758),(35,69235987),(41,38105142),(52,50689062),(24,86459907),(73,38101107),(84,22045300),(97,38105187),(66,67593041),(76,4420197)],[]),([(3,24461411),(5,41238627),(6,41181493),(25,23412851),(26,6582581),(12,41181973),(74,38822259),(96,67592981)],[]),([(11,37842997),(19,87126086),(25,39927923),(26,39862643),(35,37843027),(41,37834867),(42,37769587),(49,39932020),(50,39866740),(67,87126116),(4,119739488),(72,108270416)],[]),([(3,24531011),(5,40980547),(6,40915267),(8,120676436),(16,121725011),(32,122773571),(64,123818051)],[])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_8_18 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 7 16 [991064,2074962,1027410,1551698] [268409856,267369472,267893760,268155904,268418048,133168128,233831424,267385856,268434432,268420160,31965120,268406920,247125330,97430994,97367506] t = true := by
  refine ⟨[([(13,22179892),(19,38891587),(14,5402934),(35,69408112),(49,20074612),(52,23089780),(42,39866739),(67,38826339),(81,22442051),(82,5534051),(76,5468772),(69,22049380),(98,3301749),(41,37834867),(56,102069056)],[]),([(5,51848768),(17,51856928),(10,34027089),(34,34035249),(20,51856898),(104,33912369)],[]),([(20,22495330),(11,39874869),(13,22245414),(6,40919349),(25,22245446),(18,74473781),(97,69296245),(104,33977649)],[]),([(18,74473781),(35,69300310),(6,40919349),(52,23425600),(41,69431382),(80,22503460),(97,69296245),(66,34039089),(12,40919829)],[])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_8_19 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 7 16 [2075986,962002,1682898,898514] [268409856,267369472,267893760,268155904,268418048,133168128,233831424,267385856,268434432,268420160,31965120,268406920,247125330,97430994,97367506] t = true := by
  refine ⟨[([(6,40919349),(20,22495330),(18,74473781),(35,69300310),(37,51541254),(41,69431382),(10,34026849),(12,58024512),(49,51672326),(24,74474261),(68,22503490),(73,69431397),(97,69296245),(66,34039089),(104,33977649),(80,22503460)],[]),([(7,55668772),(25,22245446),(20,22495330),(11,37777717),(13,21196838),(49,102846580),(26,5652851),(68,22503490),(67,55668836),(97,69427317),(98,4616531),(80,22503460)],[(46,13,1985229328)]),([(4,119623780),(19,55668806),(8,120607076),(67,55668836),(81,55664756),(82,87056756)],[]),([(7,55668772),(19,86077510),(13,21196837),(26,5534486),(11,37777718),(48,23547940),(68,56057922),(81,86073460),(67,86077540),(97,69427317),(98,4551011)],[(46,14,1985229328)])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_8_20 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 7 16 [1914322,2029418] [268409856,267369472,267893760,268155904,268418048,133168128,233831424,267385856,268434432,268420160,31965120,268406920,247125330,97430994,97367506] t = true := by
  refine ⟨[([(3,24530980),(9,58085412),(6,24531460),(52,51737632),(42,4550966),(69,55996452),(74,4546931),(12,58085892),(81,51733616),(98,4551011),(88,5534561)],[]),([(1,117854787),(4,119951427),(8,121000002),(16,122048562),(32,123093042),(64,124076082)],[(2,12,1698918928)])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_9_0 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 8 20 [268409856,267369472,267893760,268155904] [68718395392,68585226240,68719443968,8387558400] t = true := by
  refine ⟨[([(5,42037349),(6,41972069),(17,75591781),(3,25325669),(18,75526501),(20,75526757),(8,137827920),(97,40984709),(98,40919429),(100,24142469),(48,75961696)],[]),([(5,42033269),(9,58810485),(6,41967989),(3,25321589),(10,58745205),(12,58745461),(17,75587701),(18,75522421),(20,75522677),(24,75522933),(97,40984709),(98,40919429),(100,24142469),(104,24142725),(48,75896176)],[]),([(5,42037349),(9,58814565),(6,41972069),(3,25325669),(10,58749285),(12,58749541),(17,75591781),(18,75526501),(20,75526757),(24,75527013),(97,40984709),(98,40919429),(100,24142469),(104,24142725),(48,75961696)],[]),([(5,42037349),(6,41972069),(3,25325669),(17,75591781),(18,75526501),(20,75526757),(8,137827680),(97,40984709),(98,40919429),(100,24142469),(48,75961696)],[])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_9_1 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 8 20 [268418048,133168128,233831424,267385856] [68718395392,68585226240,68719443968,8387558400] t = true := by
  refine ⟨[([(3,25325669),(5,42037349),(6,41972069),(9,58814565),(10,58749285),(12,58749541),(97,40984709),(98,40919429),(100,24142469),(104,24142725),(161,39940229),(162,39874949),(164,23097989),(168,23098245),(193,22179974),(194,5403014),(196,5337734),(200,5337990),(16,138876496)],[(224,0,31764001296)]),([(4,136713584),(8,137762160),(35,39944279),(16,138810736),(131,39944309),(97,40984709),(98,40919429)],[]),([(3,25321589),(5,42033269),(6,41967989),(9,58810485),(10,58745205),(12,58745461),(97,24273029),(98,7496069),(100,7430789),(104,7431045),(16,138810736)],[]),([(3,25321589),(5,42033269),(6,41967989),(9,58810485),(10,58745205),(12,58745461),(17,75587701),(18,75522421),(20,75522677),(24,75522933),(97,40984709),(98,40919429),(100,24142469),(104,24142725),(112,24142981),(161,39940229),(162,39874949),(164,23097989),(168,23098245),(176,23098501),(193,38891654),(194,38826374),(196,22049414),(200,22049670),(208,22049926)],[(224,1,31767933456)])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_9_2 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 8 20 [268434432,268420160,31965120,268406920] [68718395392,68585226240,68719443968,8387558400] t = true := by
  refine ⟨[([(1,134686049),(2,135734624),(4,136779104),(8,137827680),(16,138876256)],[(96,0,27238085136),(160,0,31516275216),(192,0,31767933456),(224,2,31767933456)]),([(16,138506326),(32,139554886),(2,135747136),(9,59203668),(4,136795712)],[]),([(19,103093376),(21,102048896),(22,101000321),(35,103028096),(37,101983616),(38,100935041),(49,39932036),(50,39866756),(52,23089796),(67,86251136),(69,85206656),(70,84158081),(81,38887556),(82,38822276),(84,22045316),(97,37838981),(98,37773701),(100,20996741),(56,23090052),(131,86251392),(133,85206912),(134,84158337),(145,38891652),(146,38826372),(148,22049412),(161,37843077),(162,37777797),(164,21000837),(193,37843078),(194,37777798),(196,21000838),(88,22045572),(104,20996997)],[(15,3,13439104596),(240,3,31764001296)]),([(3,25325622),(5,42037302),(6,41972038),(17,75591734),(10,58749254),(12,58749526),(33,92368950),(34,92303686),(20,75526742),(24,75592454),(129,68711984),(130,50886209),(132,50886226),(40,92369670),(48,92304406)],[])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
private theorem nine_rows_9_3 :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  ∃ t : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)), unitOK 8 20 [247125330,97430994,97367506] [68718395392,68585226240,68719443968,8387558400] t = true := by
  refine ⟨[([(3,25579586),(9,59134018),(20,124272722),(32,139944002),(64,140988482),(128,141971522)],[]),([(7,55672868),(25,119767110),(20,22560866),(40,4739443),(49,102846596),(67,119636068),(68,22569026),(80,22568996),(136,4747603),(145,22511682),(162,4686163),(37,21450882),(193,21463138)],[]),([(7,55672868),(19,86081606),(13,21200933),(24,41435491),(11,37781814),(14,4358455),(48,23613476),(68,56123458),(67,86081636),(97,69427333),(98,4555107),(145,56066114),(146,87191940),(161,21463122),(162,4555123),(140,67338869),(192,4747574)],[])], ?_⟩
  decide +kernel

set_option maxRecDepth 32000 in
set_option maxHeartbeats 6000000 in
theorem numerical_stages :
  let edge (g i j : ℕ) : Bool :=
    decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

  let digit (p i : ℕ) := (p >>> (4*i)) % 16

  let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

  let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
    (List.range m).all fun j =>
      decide (digit p j < n) && (List.range j).all (fun i =>
        decide (digit p i ≠ digit p j) &&
        (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
         else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


  let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
    tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
        checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
    (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
        tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
        tab.2.any (fun (v,_,_) => decide (v=s)))

  let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
    decide (src.length=tabs.length) &&
      ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
  let Stage (n q : ℕ) (A B : List ℕ) :=
    (∀ a∈A, a<2^n.choose 2) ∧ ∃ ts, unitOK n q A B ts=true
  ∃ A2 A3 A4 A5 A6 A7 A8 : List ℕ,
    Stage 1 1 [0] A2 ∧
    Stage 2 2 A2 A3 ∧
    Stage 3 4 A3 A4 ∧
    Stage 4 6 A4 A5 ∧
    Stage 5 9 A5 A6 ∧
    Stage 6 12 A6 A7 ∧
    Stage 7 16 A7 A8 ∧
    Stage 8 20 A8 [68718395392,68585226240,68719443968,8387558400] := by
  intro edge digit extend checkMap parentOK unitOK Stage
  have merge {n q : ℕ} {l r b : List ℕ}
      (lh : ∃ t, unitOK n q l b t = true) (rh : ∃ u, unitOK n q r b u = true) :
      ∃ v, unitOK n q (l++r) b v = true := by
    obtain ⟨t,hl⟩ := lh
    obtain ⟨u,hr⟩ := rh
    refine ⟨t++u,?_⟩
    simp only [unitOK,Bool.and_eq_true,decide_eq_true_eq] at hl hr ⊢
    rw [List.zip_append hl.1,List.all_append,Bool.and_eq_true]
    exact ⟨by simp [hl.1,hr.1],hl.2,hr.2⟩
  have bounded (n : ℕ) (A : List ℕ) (h : A.all (fun a => decide (a < 2 ^ n.choose 2)) = true) :
      ∀ a ∈ A, a < 2 ^ n.choose 2 := fun a ha => of_decide_eq_true (List.all_eq_true.mp h a ha)
  let A1 : List ℕ := [0]
  let A2 : List ℕ := [1]
  let A3 : List ℕ := [6,7]
  let A4 : List ℕ := [58,30,62,63]
  let A5 : List ℕ := [984,504,1016,978,474,986,490,874,1002,1018,478,990,1022,1023]
  let A6 : List ℕ := [32704,32200,32456,16328,32712,31960,32088,15832,24024,32216,16088,28376,30424,32472,16216,31576,32600,32728,7672,15864,28152,32248,32760,32082,15826,24018,28114,30162,32210,16338,32722,15770,32154,14810,15834,28122,32218,32730,15850,24042,32234,16234,30570,32618,32746,32762,15838,24030,30174,32222,16350,32734,32766,32767]
  let A7 : List ℕ := [2096192,2079936,2088128,2094272,1047744,2096320,2072000,2076096,1031616,1555904,2080192,1039808,1826240,1957312,2088384,1043904,2026944,2092480,2096576,507840,1032128,1818560,2080704,2097088,2079880,2092168,1047688,2096264,2071752,2075848,2078920,2084040,2086088,1948872,2047176,1563848,1957064,2022600,1043656,1961160,2092232,2076040,2090376,1043848,1961352,2026888,2090568,1031752,1556040,1818184,1949256,2080328,1044040,1961544,2027080,2092616,1048136,2096712,2026952,1810120,2006728,2039496,1945288,1816264,1961672,912600,1961176,2070872,2013528,915800,765400,1961688,991064,2074962,1027410,1551698,2075986,962002,1682898,898514,1914322,2029418]
  let A8 : List ℕ := [268409856,267369472,267893760,268155904,268418048,133168128,233831424,267385856,268434432,268420160,31965120,268406920,247125330,97430994,97367506]
  let A9 : List ℕ := [68718395392,68585226240,68719443968,8387558400]
  refine ⟨A2, A3, A4, A5, A6, A7, A8, ?_ , ?_ , ?_ , ?_ , ?_ , ?_ , ?_ , ?_ ⟩
  · refine ⟨bounded 1 A1 (by decide), ?_⟩
    exact nine_rows_2_0
  · refine ⟨bounded 2 A2 (by decide), ?_⟩
    exact nine_rows_3_0
  · refine ⟨bounded 3 A3 (by decide), ?_⟩
    exact nine_rows_4_0
  · refine ⟨bounded 4 A4 (by decide), ?_⟩
    exact nine_rows_5_0
  · refine ⟨bounded 5 A5 (by decide), ?_⟩
    exact (merge (n := 5) (q := 9) (l := [984,504,1016,978,474,986,490,874]) (r := [1002,1018,478,990,1022,1023]) (b := A6) nine_rows_6_0 nine_rows_6_1)
  · refine ⟨bounded 6 A6 (by decide), ?_⟩
    exact (merge (n := 6) (q := 12) (l := [32704,32200,32456,16328,32712,31960,32088,15832,24024,32216,16088,28376,30424,32472,16216,31576,32600,32728,7672,15864,28152,32248,32760,32082,15826,24018,28114,30162]) (r := [32210,16338,32722,15770,32154,14810,15834,28122,32218,32730,15850,24042,32234,16234,30570,32618,32746,32762,15838,24030,30174,32222,16350,32734,32766,32767]) (b := A7) (merge (n := 6) (q := 12) (l := [32704,32200,32456,16328,32712,31960,32088,15832,24024,32216,16088,28376]) (r := [30424,32472,16216,31576,32600,32728,7672,15864,28152,32248,32760,32082,15826,24018,28114,30162]) (b := A7) (merge (n := 6) (q := 12) (l := [32704,32200,32456,16328]) (r := [32712,31960,32088,15832,24024,32216,16088,28376]) (b := A7) nine_rows_7_0 (merge (n := 6) (q := 12) (l := [32712,31960,32088,15832]) (r := [24024,32216,16088,28376]) (b := A7) nine_rows_7_1 nine_rows_7_2)) (merge (n := 6) (q := 12) (l := [30424,32472,16216,31576,32600,32728,7672,15864]) (r := [28152,32248,32760,32082,15826,24018,28114,30162]) (b := A7) (merge (n := 6) (q := 12) (l := [30424,32472,16216,31576]) (r := [32600,32728,7672,15864]) (b := A7) nine_rows_7_3 nine_rows_7_4) (merge (n := 6) (q := 12) (l := [28152,32248,32760,32082]) (r := [15826,24018,28114,30162]) (b := A7) nine_rows_7_5 nine_rows_7_6))) (merge (n := 6) (q := 12) (l := [32210,16338,32722,15770,32154,14810,15834,28122,32218,32730,15850,24042]) (r := [32234,16234,30570,32618,32746,32762,15838,24030,30174,32222,16350,32734,32766,32767]) (b := A7) (merge (n := 6) (q := 12) (l := [32210,16338,32722,15770]) (r := [32154,14810,15834,28122,32218,32730,15850,24042]) (b := A7) nine_rows_7_7 (merge (n := 6) (q := 12) (l := [32154,14810,15834,28122]) (r := [32218,32730,15850,24042]) (b := A7) nine_rows_7_8 nine_rows_7_9)) (merge (n := 6) (q := 12) (l := [32234,16234,30570,32618,32746,32762,15838,24030]) (r := [30174,32222,16350,32734,32766,32767]) (b := A7) (merge (n := 6) (q := 12) (l := [32234,16234,30570,32618]) (r := [32746,32762,15838,24030]) (b := A7) nine_rows_7_10 nine_rows_7_11) (merge (n := 6) (q := 12) (l := [30174,32222,16350,32734]) (r := [32766,32767]) (b := A7) nine_rows_7_12 nine_rows_7_13))))
  · refine ⟨bounded 7 A7 (by decide), ?_⟩
    exact (merge (n := 7) (q := 16) (l := [2096192,2079936,2088128,2094272,1047744,2096320,2072000,2076096,1031616,1555904,2080192,1039808,1826240,1957312,2088384,1043904,2026944,2092480,2096576,507840,1032128,1818560,2080704,2097088,2079880,2092168,1047688,2096264,2071752,2075848,2078920,2084040,2086088,1948872,2047176,1563848,1957064,2022600,1043656,1961160]) (r := [2092232,2076040,2090376,1043848,1961352,2026888,2090568,1031752,1556040,1818184,1949256,2080328,1044040,1961544,2027080,2092616,1048136,2096712,2026952,1810120,2006728,2039496,1945288,1816264,1961672,912600,1961176,2070872,2013528,915800,765400,1961688,991064,2074962,1027410,1551698,2075986,962002,1682898,898514,1914322,2029418]) (b := A8) (merge (n := 7) (q := 16) (l := [2096192,2079936,2088128,2094272,1047744,2096320,2072000,2076096,1031616,1555904,2080192,1039808,1826240,1957312,2088384,1043904,2026944,2092480,2096576,507840]) (r := [1032128,1818560,2080704,2097088,2079880,2092168,1047688,2096264,2071752,2075848,2078920,2084040,2086088,1948872,2047176,1563848,1957064,2022600,1043656,1961160]) (b := A8) (merge (n := 7) (q := 16) (l := [2096192,2079936,2088128,2094272,1047744,2096320,2072000,2076096]) (r := [1031616,1555904,2080192,1039808,1826240,1957312,2088384,1043904,2026944,2092480,2096576,507840]) (b := A8) (merge (n := 7) (q := 16) (l := [2096192,2079936,2088128,2094272]) (r := [1047744,2096320,2072000,2076096]) (b := A8) nine_rows_8_0 nine_rows_8_1) (merge (n := 7) (q := 16) (l := [1031616,1555904,2080192,1039808]) (r := [1826240,1957312,2088384,1043904,2026944,2092480,2096576,507840]) (b := A8) nine_rows_8_2 (merge (n := 7) (q := 16) (l := [1826240,1957312,2088384,1043904]) (r := [2026944,2092480,2096576,507840]) (b := A8) nine_rows_8_3 nine_rows_8_4))) (merge (n := 7) (q := 16) (l := [1032128,1818560,2080704,2097088,2079880,2092168,1047688,2096264]) (r := [2071752,2075848,2078920,2084040,2086088,1948872,2047176,1563848,1957064,2022600,1043656,1961160]) (b := A8) (merge (n := 7) (q := 16) (l := [1032128,1818560,2080704,2097088]) (r := [2079880,2092168,1047688,2096264]) (b := A8) nine_rows_8_5 nine_rows_8_6) (merge (n := 7) (q := 16) (l := [2071752,2075848,2078920,2084040]) (r := [2086088,1948872,2047176,1563848,1957064,2022600,1043656,1961160]) (b := A8) nine_rows_8_7 (merge (n := 7) (q := 16) (l := [2086088,1948872,2047176,1563848]) (r := [1957064,2022600,1043656,1961160]) (b := A8) nine_rows_8_8 nine_rows_8_9)))) (merge (n := 7) (q := 16) (l := [2092232,2076040,2090376,1043848,1961352,2026888,2090568,1031752,1556040,1818184,1949256,2080328,1044040,1961544,2027080,2092616,1048136,2096712,2026952,1810120]) (r := [2006728,2039496,1945288,1816264,1961672,912600,1961176,2070872,2013528,915800,765400,1961688,991064,2074962,1027410,1551698,2075986,962002,1682898,898514,1914322,2029418]) (b := A8) (merge (n := 7) (q := 16) (l := [2092232,2076040,2090376,1043848,1961352,2026888,2090568,1031752]) (r := [1556040,1818184,1949256,2080328,1044040,1961544,2027080,2092616,1048136,2096712,2026952,1810120]) (b := A8) (merge (n := 7) (q := 16) (l := [2092232,2076040,2090376,1043848]) (r := [1961352,2026888,2090568,1031752]) (b := A8) nine_rows_8_10 nine_rows_8_11) (merge (n := 7) (q := 16) (l := [1556040,1818184,1949256,2080328]) (r := [1044040,1961544,2027080,2092616,1048136,2096712,2026952,1810120]) (b := A8) nine_rows_8_12 (merge (n := 7) (q := 16) (l := [1044040,1961544,2027080,2092616]) (r := [1048136,2096712,2026952,1810120]) (b := A8) nine_rows_8_13 nine_rows_8_14))) (merge (n := 7) (q := 16) (l := [2006728,2039496,1945288,1816264,1961672,912600,1961176,2070872,2013528,915800,765400,1961688]) (r := [991064,2074962,1027410,1551698,2075986,962002,1682898,898514,1914322,2029418]) (b := A8) (merge (n := 7) (q := 16) (l := [2006728,2039496,1945288,1816264]) (r := [1961672,912600,1961176,2070872,2013528,915800,765400,1961688]) (b := A8) nine_rows_8_15 (merge (n := 7) (q := 16) (l := [1961672,912600,1961176,2070872]) (r := [2013528,915800,765400,1961688]) (b := A8) nine_rows_8_16 nine_rows_8_17)) (merge (n := 7) (q := 16) (l := [991064,2074962,1027410,1551698]) (r := [2075986,962002,1682898,898514,1914322,2029418]) (b := A8) nine_rows_8_18 (merge (n := 7) (q := 16) (l := [2075986,962002,1682898,898514]) (r := [1914322,2029418]) (b := A8) nine_rows_8_19 nine_rows_8_20)))))
  · refine ⟨bounded 8 A8 (by decide), ?_⟩
    exact (merge (n := 8) (q := 20) (l := [268409856,267369472,267893760,268155904,268418048,133168128,233831424,267385856]) (r := [268434432,268420160,31965120,268406920,247125330,97430994,97367506]) (b := A9) (merge (n := 8) (q := 20) (l := [268409856,267369472,267893760,268155904]) (r := [268418048,133168128,233831424,267385856]) (b := A9) nine_rows_9_0 nine_rows_9_1) (merge (n := 8) (q := 20) (l := [268434432,268420160,31965120,268406920]) (r := [247125330,97430994,97367506]) (b := A9) nine_rows_9_2 nine_rows_9_3))

end SmallNine

namespace SmallNine

theorem dense_deletion {V : Type*} [Fintype V] (G : SimpleGraph V) {n E h : ℕ}
    (size : Fintype.card V=n+1) (many : E≤G.edgeSet.ncard)
    (arith : ∀ e d : ℕ, E≤e → (n+1)*d≤2*e → h≤e-d) :
    ∃ v : V, h≤(G.induce ({v}ᶜ : Set V)).edgeSet.ncard := by
  classical
  let nonempty : Nonempty V := Fintype.card_pos_iff.mp (by omega)
  obtain ⟨v,_,least⟩ := Finset.univ.exists_min_image (fun i => G.degree i) Finset.univ_nonempty
  have bound : (n+1)*G.degree v ≤ 2*G.edgeFinset.card := by
    have s := Finset.sum_le_sum least
    simpa [size,G.sum_degrees_eq_twice_card_edges] using s
  have card (K : SimpleGraph V) : K.edgeFinset.card=K.edgeSet.ncard := by
    rw [SimpleGraph.edgeFinset_card,Set.fintypeCard_eq_ncard]
  refine ⟨v,?_⟩
  rw [← Set.fintypeCard_eq_ncard, ← SimpleGraph.edgeFinset_card,
    G.card_edgeFinset_induce_compl_singleton, G.card_edgeFinset_deleteIncidenceSet]
  exact arith _ _ (by simpa only [card] using many) bound

theorem addr_exists {n i : ℕ} (hi : i<n.choose 2) :
    ∃ a b : Fin n, a<b ∧ b.val.choose 2+a.val=i := by
  induction n with
  | zero => simp at hi
  | succ n ih =>
    by_cases old : i<n.choose 2
    · obtain ⟨a,b,ab,eq⟩ := ih old
      exact ⟨a.castSucc,b.castSucc,ab,eq⟩
    · rw [Nat.choose_succ_succ' n 1,Nat.choose_one_right] at hi
      change i<n+n.choose 2 at hi
      let a : Fin n := ⟨i-n.choose 2,by omega⟩
      exact ⟨a.castSucc,Fin.last n,Fin.castSucc_lt_last _,by dsimp [a]; omega⟩

theorem bit_count {x l : ℕ} (bound : x<2^l) :
    ((Finset.range l).filter fun i => x.testBit i).card = x.bitIndices.length := by
  have h : (Finset.range l).filter (fun i => x.testBit i) = x.bitIndices.toFinset := by
    ext i
    simp only [Finset.mem_filter,Finset.mem_range,List.mem_toFinset,Nat.mem_bitIndices]
    refine ⟨And.right,fun b => ⟨?_,b⟩⟩
    contrapose! b
    simp [Nat.testBit_lt_two_pow (bound.trans_le (Nat.pow_le_pow_right (by decide) b))]
  rw [h,List.toFinset_card_of_nodup Nat.bitIndices_nodup]

theorem split_last {n x pre : ℕ} (bx : x<2^((n+1).choose 2)) (bp : pre<2^n.choose 2)
    (agree : ∀ i j : Fin n, i<j →
      x.testBit (j.val.choose 2+i.val)=pre.testBit (j.val.choose 2+i.val)) :
    ∃ s, s<2^n ∧ pre ||| (s <<< n.choose 2)=x := by
  refine ⟨x >>> n.choose 2, ?_,?_⟩
  · rw [Nat.shiftRight_eq_div_pow, Nat.div_lt_iff_lt_mul (Nat.two_pow_pos _)]
    rwa [Nat.choose_succ_succ' n 1,Nat.choose_one_right,pow_add] at bx
  · apply Nat.eq_of_testBit_eq
    intro i
    rw [Nat.testBit_or,Nat.testBit_shiftLeft,Nat.testBit_shiftRight]
    by_cases hi : i<n.choose 2
    · obtain ⟨a,b,ab,rfl⟩ := addr_exists hi
      simpa [hi, Nat.not_le.mpr hi] using (agree a b ab).symm
    · have le := Nat.le_of_not_lt hi
      have high : pre.testBit i = false :=
        Nat.testBit_lt_two_pow (bp.trans_le (Nat.pow_le_pow_right (by decide) le))
      simp [high,le,Nat.add_sub_cancel' le]

set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16000 in
theorem nine_from_stages (G : SimpleGraph (Fin 9)) (conn : G.Connected) (edges : G.edgeSet.ncard=16) :
    let edge (g i j : ℕ) : Bool :=
      decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

    let digit (p i : ℕ) := (p >>> (4*i)) % 16

    let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

    let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
      (List.range m).all fun j =>
        decide (digit p j < n) && (List.range j).all (fun i =>
          decide (digit p i ≠ digit p j) &&
          (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
           else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


    let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
      tab.1.all (fun (s,p) => checkMap false 7 (n+1) 1053303 (extend n src s) p) &&
      tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
          checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
      (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
          tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
          tab.2.any (fun (v,_,_) => decide (v=s)))

    let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
      decide (src.length=tabs.length) &&
        ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
    let Stage (n q : ℕ) (A B : List ℕ) :=
      (∀ a∈A, a<2^n.choose 2) ∧ ∃ ts, unitOK n q A B ts=true
    (∃ A2 A3 A4 A5 A6 A7 A8 : List ℕ,
      Stage 1 1 [0] A2 ∧
      Stage 2 2 A2 A3 ∧
      Stage 3 4 A3 A4 ∧
      Stage 4 6 A4 A5 ∧
      Stage 5 9 A5 A6 ∧
      Stage 6 12 A6 A7 ∧
      Stage 7 16 A7 A8 ∧
      Stage 8 20 A8 [68718395392,68585226240,68719443968,8387558400]) → ∃ m ∈ ([2251801971660822] : List ℕ), ∃ e : Fin 9 ↪ Fin 9,
          ∀ i j, G.Adj i j → m.testBit ((min (e i) (e j)).val*9+(max (e i) (e j)).val)=false := by
  intro edge digit extend checkMap parentOK unitOK Stage
  have map_info (eq : Bool) {m n src dst p} (h : checkMap eq m n src dst p = true) :
      (∀ j < m, digit p j<n) ∧ (∀ i j, i<j → j < m → digit p i ≠ digit p j) ∧
      ∀ i j, i<j → j < m →
        (if eq then edge src i j=edge dst (digit p i) (digit p j)
         else edge src i j=true → edge dst (digit p i) (digit p j)=true) := by
    simp only [checkMap,List.all_eq_true,List.mem_range,Bool.and_eq_true,decide_eq_true_eq] at h
    refine ⟨fun j hj => (h j hj).1,fun i j hij hj => ((h j hj).2 i hij).1,?_⟩
    intro i j l hj
    have q := ((h j hj).2 i l).2
    cases eq <;> simpa only [Bool.false_eq_true,if_false,if_true,decide_eq_true_eq] using q

  have extend_mono {n g u s i j} (h : u &&& s = u)
      (he : edge (extend n g u) i j=true) : edge (extend n g s) i j=true := by
    simp only [edge,extend,Bool.and_eq_true,decide_eq_true_eq,Nat.testBit_or,Bool.or_eq_true] at he ⊢
    refine ⟨he.1,he.2.imp_right ?_⟩
    set pos := (max i j).choose 2 + min i j
    have hs := congrArg (fun a : ℕ => (a <<< n.choose 2).testBit pos) h
    rw [Nat.shiftLeft_and_distrib,Nat.testBit_and] at hs
    intro hu
    simpa only [hu,Bool.true_and] using hs

  have extension_result (n need src s : ℕ) (targets : List ℕ) (T : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)))
      (ok : parentOK n need src targets T=true) (hs : s<2^n)
      (many : need ≤ (extend n src s).bitIndices.length) :
      (∃ p, checkMap false 7 (n+1) 1053303 (extend n src s) p = true) ∨
      ∃ c ∈ targets, ∃ p, checkMap true (n+1) (n+1) c (extend n src s) p = true := by
    simp only [parentOK,Bool.and_eq_true,List.all_eq_true,List.mem_range] at ok
    obtain ⟨⟨allP,allIso⟩,allN⟩ := ok
    have cover := allN s hs
    simp only [Bool.or_eq_true,decide_eq_true_eq,not_lt.mpr many,false_or,List.any_eq_true] at cover
    rcases cover with ⟨⟨u,p⟩,hp,sub⟩|⟨⟨u,c,p⟩,hi,eq⟩
    · left
      refine ⟨p,?_⟩
      have good := allP (u,p) hp
      simp only [checkMap,List.all_eq_true,List.mem_range,Bool.and_eq_true,decide_eq_true_eq,
        Bool.false_eq_true,if_false] at good ⊢
      intro j hj
      refine ⟨(good j hj).1,?_⟩
      intro i hij
      obtain ⟨ne,hedge⟩ := (good j hj).2 i hij
      exact ⟨ne,fun h => extend_mono sub (hedge h)⟩
    · right
      change u=s at eq
      subst u
      have cert := allIso (s,c,p) hi
      simp only [decide_eq_true_eq] at cert
      obtain ⟨idx,proof⟩ := cert
      refine ⟨targets[c],List.getElem_mem _,p,?_⟩
      simpa [List.getElem?_eq_getElem idx] using proof

  have edge_comm (g i j : ℕ) : edge g i j = edge g j i := by
    by_cases h : i=j
    · subst j
      rfl
    · simp [edge,h,Ne.symm h,max_comm j i,min_comm j i]

  have as_map (eq : Bool) {m n a b p : ℕ} (h : checkMap eq m n a b p = true) :
      ∃ f : Fin m ↪ Fin n, ∀ i j : Fin m,
        (if eq then edge a i j=edge b (f i) (f j)
         else edge a i j=true → edge b (f i) (f j)=true) := by
    obtain ⟨bound,sep,hmap⟩ := map_info eq h
    let f : Fin m ↪ Fin n :=
      ⟨fun i => ⟨digit p i,bound _ i.isLt⟩,by
        intro i j e
        by_contra ne
        rcases lt_or_gt_of_ne ne with lt|gt
        · exact sep i j lt j.isLt (congrArg Fin.val e)
        · exact sep j i gt i.isLt (congrArg Fin.val e.symm)⟩
    refine ⟨f,?_⟩
    intro i j
    rcases lt_trichotomy i j with lt|rfl|gt
    · exact hmap i j lt j.isLt
    · cases eq <;> simp [edge]
    · rw [edge_comm a, edge_comm b]
      exact hmap j i gt i.isLt

  have tab_for_parent {n need : ℕ} {src targets : List ℕ} {tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))}
      (ok : unitOK n need src targets tabs=true) {p} (hp : p∈src) :
      ∃ t, parentOK n need p targets t = true := by
    induction src generalizing tabs with
    | nil => simp at hp
    | cons x xs ih =>
      cases tabs with
      | nil => simp [unitOK] at ok
      | cons u us =>
        simp only [unitOK,List.length_cons,Nat.succ.injEq,Bool.and_eq_true,decide_eq_true_eq,
          List.zip_cons_cons,List.all_cons] at ok
        obtain ⟨len,first,rest⟩ := ok
        rcases List.mem_cons.mp hp with rfl|later
        · exact ⟨u,first⟩
        · apply ih (tabs:=us) _ later
          simp only [unitOK,Bool.and_eq_true,decide_eq_true_eq]
          exact ⟨len,rest⟩

  let Found {V : Type} (G : SimpleGraph V) : Prop :=
    ∃ f : Fin 7 ↪ V, ∀ i j : Fin 7, edge 1053303 i j=true → G.Adj (f i) (f j)

  let Listed {V : Type} (G : SimpleGraph V) (n : ℕ) (A : List ℕ) : Prop :=
    ∃ a ∈ A, ∃ f : Fin n ≃ V, ∀ i j : Fin n, edge a i j=true ↔ G.Adj (f i) (f j)

  have ordered_real {V : Type} (G : SimpleGraph V) {n x : ℕ} (e : Fin n ≃ V)
      (bits : ∀ i j : Fin n, i<j → (x.testBit (j.val.choose 2+i.val)=true ↔ G.Adj (e i) (e j))) :
      ∀ i j : Fin n, edge x i j=true ↔ G.Adj (e i) (e j) := by
    have fwd {i j : Fin n} (lt : i<j) : edge x i j=true ↔ G.Adj (e i) (e j) := by
      simpa only [edge,show decide (i.val ≠ j.val) = true from decide_eq_true (ne_of_lt (show i.val<j.val from lt)),Bool.true_and,
        min_eq_left (show i.val≤j.val from lt.le),max_eq_right (show i.val≤j.val from lt.le)]
        using bits i j lt
    intro i j
    rcases lt_trichotomy i j with lt|rfl|gt
    · exact fwd lt
    · simp [edge]
    · rw [edge_comm,SimpleGraph.adj_comm]
      exact fwd gt

  have grow {n need prev : ℕ} {A B : List ℕ} {tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))}
      (allSmall : ∀ a∈A, a<2^n.choose 2) (ok : unitOK n need A B tabs=true)
      (arith : ∀ u v : ℕ, need≤u → (n+1)*v≤2*u → prev≤u-v)
      (ih : ∀ {W : Type} [Fintype W] (H : SimpleGraph W), Fintype.card W=n →
        prev≤H.edgeSet.ncard → Found H ∨ Listed H n A)
      {V : Type} [Fintype V] (G : SimpleGraph V) (sz : Fintype.card V=n+1)
      (many : need≤G.edgeSet.ncard) : Found G ∨ Listed G (n+1) B := by
    classical
    obtain ⟨v,remain⟩ := dense_deletion G sz many arith
    let S := ({v}ᶜ : Set V)
    let H := G.induce S
    have cS : Fintype.card S=n := by
      calc
        Fintype.card S = Fintype.card V - Fintype.card ({v} : Set V) := Fintype.card_compl_set _
        _ = n := by simp [sz]
    rcases ih H cS remain with found|⟨a,ha,f,shape⟩
    · left
      obtain ⟨u,keep⟩ := found
      exact ⟨u.trans ⟨Subtype.val,Subtype.val_injective⟩,keep⟩
    · let e0 : Fin (n+1) ≃ V := (Fintype.equivOfCardEq (by simpa using sz.symm))
      obtain ⟨perm,hp⟩ := Equiv.Perm.exists_extending_pair (fun i : Fin n => e0 i.castSucc)
        (fun i => (f i).val) (e0.injective.comp (Fin.castSucc_injective n)) (Subtype.val_injective.comp f.injective)
      let e := e0.trans perm
      let J := G.comap e
      let iso : J ≃g G := SimpleGraph.Iso.comap e G
      have hJ : J.edgeSet.ncard=G.edgeSet.ncard := by
        have h := iso.card_edgeFinset_eq
        simpa only [SimpleGraph.edgeFinset_card,Set.fintypeCard_eq_ncard] using h
      obtain ⟨x,bx,bits,cnt⟩ := SmallCover.Seven.encoding_spec J
      have ordered (i j : Fin (n+1)) (h : i<j) := bits i j h
      have full := ordered_real G e ordered
      have agree (i j : Fin n) (h : i<j) :
          x.testBit (j.val.choose 2+i.val) = a.testBit (j.val.choose 2+i.val) := by
        have q := (ordered i.castSucc j.castSucc (show i.castSucc<j.castSucc from h))
        change x.testBit (j.val.choose 2+i.val)=true ↔ G.Adj (perm (e0 i.castSucc)) (perm (e0 j.castSucc)) at q
        rw [hp i,hp j] at q
        have both := q.trans (shape i j).symm
        simp only [edge,show decide (i.val ≠ j.val) = true from decide_eq_true (ne_of_lt (show i.val<j.val from h)),Bool.true_and,
          max_eq_right (show i.val≤j.val from h.le),min_eq_left (show i.val≤j.val from h.le)] at both
        exact Bool.eq_iff_iff.mpr both
      obtain ⟨s,hs,hx⟩ := split_last bx (allSmall a ha) agree
      change extend n a s=x at hx
      obtain ⟨r,hr⟩ := tab_for_parent ok ha
      have card : x.bitIndices.length = G.edgeSet.ncard := (bit_count bx).symm.trans (cnt.symm.trans hJ)
      rcases extension_result n need a s B r hr hs (by rwa [hx,card]) with ⟨p,q⟩|⟨c,hc,p,q⟩ <;> rw [hx] at q
      · left
        obtain ⟨u,keep⟩ := as_map false q
        exact ⟨u.trans e.toEmbedding,fun i j t => (full _ _).mp (keep i j t)⟩
      · right
        obtain ⟨u,keep⟩ := as_map true q
        let g := Equiv.ofBijective u u.injective.bijective_of_finite
        exact ⟨c,hc,g.trans e,fun i j => (iff_of_eq (congrArg (·=true) (keep i j))).trans (full _ _)⟩

  have endpoint_cases {m : ℕ} (hm : m∈[68718395392,68585226240,68719443968,8387558400]) :
      ∃ s : ℕ, (∃ i : Fin 9,s.testBit i = false) ∧ (∃ j : Fin 9,s.testBit j = true) ∧
        ∀ i j : Fin 9,s.testBit i ≠ s.testBit j → edge m i j = true := by
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hm
    rcases hm with rfl|rfl|rfl|rfl
    · exact ⟨127,by decide⟩
    · exact ⟨63,by decide⟩
    · exact ⟨63,by decide⟩
    · exact ⟨31,by decide⟩

  rintro ⟨A2,A3,A4,A5,A6,A7,A8,s1,s2,s3,s4,s5,s6,s7,s8⟩
  have step1 {V : Type} [Fintype V] (G : SimpleGraph V) (size : Fintype.card V=1)
      (_e : 0≤G.edgeSet.ncard) : Found G ∨ Listed G 1 ([0] : List ℕ) := by
    right
    let f : Fin 1 ≃ V := Fintype.equivOfCardEq (by simpa using size.symm)
    refine ⟨0,by decide,f,?_⟩
    intro i j
    have h : i=j := Subsingleton.elim _ _
    subst j
    simp [edge]


  have step2 {W : Type} [Fintype W] (H : SimpleGraph W) (size : Fintype.card W=2)
      (many : 1≤H.edgeSet.ncard) : Found H ∨ Listed H 2 A2 := by
    obtain ⟨tbl,ok⟩ := s1.2
    exact grow (n:=1) s1.1 ok (by intros; omega) (fun J h z => step1 J h z) H size many

  have step3 {W : Type} [Fintype W] (H : SimpleGraph W) (size : Fintype.card W=3)
      (many : 2≤H.edgeSet.ncard) : Found H ∨ Listed H 3 A3 := by
    obtain ⟨tbl,ok⟩ := s2.2
    exact grow (n:=2) s2.1 ok (by intros; omega) (fun J h z => step2 J h z) H size many

  have step4 {W : Type} [Fintype W] (H : SimpleGraph W) (size : Fintype.card W=4)
      (many : 4≤H.edgeSet.ncard) : Found H ∨ Listed H 4 A4 := by
    obtain ⟨tbl,ok⟩ := s3.2
    exact grow (n:=3) s3.1 ok (by intros; omega) (fun J h z => step3 J h z) H size many

  have step5 {W : Type} [Fintype W] (H : SimpleGraph W) (size : Fintype.card W=5)
      (many : 6≤H.edgeSet.ncard) : Found H ∨ Listed H 5 A5 := by
    obtain ⟨tbl,ok⟩ := s4.2
    exact grow (n:=4) s4.1 ok (by intros; omega) (fun J h z => step4 J h z) H size many

  have step6 {W : Type} [Fintype W] (H : SimpleGraph W) (size : Fintype.card W=6)
      (many : 9≤H.edgeSet.ncard) : Found H ∨ Listed H 6 A6 := by
    obtain ⟨tbl,ok⟩ := s5.2
    exact grow (n:=5) s5.1 ok (by intros; omega) (fun J h z => step5 J h z) H size many

  have step7 {W : Type} [Fintype W] (H : SimpleGraph W) (size : Fintype.card W=7)
      (many : 12≤H.edgeSet.ncard) : Found H ∨ Listed H 7 A7 := by
    obtain ⟨tbl,ok⟩ := s6.2
    exact grow (n:=6) s6.1 ok (by intros; omega) (fun J h z => step6 J h z) H size many

  have step8 {W : Type} [Fintype W] (H : SimpleGraph W) (size : Fintype.card W=8)
      (many : 16≤H.edgeSet.ncard) : Found H ∨ Listed H 8 A8 := by
    obtain ⟨tbl,ok⟩ := s7.2
    exact grow (n:=7) s7.1 ok (by intros; omega) (fun J h z => step7 J h z) H size many

  have step9 {W : Type} [Fintype W] (H : SimpleGraph W) (size : Fintype.card W=9)
      (many : 20≤H.edgeSet.ncard) : Found H ∨ Listed H 9 [68718395392,68585226240,68719443968,8387558400] := by
    obtain ⟨tbl,ok⟩ := s8.2
    exact grow (n:=8) s8.1 ok (by intros; omega) (fun J h z => step8 J h z) H size many
  have many : 20 ≤ Gᶜ.edgeSet.ncard := by
    classical
    have dis : Disjoint G.edgeFinset Gᶜ.edgeFinset := SimpleGraph.disjoint_edgeFinset.mpr disjoint_compl_right
    have hh := Finset.card_union_of_disjoint dis
    rw [← SimpleGraph.edgeFinset_sup] at hh
    simp only [SimpleGraph.edgeFinset_card,Set.fintypeCard_eq_ncard,edges] at hh
    rw [sup_compl_eq_top] at hh
    have top : (⊤ : SimpleGraph (Fin 9)).edgeSet.ncard=36 := by
      rw [← Set.fintypeCard_eq_ncard, ← SimpleGraph.edgeFinset_card, SimpleGraph.card_edgeFinset_top_eq_card_choose_two]
      decide
    rw [top] at hh
    omega
  rcases step9 Gᶜ (Fintype.card_fin _) many with ⟨f,embed⟩|⟨m,hm,f,data⟩
  · let h : 7≤9 := by decide
    obtain ⟨e,ext⟩ := Equiv.Perm.exists_extending_pair (fun i : Fin 7 => Fin.castLE h i)
      (fun i => f i) (Fin.castLE_injective _) f.injective
    refine ⟨2251801971660822,by simp,e.symm.toEmbedding,?_⟩
    have support : ∀ i j : Fin 9, (2251801971660822:ℕ).testBit ((min i j).val*9+(max i j).val)=true →
        ∃ a b : Fin 7, Fin.castLE h a=i ∧ Fin.castLE h b=j ∧ edge 1053303 a b=true := by decide +kernel
    intro i j adj
    change (2251801971660822:ℕ).testBit ((min (e.symm i) (e.symm j)).val*9 + (max (e.symm i) (e.symm j)).val)=false
    cases bit : (2251801971660822:ℕ).testBit ((min (e.symm i) (e.symm j)).val*9+(max (e.symm i) (e.symm j)).val) with
    | false => rfl
    | true =>
      obtain ⟨a,b,ha,hb,edgeAB⟩ := support _ _ bit
      have bad := embed a b edgeAB
      rw [← ext a, ← ext b,ha,hb,e.apply_symm_apply,e.apply_symm_apply] at bad
      exact (bad.2 adj).elim
  · obtain ⟨s,⟨i,hi⟩,⟨j,hj⟩,cross⟩ := endpoint_cases hm
    obtain ⟨a,b,ab,distinct⟩ := SmallCover.Seven.seven_connected_cut conn
      (fun v => s.testBit (f.symm v)) ⟨f i,by simpa using hi⟩ ⟨f j,by simpa using hj⟩
    have bad := (data (f.symm a) (f.symm b)).mp (cross _ _ distinct)
    rw [f.apply_symm_apply,f.apply_symm_apply] at bad
    exact (bad.2 ab).elim

end SmallNine

namespace SmallNine

theorem nine_sparse (G : SimpleGraph (Fin 9)) (conn : G.Connected) (edges : G.edgeSet.ncard=16) :
    ∃ m ∈ ([2251801971660822] : List ℕ), ∃ e : Fin 9 ↪ Fin 9,
      ∀ i j, G.Adj i j → m.testBit ((min (e i) (e j)).val*9+(max (e i) (e j)).val)=false :=
  nine_from_stages G conn edges numerical_stages

end SmallNine

namespace OMA.R_Erdos1182_erdos_1182_variants_small_values_R2_H1_R1

def H1 : Prop := ∀ G : SimpleGraph (Fin 10), G.Connected → G.edgeSet.ncard = 18 →
    ∃ m ∈ ([618970019714747783169716278,72057645653176374] : List ℕ), ∃ e : Fin 10 ↪ Fin 10,
      ∀ i j, G.Adj i j → m.testBit ((min (e i) (e j)).val * 10 + (max (e i) (e j)).val) = false

def H2 : Prop := ∀ t : Fin 2,
  let n := t.val + 11
  let masks := (![[158495020111019088292975255562,9444734656926049394710],[14855280693082744087392632874,4951760378943817067685560330,604831853708092460023990,40564825856395375891792278241302]] : Fin 2 → List ℕ) t
  ∀ G : SimpleGraph (Fin n), G.Connected → G.edgeSet.ncard = 23 →
    ∃ m ∈ masks, ∃ e : Fin n ↪ Fin n, ∀ i j, G.Adj i j →
      m.testBit ((min (e i) (e j)).val * n + (max (e i) (e j)).val) = false

theorem main : H1 → H2 → OMA.R_Erdos1182_erdos_1182_variants_small_values_R2.H1 := by
  intro ten eleven_twelve k
  fin_cases k
  · exact SmallNine.nine_sparse
  · exact ten
  · exact eleven_twelve 0
  · exact eleven_twelve 1

end OMA.R_Erdos1182_erdos_1182_variants_small_values_R2_H1_R1
