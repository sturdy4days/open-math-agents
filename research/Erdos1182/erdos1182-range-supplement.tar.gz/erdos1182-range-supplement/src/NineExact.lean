import RangeBase
import FullUpper

/-! One 17-vertex host certificate supplies both extremal values at order nine. -/
theorem BBHRange.nine_exact (cert : BBHRange.Cert 9 2251801971660822) :
    Erdos1182.F 9 = 16 ∧ Erdos1182.f 9 = 27 :=
  ⟨(BBHRange.nine cert).1, le_antisymm (E1182Complete.upper_table 5) (BBHRange.nine cert).2⟩
