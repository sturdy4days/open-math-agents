import TerminalCensus

/-! Decode the graph represented by a terminal complement. -/
open SimpleGraph
namespace SmallTenResidual

def terminalGraph (m : ℕ) : SimpleGraph (Fin 10) where
  Adj i j := i ≠ j ∧ triEdge m i j = false
  symm := ⟨fun i j h => ⟨h.1.symm,by
    simpa only [triEdge,ne_comm,min_comm j.val i.val,max_comm j.val i.val] using h.2⟩⟩
  loopless := ⟨fun _ h => h.1 rfl⟩

instance (m : ℕ) : DecidableRel (terminalGraph m).Adj :=
  fun _ _ => inferInstanceAs (Decidable (_ ∧ _))

noncomputable def iso_of_repr {G : SimpleGraph (Fin 10)} {m : ℕ} (f : Fin 10 ≃ Fin 10)
    (hf : ∀ i j : Fin 10, triEdge m i j = true ↔ Gᶜ.Adj (f i) (f j)) : terminalGraph m ≃g G where
  toEquiv := f
  map_rel_iff' := by
    intro i j
    change G.Adj (f i) (f j) ↔ i ≠ j ∧ triEdge m i j = false
    constructor
    · intro a
      refine ⟨fun eq => a.ne (congrArg f eq),?_⟩
      cases b : triEdge m i j with
      | false => rfl
      | true => exact False.elim (((hf i j).mp b).2 a)
    · rintro ⟨ne,zero⟩
      by_contra notAdj
      have one := (hf i j).mpr ⟨f.injective.ne ne,notAdj⟩
      simp [one] at zero

end SmallTenResidual
