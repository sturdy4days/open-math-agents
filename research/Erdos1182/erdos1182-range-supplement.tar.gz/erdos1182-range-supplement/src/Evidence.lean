import Range
import LowerRange

/-! Axiom audit for the order-local and unconditional bounds. -/
#print axioms BBHRange.cert_iff_good
#print axioms BBHRange.nine
#print axioms BBHRange.ten_dense
#print axioms BBHRange.ten_sparse
#print axioms BBHRange.remaining_sparse
#print axioms BBHRange.local_cases_of_H2
#print axioms BBHPendant.good
#print axioms BBHPendant.count
#print axioms BBHPendant.f_succ
#print axioms BBHPendant.f_growth
#print axioms BBHPendant.eight_certificate
#print axioms BBHPendant.eight_and_above
#print axioms BBHPendant.nine_twelve_lower
