import AlternativeMasks

/-! Standard-axiom audit for the localized dense extrema. -/
#print axioms BBHRange.nine_exact
#print axioms BBHRange.ten_either
#print axioms BBHRange.eleven_either
#print axioms BBHRange.twelve_either
#print axioms BBHRange.twelve_secondary
