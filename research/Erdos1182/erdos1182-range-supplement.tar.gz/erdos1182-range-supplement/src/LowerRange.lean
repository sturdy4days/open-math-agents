import RangeBase
import Growth
import EightPrimary

/-! Propagate the eight-vertex witness of BBH, verified in OMA #13482. -/
open SimpleGraph Erdos1182
namespace BBHPendant

theorem eight_certificate : BBHRange.Cert 8 36169948434793600 := by
  apply BBHFinite.certificate_of_universal (by decide)
  intro C ht
  obtain ⟨f,hf⟩ := OMA.SmallTriangleGood.Order8.embedding C ht
  obtain ⟨e,he⟩ := OMA.R_Erdos1182_erdos_1182_variants_small_values_R2.symmetric_mask
    (n := 8) (m := 36169948434793600) (C := C) ⟨f,hf⟩
  exact ⟨⟨⟨e,fun h => ⟨e.injective.ne h.ne,he _ _ h.1 h.2⟩⟩,e.injective⟩⟩

theorem eight_lower : 20 ≤ f 8 := by
  obtain ⟨paths,count⟩ := SmallTable.Witness.sizes_and_paths 4
  exact BBHRange.lower_f (by decide) paths
    (BBHRange.sizing 8 36169948434793600 count) eight_certificate

theorem eight_and_above (n : ℕ) (hn : 8 ≤ n) : n + 12 ≤ f n := by
  obtain ⟨k,rfl⟩ := Nat.exists_eq_add_of_le hn
  have bound := f_growth (n := 8) (by decide) k
  have := eight_lower
  omega

theorem nine_twelve_lower :
    21 ≤ f 9 ∧ 22 ≤ f 10 ∧ 23 ≤ f 11 ∧ 24 ≤ f 12 :=
  ⟨eight_and_above 9 (by decide),eight_and_above 10 (by decide),
   eight_and_above 11 (by decide),eight_and_above 12 (by decide)⟩

end BBHPendant
