import SecondarySeventeen

/-! The geometric threshold 17 is sharp for the secondary template. An 18-edge
connected obstruction is a copy of K₄,₄ and two leaves at one of its vertices. -/
open SimpleGraph Finset

namespace SmallTenResidual

private abbrev H := BBHRange.template 10 72057645653176374

private def common (s : Finset (Fin 10)) := univ.filter (fun y => ∀ x∈s, H.Adj x y)

private def common4 (a b c d : Fin 10) : Finset (Fin 10) :=
  univ.filter (fun i => H.Adj a i ∧ H.Adj b i ∧ H.Adj c i ∧ H.Adj d i)

private def good (a : Fin 10) : Prop :=
  ∀ b c d : Fin 10, a < b → b < c → c < d → (common4 a b c d).card ≤ 3

private instance (a : Fin 10) : Decidable (good a) := by unfold good; infer_instance

private theorem at0 : good 0 := by decide +kernel

private theorem at1 : good 1 := by decide +kernel

private theorem at2 : good 2 := by decide +kernel

private theorem at3 : good 3 := by decide +kernel

private theorem at4 : good 4 := by decide +kernel

private theorem at5 : good 5 := by decide +kernel

private theorem at6 : good 6 := by decide +kernel

private theorem at7 : good 7 := by decide +kernel

private theorem at8 : good 8 := by decide +kernel

private theorem at9 : good 9 := by decide +kernel

private theorem common_bound {s : Finset (Fin 10)} (hs : s.card = 4) :
    (common s).card ≤ 3 := by
  let e := s.orderIsoOfFin hs
  have good_all (a : Fin 10) : good a := by
    fin_cases a <;> first | exact at0 | exact at1 | exact at2 | exact at3 | exact at4 | exact at5 | exact at6 | exact at7 | exact at8 | exact at9
  have bound := good_all (e 0).val (e 1).val (e 2).val (e 3).val
    (e.strictMono (by decide : (0 : Fin 4) < 1))
    (e.strictMono (by decide : (1 : Fin 4) < 2))
    (e.strictMono (by decide : (2 : Fin 4) < 3))
  apply le_trans (card_le_card ?_) bound
  intro z hz
  obtain ⟨_,all⟩ := mem_filter.mp hz
  exact mem_filter.mpr ⟨mem_univ _,all _ (e 0).property,all _ (e 1).property,
    all _ (e 2).property,all _ (e 3).property⟩

theorem eighteen_obstruction :
    ∃ G : SimpleGraph (Fin 10), G.Connected ∧ G.edgeSet.ncard=18 ∧ ¬Placement G := by
  let G := terminalGraph 26353739671890
  have from_seven : ∀ i : Fin 10, i=7 ∨ G.Adj 7 i ∨ G.Adj 7 0 ∧ G.Adj 0 i := by decide
  have reach (i) : G.Reachable 7 i := by
    rcases from_seven i with rfl | near | ⟨left,right⟩
    · exact .refl _
    · exact near.reachable
    · exact left.reachable.trans right.reachable
  refine ⟨G,⟨fun i j => (reach i).symm.trans (reach j)⟩,(Set.ncard_eq_toFinset_card' _).trans ?_,?_⟩
  · change G.edgeFinset.card=18
    decide
  rintro ⟨f,hf⟩
  let A : Finset (Fin 10) := {0,2,4,6}
  let B : Finset (Fin 10) := {1,3,5,7}
  have cross : ∀ i ∈ A, ∀ j ∈ B, G.Adj i j := by decide
  have subset : B.map f ⊆ common (A.map f) := by
    intro y hy
    obtain ⟨j,hj,rfl⟩ := mem_map.mp hy
    apply mem_filter.mpr
    refine ⟨mem_univ _,?_⟩
    intro x hx
    obtain ⟨i,hi,rfl⟩ := mem_map.mp hx
    exact ⟨f.injective.ne (cross i hi j hj).ne,hf _ _ (cross i hi j hj)⟩
  have limit := common_bound (s := A.map f) ((card_map f).trans (by decide : A.card=4))
  have many := card_le_card subset
  rw [card_map,show B.card=4 by decide] at many
  omega

end SmallTenResidual

#print axioms SmallTenResidual.eighteen_obstruction
