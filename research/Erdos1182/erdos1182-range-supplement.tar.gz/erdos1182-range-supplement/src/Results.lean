import SecondaryForce
import LowerRange

/-! The order-ten maxima share a single BBH host certificate. -/
namespace BBHRange
open Erdos1182

theorem ten_values_from_secondary (h : Cert 10 72057645653176374) :
    F 10 = 18 ∧ f 10 = 33 := by
  refine ⟨ten_secondary_exact h,?_⟩
  apply le_antisymm OMA.R_Erdos1182_erdos_1182_variants_small_values_R2.upper_ten
  exact lower_f (n := 10) (m := 72057645653176374) (by decide) (by decide)
    (sizing _ _ (by decide)) h

theorem later_of_secondary (h : Cert 10 72057645653176374) (k : ℕ) : 33+k ≤ f (10+k) := by
  simpa only [(ten_values_from_secondary h).2] using BBHPendant.f_growth (n := 10) (by decide) k

end BBHRange
#print axioms BBHRange.ten_values_from_secondary
#print axioms BBHRange.later_of_secondary
