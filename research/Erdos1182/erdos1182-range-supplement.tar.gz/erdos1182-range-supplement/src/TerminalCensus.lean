import TenProof

/-! Recover the exhaustive terminal alternatives hidden by the final template placement
in the ten-vertex census. The extension and minimum-degree deletion arguments below
are those of `SmallTen.ten_from_stages`, with the original numerical stages unchanged. -/
namespace SmallTenResidual
open SimpleGraph

def terminals : List ℕ := [35184196563136,35184151143560,35184156285512,35149824432712,35167004301896,35183110429256,17591998126664,35184184171080,35132652824914,35141242759506,17557646649682,26353739671890,30751786182994,32950809438546,35149832694098,17592006388050,35184192432466]

def triEdge (m i j : ℕ) : Bool :=
  decide (i ≠ j) && m.testBit ((max i j).choose 2 + min i j)

def Placement (G : SimpleGraph (Fin 10)) : Prop :=
  ∃ f : Fin 10 ↪ Fin 10, ∀ i j, G.Adj i j →
    (72057645653176374 : ℕ).testBit ((min (f i) (f j)).val*10+(max (f i) (f j)).val)=false

def Outcome (G : SimpleGraph (Fin 10)) : Prop :=
  Placement G ∨ ∃ m ∈ terminals, ∃ f : Fin 10 ≃ Fin 10, ∀ i j : Fin 10,
    triEdge m i j = true ↔ Gᶜ.Adj (f i) (f j)

set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16000 in
private theorem from_stages (G : SimpleGraph (Fin 10)) (edges : G.edgeSet.ncard≤18) :
    let edge (g i j : ℕ) : Bool :=
      decide (i ≠ j) && g.testBit ((max i j).choose 2 + min i j)

    let digit (p i : ℕ) := (p >>> (4*i)) % 16

    let extend (n g s : ℕ) := g ||| (s <<< (n.choose 2))

    let checkMap (eq : Bool) (m n src dst p : ℕ) : Bool :=
      (List.range m).all fun j =>
        decide (digit p j < n) && (List.range j).all (fun i =>
          decide (digit p i ≠ digit p j) &&
          (if eq then decide (edge src i j = edge dst (digit p i) (digit p j))
           else decide (edge src i j=true → edge dst (digit p i) (digit p j)=true)))


    let parentOK (n need src : ℕ) (targets : List ℕ) (tab : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
      tab.1.all (fun (s,p) => checkMap false 8 (n+1) 5383799 (extend n src s) p) &&
      tab.2.all (fun (s,i,p) => decide (i<targets.length) &&
          checkMap true (n+1) (n+1) (targets[i]?.getD 0) (extend n src s) p) &&
      (List.range (2^n)).all (fun s => decide ((extend n src s).bitIndices.length<need) ||
          tab.1.any (fun (v,_) => decide (v &&& s = v)) ||
          tab.2.any (fun (v,_,_) => decide (v=s)))

    let unitOK (n need : ℕ) (src targets : List ℕ) (tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))) : Bool :=
      decide (src.length=tabs.length) &&
        ((src.zip tabs).all fun (g,tab) => parentOK n need g targets tab)
    let Stage (n q : ℕ) (A B : List ℕ) :=
      (∀ a∈A, a<2^n.choose 2) ∧ ∃ ts, unitOK n q A B ts=true
    (∃ A2 A3 A4 A5 A6 A7 A8 A9 : List ℕ,
      Stage 1 1 [0] A2 ∧
      Stage 2 3 A2 A3 ∧
      Stage 3 5 A3 A4 ∧
      Stage 4 7 A4 A5 ∧
      Stage 5 10 A5 A6 ∧
      Stage 6 14 A6 A7 ∧
      Stage 7 18 A7 A8 ∧
      Stage 8 22 A8 A9 ∧
      Stage 9 27 A9 [35184196563136,35184151143560,35184156285512,35149824432712,35167004301896,35183110429256,17591998126664,35184184171080,35132652824914,35141242759506,17557646649682,26353739671890,30751786182994,32950809438546,35149832694098,17592006388050,35184192432466]) → Outcome G := by
  intro edge digit extend checkMap parentOK unitOK Stage
  have map_info (eq : Bool) {m n src dst p} (h : checkMap eq m n src dst p = true) :
      (∀ j < m, digit p j<n) ∧ (∀ i j, i<j → j < m → digit p i ≠ digit p j) ∧
      ∀ i j, i<j → j < m →
        (if eq then edge src i j=edge dst (digit p i) (digit p j)
         else edge src i j=true → edge dst (digit p i) (digit p j)=true) := by
    simp only [checkMap,List.all_eq_true,List.mem_range,Bool.and_eq_true,decide_eq_true_eq] at h
    refine ⟨fun j hj => (h j hj).1,fun i j hij hj => ((h j hj).2 i hij).1,?_⟩
    intro i j l hj
    have q := ((h j hj).2 i l).2
    cases eq <;> simpa only [Bool.false_eq_true,if_false,if_true,decide_eq_true_eq] using q

  have extend_mono {n g u s i j} (h : u &&& s = u)
      (he : edge (extend n g u) i j=true) : edge (extend n g s) i j=true := by
    simp only [edge,extend,Bool.and_eq_true,decide_eq_true_eq,Nat.testBit_or,Bool.or_eq_true] at he ⊢
    refine ⟨he.1,he.2.imp_right ?_⟩
    set pos := (max i j).choose 2 + min i j
    have hs := congrArg (fun a : ℕ => (a <<< n.choose 2).testBit pos) h
    rw [Nat.shiftLeft_and_distrib,Nat.testBit_and] at hs
    intro hu
    simpa only [hu,Bool.true_and] using hs

  have extension_result (n need src s : ℕ) (targets : List ℕ) (T : (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ)))
      (ok : parentOK n need src targets T=true) (hs : s<2^n)
      (many : need ≤ (extend n src s).bitIndices.length) :
      (∃ p, checkMap false 8 (n+1) 5383799 (extend n src s) p = true) ∨
      ∃ c ∈ targets, ∃ p, checkMap true (n+1) (n+1) c (extend n src s) p = true := by
    simp only [parentOK,Bool.and_eq_true,List.all_eq_true,List.mem_range] at ok
    obtain ⟨⟨allP,allIso⟩,allN⟩ := ok
    have cover := allN s hs
    simp only [Bool.or_eq_true,decide_eq_true_eq,not_lt.mpr many,false_or,List.any_eq_true] at cover
    rcases cover with ⟨⟨u,p⟩,hp,sub⟩|⟨⟨u,c,p⟩,hi,eq⟩
    · left
      refine ⟨p,?_⟩
      have good := allP (u,p) hp
      simp only [checkMap,List.all_eq_true,List.mem_range,Bool.and_eq_true,decide_eq_true_eq,
        Bool.false_eq_true,if_false] at good ⊢
      intro j hj
      refine ⟨(good j hj).1,?_⟩
      intro i hij
      obtain ⟨ne,hedge⟩ := (good j hj).2 i hij
      exact ⟨ne,fun h => extend_mono sub (hedge h)⟩
    · right
      change u=s at eq
      subst u
      have cert := allIso (s,c,p) hi
      simp only [decide_eq_true_eq] at cert
      obtain ⟨idx,proof⟩ := cert
      refine ⟨targets[c],List.getElem_mem _,p,?_⟩
      simpa [List.getElem?_eq_getElem idx] using proof

  have edge_comm (g i j : ℕ) : edge g i j = edge g j i := by
    by_cases h : i=j
    · subst j
      rfl
    · simp [edge,h,Ne.symm h,max_comm j i,min_comm j i]

  have as_map (eq : Bool) {m n a b p : ℕ} (h : checkMap eq m n a b p = true) :
      ∃ f : Fin m ↪ Fin n, ∀ i j : Fin m,
        (if eq then edge a i j=edge b (f i) (f j)
         else edge a i j=true → edge b (f i) (f j)=true) := by
    obtain ⟨bound,sep,hmap⟩ := map_info eq h
    let f : Fin m ↪ Fin n :=
      ⟨fun i => ⟨digit p i,bound _ i.isLt⟩,by
        intro i j e
        by_contra ne
        rcases lt_or_gt_of_ne ne with lt|gt
        · exact sep i j lt j.isLt (congrArg Fin.val e)
        · exact sep j i gt i.isLt (congrArg Fin.val e.symm)⟩
    refine ⟨f,?_⟩
    intro i j
    rcases lt_trichotomy i j with lt|rfl|gt
    · exact hmap i j lt j.isLt
    · cases eq <;> simp [edge]
    · rw [edge_comm a, edge_comm b]
      exact hmap j i gt i.isLt

  have tab_for_parent {n need : ℕ} {src targets : List ℕ} {tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))}
      (ok : unitOK n need src targets tabs=true) {p} (hp : p∈src) :
      ∃ t, parentOK n need p targets t = true := by
    induction src generalizing tabs with
    | nil => simp at hp
    | cons x xs ih =>
      cases tabs with
      | nil => simp [unitOK] at ok
      | cons u us =>
        simp only [unitOK,List.length_cons,Nat.succ.injEq,Bool.and_eq_true,decide_eq_true_eq,
          List.zip_cons_cons,List.all_cons] at ok
        obtain ⟨len,first,rest⟩ := ok
        rcases List.mem_cons.mp hp with rfl|later
        · exact ⟨u,first⟩
        · apply ih (tabs:=us) _ later
          simp only [unitOK,Bool.and_eq_true,decide_eq_true_eq]
          exact ⟨len,rest⟩

  let Found {V : Type} (G : SimpleGraph V) : Prop :=
    ∃ f : Fin 8 ↪ V, ∀ i j : Fin 8, edge 5383799 i j=true → G.Adj (f i) (f j)

  let Listed {V : Type} (G : SimpleGraph V) (n : ℕ) (A : List ℕ) : Prop :=
    ∃ a ∈ A, ∃ f : Fin n ≃ V, ∀ i j : Fin n, edge a i j=true ↔ G.Adj (f i) (f j)

  have ordered_real {V : Type} (G : SimpleGraph V) {n x : ℕ} (e : Fin n ≃ V)
      (bits : ∀ i j : Fin n, i<j → (x.testBit (j.val.choose 2+i.val)=true ↔ G.Adj (e i) (e j))) :
      ∀ i j : Fin n, edge x i j=true ↔ G.Adj (e i) (e j) := by
    have fwd {i j : Fin n} (lt : i<j) : edge x i j=true ↔ G.Adj (e i) (e j) := by
      simpa only [edge,show decide (i.val ≠ j.val) = true from decide_eq_true (ne_of_lt (show i.val<j.val from lt)),Bool.true_and,
        min_eq_left (show i.val≤j.val from lt.le),max_eq_right (show i.val≤j.val from lt.le)]
        using bits i j lt
    intro i j
    rcases lt_trichotomy i j with lt|rfl|gt
    · exact fwd lt
    · simp [edge]
    · rw [edge_comm,SimpleGraph.adj_comm]
      exact fwd gt

  have grow {n need prev : ℕ} {A B : List ℕ} {tabs : List (List (ℕ × ℕ) × List (ℕ × ℕ × ℕ))}
      (allSmall : ∀ a∈A, a<2^n.choose 2) (ok : unitOK n need A B tabs=true)
      (arith : ∀ u v : ℕ, need≤u → (n+1)*v≤2*u → prev≤u-v)
      (ih : ∀ {W : Type} [Fintype W] (H : SimpleGraph W), Fintype.card W=n →
        prev≤H.edgeSet.ncard → Found H ∨ Listed H n A)
      {V : Type} [Fintype V] (G : SimpleGraph V) (sz : Fintype.card V=n+1)
      (many : need≤G.edgeSet.ncard) : Found G ∨ Listed G (n+1) B := by
    classical
    obtain ⟨v,remain⟩ := SmallNine.dense_deletion G sz many arith
    let S := ({v}ᶜ : Set V)
    let H := G.induce S
    have cS : Fintype.card S=n := by
      calc
        Fintype.card S = Fintype.card V - Fintype.card ({v} : Set V) := Fintype.card_compl_set _
        _ = n := by simp [sz]
    rcases ih H cS remain with found|⟨a,ha,f,shape⟩
    · left
      obtain ⟨u,keep⟩ := found
      exact ⟨u.trans ⟨Subtype.val,Subtype.val_injective⟩,keep⟩
    · let e0 : Fin (n+1) ≃ V := (Fintype.equivOfCardEq (by simpa using sz.symm))
      obtain ⟨perm,hp⟩ := Equiv.Perm.exists_extending_pair (fun i : Fin n => e0 i.castSucc)
        (fun i => (f i).val) (e0.injective.comp (Fin.castSucc_injective n)) (Subtype.val_injective.comp f.injective)
      let e := e0.trans perm
      let J := G.comap e
      let iso : J ≃g G := SimpleGraph.Iso.comap e G
      have hJ : J.edgeSet.ncard=G.edgeSet.ncard := by
        have h := iso.card_edgeFinset_eq
        simpa only [SimpleGraph.edgeFinset_card,Set.fintypeCard_eq_ncard] using h
      obtain ⟨x,bx,bits,cnt⟩ := SmallCover.Seven.encoding_spec J
      have ordered (i j : Fin (n+1)) (h : i<j) := bits i j h
      have full := ordered_real G e ordered
      have agree (i j : Fin n) (h : i<j) :
          x.testBit (j.val.choose 2+i.val) = a.testBit (j.val.choose 2+i.val) := by
        have q := (ordered i.castSucc j.castSucc (show i.castSucc<j.castSucc from h))
        change x.testBit (j.val.choose 2+i.val)=true ↔ G.Adj (perm (e0 i.castSucc)) (perm (e0 j.castSucc)) at q
        rw [hp i,hp j] at q
        have both := q.trans (shape i j).symm
        simp only [edge,show decide (i.val ≠ j.val) = true from decide_eq_true (ne_of_lt (show i.val<j.val from h)),Bool.true_and,
          max_eq_right (show i.val≤j.val from h.le),min_eq_left (show i.val≤j.val from h.le)] at both
        exact Bool.eq_iff_iff.mpr both
      obtain ⟨s,hs,hx⟩ := SmallNine.split_last bx (allSmall a ha) agree
      change extend n a s=x at hx
      obtain ⟨r,hr⟩ := tab_for_parent ok ha
      have card : x.bitIndices.length = G.edgeSet.ncard := (SmallNine.bit_count bx).symm.trans (cnt.symm.trans hJ)
      rcases extension_result n need a s B r hr hs (by rwa [hx,card]) with ⟨p,q⟩|⟨c,hc,p,q⟩ <;> rw [hx] at q
      · left
        obtain ⟨u,keep⟩ := as_map false q
        exact ⟨u.trans e.toEmbedding,fun i j t => (full _ _).mp (keep i j t)⟩
      · right
        obtain ⟨u,keep⟩ := as_map true q
        let g := Equiv.ofBijective u u.injective.bijective_of_finite
        exact ⟨c,hc,g.trans e,fun i j => (iff_of_eq (congrArg (·=true) (keep i j))).trans (full _ _)⟩

  have matrix_of_map {d src mat : ℕ} (le : d≤10)
      (support : ∀ i j : Fin 10, mat.testBit ((min i j).val*10+(max i j).val)=true →
        ∃ a b : Fin d, Fin.castLE le a=i ∧ Fin.castLE le b=j ∧ edge src a b=true)
      (f : Fin d ↪ Fin 10) (embed : ∀ i j : Fin d, edge src i j=true → Gᶜ.Adj (f i) (f j)) :
      ∃ e : Fin 10 ↪ Fin 10, ∀ i j, G.Adj i j →
        mat.testBit ((min (e i) (e j)).val*10+(max (e i) (e j)).val)=false := by
    obtain ⟨e,ext⟩ := Equiv.Perm.exists_extending_pair (fun i : Fin d => Fin.castLE le i)
      (fun i => f i) (Fin.castLE_injective _) f.injective
    refine ⟨e.symm.toEmbedding,?_⟩
    intro i j adj
    change mat.testBit ((min (e.symm i) (e.symm j)).val*10+(max (e.symm i) (e.symm j)).val)=false
    cases h : mat.testBit ((min (e.symm i) (e.symm j)).val*10+(max (e.symm i) (e.symm j)).val) with
    | false => rfl
    | true =>
      obtain ⟨a,b,ha,hb,edgeAB⟩ := support _ _ h
      have bad := embed a b edgeAB
      rw [← ext a, ← ext b, ha,hb,e.apply_symm_apply,e.apply_symm_apply] at bad
      exact (bad.2 adj).elim

  rintro ⟨A2,A3,A4,A5,A6,A7,A8,A9,s1,s2,s3,s4,s5,s6,s7,s8,s9⟩
  have step1 {V : Type} [Fintype V] (G : SimpleGraph V) (size : Fintype.card V=1)
      (_e : 0≤G.edgeSet.ncard) : Found G ∨ Listed G 1 ([0] : List ℕ) := by
    right
    let f : Fin 1 ≃ V := Fintype.equivOfCardEq (by simpa using size.symm)
    refine ⟨0,by decide,f,?_⟩
    intro i j
    have h : i=j := Subsingleton.elim _ _
    subst j
    simp [edge]


  have step2 {W : Type} [Fintype W] (H : SimpleGraph W) (size : Fintype.card W=2)
      (many : 1≤H.edgeSet.ncard) : Found H ∨ Listed H 2 A2 := by
    obtain ⟨tbl,ok⟩ := s1.2
    exact grow (n:=1) s1.1 ok (by intros; omega) (fun J h z => step1 J h z) H size many

  have step3 {W : Type} [Fintype W] (H : SimpleGraph W) (size : Fintype.card W=3)
      (many : 3≤H.edgeSet.ncard) : Found H ∨ Listed H 3 A3 := by
    obtain ⟨tbl,ok⟩ := s2.2
    exact grow (n:=2) s2.1 ok (by intros; omega) (fun J h z => step2 J h z) H size many

  have step4 {W : Type} [Fintype W] (H : SimpleGraph W) (size : Fintype.card W=4)
      (many : 5≤H.edgeSet.ncard) : Found H ∨ Listed H 4 A4 := by
    obtain ⟨tbl,ok⟩ := s3.2
    exact grow (n:=3) s3.1 ok (by intros; omega) (fun J h z => step3 J h z) H size many

  have step5 {W : Type} [Fintype W] (H : SimpleGraph W) (size : Fintype.card W=5)
      (many : 7≤H.edgeSet.ncard) : Found H ∨ Listed H 5 A5 := by
    obtain ⟨tbl,ok⟩ := s4.2
    exact grow (n:=4) s4.1 ok (by intros; omega) (fun J h z => step4 J h z) H size many

  have step6 {W : Type} [Fintype W] (H : SimpleGraph W) (size : Fintype.card W=6)
      (many : 10≤H.edgeSet.ncard) : Found H ∨ Listed H 6 A6 := by
    obtain ⟨tbl,ok⟩ := s5.2
    exact grow (n:=5) s5.1 ok (by intros; omega) (fun J h z => step5 J h z) H size many

  have step7 {W : Type} [Fintype W] (H : SimpleGraph W) (size : Fintype.card W=7)
      (many : 14≤H.edgeSet.ncard) : Found H ∨ Listed H 7 A7 := by
    obtain ⟨tbl,ok⟩ := s6.2
    exact grow (n:=6) s6.1 ok (by intros; omega) (fun J h z => step6 J h z) H size many

  have step8 {W : Type} [Fintype W] (H : SimpleGraph W) (size : Fintype.card W=8)
      (many : 18≤H.edgeSet.ncard) : Found H ∨ Listed H 8 A8 := by
    obtain ⟨tbl,ok⟩ := s7.2
    exact grow (n:=7) s7.1 ok (by intros; omega) (fun J h z => step7 J h z) H size many

  have step9 {W : Type} [Fintype W] (H : SimpleGraph W) (size : Fintype.card W=9)
      (many : 22≤H.edgeSet.ncard) : Found H ∨ Listed H 9 A9 := by
    obtain ⟨tbl,ok⟩ := s8.2
    exact grow (n:=8) s8.1 ok (by intros; omega) (fun J h z => step8 J h z) H size many

  have step10 {W : Type} [Fintype W] (H : SimpleGraph W) (size : Fintype.card W=10)
      (many : 27≤H.edgeSet.ncard) : Found H ∨ Listed H 10 [35184196563136,35184151143560,35184156285512,35149824432712,35167004301896,35183110429256,17591998126664,35184184171080,35132652824914,35141242759506,17557646649682,26353739671890,30751786182994,32950809438546,35149832694098,17592006388050,35184192432466] := by
    obtain ⟨tbl,ok⟩ := s9.2
    exact grow (n:=9) s9.1 ok (by intros; omega) (fun J h z => step9 J h z) H size many
  have many : 27 ≤ Gᶜ.edgeSet.ncard := by
    classical
    have dis : Disjoint G.edgeFinset Gᶜ.edgeFinset := SimpleGraph.disjoint_edgeFinset.mpr disjoint_compl_right
    have hh := Finset.card_union_of_disjoint dis
    rw [← SimpleGraph.edgeFinset_sup] at hh
    simp only [SimpleGraph.edgeFinset_card,Set.fintypeCard_eq_ncard] at hh
    rw [sup_compl_eq_top] at hh
    have top : (⊤ : SimpleGraph (Fin 10)).edgeSet.ncard=45 := by
      rw [← Set.fintypeCard_eq_ncard, ← SimpleGraph.edgeFinset_card, SimpleGraph.card_edgeFinset_top_eq_card_choose_two]
      decide
    rw [top] at hh
    omega
  rcases step10 Gᶜ (Fintype.card_fin _) many with ⟨f,embed⟩|⟨m,hm,f,rep⟩
  · left
    exact matrix_of_map (src:=5383799) (by decide : 8≤10) (by decide +kernel) f embed
  · exact Or.inr ⟨m,hm,f,rep⟩

theorem census (G : SimpleGraph (Fin 10)) (edges : G.edgeSet.ncard ≤ 18) : Outcome G :=
  from_stages G edges SmallTen.numerical_stages

end SmallTenResidual
