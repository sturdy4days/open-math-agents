import RangeBase
import TenProof

/-! The two order-ten sparse placements finish the localized F consequence. -/
open SimpleGraph Erdos1182
namespace BBHRange

theorem ten_sparse (primary : Cert 10 618970019714747783169716278)
    (secondary : Cert 10 72057645653176374) : F 10 = 18 := by
  apply le_antisymm SmallTable.Sparse.upper10
  exact lower_F (by decide) (by decide) _ (fun G _ => SmallTen.ten_sparse G)
    (by simp [primary,secondary])

theorem remaining_sparse :
    OMA.R_Erdos1182_erdos_1182_variants_small_values_R2.H1 ↔
    OMA.R_Erdos1182_erdos_1182_variants_small_values_R2_H1_R1.H2 := by
  refine ⟨fun h k => ?_,OMA.R_Erdos1182_erdos_1182_variants_small_values_R2_H1_R1.main OMA.solution⟩
  fin_cases k
  · exact h 2
  · exact h 3

theorem local_cases_of_H2 (h : OMA.R_Erdos1182_erdos_1182_variants_small_values_R2.H2) :
    Cert 9 2251801971660822 ∧ Cert 10 618970019714747783169716278 ∧ Cert 10 72057645653176374 :=
  ⟨h 2 _ (by decide),h 3 _ (by decide),h 3 _ (by decide)⟩

end BBHRange
