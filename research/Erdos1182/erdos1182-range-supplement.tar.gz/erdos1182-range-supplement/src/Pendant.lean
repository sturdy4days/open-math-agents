import OMAReductions.R_Erdos1182_erdos_1182_variants_small_values_R2
import Mathlib.Combinatorics.SimpleGraph.Operations
import Mathlib.Data.Fin.Tuple.Basic

/-! Extending a triangle-good graph by a pendant edge preserves triangle-goodness. -/
open SimpleGraph Erdos1182
namespace BBHPendant

/-- Keep the old vertices at successors and attach vertex zero at the prescribed anchor. -/
def extend {n : ℕ} (G : SimpleGraph (Fin n)) (a : Fin n) : SimpleGraph (Fin (n+1)) :=
  G.map (Fin.succEmb n) ⊔ edge 0 a.succ

theorem connected {n : ℕ} {G : SimpleGraph (Fin n)} (hc : G.Connected) (a : Fin n) :
    (extend G a).Connected := by
  let f : G →g extend G a := ⟨Fin.succ,fun h => Or.inl (map_adj_apply.mpr h)⟩
  have anchor : (extend G a).Adj 0 a.succ :=
    Or.inr ((edge_adj ..).mpr ⟨Or.inl ⟨rfl,rfl⟩,a.succ_ne_zero.symm⟩)
  have all (i : Fin (n+1)) : (extend G a).Reachable 0 i := by
    refine Fin.cases (.refl _) (fun j => ?_) i
    exact anchor.reachable.trans ((hc.preconnected a j).map f)
  exact ⟨fun i j => (all i).symm.trans (all j)⟩

theorem count {n : ℕ} (G : SimpleGraph (Fin n)) (a : Fin n) :
    (extend G a).edgeSet.ncard = G.edgeSet.ncard+1 := by
  classical
  have fresh : ¬(G.map (Fin.succEmb n)).Adj 0 a.succ := by
    rintro h
    obtain ⟨b,c,_,hb,_⟩ := (map_adj ..).mp h
    exact b.succ_ne_zero hb
  have absent : s(0,a.succ) ∉ (G.map (Fin.succEmb n)).edgeSet := fresh
  rw [extend,edgeSet_sup,edgeSet_edge_of_ne a.succ_ne_zero.symm,Set.union_singleton,
    Set.ncard_insert_of_notMem absent,edgeSet_map,Set.ncard_image_of_injective _ (Fin.succEmb n).sym2Map.injective]

theorem good {n : ℕ} (hn : 2 ≤ n) {G : SimpleGraph (Fin n)} (hc : G.Connected)
    (goodG : IsTriangleGood G) (a : Fin n) : IsTriangleGood (extend G a) := by
  classical
  apply SmallTable.Sparse.sufficient (by omega) _ (connected hc a)
  intro C ht
  let h := 2*(n+1)-1
  by_cases high : ∃ v, n+1 ≤ C.degree v
  · obtain ⟨v,hv⟩ := high
    let S := C.neighborFinset v
    have enough : n+1 ≤ Fintype.card S := by
      rw [Fintype.card_coe,C.card_neighborFinset_eq_degree]
      exact hv
    let emb := (Fin.castLEEmb enough).trans (Fintype.equivFin S).symm.toEmbedding
    have blue : Cᶜ.IsClique (S : Set (Fin h)) := by
      rw [isClique_compl]
      simpa only [S,coe_neighborFinset] using isIndepSet_neighborSet_of_triangleFree C ht v
    refine ⟨⟨⟨fun i => (emb i).val,fun e => blue (emb _).property (emb _).property
      (fun eq => e.ne (emb.injective (Subtype.ext eq)))⟩,fun i j eq => emb.injective (Subtype.ext eq)⟩⟩
  · have low (v : Fin h) : C.degree v ≤ n := by
      by_contra! hh
      exact high ⟨v,hh⟩
    let ι := Fin.castLEEmb (show 2*n-1 ≤ h by dsimp [h]; omega)
    have sub : C.comap ι ⊑ C := (Embedding.comap ι C).isContained
    obtain ⟨old⟩ := (SmallTable.Dense.good_iff hn hc).mp goodG (C.comap ι) (ht.comap sub)
    let b := old.toEmbedding.trans ι
    have blue {i j} (e : G.Adj i j) : Cᶜ.Adj (b i) (b j) :=
      ⟨b.injective.ne e.ne,(old.toHom.map_adj e).2⟩
    let used := Finset.univ.map b
    have card : used.card = n := by simp [used]
    have center : b a ∈ used := Finset.mem_map.mpr ⟨a,Finset.mem_univ _,rfl⟩
    let N := Cᶜ.neighborFinset (b a)
    have deg := C.degree_compl (b a)
    rw [Fintype.card_fin] at deg
    have big : used.card < (insert (b a) N).card := by
      rw [Finset.card_insert_of_notMem (Cᶜ.notMem_neighborFinset_self _),card]
      rw [card_neighborFinset_eq_degree]
      have := low (b a)
      omega
    obtain ⟨w,hw,out⟩ := Finset.exists_mem_notMem_of_card_lt_card big
    have adj : Cᶜ.Adj (b a) w := (Cᶜ.mem_neighborFinset _ _).mp
      ((Finset.mem_insert.mp hw).resolve_left (fun eq => out (eq ▸ center)))
    have notRange : w ∉ Set.range b := by
      rintro ⟨i,rfl⟩
      exact out (Finset.mem_map.mpr ⟨i,Finset.mem_univ _,rfl⟩)
    let emb : Fin (n+1) ↪ Fin h := ⟨Fin.cons w b, Fin.cons_injective_of_injective notRange b.injective⟩
    refine isContained_iff_exists_le_comap.mpr ⟨emb,sup_le ?_ ?_⟩
    · rintro i j e
      obtain ⟨x,y,hxy,rfl,rfl⟩ := (map_adj ..).mp e
      exact blue hxy
    · intro i j hEdge
      rcases (edge_adj ..).mp hEdge with ⟨(⟨rfl,rfl⟩ | ⟨rfl,rfl⟩),_⟩
      · exact adj.symm
      · exact adj

theorem witness_succ {n q : ℕ} (hn : 2 ≤ n)
    (has : ∃ G : SimpleGraph (Fin n), G.Connected ∧ G.edgeSet.ncard=q ∧ IsTriangleGood G) :
    ∃ G : SimpleGraph (Fin (n+1)), G.Connected ∧ G.edgeSet.ncard=q+1 ∧ IsTriangleGood G := by
  obtain ⟨G,hc,size,hg⟩ := has
  let a : Fin n := ⟨0,by omega⟩
  exact ⟨extend G a,connected hc a,(count G a).trans (by rw [size]),good hn hc hg a⟩

end BBHPendant
