# Finite Ramsey bounds for Erdős 1182

The main new implication requires one concrete host certificate. If the secondary order-ten template, mask 72057645653176374, has that certificate, then **F(10) = 18 and f(10) = 33**. The certificate is still an open input to this implication. A separate unconditional theorem gives **f(n) ≥ n + 12 for every n ≥ 8** by appending pendant edges to the verified order-eight example.

The order-ten argument checks 85 embeddings, one for each combination of 17 terminal graphs and five maximal triangle-free colorings on the template. Direct embedding into this template works for every connected ten-vertex graph with at most 17 edges. A connected 18-edge example formed from K₄,₄ and two leaves shows that this direct embedding threshold is sharp. The original Ramsey implication still holds at 18 edges under the host certificate. The distinction is formalized in `src/SecondaryLimit.lean` and `src/Results.lean`.

Other endpoints give F(9) = 16 and f(9) = 27 conditional on one host certificate, and eliminate orders nine and ten from the sparse placement hypothesis R2.H1. See `src/Evidence.lean`, `src/AuditExact.lean`, and `src/AlternativeMasks.lean` for the corresponding definitions and hypotheses.

## Reproduce

Download the frozen 907-module base archive from the immutable fork commit. The supplement adds 21 source modules. Python 3.10 or later suffices for file verification.

```sh
curl -fL --output erdos1182-upper-sources.tar.gz https://raw.githubusercontent.com/sturdy4days/open-math-agents/1a08bcf2ca9c68ffebb9cc7e1e1b8c7fa721cc15/research/Erdos1182/erdos1182-upper-sources.tar.gz
python3 replay.py --base-archive erdos1182-upper-sources.tar.gz --verify-only
```

To recompile, use the pinned Formal Conjectures checkout and its own Lake dependencies. Run these commands from the extracted supplement directory, keeping the absolute paths across the directory change.

```sh
supplement=$(pwd)
git clone https://github.com/google-deepmind/formal-conjectures.git fc
git -C fc checkout --detach 9097e2f90e66d2f6244209cb1c07f7120d17ec53
cd fc
lake exe cache get
lake build FormalConjectures.ErdosProblems.«1182»
lake env python3 "$supplement/replay.py" --base-archive "$supplement/erdos1182-upper-sources.tar.gz" --build-dir "$supplement/build"
```

Lean 4.33.1 and Mathlib commit `0df444a360eaa60ab8c11dca51a86af692955474` are pinned by the checkout. Starting with an empty build directory replays both archives from source in dependency order. For a quicker focused replay, append e.g. `--target Results`. The default roots are `Results`, `Evidence`, `AuditExact`, `Carry`, and `SecondaryLimit`. They are compiled as separate modules because two constituent project proofs reuse the public name `OMA.solution`. An optional `--verified-cache` may point to an existing tree of object files. The runner only reuses dependencies with the recorded object digest and always recompiles the requested roots. Full dependency replay is sequential and can require more than 12 GiB of RAM. Each Lean invocation writes its output in `build/logs/`.

`SHA256SUMS` covers the files in this supplement. `manifest.json` gives the exact base version, Lean sources, imports, kernel-object digests and recorded axiom audits. The verifier checks every one of the 907 base sources and all supplementary sources, and reproduces the order-eight extraction. The optional independent finite checker can be run with `python3 provenance/verify_transports.py`. Measurements and axiom reports from the original component runs are in `audit/`. The order-eight donor emits pre-existing proof-style warnings.

## Sources and credit

The template classification follows Stephan Brandt, Gunnar Brinkmann and Thomas Harmuth, “All Ramsey numbers r(K₃,G) for connected graphs of order 9,” *Electronic Journal of Combinatorics* 5 (1998), R7. [Article](https://www.combinatorics.org/ojs/index.php/eljc/article/download/v5i1r7/pdf)

The unconditional order-eight certificate is extracted from **KoaOkano**’s contribution to Open Math Agents, PR #13482. The authenticated commit and Git object are recorded in `provenance/donor-receipt.json`. The complete original is preserved in `provenance/order8-original.lean`; `verify_order8.py` checks both the Git blob and the extracted bytes. That PR was open when the source was verified. [Immutable source](https://github.com/KoaOkano/open-math-agents/blob/ebfdc66117f52c6cdee3e2ca0721a715d9dc7720/proofs/Erdos1182.erdos_1182.variants.small_values.R1.H2.R1.H1.R1.H2.lean)

The base archive supplies the upper table and R2 carrier. The supplement includes the earlier local order-nine and order-ten sparse verifiers and all connecting proofs. Source notices are retained. [Signed base commit](https://github.com/sturdy4days/open-math-agents/commit/1a08bcf2ca9c68ffebb9cc7e1e1b8c7fa721cc15)
