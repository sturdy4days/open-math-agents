#!/usr/bin/env python3
"""Verify the two source archives and replay the chosen finite Ramsey results."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
BASE = "erdos1182-upper/"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def require(test, message):
    if not test:
        raise ValueError(message)


def imports(source):
    return [name for line in source.decode().splitlines() if line.startswith("import ")
            for name in line.split("--", 1)[0].split()[1:]]


def verify():
    for entry in (HERE / "SHA256SUMS").read_text().splitlines():
        expected, name = entry.split("  ", 1)
        require(digest((HERE / name).read_bytes()) == expected, f"changed file: {name}")
    manifest = json.loads((HERE / "manifest.json").read_bytes())
    base = manifest["base"]
    require(digest(args.base_archive.read_bytes()) == base["sha256"], "wrong upper archive")
    with tarfile.open(args.base_archive) as tar:
        def read(name):
            return tar.extractfile(BASE + name).read()
        encoded = read("manifest.json")
        require(digest(encoded) == base["manifestSHA256"], "wrong upper manifest")
        upper = json.loads(encoded)
        article = read("upstream/FormalConjectures/ErdosProblems/1182.lean")
        require(digest(article) == upper["originalArticleSha256"], "changed upstream article")
        entries = list(upper["dependencyOrder"])
        require(len(entries) == base["modules"], "upper module count changed")
        sources = {r["name"]: read("src/" + r["source"]) for r in entries}
    additions = manifest["dependencyOrder"]
    entries += additions
    sources.update({r["name"]: (HERE / "src" / r["source"]).read_bytes() for r in additions})
    known = {r["name"] for r in entries}
    seen = set()
    for r in entries:
        name = r["name"]
        data = sources[name]
        require(name not in seen and len(data) == r["bytes"] and digest(data) == r["sha256"],
                f"duplicate or altered source: {name}")
        require(imports(data) == r["imports"], f"unrecorded dependency in {name}")
        for dep in r["imports"]:
            if dep in known:
                require(dep in seen, f"dependency order: {name} before {dep}")
            else:
                require(dep.split(".")[0] in ("Mathlib", "FormalConjectures", "Lean", "Std", "Init"),
                        f"missing source {dep} required by {name}")
        seen.add(name)
    subprocess.run([os.sys.executable, str(HERE / "provenance" / "verify_order8.py")], check=True)
    print(f"Verified {base['modules']} base modules and {len(additions)} supplementary modules.",
          flush=True)
    return manifest, entries, sources


def replay(manifest, entries, sources):
    records = {r["name"]: r for r in entries}
    roots = args.target or manifest["roots"]
    desired = set()

    def visit(name):
        if name in desired:
            return
        for dep in records[name]["imports"]:
            if dep in records:
                visit(dep)
        desired.add(name)

    for name in roots:
        require(name in manifest["roots"] or name in {r["name"] for r in manifest["dependencyOrder"]},
                f"unknown supplementary target {name}")
        visit(name)
    lean = shutil.which(args.lean)
    require(lean, "Lean not found; use the pinned Formal Conjectures lake env")
    version = subprocess.check_output([lean, "--version"], text=True)
    require("version 4.33.1," in version, f"incorrect Lean version: {version}")
    out = args.build_dir.resolve()
    src, lib, logs = (out / k for k in ("src", "lib", "logs"))
    paths = [str(Path(p).resolve()) for p in os.environ.get("LEAN_PATH", "").split(os.pathsep) if p]
    env = dict(os.environ, LEAN_PATH=os.pathsep.join([str(lib), *paths]), LEAN_NUM_THREADS="1")
    old = args.verified_cache.resolve() if args.verified_cache else None
    built = reused = 0
    for r in entries:
        name = r["name"]
        if name not in desired:
            continue
        rel = Path(r["source"])
        source = src / rel
        obj = lib / rel.with_suffix(".olean")
        obj.parent.mkdir(parents=True, exist_ok=True)
        if old and name not in roots:
            candidate = old / rel.with_suffix(".olean")
            if candidate.exists() and digest(candidate.read_bytes()) == r["verifiedObjectSha256"]:
                shutil.copyfile(candidate, obj)
                for suffix in (".olean.server", ".olean.private", ".ir"):
                    side = old / rel.with_suffix(suffix)
                    if side.is_file():
                        shutil.copyfile(side, lib / rel.with_suffix(suffix))
                reused += 1
                continue
        source.parent.mkdir(parents=True, exist_ok=True)
        source.write_bytes(sources[name])
        log = logs / rel.with_suffix(".log")
        log.parent.mkdir(parents=True, exist_ok=True)
        print(f"Compiling {name}", flush=True)
        with log.open("wb") as capture:
            result = subprocess.run([lean, "-j1", f"-M{args.memory_mib}", "-o", str(obj),
                                     str(rel)], cwd=src, env=env, stdout=capture,
                                    stderr=subprocess.STDOUT)
        if result.returncode:
            raise SystemExit(f"Lean failed on {name}; see {log}")
        built += 1
    print(f"Kernel replay completed. Compiled {built} module(s); reused {reused} verified object(s).")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-archive", type=Path, required=True)
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument("--target", action="append", help="supplement module; repeat for more")
    parser.add_argument("--build-dir", type=Path, default=Path("erdos1182-range-build"))
    parser.add_argument("--verified-cache", type=Path, help="optional tree of previously checked objects")
    parser.add_argument("--lean", default="lean")
    parser.add_argument("--memory-mib", type=int, default=15000)
    args = parser.parse_args()
    verified = verify()
    if not args.verify_only:
        replay(*verified)
