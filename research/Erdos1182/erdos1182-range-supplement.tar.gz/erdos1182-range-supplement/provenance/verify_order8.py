"""Reconstruct the exact filtered order-eight source and check its immutable Git blob."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parents[1]
receipt = json.loads((root / "provenance" / "donor-receipt.json").read_bytes())
original = (root / "provenance" / "order8-original.lean").read_bytes()
git_blob = b"blob " + str(len(original)).encode() + b"\0" + original
if (len(original) != receipt["bytes"] or hashlib.sha256(original).hexdigest() != receipt["sha256"]
        or hashlib.sha1(git_blob).hexdigest() != receipt["git_blob_sha1"]):
    raise SystemExit("order-eight donor does not match its immutable Git object")
source = original.decode()
header = source[source.index("/-!"):source.index("namespace Order7")]
order8 = source[source.index("namespace Order8"):source.index("-- Lean formalization")]
imports = ("import Mathlib.Combinatorics.SimpleGraph.Clique\n"
           "import Mathlib.Data.Fin.Tuple.Embedding\n"
           "import Mathlib.Data.Nat.Bitwise\n\n")
credit = "/- Order-eight specialization of @KoaOkano, OMA PR #13482. -/\n"
if (imports + credit + header + order8).encode() != (root / "src" / "EightPrimary.lean").read_bytes():
    raise SystemExit("order-eight extraction differs")
print("Verified KoaOkano's original Git blob and the order-eight extraction.")
