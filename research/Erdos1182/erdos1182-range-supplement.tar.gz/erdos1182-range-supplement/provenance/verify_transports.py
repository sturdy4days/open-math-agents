"""Independent, direct finite verification of the 85 injections in RedTransports.lean."""
from pathlib import Path
from itertools import combinations
import json,re,hashlib
w=Path(__file__).resolve().parents[1]/'src'
s=(w/'RedTransports.lean').read_text()
tri=[(i,j) for j in range(10) for i in range(j)]
base=72057645653176374
allowed=[5383765,5383766,5383781,5383782,5383795]
edges=[(i,j) for (i,j) in tri if base>>(10*i+j)&1]
def triangular(e):return sum(1<<(j*(j-1)//2+i) for i,j in e)
def triangle_free(E):
 return not any(all((a,b) in E for a,b in combinations(v,2)) for v in combinations(range(10),3))
valid=[]
for sub in range(2**len(edges)):
 graph={e for i,e in enumerate(edges) if sub>>i&1}
 if triangle_free(graph):
  assert any(triangular(graph)&r==triangular(graph) for r in allowed)
  valid.append(triangular(graph))
assert set(allowed)=={x for x in valid if all(x==y or x&y!=x for y in valid)}
words={int(m):list(map(int,row.split(','))) for m,row in re.findall(r'\((\d+),!\[([\d,]+)\]\)',s)}
original=list(map(int,re.search(r'def terminals : List ℕ := \[([0-9,]+)\]',(w/'TerminalCensus.lean').read_text()).group(1).split(',')));assert list(words)==original
for m,ws in words.items():
 for word,r in zip(ws,allowed,strict=True):
  P=[(word>>(4*i))%16 for i in range(10)];assert len(set(P))==10 and max(P)==9
  mapped=triangular({tuple(sorted((P[i],P[j]))) for x,(i,j) in enumerate(tri) if r>>x&1})
  assert mapped&m==mapped
receipt={'secondary_forbidden_matrix':base,'examined_red_subgraphs':2**len(edges),'triangle_free_subgraphs':len(valid),'maximal_triangle_free_masks':allowed,'terminals':len(original),'verified_permutations':5*len(original),'transports_sha256':hashlib.sha256(s.encode()).hexdigest()}
assert receipt==json.loads((w.parent/'provenance/secondary-numeric.json').read_text())
print(receipt)
