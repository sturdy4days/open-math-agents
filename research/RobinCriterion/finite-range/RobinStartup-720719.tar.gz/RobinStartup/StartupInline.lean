import Mathlib.Algebra.BigOperators.Field
import Mathlib.Algebra.Field.GeomSum
import Mathlib.Analysis.Calculus.Deriv.MeanValue
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
import Mathlib.NumberTheory.ArithmeticFunction.Misc
import Mathlib.NumberTheory.Harmonic.Bounds
import Mathlib.NumberTheory.Harmonic.EulerMascheroni
import Mathlib.Tactic
import Mathlib.Tactic.NormNum.Prime

/- Pinned donor: Robin1984 by Jonas Whidden, Apache-2.0, e3697139babfe0f6cc7a76a08bf41a92aa7a2978.
   The registered divisor-sum identification follows FCRobinLagarias.Robin by Sky.
   The dependencies, original notices, source files, and patches are recorded in the adjoining verified source bundle. -/

/- Inlined module Robin1984.Arithmetic.Definitions. -/
section

/-!
## Provenance

- Classification: **Direct source formalization**.
- Mathematical source: Guy Robin, Grandes valeurs de la fonction somme des diviseurs et hypothese de Riemann (1984).
- Formalization note: The retained statement or source-level argument is Robin's; the Lean encoding, exact constants, and proof decomposition are the formalization authors' work.
- PROVENANCE-END
-/

/-!
# Core Robin definitions

This module gives the divisor sum, Robin's pointwise inequality, and its
quantified form above the exceptional cutoff `5040`.
-/

namespace Robin1984.Core

/-- Sum of divisors `sigma(n)`, using Mathlib's arithmetic-function definition. -/
noncomputable def sigmaOneNat (n : Nat) : Nat :=
  ArithmeticFunction.sigma 1 n

/-- Robin's inequality for a single natural number. -/
noncomputable def NativeRobinInequality (n : Nat) : Prop :=
  (sigmaOneNat n : Real) <
    Real.exp Real.eulerMascheroniConstant * (n : Real) *
      Real.log (Real.log (n : Real))

/-- Robin's inequality for every natural number greater than `5040`. -/
noncomputable def NativeRobinInequalityAll : Prop :=
  forall n : Nat, 5040 < n -> NativeRobinInequality n


end Robin1984.Core

namespace Robin1984

/-- Public sum-of-divisors vocabulary used by the Palomar theorem surface. -/
noncomputable def sigmaOneNat (n : Nat) : Nat :=
  ArithmeticFunction.sigma 1 n

end Robin1984
end

/- Inlined module Robin1984.Helpers.Event. -/
section

/-!
## Provenance

- Classification: **Primarily project-original**.
- Mathematical source: No external theorem is directly formalized; published inputs retain their attribution in the imported modules and project bibliography.
- Formalization note: The retained definitions, interfaces, reductions, or proof assembly are primarily original to this formalization.
- PROVENANCE-END
-/

/-!
# Exact colossally abundant marginal events

An event raises one prime exponent by one.  Its logarithmic gain and threshold
give an exact finite representation of the fixed-parameter colossally
abundant objective.
-/

namespace Robin1984
/-- A marginal event `(p, j)` raises the exponent of `p` from `j - 1` to `j`. -/
structure Event where
  p : ℕ
  j : ℕ
  hp : Nat.Prime p
  hj : 0 < j
deriving Repr, DecidableEq

namespace Event

/-- The exact logarithmic gain in `σ(n)/n` from a marginal event. -/
noncomputable def gain (e : Event) : ℝ :=
  Real.log ((1 - (e.p : ℝ) ^ (-(e.j + 1 : ℤ))) /
    (1 - (e.p : ℝ) ^ (-(e.j : ℤ))))

/-- The event threshold, used to order CA marginal events. -/
noncomputable def threshold (e : Event) : ℝ :=
  e.gain / Real.log e.p


lemma prime_pos (e : Event) : 0 < (e.p : ℝ) := by
  exact_mod_cast Nat.Prime.pos e.hp

lemma log_prime_pos (e : Event) : 0 < Real.log (e.p : ℝ) := by
  exact Real.log_pos (by exact_mod_cast e.hp.one_lt)

lemma threshold_mul_log (e : Event) :
    e.threshold * Real.log e.p = e.gain := by
  unfold threshold
  field_simp [ne_of_gt e.log_prime_pos]

lemma gain_eq_firstLayerContinuousGain_of_j_eq_one
    {e : Event}
    (hj : e.j = 1) :
    e.gain = Real.log (1 + (e.p : ℝ)⁻¹) := by
  unfold gain
  rw [hj]
  have hpne : (e.p : ℝ) ≠ 0 := ne_of_gt e.prime_pos
  have hpone : (e.p : ℝ) ≠ 1 := by
    have hpgt : (1 : ℝ) < e.p := by exact_mod_cast e.hp.one_lt
    exact ne_of_gt hpgt
  have hden : 1 - (e.p : ℝ) ^ (-(1 : ℤ)) ≠ 0 := by
    have hpgt : (1 : ℝ) < e.p := by exact_mod_cast e.hp.one_lt
    have hinvlt : (e.p : ℝ)⁻¹ < 1 := inv_lt_one_of_one_lt₀ hpgt
    rw [zpow_neg, zpow_one]
    linarith
  have hratio :
      (1 - ((e.p : ℝ) ^ 2)⁻¹) / (1 - ((e.p : ℝ))⁻¹) =
        1 + 1 / (e.p : ℝ) := by
    have hden' : -1 + (e.p : ℝ) ≠ 0 := by
      intro h
      apply hpone
      linarith
    field_simp [hpne, hden']
    ring
  norm_num
  exact (congrArg Real.log hratio).trans (by simp [one_div])

lemma threshold_eq_firstLayer_of_j_eq_one
    {e : Event}
    (hj : e.j = 1) :
    e.threshold = Real.log (1 + (e.p : ℝ)⁻¹) / Real.log (e.p : ℝ) := by
  unfold threshold
  rw [gain_eq_firstLayerContinuousGain_of_j_eq_one hj]

end Event

end Robin1984
end

/- Inlined module Robin1984.Arithmetic.RobinBounds. -/
section

/-!
## Provenance

- Classification: **Primarily project-original**.
- Mathematical source: No external theorem is directly formalized; published inputs retain their attribution in the imported modules and project bibliography.
- Formalization note: The retained definitions, interfaces, reductions, or proof assembly are primarily original to this formalization.
- PROVENANCE-END
-/

/-!
# Divisor ratios and Robin's comparison bound

This module collects the elementary arithmetic and logarithmic comparisons
used throughout the finite, colossally abundant, and analytic parts of the
formalization.
-/

namespace Robin1984

/-- The abundancy ratio `sigma(n) / n`, regarded as a real number. -/
noncomputable def abundancy (n : Nat) : Real :=
  (Core.sigmaOneNat n : Real) / (n : Real)

/-- The right-hand side of Robin's inequality after division by `n`. -/
noncomputable def robinBoundRatio (n : Nat) : Real :=
  Real.exp Real.eulerMascheroniConstant * Real.log (Real.log (n : Real))

/-- The reciprocal logarithmic scale attached to the Robin bound. -/
noncomputable def robinFrontierCutoff (n : Nat) : Real :=
  (Real.log (n : Real) * Real.log (Real.log (n : Real)))⁻¹

/-- The Robin comparison ratio is positive above the exceptional cutoff. -/
theorem robinBoundRatio_pos_of_cutoff
    {n : Nat} (hnCut : 5040 < n) :
    0 < robinBoundRatio n := by
  unfold robinBoundRatio
  have hnPos : (0 : Real) < (n : Real) := by
    exact_mod_cast (Nat.zero_lt_of_lt hnCut)
  have hlogGtOne : (1 : Real) < Real.log (n : Real) := by
    rw [Real.lt_log_iff_exp_lt hnPos]
    exact lt_trans Real.exp_one_lt_three
      (by exact_mod_cast (by omega : 3 < n))
  have hloglogPos : 0 < Real.log (Real.log (n : Real)) :=
    Real.log_pos hlogGtOne
  positivity

/-- Logarithmic form of the Robin comparison ratio above the cutoff. -/
theorem log_robinBoundRatio_eq_of_cutoff
    {n : Nat} (hnCut : 5040 < n) :
    Real.log (robinBoundRatio n) =
      Real.eulerMascheroniConstant +
        Real.log (Real.log (Real.log (n : Real))) := by
  unfold robinBoundRatio
  have hnPos : (0 : Real) < (n : Real) := by
    exact_mod_cast (Nat.zero_lt_of_lt hnCut)
  have hlogGtOne : (1 : Real) < Real.log (n : Real) := by
    rw [Real.lt_log_iff_exp_lt hnPos]
    exact lt_trans Real.exp_one_lt_three
      (by exact_mod_cast (by omega : 3 < n))
  have hloglogPos : 0 < Real.log (Real.log (n : Real)) :=
    Real.log_pos hlogGtOne
  rw [Real.log_mul (Real.exp_ne_zero _) (ne_of_gt hloglogPos), Real.log_exp]

/-- The Robin frontier cutoff is positive above the exceptional cutoff. -/
theorem robinFrontierCutoff_pos_of_cutoff
    {n : Nat} (hnCut : 5040 < n) :
    0 < robinFrontierCutoff n := by
  have hnPos : (0 : Real) < (n : Real) := by
    exact_mod_cast (Nat.zero_lt_of_lt hnCut)
  have hlogPos : 0 < Real.log (n : Real) := by
    exact Real.log_pos (by exact_mod_cast (by omega : 1 < n))
  have hlogGtOne : (1 : Real) < Real.log (n : Real) := by
    rw [Real.lt_log_iff_exp_lt hnPos]
    exact lt_trans Real.exp_one_lt_three
      (by exact_mod_cast (by omega : 3 < n))
  have hloglogPos : 0 < Real.log (Real.log (n : Real)) :=
    Real.log_pos hlogGtOne
  unfold robinFrontierCutoff
  exact inv_pos.mpr (mul_pos hlogPos hloglogPos)

/-- Robin's inequality rewritten after division by the positive integer `n`. -/
theorem nativeRobinInequality_iff_abundancy_lt_bound
    {n : Nat} (hn : 0 < n) :
    Core.NativeRobinInequality n <-> abundancy n < robinBoundRatio n := by
  unfold Core.NativeRobinInequality abundancy robinBoundRatio
  have hnReal : (0 : Real) < (n : Real) := by exact_mod_cast hn
  constructor
  . intro h
    have hdiv := div_lt_div_of_pos_right h hnReal
    have hright :
        (Real.exp Real.eulerMascheroniConstant * (n : Real) *
            Real.log (Real.log (n : Real))) / (n : Real) =
          Real.exp Real.eulerMascheroniConstant *
            Real.log (Real.log (n : Real)) := by
      field_simp [hnReal.ne']
    simpa [abundancy, robinBoundRatio, hright] using hdiv
  . intro h
    have hmul := mul_lt_mul_of_pos_right h hnReal
    have hleft :
        ((Core.sigmaOneNat n : Real) / (n : Real)) * (n : Real) =
          (Core.sigmaOneNat n : Real) := by
      field_simp [hnReal.ne']
    have hright :
        (Real.exp Real.eulerMascheroniConstant *
            Real.log (Real.log (n : Real))) * (n : Real) =
          Real.exp Real.eulerMascheroniConstant * (n : Real) *
            Real.log (Real.log (n : Real)) := by
      ring
    simpa [abundancy, robinBoundRatio, hleft, hright] using hmul

/-- The Robin frontier cutoff is antitone above the exceptional cutoff. -/
theorem robinFrontierCutoff_antitone_above_cutoff
    {n m : Nat} (hnCut : 5040 < n) (hnm : n <= m) :
    robinFrontierCutoff m <= robinFrontierCutoff n := by
  have hnPosNat : 0 < n := Nat.zero_lt_of_lt hnCut
  have hmPosNat : 0 < m := lt_of_lt_of_le hnPosNat hnm
  have hnRealPos : (0 : Real) < (n : Real) := by exact_mod_cast hnPosNat
  have hmRealPos : (0 : Real) < (m : Real) := by exact_mod_cast hmPosNat
  have hnmReal : (n : Real) <= (m : Real) := by exact_mod_cast hnm
  have hlognPos : 0 < Real.log (n : Real) := by
    exact Real.log_pos (by exact_mod_cast (by omega : 1 < n))
  have hloglognPos : 0 < Real.log (Real.log (n : Real)) := by
    have hlognGtOne : (1 : Real) < Real.log (n : Real) := by
      rw [Real.lt_log_iff_exp_lt hnRealPos]
      exact lt_trans Real.exp_one_lt_three
        (by exact_mod_cast (by omega : 3 < n))
    exact Real.log_pos hlognGtOne
  have hlogLe : Real.log (n : Real) <= Real.log (m : Real) :=
    Real.log_le_log hnRealPos hnmReal
  have hloglogLe :
      Real.log (Real.log (n : Real)) <= Real.log (Real.log (m : Real)) :=
    Real.log_le_log hlognPos hlogLe
  have hlogmPos : 0 < Real.log (m : Real) := lt_of_lt_of_le hlognPos hlogLe
  have hloglogmPos : 0 < Real.log (Real.log (m : Real)) :=
    lt_of_lt_of_le hloglognPos hloglogLe
  have hProd :
      Real.log (n : Real) * Real.log (Real.log (n : Real)) <=
        Real.log (m : Real) * Real.log (Real.log (m : Real)) := by
    exact mul_le_mul hlogLe hloglogLe
      (le_of_lt hloglognPos) (le_of_lt hlogmPos)
  have hnProdPos :
      0 < Real.log (n : Real) * Real.log (Real.log (n : Real)) :=
    mul_pos hlognPos hloglognPos
  have hmProdPos :
      0 < Real.log (m : Real) * Real.log (Real.log (m : Real)) :=
    mul_pos hlogmPos hloglogmPos
  unfold robinFrontierCutoff
  exact (inv_le_inv₀ hmProdPos hnProdPos).2 hProd

/-- The divisor sum is positive for every positive integer. -/
theorem sigmaOneNat_pos {n : Nat} (hn : 0 < n) :
    0 < Core.sigmaOneNat n := by
  unfold Core.sigmaOneNat
  exact ArithmeticFunction.sigma_pos 1 n (Nat.ne_of_gt hn)

/-- The abundancy ratio is positive for every positive integer. -/
theorem abundancy_pos {n : Nat} (hn : 0 < n) :
    0 < abundancy n := by
  unfold abundancy
  exact div_pos
    (by exact_mod_cast sigmaOneNat_pos hn)
    (by exact_mod_cast hn)

end Robin1984
end

/- Inlined module Robin1984.Helpers.Lyapunov. -/
section

/-!
## Provenance

- Classification: **Primarily project-original**.
- Mathematical source: No external theorem is directly formalized; published inputs retain their attribution in the imported modules and project bibliography.
- Formalization note: The retained definitions, interfaces, reductions, or proof assembly are primarily original to this formalization.
- PROVENANCE-END
-/

/-!
# State and potential for colossally abundant event packets

`CAState` records the accumulated logarithmic size, logarithmic abundancy gain,
and event support of a prime-power packet. This module defines the zero state,
packet application, total event mass and gain, and the Lyapunov potential used
to compare successive colossally abundant states.
-/

namespace Robin1984
/-- A finite CA-state summary, using logarithms to avoid huge integer products. -/
structure CAState where
  logN : ℝ
  logSigmaOverN : ℝ

/-- Empty CA-state before applying any event prefix. -/
def zeroCAState : CAState where
  logN := 0
  logSigmaOverN := 0


/-- Robin Lyapunov value `L = -log R = γ + log(log(log N)) - log(σ(N)/N)`. -/
noncomputable def lyapunov (s : CAState) : ℝ :=
  Real.eulerMascheroniConstant + Real.log (Real.log s.logN) - s.logSigmaOverN


/-- Apply a finite event packet to the logarithmic CA-state summary. -/
noncomputable def applyPacket (s : CAState) (events : Finset Event) : CAState where
  logN := s.logN + (∑ e ∈ events, Real.log (e.p : ℝ))
  logSigmaOverN := s.logSigmaOverN + (∑ e ∈ events, e.gain)

/-- Total logarithmic prime mass of a finite event set. -/
noncomputable def eventLogMass (events : Finset Event) : ℝ :=
  ∑ e ∈ events, Real.log (e.p : ℝ)


/-- Prime numbers up to a bound `P`, represented as a finite filtered range. -/
def primesUpToSet (P : ℕ) : Finset ℕ :=
  (Finset.range (P + 1)).filter Nat.Prime


/-- The canonical layer-`j` event attached to a prime `p`. -/
def layerEventOfPrime (p j : ℕ) (hp : Nat.Prime p) (hj : 0 < j) : Event where
  p := p
  j := j
  hp := hp
  hj := hj


/-- Total logarithmic gain in `sigma(n)/n` from a finite event set. -/
noncomputable def eventGainSum (events : Finset Event) : ℝ :=
  ∑ e ∈ events, e.gain


end Robin1984
end

/- Inlined module Robin1984.Helpers.FirstLayerThreshold. -/
section

/-!
## Provenance

- Classification: **Primarily project-original**.
- Mathematical source: No external theorem is directly formalized; published inputs retain their attribution in the imported modules and project bibliography.
- Formalization note: The retained definitions, interfaces, reductions, or proof assembly are primarily original to this formalization.
- PROVENANCE-END
-/

/-!
# First-layer event thresholds

This module treats the first-layer gain and threshold as real functions of the
prime scale, proves their derivative formulas, and establishes the threshold's
monotonic decrease.
-/

namespace Robin1984


/-- Continuous first-layer gain `log(1 + 1/t)`. -/
noncomputable def firstLayerContinuousGain (t : ℝ) : ℝ :=
  Real.log (1 + t⁻¹)


/-- First-layer threshold as a continuous function of the prime scale. -/
noncomputable def firstLayerThreshold (t : ℝ) : ℝ :=
  firstLayerContinuousGain t / Real.log t


lemma hasDerivAt_firstLayerContinuousGain
    {t : ℝ}
    (ht : t ≠ 0)
    (harg : 1 + 1 / t ≠ 0) :
    HasDerivAt firstLayerContinuousGain (-(1 / (t^2)) / (1 + 1 / t)) t := by
  unfold firstLayerContinuousGain
  have hdiv : HasDerivAt (fun u : ℝ => 1 / u) ((0 * t - 1 * 1) / t ^ 2) t := by
    exact (hasDerivAt_const t (1 : ℝ)).div (hasDerivAt_id t) ht
  have hslope : (0 * t - 1 * 1) / t ^ 2 = -(1 / t^2) := by
    field_simp [ht]
    ring
  have hinner : HasDerivAt (fun u : ℝ => 1 + 1 / u) (-(1 / t^2)) t := by
    exact (hdiv.const_add (1 : Real)).congr_deriv hslope
  simpa [one_div] using hinner.log harg


lemma firstLayerThreshold_derivativeNumerator_neg
    {t : ℝ}
    (ht : 1 < t) :
    (-(1 / (t^2)) / (1 + 1 / t)) * Real.log t -
        firstLayerContinuousGain t * (1 / t) < 0 := by
  have htpos : 0 < t := by linarith
  have htne : t ≠ 0 := ne_of_gt htpos
  have hlogpos : 0 < Real.log t := Real.log_pos ht
  have hgainpos : 0 < firstLayerContinuousGain t := by
    unfold firstLayerContinuousGain
    apply Real.log_pos
    have hinvpos : 0 < t⁻¹ := inv_pos.mpr htpos
    linarith
  have hdenpos : 0 < 1 + 1 / t := by
    have hinvpos : 0 < 1 / t := by positivity
    linarith
  have hleftneg : (-(1 / (t^2)) / (1 + 1 / t)) * Real.log t < 0 := by
    have hslopeNeg : (-(1 / (t^2)) / (1 + 1 / t)) < 0 := by
      have ht2pos : 0 < t^2 := sq_pos_of_ne_zero htne
      have hinv2pos : 0 < 1 / (t^2) := by positivity
      have hnumneg : -(1 / (t^2)) < 0 := by linarith
      exact div_neg_of_neg_of_pos hnumneg hdenpos
    exact mul_neg_of_neg_of_pos hslopeNeg hlogpos
  have hrightpos : 0 < firstLayerContinuousGain t * (1 / t) := by
    have hinvpos : 0 < 1 / t := by positivity
    exact mul_pos hgainpos hinvpos
  nlinarith

lemma hasDerivAt_firstLayerThreshold
    {t : ℝ}
    (ht : 1 < t) :
    HasDerivAt (fun u : ℝ => firstLayerThreshold u)
      (((-(1 / (t^2)) / (1 + 1 / t)) * Real.log t -
          firstLayerContinuousGain t * (1 / t)) / (Real.log t)^2) t := by
  unfold firstLayerThreshold
  have htpos : 0 < t := by linarith
  have htne : t ≠ 0 := ne_of_gt htpos
  have harg : 1 + 1 / t ≠ 0 := by
    have hinvpos : 0 < 1 / t := by positivity
    positivity
  have hg := hasDerivAt_firstLayerContinuousGain (t := t) htne harg
  have hlogd : HasDerivAt (fun u : ℝ => Real.log u) (1 / t) t := by
    simpa [one_div] using Real.hasDerivAt_log htne
  have hlogne : Real.log t ≠ 0 := ne_of_gt (Real.log_pos ht)
  exact hg.div hlogd hlogne

lemma firstLayerThreshold_derivative_neg
    {t : ℝ}
    (ht : 1 < t) :
    ((-(1 / (t^2)) / (1 + 1 / t)) * Real.log t -
        firstLayerContinuousGain t * (1 / t)) / (Real.log t)^2 < 0 := by
  have hnum := firstLayerThreshold_derivativeNumerator_neg ht
  have hdenpos : 0 < (Real.log t)^2 := sq_pos_of_ne_zero (ne_of_gt (Real.log_pos ht))
  exact div_neg_of_neg_of_pos hnum hdenpos

lemma strictAntiOn_firstLayerThreshold :
    StrictAntiOn firstLayerThreshold (Set.Ioi (1 : ℝ)) := by
  exact strictAntiOn_of_deriv_neg (convex_Ioi (1 : ℝ))
    (by
      intro x hx
      exact (hasDerivAt_firstLayerThreshold (t := x) hx).continuousAt.continuousWithinAt)
    (by
      intro x hx
      rw [interior_Ioi] at hx
      have hder := hasDerivAt_firstLayerThreshold (t := x) hx
      rw [hder.deriv]
      exact firstLayerThreshold_derivative_neg hx)

lemma firstLayerThreshold_antitone_on_gt_one
    {a b : ℝ}
    (ha : 1 < a)
    (hab : a ≤ b) :
    firstLayerThreshold b ≤ firstLayerThreshold a := by
  by_cases heq : a = b
  · subst b
    exact le_rfl
  · have hlt : a < b := lt_of_le_of_ne hab heq
    have hb : b ∈ Set.Ioi (1 : ℝ) := by
      exact lt_trans ha hlt
    have ha' : a ∈ Set.Ioi (1 : ℝ) := ha
    exact (strictAntiOn_firstLayerThreshold ha' hb hlt).le

lemma firstLayerThreshold_nat_antitone
    {p q : ℕ}
    (hp : 1 < p)
    (hpq : p ≤ q) :
    firstLayerThreshold (q : ℝ) ≤ firstLayerThreshold (p : ℝ) := by
  have hpReal : 1 < (p : ℝ) := by exact_mod_cast hp
  have hpqReal : (p : ℝ) ≤ (q : ℝ) := by exact_mod_cast hpq
  exact firstLayerThreshold_antitone_on_gt_one hpReal hpqReal


lemma firstLayerEvent_threshold_antitone
    {e f : Event}
    (hej : e.j = 1)
    (hfj : f.j = 1)
    (hpf : e.p ≤ f.p) :
    f.threshold ≤ e.threshold := by
  rw [Event.threshold_eq_firstLayer_of_j_eq_one hej,
    Event.threshold_eq_firstLayer_of_j_eq_one hfj]
  exact firstLayerThreshold_nat_antitone e.hp.one_lt hpf


end Robin1984
end

/- Inlined module Robin1984.ColossallyAbundant.CAProfile. -/
section
/-!
## Provenance

- Classification: **Other published source formalization**.
- Mathematical source: Leonidas Alaoglu and Paul Erdos (1944), with Guy Robin's 1984 use of colossally abundant numbers.
- Formalization note: The CA objective and threshold characterization are published mathematics; the event representation and Lean interfaces are specific to this formalization.
- PROVENANCE-END
-/

/-!
# Colossally abundant threshold profiles

A colossally abundant factorization packet satisfies complementary slackness
for the marginal-event objective.  The resulting event packet is exactly the
canonical threshold prefix, and its logarithmic mass and gain recover
`log n` and `log (sigma(n) / n)`.
-/

namespace Robin1984
/-- Reduced marginal weight for the CA Lagrangian at cutoff `lambda`. -/
noncomputable def eventReducedWeight (lambda : Real) (e : Event) : Real :=
  e.gain - lambda * Real.log (e.p : Real)

/-- Reduced weight is threshold gap times prime log. -/
theorem eventReducedWeight_eq_threshold_sub_mul
    (lambda : Real) (e : Event) :
    eventReducedWeight lambda e =
      (e.threshold - lambda) * Real.log (e.p : Real) := by
  unfold eventReducedWeight
  rw [← e.threshold_mul_log]
  ring

/-- Nonnegative reduced weight is the same as lying above the threshold. -/
theorem eventReducedWeight_nonneg_iff_threshold
    (lambda : Real) (e : Event) :
    0 <= eventReducedWeight lambda e <-> lambda <= e.threshold := by
  unfold eventReducedWeight
  constructor
  · intro h
    have hmul : lambda * Real.log (e.p : Real) <=
        e.threshold * Real.log (e.p : Real) := by
      rw [e.threshold_mul_log]
      linarith
    have hmulLeft :
        Real.log (e.p : Real) * lambda <=
          Real.log (e.p : Real) * e.threshold := by
      simpa [mul_comm] using hmul
    exact (mul_le_mul_iff_right₀ e.log_prime_pos).mp hmulLeft
  · intro h
    have hmulLeft :
        Real.log (e.p : Real) * lambda <=
          Real.log (e.p : Real) * e.threshold :=
      (mul_le_mul_iff_right₀ e.log_prime_pos).mpr h
    have hmul : lambda * Real.log (e.p : Real) <=
        e.threshold * Real.log (e.p : Real) := by
      simpa [mul_comm] using hmulLeft
    rw [e.threshold_mul_log] at hmul
    linarith


/-- Nonpositive reduced weight is the same as lying at or below the cutoff. -/
theorem eventReducedWeight_nonpos_iff_threshold
    (lambda : Real) (e : Event) :
    eventReducedWeight lambda e <= 0 <-> e.threshold <= lambda := by
  rw [eventReducedWeight_eq_threshold_sub_mul]
  constructor
  · intro h
    have hgap :
        e.threshold - lambda <= 0 := by
      have hmul :
          (e.threshold - lambda) * Real.log (e.p : Real) <=
            0 * Real.log (e.p : Real) := by
        simpa using h
      exact (mul_le_mul_iff_right₀ e.log_prime_pos).mp
        (by simpa [mul_comm] using hmul)
    linarith
  · intro h
    have hgap : e.threshold - lambda <= 0 := by linarith
    have hmul :
        (e.threshold - lambda) * Real.log (e.p : Real) <=
          0 * Real.log (e.p : Real) :=
      by
        simpa [mul_comm] using
          ((mul_le_mul_iff_right₀ e.log_prime_pos).mpr hgap)
    simpa using hmul


/-- A zero-threshold tie has zero reduced weight. -/
theorem eventReducedWeight_eq_zero_of_threshold_eq
    {lambda : Real} {e : Event} (hTie : e.threshold = lambda) :
    eventReducedWeight lambda e = 0 := by
  rw [eventReducedWeight_eq_threshold_sub_mul, hTie]
  ring


/-- Total reduced Lagrange weight of a finite event packet. -/
noncomputable def eventPacketReducedWeight
    (lambda : Real) (events : Finset Event) : Real :=
  ∑ e ∈ events, eventReducedWeight lambda e

/-- Packet reduced weight is total gain minus the cutoff times total
logarithmic prime mass. -/
theorem eventPacketReducedWeight_eq_eventGainSum_sub
    (lambda : Real) (events : Finset Event) :
    eventPacketReducedWeight lambda events =
      eventGainSum events - lambda * eventLogMass events := by
  unfold eventPacketReducedWeight eventReducedWeight eventGainSum eventLogMass
  rw [Finset.sum_sub_distrib]
  rw [Finset.mul_sum]


/-- The multiplicative gain ratio for a single prime-power layer. -/
noncomputable def eventGainRatio (q : Real) (j : Nat) : Real :=
  (1 - q ^ (j + 1)) / (1 - q ^ j)

/-- The gain ratio is positive for `0 < q < 1` and positive layers. -/
theorem eventGainRatio_pos
    {q : Real} (hq0 : 0 < q) (hq1 : q < 1)
    {j : Nat} (hj : 0 < j) :
    0 < eventGainRatio q j := by
  unfold eventGainRatio
  have hq0le : 0 <= q := le_of_lt hq0
  have hjne : j ≠ 0 := Nat.ne_of_gt hj
  have hj1ne : j + 1 ≠ 0 := Nat.succ_ne_zero j
  have hpowj_lt : q ^ j < 1 :=
    (pow_lt_one_iff_of_nonneg hq0le hjne).mpr hq1
  have hpowj1_lt : q ^ (j + 1) < 1 :=
    (pow_lt_one_iff_of_nonneg hq0le hj1ne).mpr hq1
  exact div_pos (by linarith) (by linarith)


/-- One-step decrease of the prime-power gain ratio. -/
theorem eventGainRatio_step_le
    {q : Real} (hq0 : 0 < q) (hq1 : q < 1)
    {j : Nat} (hj : 0 < j) :
    eventGainRatio q (j + 1) <= eventGainRatio q j := by
  unfold eventGainRatio
  have hq0le : 0 <= q := le_of_lt hq0
  have hjne : j ≠ 0 := Nat.ne_of_gt hj
  have hj1ne : j + 1 ≠ 0 := Nat.succ_ne_zero j
  have hpowj_lt : q ^ j < 1 :=
    (pow_lt_one_iff_of_nonneg hq0le hjne).mpr hq1
  have hpowj1_lt : q ^ (j + 1) < 1 :=
    (pow_lt_one_iff_of_nonneg hq0le hj1ne).mpr hq1
  have hdenj : 0 < 1 - q ^ j := by linarith
  have hdenj1 : 0 < 1 - q ^ (j + 1) := by linarith
  have hsq : 0 <= q ^ j * (1 - q) ^ 2 :=
    mul_nonneg (pow_nonneg hq0le j) (sq_nonneg (1 - q))
  field_simp [hdenj.ne', hdenj1.ne']
  ring_nf
  nlinarith [hsq]

/-- The prime-power gain ratio decreases along same-prime layers. -/
theorem eventGainRatio_le_of_le
    {q : Real} (hq0 : 0 < q) (hq1 : q < 1)
    {j k : Nat} (hj : 0 < j) (hjk : j <= k) :
    eventGainRatio q k <= eventGainRatio q j := by
  induction hjk with
  | refl => exact le_rfl
  | step hm ih =>
      have hmpos : 0 < _ := lt_of_lt_of_le hj hm
      exact le_trans (eventGainRatio_step_le hq0 hq1 hmpos) ih

/-- Event gain is the logarithm of its prime-power gain ratio. -/
theorem event_gain_eq_log_eventGainRatio (e : Event) :
    e.gain = Real.log (eventGainRatio ((e.p : Real)⁻¹) e.j) := by
  unfold Event.gain eventGainRatio
  have hExp1 :
      -((e.j : Int) + 1) = -(((e.j + 1 : Nat) : Int)) := by
    omega
  have hExp0 : -((e.j : Int)) = -(((e.j : Nat) : Int)) := rfl
  rw [hExp1, hExp0]
  rw [zpow_neg, zpow_natCast, inv_pow]
  rw [zpow_neg, zpow_natCast, inv_pow]


/-- For a fixed prime, event gains decrease as the exponent layer increases. -/
theorem event_gain_antitone_same_prime
    {e f : Event} (hSame : e.p = f.p) (hLayer : e.j <= f.j) :
    f.gain <= e.gain := by
  let q : Real := (e.p : Real)⁻¹
  have hq0 : 0 < q := by
    dsimp [q]
    exact inv_pos.mpr e.prime_pos
  have hpgt : (1 : Real) < (e.p : Real) := by
    exact_mod_cast e.hp.one_lt
  have hq1 : q < 1 := by
    dsimp [q]
    exact inv_lt_one_of_one_lt₀ hpgt
  have hle : eventGainRatio q f.j <= eventGainRatio q e.j :=
    eventGainRatio_le_of_le hq0 hq1 e.hj hLayer
  have hpos : 0 < eventGainRatio q f.j :=
    eventGainRatio_pos hq0 hq1 f.hj
  rw [event_gain_eq_log_eventGainRatio e,
    event_gain_eq_log_eventGainRatio f]
  change
    Real.log (eventGainRatio ((f.p : Real)⁻¹) f.j) <=
      Real.log (eventGainRatio q e.j)
  rw [← hSame]
  exact Real.log_le_log hpos hle

/-- For a fixed prime, event thresholds decrease as the exponent layer
increases. -/
theorem event_threshold_antitone_same_prime
    {e f : Event} (hSame : e.p = f.p) (hLayer : e.j <= f.j) :
    f.threshold <= e.threshold := by
  unfold Event.threshold
  have hgain := event_gain_antitone_same_prime hSame hLayer
  have hlogpos : 0 < Real.log (e.p : Real) := e.log_prime_pos
  have hlogeq : Real.log (f.p : Real) = Real.log (e.p : Real) := by
    rw [← hSame]
  rw [hlogeq]
  exact (div_le_div_iff_of_pos_right hlogpos).mpr hgain


end Robin1984
namespace Robin1984

/-- Textbook colossally-abundant objective at parameter `eps`. -/
noncomputable def caObjective (eps : Real) (n : Nat) : Real :=
  (sigmaOneNat n : Real) /
    ((n : Real) ^ (1 + eps))

/-- Logarithmic form of the fixed-parameter CA objective. -/
noncomputable def caLogObjective (eps : Real) (n : Nat) : Real :=
  Real.log (caObjective eps n)

/--
Classical colossally-abundant condition with a fixed parameter `eps`:
`n` maximizes `sigma(k) / k^(1+eps)` among integers above `1`.
-/
noncomputable def IsColossallyAbundantWith (n : Nat) (eps : Real) : Prop :=
  0 < eps ∧ 1 < n ∧
    ∀ k : Nat, 1 < k -> caObjective eps k <= caObjective eps n

theorem IsColossallyAbundantWith.eps_pos
    {n : Nat} {eps : Real} (h : IsColossallyAbundantWith n eps) :
    0 < eps := h.1

theorem IsColossallyAbundantWith.one_lt
    {n : Nat} {eps : Real} (h : IsColossallyAbundantWith n eps) :
    1 < n := h.2.1

theorem IsColossallyAbundantWith.objective_max
    {n : Nat} {eps : Real} (h : IsColossallyAbundantWith n eps)
    {k : Nat} (hk : 1 < k) :
    caObjective eps k <= caObjective eps n := h.2.2 k hk

/-- A concrete tail bound below the value at `2` produces a textbook
colossally-abundant maximizer at parameter `eps`.  This is the finite-maximum
extraction step behind CA existence; the analytic work is exactly the tail
bound hypothesis. -/
theorem exists_colossallyAbundantWith_of_tail_le_two
    {eps : Real} (heps : 0 < eps) {B : Nat} (hB : 2 <= B)
    (hTail :
      ∀ k : Nat, B < k -> caObjective eps k <= caObjective eps 2) :
    ∃ m : Nat, IsColossallyAbundantWith m eps := by
  classical
  let candidates : Finset Nat :=
    (Finset.range (B + 1)).filter (fun k => 1 < k)
  have h2Candidates : 2 ∈ candidates := by
    unfold candidates
    exact Finset.mem_filter.mpr
      ⟨Finset.mem_range.mpr (Nat.lt_succ_iff.mpr hB), by norm_num⟩
  have hCandidatesNonempty : candidates.Nonempty := ⟨2, h2Candidates⟩
  rcases Finset.exists_max_image candidates (fun k => caObjective eps k)
      hCandidatesNonempty with
    ⟨m, hmCandidates, hmMax⟩
  have hmOne : 1 < m := (Finset.mem_filter.mp hmCandidates).2
  refine ⟨m, heps, hmOne, ?_⟩
  intro k hk
  by_cases hkB : k <= B
  · have hkCandidates : k ∈ candidates := by
      unfold candidates
      exact Finset.mem_filter.mpr
        ⟨Finset.mem_range.mpr (Nat.lt_succ_iff.mpr hkB), hk⟩
    exact hmMax k hkCandidates
  · have hTailK : caObjective eps k <= caObjective eps 2 :=
      hTail k (Nat.lt_of_not_ge hkB)
    have hTwoLeM : caObjective eps 2 <= caObjective eps m :=
      hmMax 2 h2Candidates
    exact le_trans hTailK hTwoLeM

/-- An eventual tail bound below the value at `2` is enough to produce a
textbook CA maximizer. -/
theorem exists_colossallyAbundantWith_of_eventual_tail_le_two
    {eps : Real} (heps : 0 < eps)
    (hTail :
      ∃ B : Nat, ∀ k : Nat, B < k -> caObjective eps k <= caObjective eps 2) :
    ∃ m : Nat, IsColossallyAbundantWith m eps := by
  rcases hTail with ⟨B, hTailB⟩
  exact exists_colossallyAbundantWith_of_tail_le_two heps
    (B := max 2 B) (le_max_left 2 B)
    (fun k hk => hTailB k (lt_of_le_of_lt (le_max_right 2 B) hk))

/-- The fixed-parameter CA objective is positive on positive integers. -/
theorem caObjective_pos {eps : Real} {n : Nat} (hn : 0 < n) :
    0 < caObjective eps n := by
  unfold caObjective
  exact div_pos
    (by exact_mod_cast sigmaOneNat_pos hn)
    (Real.rpow_pos_of_pos (by exact_mod_cast hn) (1 + eps))

/-- If the fixed-parameter CA objective tends to zero, then a textbook CA
maximizer exists.  Thus the remaining analytic existence input can be stated
as ordinary tail decay of `sigma(k) / k^(1+eps)`. -/
theorem exists_colossallyAbundantWith_of_tendsto_caObjective_zero
    {eps : Real} (heps : 0 < eps)
    (hTendsto :
      Filter.Tendsto (fun k : Nat => caObjective eps k) Filter.atTop
        (nhds 0)) :
    ∃ m : Nat, IsColossallyAbundantWith m eps := by
  have hTwoPos : 0 < caObjective eps 2 :=
    caObjective_pos (eps := eps) (n := 2) (by norm_num)
  have hEventuallyLt :
      ∀ᶠ k : Nat in Filter.atTop, caObjective eps k < caObjective eps 2 :=
    hTendsto.eventually (eventually_lt_nhds hTwoPos)
  rcases Filter.eventually_atTop.mp hEventuallyLt with ⟨B, hB⟩
  exact exists_colossallyAbundantWith_of_eventual_tail_le_two heps
    ⟨B, fun k hk => le_of_lt (hB k (le_of_lt hk))⟩

/-- The CA objective is the abundancy ratio with the Lagrange denominator
separated. -/
theorem caObjective_eq_abundancy_div_rpow
    {eps : Real} {n : Nat} (hn : 0 < n) :
    caObjective eps n = abundancy n / ((n : Real) ^ eps) := by
  unfold caObjective abundancy
  have hnR : (0 : Real) < n := by exact_mod_cast hn
  have hpow : 0 < (n : Real) ^ eps := Real.rpow_pos_of_pos hnR eps
  rw [show (1 + eps) = (1 : Real) + eps by ring]
  rw [Real.rpow_add hnR, Real.rpow_one]
  field_simp [hnR.ne', hpow.ne']
  rfl


/-- Logarithmic CA objective split into abundancy and size terms. -/
theorem caLogObjective_eq_log_abundancy_sub
    {eps : Real} {n : Nat} (hn : 0 < n) :
    caLogObjective eps n =
      Real.log (abundancy n) - eps * Real.log (n : Real) := by
  unfold caLogObjective
  rw [caObjective_eq_abundancy_div_rpow (eps := eps) hn]
  have hab : 0 < abundancy n := abundancy_pos hn
  have hnR : (0 : Real) < n := by exact_mod_cast hn
  have hpow : 0 < (n : Real) ^ eps := Real.rpow_pos_of_pos hnR eps
  rw [Real.log_div hab.ne' hpow.ne']
  rw [Real.log_rpow hnR]


/-- The abundancy ratio is bounded by the harmonic sum over `1, ..., n`:
`sigma(n) / n = sum_{d|n} 1/d <= H_n`. -/
theorem abundancy_le_harmonic {n : Nat} (hn : 0 < n) :
    abundancy n <= (harmonic n : Real) := by
  unfold abundancy Robin1984.Core.sigmaOneNat
  rw [ArithmeticFunction.sigma_eq_sum_div]
  have hnR : (0 : Real) < (n : Real) := by exact_mod_cast hn
  calc
    ((∑ d ∈ n.divisors, (n / d) ^ 1 : Nat) : Real) / (n : Real)
        = (∑ d ∈ n.divisors, ((n / d : Nat) : Real)) / (n : Real) := by
      simp
    _ = ∑ d ∈ n.divisors, (((n / d : Nat) : Real) / (n : Real)) := by
      rw [Finset.sum_div]
    _ = ∑ d ∈ n.divisors, ((d : Real)⁻¹) := by
      apply Finset.sum_congr rfl
      intro d hd
      have hdvd : d ∣ n := Nat.dvd_of_mem_divisors hd
      have hdpos : 0 < d := Nat.pos_of_mem_divisors hd
      have hdR : (d : Real) ≠ 0 := by exact_mod_cast (ne_of_gt hdpos)
      have hmulNat : d * (n / d) = n := Nat.mul_div_cancel' hdvd
      have hmulReal :
          (d : Real) * ((n / d : Nat) : Real) = (n : Real) := by
        exact_mod_cast hmulNat
      field_simp [hdR, ne_of_gt hnR]
      nlinarith
    _ ≤ ∑ d ∈ Finset.Icc 1 n, ((d : Real)⁻¹) := by
      apply Finset.sum_le_sum_of_subset_of_nonneg
      · intro d hd
        exact Finset.mem_Icc.mpr
          ⟨Nat.pos_of_mem_divisors hd, Nat.divisor_le hd⟩
      · intro d _hdIcc _hdNot
        exact inv_nonneg.mpr (by positivity)
    _ = (harmonic n : Real) := by
      simp only [harmonic_eq_sum_Icc, Rat.cast_sum, Rat.cast_inv,
        Rat.cast_natCast]

/-- Elementary Robin-side growth bound: `sigma(n)/n <= 1 + log n`. -/
theorem abundancy_le_one_add_log {n : Nat} (hn : 0 < n) :
    abundancy n <= 1 + Real.log (n : Real) :=
  (abundancy_le_harmonic hn).trans (harmonic_le_one_add_log n)

/-- The constant part of `(1 + log n) / n^eps` tends to zero. -/
theorem tendsto_nat_one_div_rpow_atTop_zero
    {eps : Real} (heps : 0 < eps) :
    Filter.Tendsto
      (fun n : Nat => (1 : Real) / ((n : Real) ^ eps))
      Filter.atTop (nhds 0) := by
  have hpow :
      Filter.Tendsto (fun x : Real => x ^ (-eps))
        Filter.atTop (nhds 0) :=
    tendsto_rpow_neg_atTop heps
  have hnat :
      Filter.Tendsto (fun n : Nat => (n : Real) ^ (-eps))
        Filter.atTop (nhds 0) :=
    hpow.comp tendsto_natCast_atTop_atTop
  refine hnat.congr' ?_
  filter_upwards [Filter.eventually_gt_atTop (0 : Nat)] with n hn
  have hnR : 0 <= (n : Real) := by positivity
  rw [Real.rpow_neg hnR eps]
  simp [one_div]

/-- The logarithmic part of `(1 + log n) / n^eps` tends to zero. -/
theorem tendsto_nat_log_div_rpow_atTop_zero
    {eps : Real} (heps : 0 < eps) :
    Filter.Tendsto
      (fun n : Nat => Real.log (n : Real) / ((n : Real) ^ eps))
      Filter.atTop (nhds 0) := by
  exact ((isLittleO_log_rpow_atTop heps).tendsto_div_nhds_zero).comp
    tendsto_natCast_atTop_atTop

/-- The elementary divisor-sum majorant decays after division by `n^eps`. -/
theorem tendsto_nat_one_add_log_div_rpow_atTop_zero
    {eps : Real} (heps : 0 < eps) :
    Filter.Tendsto
      (fun n : Nat =>
        (1 + Real.log (n : Real)) / ((n : Real) ^ eps))
      Filter.atTop (nhds 0) := by
  have hone := tendsto_nat_one_div_rpow_atTop_zero (eps := eps) heps
  have hlog := tendsto_nat_log_div_rpow_atTop_zero (eps := eps) heps
  have hsum := hone.add hlog
  have hsum0 :
      Filter.Tendsto
        (fun n : Nat =>
          (1 : Real) / ((n : Real) ^ eps) +
            Real.log (n : Real) / ((n : Real) ^ eps))
        Filter.atTop (nhds 0) := by
    simpa using hsum
  refine hsum0.congr' ?_
  filter_upwards with n
  ring

/-- Pointwise CA-objective upper bound by the elementary harmonic majorant. -/
theorem caObjective_le_one_add_log_div_rpow
    {eps : Real} {n : Nat} (hn : 0 < n) :
    caObjective eps n <=
      (1 + Real.log (n : Real)) / ((n : Real) ^ eps) := by
  rw [caObjective_eq_abundancy_div_rpow (eps := eps) hn]
  have hnR : (0 : Real) < (n : Real) := by exact_mod_cast hn
  have hden : 0 <= (((n : Real) ^ eps)⁻¹) :=
    inv_nonneg.mpr (le_of_lt (Real.rpow_pos_of_pos hnR eps))
  simpa [div_eq_mul_inv] using
    mul_le_mul_of_nonneg_right (abundancy_le_one_add_log hn) hden

/-- For every positive CA parameter, the textbook objective tends to zero. -/
theorem tendsto_caObjective_zero
    {eps : Real} (heps : 0 < eps) :
    Filter.Tendsto (fun n : Nat => caObjective eps n)
      Filter.atTop (nhds 0) := by
  refine tendsto_of_tendsto_of_tendsto_of_le_of_le'
    tendsto_const_nhds
    (tendsto_nat_one_add_log_div_rpow_atTop_zero (eps := eps) heps)
    ?_ ?_
  · filter_upwards [Filter.eventually_gt_atTop (0 : Nat)] with n hn
    exact le_of_lt (caObjective_pos (eps := eps) hn)
  · filter_upwards [Filter.eventually_gt_atTop (0 : Nat)] with n hn
    exact caObjective_le_one_add_log_div_rpow (eps := eps) hn

/-- Textbook colossally-abundant maximizers exist for every positive
parameter, using only the elementary divisor-sum tail bound. -/
theorem exists_colossallyAbundantWith
    {eps : Real} (heps : 0 < eps) :
    ∃ m : Nat, IsColossallyAbundantWith m eps :=
  exists_colossallyAbundantWith_of_tendsto_caObjective_zero heps
    (tendsto_caObjective_zero heps)

/-- Closed form for the divisor sum of a prime power, as a real identity. -/
theorem sigma_one_prime_pow_real_closed {p a : Nat} (hp : Nat.Prime p) :
    ((Robin1984.Core.sigmaOneNat (p ^ a) : Nat) : Real) =
      (((p : Real) ^ (a + 1) - 1) / ((p : Real) - 1)) := by
  unfold Robin1984.Core.sigmaOneNat
  rw [ArithmeticFunction.sigma_one_apply_prime_pow hp]
  norm_num
  have hpne : (p : Real) ≠ 1 := by exact_mod_cast hp.ne_one
  rw [geom_sum_eq (x := (p : Real)) hpne (a + 1)]

/-- Event gain ratio after replacing the event parameter by the prime itself. -/
theorem eventGainRatio_inv_eq {p : Real} (hp0 : p ≠ 0)
    {k : Nat} (hden : p ^ (k + 1) - 1 ≠ 0) :
    Robin1984.eventGainRatio p⁻¹ (k + 1) =
      (p ^ (k + 2) - 1) / (p * (p ^ (k + 1) - 1)) := by
  unfold Robin1984.eventGainRatio
  rw [inv_pow, inv_pow]
  field_simp [hp0, hden]
  ring

/-- Adjacent prime-power abundancy ratios are exactly event gain ratios. -/
theorem primePowAbundancyRatio_succ_eq_eventGainRatio {p k : Nat}
    (hp : Nat.Prime p) :
    (((Robin1984.Core.sigmaOneNat (p ^ (k + 1)) : Real) /
          ((p : Real) ^ (k + 1))) /
        ((Robin1984.Core.sigmaOneNat (p ^ k) : Real) /
          ((p : Real) ^ k))) =
      Robin1984.eventGainRatio ((p : Real)⁻¹) (k + 1) := by
  have hpRpos : (0 : Real) < p := by exact_mod_cast hp.pos
  have hpRone : (1 : Real) < p := by exact_mod_cast hp.one_lt
  have hpRne0 : (p : Real) ≠ 0 := ne_of_gt hpRpos
  have hpRne1 : (p : Real) ≠ 1 := by exact_mod_cast hp.ne_one
  have hdenSig : (p : Real) ^ (k + 1) - 1 ≠ 0 := by
    have hpowgt : 1 < (p : Real) ^ (k + 1) := by
      induction k with
      | zero =>
          simpa using hpRone
      | succ k ih =>
          rw [pow_succ]
          have hpowpos : 0 < (p : Real) ^ (k + 1) :=
            pow_pos hpRpos (k + 1)
          nlinarith [ih, hpRone, hpowpos]
    exact ne_of_gt (by linarith)
  have hsig1 := sigma_one_prime_pow_real_closed (p := p) (a := k + 1) hp
  have hsig0 := sigma_one_prime_pow_real_closed (p := p) (a := k) hp
  rw [eventGainRatio_inv_eq hpRne0 hdenSig]
  rw [hsig1, hsig0]
  field_simp [hpRne0, hpRne1, hdenSig]
  ring

/-- The divisor sum factors across a prime-power part and its p-adic
complement. -/
theorem sigmaOneNat_mul_primePow_ordCompl {n p : Nat}
    (hp : Nat.Prime p) (hn : n ≠ 0) :
    Robin1984.Core.sigmaOneNat n =
      Robin1984.Core.sigmaOneNat (p ^ n.factorization p) *
        Robin1984.Core.sigmaOneNat
          (n / p ^ n.factorization p) := by
  have hcop :
      (p ^ n.factorization p).Coprime
        (n / p ^ n.factorization p) :=
    Nat.Coprime.pow_left (n.factorization p) (Nat.coprime_ordCompl hp hn)
  have hmul :=
    (ArithmeticFunction.isMultiplicative_sigma (k := 1)).map_mul_of_coprime
      hcop
  unfold Robin1984.Core.sigmaOneNat
  conv_lhs =>
    rw [← Nat.ordProj_mul_ordCompl_eq_self n p]
  exact hmul

/-- The abundancy ratio factors across a prime-power part and its p-adic
complement. -/
theorem abundancy_eq_primePow_mul_ordCompl {n p : Nat}
    (hp : Nat.Prime p) (hn : n ≠ 0) :
    abundancy n =
      ((Robin1984.Core.sigmaOneNat (p ^ n.factorization p) : Real) /
        ((p : Real) ^ n.factorization p)) *
      abundancy (n / p ^ n.factorization p) := by
  have hcompPosNat : 0 < n / p ^ n.factorization p := Nat.ordCompl_pos p hn
  have hpRpos : (0 : Real) < p := by exact_mod_cast hp.pos
  have hpPowRealPos : 0 < (p : Real) ^ n.factorization p :=
    pow_pos hpRpos _
  have hcompPos : (0 : Real) <
      (n / p ^ n.factorization p : Nat) := by
    exact_mod_cast hcompPosNat
  have hsig := sigmaOneNat_mul_primePow_ordCompl hp hn
  have hnCast :
      (n : Real) =
        ((p ^ n.factorization p : Nat) : Real) *
          ((n / p ^ n.factorization p : Nat) : Real) := by
    exact_mod_cast (Eq.symm (Nat.ordProj_mul_ordCompl_eq_self n p))
  unfold abundancy
  rw [hsig, hnCast]
  norm_num
  field_simp [hpPowRealPos.ne', hcompPos.ne']

/-- Multiplying by a prime increments that prime's factorization exponent. -/
theorem factorization_mul_prime_self {n p : Nat}
    (hp : Nat.Prime p) (hn : n ≠ 0) :
    (n * p).factorization p = n.factorization p + 1 := by
  have hmul := Nat.factorization_mul hn hp.ne_zero
  have happly := congrArg (fun f => f p) hmul
  simpa [Finsupp.add_apply, hp.factorization_self] using happly


/-- The p-adic complement is unchanged when multiplying by one more `p`. -/
theorem ordCompl_mul_prime_eq {n p : Nat}
    (hp : Nat.Prime p) (hn : n ≠ 0) :
    (n * p) / p ^ ((n * p).factorization p) =
      n / p ^ n.factorization p := by
  let a := n.factorization p
  let m := n / p ^ a
  have hfac : (n * p).factorization p = a + 1 := by
    simpa [a] using factorization_mul_prime_self hp hn
  have hrepr : p ^ a * m = n := by
    simpa [a, m] using Nat.ordProj_mul_ordCompl_eq_self n p
  have hnum : n * p = p ^ (a + 1) * m := by
    rw [← hrepr]
    rw [pow_succ]
    ring
  rw [hfac, hnum]
  exact Nat.mul_div_right m (Nat.pow_pos (a := p) (n := a + 1) hp.pos)


/-- Multiplying by one more `p` changes abundancy by the first missing event
gain ratio. -/
theorem abundancy_mul_prime_ratio_eq_eventGainRatio {n p : Nat}
    (hp : Nat.Prime p) (hn : n ≠ 0) :
    abundancy (n * p) / abundancy n =
      Robin1984.eventGainRatio ((p : Real)⁻¹) (n.factorization p + 1) := by
  have hmul :=
    abundancy_eq_primePow_mul_ordCompl hp (Nat.mul_ne_zero hn hp.ne_zero)
  have hbase := abundancy_eq_primePow_mul_ordCompl hp hn
  have hfac := factorization_mul_prime_self hp hn
  have hcompl := ordCompl_mul_prime_eq hp hn
  rw [hmul, hbase, hcompl, hfac]
  have hCpos : 0 < abundancy (n / p ^ n.factorization p) :=
    abundancy_pos (Nat.ordCompl_pos p hn)
  have hApos : 0 <
      ((Robin1984.Core.sigmaOneNat (p ^ n.factorization p) : Real) /
        ((p : Real) ^ n.factorization p)) := by
    exact div_pos
      (by
        exact_mod_cast
          sigmaOneNat_pos
            (Nat.pow_pos (a := p) (n := n.factorization p) hp.pos))
      (pow_pos (by exact_mod_cast hp.pos : (0 : Real) < p) _)
  have hratio :=
    primePowAbundancyRatio_succ_eq_eventGainRatio
      (p := p) (k := n.factorization p) hp
  rw [← hratio]
  field_simp [hCpos.ne', hApos.ne']


/-- Log variation for adding the first missing exponent of a prime. -/
theorem eventReducedWeight_add_first_eq_logVariation
    {n : Nat} {eps : Real} {first : Robin1984.Event}
    (hn : 0 < n)
    (hfirst : first.j = n.factorization first.p + 1) :
    Robin1984.eventReducedWeight eps first =
      caLogObjective eps (n * first.p) - caLogObjective eps n := by
  have hnNe : n ≠ 0 := Nat.ne_of_gt hn
  have hpRpos : (0 : Real) < first.p := first.prime_pos
  have hnRpos : (0 : Real) < n := by exact_mod_cast hn
  have hnpPos : 0 < n * first.p := Nat.mul_pos hn first.hp.pos
  have hratio :=
    abundancy_mul_prime_ratio_eq_eventGainRatio first.hp hnNe
  have hlogAb :
      Real.log (abundancy (n * first.p)) - Real.log (abundancy n) =
        Real.log
          (Robin1984.eventGainRatio ((first.p : Real)⁻¹)
            (n.factorization first.p + 1)) := by
    have hdiv :=
      Real.log_div
        (ne_of_gt (abundancy_pos hnpPos))
        (ne_of_gt (abundancy_pos hn))
    rw [hratio] at hdiv
    linarith
  have hlogN :
      Real.log ((n * first.p : Nat) : Real) - Real.log (n : Real) =
        Real.log (first.p : Real) := by
    have hmul : Real.log ((n * first.p : Nat) : Real) =
        Real.log (n : Real) + Real.log (first.p : Real) := by
      rw [Nat.cast_mul]
      exact Real.log_mul (ne_of_gt hnRpos) (ne_of_gt hpRpos)
    linarith
  rw [caLogObjective_eq_log_abundancy_sub (eps := eps) hnpPos,
    caLogObjective_eq_log_abundancy_sub (eps := eps) hn]
  unfold Robin1984.eventReducedWeight
  rw [Robin1984.event_gain_eq_log_eventGainRatio first, hfirst]
  rw [show
      Real.log (abundancy (n * first.p)) -
          eps * Real.log ((n * first.p : Nat) : Real) -
        (Real.log (abundancy n) - eps * Real.log (n : Real)) =
        (Real.log (abundancy (n * first.p)) - Real.log (abundancy n)) -
          eps *
            (Real.log ((n * first.p : Nat) : Real) -
              Real.log (n : Real)) by
    ring]
  rw [hlogAb, hlogN]


/-- Textbook CA maximality transferred to the logarithmic objective. -/
theorem IsColossallyAbundantWith.logObjective_max
    {n : Nat} {eps : Real} (h : IsColossallyAbundantWith n eps)
    {k : Nat} (hk : 1 < k) :
    caLogObjective eps k <= caLogObjective eps n := by
  unfold caLogObjective
  exact Real.log_le_log
    (caObjective_pos (Nat.zero_lt_of_lt hk))
    (h.objective_max hk)

/-- The marginal prime-power events present in the factorization of `n`. -/
noncomputable def actualExponentEvents (n : Nat) : Finset Event := by
  classical
  exact (primesUpToSet n).attach.biUnion fun p =>
    ((Finset.range (n.factorization p.val + 1)).filter (fun j => 0 < j)).attach.image
      (fun j => {
        p := p.val
        j := j.val
        hp := (Finset.mem_filter.mp p.property).2
        hj := (Finset.mem_filter.mp j.property).2
      })

/-- The event state associated with the prime factorization of `n`. -/
noncomputable def actualExponentState (n : Nat) : CAState :=
  applyPacket zeroCAState (actualExponentEvents n)


/-- Membership in the actual exponent packet is exactly bounded by the
factorization exponent of the event's prime base. -/
theorem mem_actualExponentEvents_iff
    {n : Nat} (hn : n ≠ 0) {e : Robin1984.Event} :
    e ∈ actualExponentEvents n ↔ e.j <= n.factorization e.p := by
  classical
  constructor
  · intro he
    unfold actualExponentEvents at he
    rcases Finset.mem_biUnion.mp he with ⟨p, _hpMem, heImage⟩
    rcases Finset.mem_image.mp heImage with ⟨j, _hjMem, hje⟩
    rw [← hje]
    exact Nat.lt_succ_iff.mp
      (Finset.mem_range.mp (Finset.mem_filter.mp j.property).1)
  · intro hle
    unfold actualExponentEvents
    have hfacpos : n.factorization e.p ≠ 0 := by
      exact ne_of_gt (lt_of_lt_of_le e.hj hle)
    have hpdvd : e.p ∣ n := Nat.dvd_of_factorization_pos hfacpos
    have hp_le_n : e.p <= n :=
      Nat.le_of_dvd (Nat.pos_of_ne_zero hn) hpdvd
    have hpMem : e.p ∈ Robin1984.primesUpToSet n := by
      unfold Robin1984.primesUpToSet
      exact Finset.mem_filter.mpr
        ⟨Finset.mem_range.mpr (Nat.lt_succ_iff.mpr hp_le_n), e.hp⟩
    refine
      Finset.mem_biUnion.mpr
        ⟨⟨e.p, hpMem⟩, Finset.mem_attach _ _, ?_⟩
    apply Finset.mem_image.mpr
    have hjMem :
        e.j ∈ (Finset.range (n.factorization e.p + 1)).filter
          (fun j => 0 < j) := by
      exact Finset.mem_filter.mpr
        ⟨Finset.mem_range.mpr (Nat.lt_succ_iff.mpr hle), e.hj⟩
    refine ⟨⟨e.j, hjMem⟩, Finset.mem_attach _ _, ?_⟩
    cases e
    rfl

/-- The actual tower events for one prime in the support of `n.factorization`. -/
noncomputable def actualFactorizationTowerEventsForPrime
    (n : Nat) (p : {p : Nat // p ∈ n.factorization.support}) :
    Finset Robin1984.Event := by
  classical
  exact (Finset.Icc 1 (n.factorization p.val)).attach.image
    (fun j => {
      p := p.val
      j := j.val
      hp := by
        have hpPrimeFactors : p.val ∈ n.primeFactors := by
          exact p.property
        exact Nat.prime_of_mem_primeFactors hpPrimeFactors
      hj := (Finset.mem_Icc.mp j.property).1
    })

/-- The same actual exponent packet, indexed directly by the support of
`n.factorization`. -/
noncomputable def actualFactorizationTowerEvents (n : Nat) :
    Finset Robin1984.Event :=
  n.factorization.support.attach.biUnion
    (actualFactorizationTowerEventsForPrime n)

/-- Membership in the support-indexed factorization tower is exactly bounded by
the factorization exponent of the event's prime base. -/
theorem mem_actualFactorizationTowerEvents_iff
    {n : Nat} {e : Robin1984.Event} :
    e ∈ actualFactorizationTowerEvents n ↔
      e.j <= n.factorization e.p := by
  classical
  constructor
  · intro he
    unfold actualFactorizationTowerEvents at he
    rcases Finset.mem_biUnion.mp he with ⟨p, _hpMem, heImage⟩
    rcases Finset.mem_image.mp heImage with ⟨j, _hjMem, hje⟩
    rw [← hje]
    exact (Finset.mem_Icc.mp j.property).2
  · intro hle
    unfold actualFactorizationTowerEvents
    have hfacpos : n.factorization e.p ≠ 0 :=
      ne_of_gt (lt_of_lt_of_le e.hj hle)
    have hpSupport : e.p ∈ n.factorization.support :=
      Finsupp.mem_support_iff.mpr hfacpos
    refine
      Finset.mem_biUnion.mpr
        ⟨⟨e.p, hpSupport⟩, Finset.mem_attach _ _, ?_⟩
    apply Finset.mem_image.mpr
    have hjMem : e.j ∈ Finset.Icc 1 (n.factorization e.p) :=
      Finset.mem_Icc.mpr ⟨e.hj, hle⟩
    refine ⟨⟨e.j, hjMem⟩, Finset.mem_attach _ _, ?_⟩
    cases e
    rfl

/-- The range-based actual packet agrees with the direct factorization-tower
packet for nonzero `n`. -/
theorem actualExponentEvents_eq_actualFactorizationTowerEvents
    {n : Nat} (hn : n ≠ 0) :
    actualExponentEvents n = actualFactorizationTowerEvents n := by
  classical
  ext e
  rw [mem_actualExponentEvents_iff (n := n) hn,
    mem_actualFactorizationTowerEvents_iff]

/-- Distinct prime-base tower packets are disjoint. -/
theorem pairwiseDisjoint_actualFactorizationTowerEventsForPrime
    (n : Nat) :
    Set.PairwiseDisjoint (↑(n.factorization.support.attach))
      (actualFactorizationTowerEventsForPrime n) := by
  rw [Set.PairwiseDisjoint]
  intro p _hp q _hq hpq
  change Disjoint (actualFactorizationTowerEventsForPrime n p)
    (actualFactorizationTowerEventsForPrime n q)
  rw [Finset.disjoint_left]
  intro e hep heq
  unfold actualFactorizationTowerEventsForPrime at hep heq
  rcases Finset.mem_image.mp hep with ⟨j, _hj, hje⟩
  rcases Finset.mem_image.mp heq with ⟨k, _hk, hke⟩
  have hpvalq : p.val = q.val := by
    have hbase := congrArg Robin1984.Event.p (hje.trans hke.symm)
    simpa using hbase
  exact hpq (Subtype.ext hpvalq)

/-- The support-indexed factorization tower has logarithmic mass equal to the
finite factorization log sum. -/
theorem actualFactorizationTowerEvents_sum_log_eq_factorization_log
    (n : Nat) :
    (actualFactorizationTowerEvents n).sum
        (fun e => Real.log (e.p : Real)) =
      n.factorization.sum
        (fun p t => (t : Real) * Real.log (p : Real)) := by
  classical
  unfold actualFactorizationTowerEvents
  rw [Finset.sum_biUnion
    (pairwiseDisjoint_actualFactorizationTowerEventsForPrime n)]
  rw [Finsupp.sum]
  conv_rhs =>
    rw [← Finset.sum_attach]
  apply Finset.sum_congr rfl
  intro p hp
  unfold actualFactorizationTowerEventsForPrime
  rw [Finset.sum_image]
  · simp [Finset.sum_const, Nat.card_Icc, mul_comm]
  · intro a _ha b _hb h
    exact Subtype.ext (congrArg Robin1984.Event.j h)

/-- Native actual-packet log-mass identity: summing `log p` over all
factorization events gives `log n`. -/
theorem actualExponentEvents_eventLogMass_eq_log
    {n : Nat} (hn : n ≠ 0) :
    Robin1984.eventLogMass (actualExponentEvents n) = Real.log (n : Real) := by
  rw [actualExponentEvents_eq_actualFactorizationTowerEvents hn]
  unfold Robin1984.eventLogMass
  rw [actualFactorizationTowerEvents_sum_log_eq_factorization_log]
  rw [← Real.log_nat_eq_sum_factorization n]

/-- The actual exponent-event packet has logarithmic height `log n`. -/
theorem actualExponentState_logN_eq_log
    {n : Nat} (hn : n ≠ 0) :
    (actualExponentState n).logN = Real.log (n : Real) := by
  unfold actualExponentState Robin1984.applyPacket
  simpa [Robin1984.zeroCAState, Robin1984.eventLogMass] using
    actualExponentEvents_eventLogMass_eq_log (n := n) hn

/-- Finite Euler-factor correction attached to the top exponent of one prime. -/
noncomputable def primeTowerTopCorrection (p j : Nat) : Real :=
  - Real.log (1 - (p : Real) ^ (-(j + 1 : Int)))

/-- For a base above `1`, the Euler-factor term at a positive layer has a
strictly positive logarithm argument. -/
theorem one_sub_prime_zpow_neg_pos
    {p : Nat} (hp : 1 < (p : Real)) {j : Nat} (hj : 0 < j) :
    0 < 1 - (p : Real) ^ (-(j : Int)) := by
  have hp_nonneg : 0 <= (p : Real) := le_of_lt (lt_trans zero_lt_one hp)
  have hpow_gt_one : 1 < (p : Real) ^ j := by
    exact (one_lt_pow_iff_of_nonneg hp_nonneg hj.ne').mpr hp
  have hinv_lt_one : ((p : Real) ^ j)⁻¹ < 1 :=
    inv_lt_one_of_one_lt₀ hpow_gt_one
  rw [zpow_neg, zpow_natCast]
  exact sub_pos.mpr hinv_lt_one

/-- One event gain is the drop in the finite Euler-factor correction from the
previous layer to the new top layer. -/
theorem primeTowerEventGain_succ_eq_topCorrection_sub
    {p d : Nat} (hpPrime : Nat.Prime p) :
    ({ p := p, j := d + 1, hp := hpPrime, hj := Nat.succ_pos d } :
        Robin1984.Event).gain =
      primeTowerTopCorrection p d - primeTowerTopCorrection p (d + 1) := by
  have hpReal : 1 < (p : Real) := by exact_mod_cast hpPrime.one_lt
  have hA : 0 < 1 - (p : Real) ^ (-(d + 2 : Int)) := by
    simpa using one_sub_prime_zpow_neg_pos (p := p) hpReal
      (j := d + 2) (by omega)
  have hB : 0 < 1 - (p : Real) ^ (-(d + 1 : Int)) := by
    simpa using one_sub_prime_zpow_neg_pos (p := p) hpReal
      (j := d + 1) (Nat.succ_pos d)
  change
    Real.log
        ((1 - (p : Real) ^ (-(d + 2 : Int))) /
          (1 - (p : Real) ^ (-(d + 1 : Int)))) =
      -Real.log (1 - (p : Real) ^ (-(d + 1 : Int))) -
        -Real.log (1 - (p : Real) ^ (-(d + 2 : Int)))
  rw [Real.log_div (ne_of_gt hA) (ne_of_gt hB)]
  ring

/-- Full-tower telescope for one prime base. -/
theorem primeTowerEventGains_sum_eq_topCorrection_sub
    {p d : Nat} (hpPrime : Nat.Prime p) :
    (Finset.Icc 1 d).sum
        (fun j =>
          if hj : 0 < j then
            ({ p := p, j := j, hp := hpPrime, hj := hj } : Robin1984.Event).gain
          else 0) =
      primeTowerTopCorrection p 0 - primeTowerTopCorrection p d := by
  induction d with
  | zero =>
      simp [primeTowerTopCorrection]
  | succ d ih =>
      have hIcc :
          Finset.Icc 1 (d + 1) =
            insert (d + 1) (Finset.Icc 1 d) := by
        ext j
        simp
        omega
      have hnotmem : d + 1 ∉ Finset.Icc 1 d := by
        simp
      have hgain :
          (if hj : 0 < d + 1 then
              ({ p := p, j := d + 1, hp := hpPrime, hj := hj } :
                Robin1984.Event).gain
            else 0) =
            primeTowerTopCorrection p d -
              primeTowerTopCorrection p (d + 1) := by
        split
        · simpa using
            primeTowerEventGain_succ_eq_topCorrection_sub
              (p := p) (d := d) hpPrime
        · omega
      rw [hIcc, Finset.sum_insert hnotmem, ih, hgain]
      ring

/-- Attached-index version of the one-prime tower telescope, matching
`actualFactorizationTowerEventsForPrime`. -/
theorem primeTowerEventGains_attach_sum_eq_topCorrection_sub
    {p d : Nat} (hpPrime : Nat.Prime p) :
    (Finset.Icc 1 d).attach.sum
        (fun j =>
          ({ p := p, j := j.val, hp := hpPrime,
              hj := (Finset.mem_Icc.mp j.property).1 } : Robin1984.Event).gain) =
      primeTowerTopCorrection p 0 - primeTowerTopCorrection p d := by
  have hattach :
      (Finset.Icc 1 d).attach.sum
          (fun j =>
            ({ p := p, j := j.val, hp := hpPrime,
                hj := (Finset.mem_Icc.mp j.property).1 } : Robin1984.Event).gain) =
        (Finset.Icc 1 d).sum
          (fun j =>
            if hj : 0 < j then
              ({ p := p, j := j, hp := hpPrime, hj := hj } :
                Robin1984.Event).gain
            else 0) := by
    rw [← Finset.sum_attach (s := Finset.Icc 1 d)
      (f := fun j =>
        if hj : 0 < j then
          ({ p := p, j := j, hp := hpPrime, hj := hj } : Robin1984.Event).gain
        else 0)]
    apply Finset.sum_congr rfl
    intro j _hj
    have hpos : 0 < (j : Nat) := (Finset.mem_Icc.mp j.property).1
    simp [hpos]
  rw [hattach]
  exact primeTowerEventGains_sum_eq_topCorrection_sub
    (p := p) (d := d) hpPrime

/-- The endpoint correction drop is the local prime-power abundancy factor. -/
theorem primeTowerTopCorrection_zero_sub_eq_log_geom_div_pow
    {p k : Nat} (hp : 1 < (p : Real)) :
    primeTowerTopCorrection p 0 - primeTowerTopCorrection p k =
      Real.log
        (((Finset.range (k + 1)).sum (fun i => (p : Real) ^ i)) /
          ((p : Real) ^ k)) := by
  have hA : 0 < 1 - (p : Real) ^ (-(k + 1 : Int)) := by
    simpa using
      one_sub_prime_zpow_neg_pos (p := p) hp (j := k + 1)
        (Nat.succ_pos k)
  have hB : 0 < 1 - (p : Real) ^ (-(1 : Int)) := by
    simpa using
      one_sub_prime_zpow_neg_pos (p := p) hp (j := 1)
        (by norm_num : 0 < 1)
  have hlog :
      primeTowerTopCorrection p 0 - primeTowerTopCorrection p k =
        Real.log
          (((1 - (p : Real) ^ (-(k + 1 : Int))) /
            (1 - (p : Real) ^ (-(1 : Int))))) := by
    dsimp [primeTowerTopCorrection]
    rw [Real.log_div (ne_of_gt hA) (ne_of_gt hB)]
    ring
  rw [hlog]
  apply congrArg Real.log
  have hp_pos : 0 < (p : Real) := lt_trans zero_lt_one hp
  have hp0 : (p : Real) ≠ 0 := ne_of_gt hp_pos
  have hp1 : (p : Real) ≠ 1 := ne_of_gt hp
  have hz : (p : Real) ^ ((k : Int) + 1) = (p : Real) ^ (k + 1) := by
    simpa using zpow_natCast (p : Real) (k + 1)
  rw [geom_sum_eq hp1]
  rw [zpow_neg, zpow_neg, hz]
  norm_num
  field_simp [hp0, hp1]
  ring

/-- The support-indexed factorization tower gain sum telescopes prime by prime
to finite Euler-factor endpoint corrections. -/
theorem actualFactorizationTowerEvents_sum_gain_eq_factorization_topCorrection
    (n : Nat) :
    (actualFactorizationTowerEvents n).sum (fun e => e.gain) =
      n.factorization.sum
        (fun p k =>
          primeTowerTopCorrection p 0 - primeTowerTopCorrection p k) := by
  classical
  unfold actualFactorizationTowerEvents
  rw [Finset.sum_biUnion
    (pairwiseDisjoint_actualFactorizationTowerEventsForPrime n)]
  rw [Finsupp.sum]
  conv_rhs =>
    rw [← Finset.sum_attach]
  apply Finset.sum_congr rfl
  intro p hp
  unfold actualFactorizationTowerEventsForPrime
  rw [Finset.sum_image]
  · have hpPrime : Nat.Prime p.val := by
      have hpPrimeFactors : p.val ∈ n.primeFactors := by
        exact p.property
      exact Nat.prime_of_mem_primeFactors hpPrimeFactors
    simpa using
      primeTowerEventGains_attach_sum_eq_topCorrection_sub
        (p := p.val) (d := n.factorization p.val) hpPrime
  · intro a _ha b _hb h
    exact Subtype.ext (congrArg Robin1984.Event.j h)

/-- The factorization endpoint-correction product is exactly
`log (sigma(n) / n)`. -/
theorem factorization_primeTowerTopCorrection_sum_eq_log_abundancy
    {n : Nat} (hn : n ≠ 0) :
    n.factorization.sum
        (fun p k =>
          primeTowerTopCorrection p 0 - primeTowerTopCorrection p k) =
      Real.log (abundancy n) := by
  classical
  let localGain : Nat → Real := fun p =>
    ((Finset.range (n.factorization p + 1)).sum
        (fun i => (p : Real) ^ i)) /
      ((p : Real) ^ n.factorization p)
  have hsum :
      n.factorization.sum
          (fun p k =>
            primeTowerTopCorrection p 0 - primeTowerTopCorrection p k) =
        ∑ p ∈ n.factorization.support, Real.log (localGain p) := by
    rw [Finsupp.sum]
    apply Finset.sum_congr rfl
    intro p hp
    have hpPrime : Nat.Prime p :=
      Nat.prime_of_mem_primeFactors (by
        simpa [Nat.support_factorization] using hp)
    have hpReal : 1 < (p : Real) := by exact_mod_cast hpPrime.one_lt
    simp [localGain,
      primeTowerTopCorrection_zero_sub_eq_log_geom_div_pow
        (p := p) (k := n.factorization p) hpReal]
  have hlocal_ne :
      ∀ p ∈ n.factorization.support, localGain p ≠ 0 := by
    intro p hp
    have hpPrime : Nat.Prime p :=
      Nat.prime_of_mem_primeFactors (by
        simpa [Nat.support_factorization] using hp)
    have hp_pos : 0 < (p : Real) := by exact_mod_cast hpPrime.pos
    have hden : (p : Real) ^ n.factorization p ≠ 0 :=
      pow_ne_zero _ (ne_of_gt hp_pos)
    have hnum_pos :
        0 <
          (Finset.range (n.factorization p + 1)).sum
            (fun i => (p : Real) ^ i) := by
      refine Finset.sum_pos (fun i _hi => pow_pos hp_pos i) ?_
      exact ⟨0, by simp⟩
    dsimp [localGain]
    exact div_ne_zero (ne_of_gt hnum_pos) hden
  have hprod_log :
      (∑ p ∈ n.factorization.support, Real.log (localGain p)) =
        Real.log (∏ p ∈ n.factorization.support, localGain p) :=
    (Real.log_prod hlocal_ne).symm
  rw [hsum, hprod_log]
  apply congrArg Real.log
  unfold abundancy
  have hsigma :
      (Robin1984.Core.sigmaOneNat n : Real) =
        ∏ p ∈ n.factorization.support,
          (Finset.range (n.factorization p + 1)).sum
            (fun i => (p : Real) ^ i) := by
    have h :=
      ArithmeticFunction.sigma_eq_prod_primeFactors_sum_range_factorization_pow_mul
        (k := 1) (n := n) hn
    unfold Robin1984.Core.sigmaOneNat
    rw [h]
    simp [Nat.support_factorization]
  have hnprod :
      (n : Real) =
        ∏ p ∈ n.factorization.support,
          (p : Real) ^ n.factorization p := by
    have hNat :
        (∏ p ∈ n.factorization.support, p ^ n.factorization p) = n := by
      simpa [Finsupp.prod] using Nat.prod_factorization_pow_eq_self hn
    exact_mod_cast hNat.symm
  rw [hsigma, hnprod]
  dsimp [localGain]
  rw [Finset.prod_div_distrib]

/-- Native actual-packet gain identity: summing event gains over the concrete
factorization packet gives `log (sigma(n) / n)`. -/
theorem actualExponentEvents_eventGainSum_eq_log_abundancy
    {n : Nat} (hn : n ≠ 0) :
    Robin1984.eventGainSum (actualExponentEvents n) = Real.log (abundancy n) := by
  rw [actualExponentEvents_eq_actualFactorizationTowerEvents hn]
  unfold Robin1984.eventGainSum
  rw [actualFactorizationTowerEvents_sum_gain_eq_factorization_topCorrection]
  exact factorization_primeTowerTopCorrection_sum_eq_log_abundancy (n := n) hn


/-- The CA log-objective of an integer is exactly the reduced weight of its
actual factorization event packet at the same cutoff. -/
theorem caLogObjective_eq_actualExponentEvents_eventPacketReducedWeight
    {eps : Real} {n : Nat} (hn : n ≠ 0) :
    caLogObjective eps n =
      Robin1984.eventPacketReducedWeight eps (actualExponentEvents n) := by
  rw [caLogObjective_eq_log_abundancy_sub (eps := eps)
    (n := n) (Nat.pos_of_ne_zero hn)]
  rw [Robin1984.eventPacketReducedWeight_eq_eventGainSum_sub]
  rw [actualExponentEvents_eventGainSum_eq_log_abundancy (n := n) hn,
    actualExponentEvents_eventLogMass_eq_log (n := n) hn]

/-- The actual exponent-event packet has sigma coordinate
`log (sigma(n) / n)`. -/
theorem actualExponentState_logSigmaOverN_eq_log_abundancy
    {n : Nat} (hn : n ≠ 0) :
    (actualExponentState n).logSigmaOverN = Real.log (abundancy n) := by
  unfold actualExponentState Robin1984.applyPacket
  simpa [Robin1984.zeroCAState, Robin1984.eventGainSum] using
    actualExponentEvents_eventGainSum_eq_log_abundancy (n := n) hn


/-- The same tangent bound for every `U > 1`, not only for points to the
right of `L`.  This is the form needed to move from a Robin counterexample to
a CA/log-objective maximizer at the tangent cutoff. -/
theorem log_log_sub_le_frontier_tangent_global
    {L U : Real} (hL : 1 < L) (hU : 1 < U) :
    Real.log (Real.log U) - Real.log (Real.log L) <=
      (L * Real.log L)⁻¹ * (U - L) := by
  have hLpos : 0 < L := lt_trans zero_lt_one hL
  have hUpos : 0 < U := lt_trans zero_lt_one hU
  have hLogLpos : 0 < Real.log L := Real.log_pos hL
  have hLogUpos : 0 < Real.log U := Real.log_pos hU
  have hLogRatioPos : 0 < Real.log U / Real.log L :=
    div_pos hLogUpos hLogLpos
  have hLogRatio := Real.log_le_sub_one_of_pos hLogRatioPos
  have hLogDivLogs :
      Real.log (Real.log U / Real.log L) =
        Real.log (Real.log U) - Real.log (Real.log L) :=
    Real.log_div (ne_of_gt hLogUpos) (ne_of_gt hLogLpos)
  have hStep1 :
      Real.log (Real.log U) - Real.log (Real.log L) <=
        Real.log U / Real.log L - 1 := by
    rw [← hLogDivLogs]
    exact hLogRatio
  have hURatioPos : 0 < U / L := div_pos hUpos hLpos
  have hLogURatio := Real.log_le_sub_one_of_pos hURatioPos
  have hLogDivUL : Real.log (U / L) = Real.log U - Real.log L :=
    Real.log_div (ne_of_gt hUpos) (ne_of_gt hLpos)
  have hLogDiff_le : Real.log U - Real.log L <= U / L - 1 := by
    rw [← hLogDivUL]
    exact hLogURatio
  have hUL_sub : U / L - 1 = (U - L) / L := by
    field_simp [ne_of_gt hLpos]
  have hLogDiff_le' : Real.log U - Real.log L <= (U - L) / L := by
    simpa [hUL_sub] using hLogDiff_le
  have hStep2 :
      Real.log U / Real.log L - 1 <=
        ((U - L) / L) / Real.log L := by
    have hEq :
        Real.log U / Real.log L - 1 =
          (Real.log U - Real.log L) / Real.log L := by
      field_simp [ne_of_gt hLogLpos]
    rw [hEq]
    exact div_le_div_of_nonneg_right hLogDiff_le' (le_of_lt hLogLpos)
  have hStep3 :
      ((U - L) / L) / Real.log L =
        (L * Real.log L)⁻¹ * (U - L) := by
    field_simp [ne_of_gt hLpos, ne_of_gt hLogLpos]
  exact hStep1.trans (hStep2.trans (le_of_eq hStep3))


end Robin1984
end

/- Inlined module Robin1984.ColossallyAbundant.RobinLogMargin. -/
section
/-!
## Provenance

- Classification: **Primarily project-original**.
- Mathematical source: No external theorem is directly formalized; published inputs retain their attribution in the imported modules and project bibliography.
- Formalization note: The retained definitions, interfaces, reductions, or proof assembly are primarily original to this formalization.
- PROVENANCE-END
-/

/-!
# Robin's inequality as positivity of a logarithmic margin

The logarithmic margin of the actual exponent state is positive exactly when
the integer satisfies Robin's inequality.
-/

namespace Robin1984

noncomputable section

theorem actualExponentState_lyapunov_pos_iff_nativeRobinInequality
    {n : Nat} (hnCut : 5040 < n) :
    0 < Robin1984.lyapunov (actualExponentState n) <->
      Robin1984.Core.NativeRobinInequality n := by
  have hnPos : 0 < n := Nat.zero_lt_of_lt hnCut
  have hnNe : Not (n = 0) := Nat.ne_of_gt hnPos
  have hAbundancyPos : 0 < abundancy n := abundancy_pos hnPos
  have hBoundPos : 0 < robinBoundRatio n :=
    robinBoundRatio_pos_of_cutoff hnCut
  rw [nativeRobinInequality_iff_abundancy_lt_bound hnPos]
  unfold Robin1984.lyapunov
  rw [actualExponentState_logN_eq_log hnNe,
    actualExponentState_logSigmaOverN_eq_log_abundancy hnNe]
  constructor
  case mp =>
    intro hMargin
    have hLog :
        Real.log (abundancy n) < Real.log (robinBoundRatio n) := by
      rw [log_robinBoundRatio_eq_of_cutoff hnCut]
      linarith
    calc
      abundancy n = Real.exp (Real.log (abundancy n)) :=
        (Real.exp_log hAbundancyPos).symm
      _ < Real.exp (Real.log (robinBoundRatio n)) :=
        Real.exp_lt_exp.mpr hLog
      _ = robinBoundRatio n := Real.exp_log hBoundPos
  case mpr =>
    intro hRobin
    have hLog :
        Real.log (abundancy n) < Real.log (robinBoundRatio n) :=
      Real.log_lt_log hAbundancyPos hRobin
    rw [log_robinBoundRatio_eq_of_cutoff hnCut] at hLog
    linarith


end

end Robin1984
end

/- Inlined module Robin1984.Finite.RobinTangentStartup. -/
section
/-!
## Provenance

- Classification: **Primarily project-original**.
- Mathematical source: Robin (1984) supplies the exceptional cutoff and finite proof obligation.
- Formalization note: The rational certificate formats, interval partition, tangent argument, and exact startup verification are primarily project-authored.
- PROVENANCE-END
-/

/-!
# Constructive startup for the Robin tangent-CA coverage

This module isolates the finite `5040 -> 55440` transition used by the exact
Robin-equivalent coverage theorem.
-/

namespace Robin1984

noncomputable section

private theorem startup_mul_div_cancel_left_pos
    (x y : Real) (hx : 0 < x) :
    x * y / x = y := by
  field_simp [ne_of_gt hx]

private theorem startup_div_div_cancel_left_pos
    (x y : Real) (hx : 0 < x) (hy : 0 < y) :
    (x / y) / x = 1 / y := by
  field_simp [ne_of_gt hx, ne_of_gt hy]

/-- The shared CA transition parameter of `5040` and `55440`. -/
def ca5040To55440Cutoff : Real :=
  Robin1984.firstLayerThreshold (11 : Real)

/-- Every prime divisor of `5040` is one of its four prime bases. -/
theorem prime_dvd_5040_cases
    {p : Nat} (hp : Nat.Prime p) (hd : Dvd.dvd p 5040) :
    Or (p = 2) (Or (p = 3) (Or (p = 5) (p = 7))) := by
  have hfac : 5040 = (((2 ^ 4) * (3 ^ 2)) * 5) * 7 := by
    norm_num
  rw [hfac] at hd
  exact Or.elim (hp.dvd_mul.mp hd)
    (fun h235 =>
      Or.elim (hp.dvd_mul.mp h235)
        (fun h23 =>
          Or.elim (hp.dvd_mul.mp h23)
            (fun h2 => Or.inl
              ((Nat.prime_dvd_prime_iff_eq hp (by norm_num)).mp
                (hp.dvd_of_dvd_pow h2)))
            (fun h3 => Or.inr (Or.inl
              ((Nat.prime_dvd_prime_iff_eq hp (by norm_num)).mp
                (hp.dvd_of_dvd_pow h3)))))
        (fun h5 => Or.inr (Or.inr (Or.inl
          ((Nat.prime_dvd_prime_iff_eq hp (by norm_num)).mp h5)))))
    (fun h7 => Or.inr (Or.inr (Or.inr
      ((Nat.prime_dvd_prime_iff_eq hp (by norm_num)).mp h7))))

/-- A rational power certificate puts an event threshold above `1 / N`. -/
theorem one_div_nat_lt_event_threshold_of_prime_lt_gainRatio_pow
    {e : Robin1984.Event} {N : Nat} (hN : 0 < N)
    (hPow :
      (e.p : Real) <
        (Robin1984.eventGainRatio ((e.p : Real) ^ (-1 : Int)) e.j) ^ N) :
    1 / (N : Real) < e.threshold := by
  have hNReal : (0 : Real) < (N : Real) := by
    exact_mod_cast hN
  have hRatioPos :
      0 < Robin1984.eventGainRatio ((e.p : Real) ^ (-1 : Int)) e.j := by
    apply Robin1984.eventGainRatio_pos
    rw [zpow_neg_one]
    exact inv_pos.mpr e.prime_pos
    rw [zpow_neg_one]
    have hpOne : (1 : Real) < (e.p : Real) := by
      exact_mod_cast e.hp.one_lt
    have hInv :=
      (div_lt_div_iff_of_pos_left (a := (1 : Real))
        (by norm_num : (0 : Real) < 1) e.prime_pos
        (by norm_num : (0 : Real) < 1)).2 hpOne
    simpa [one_div] using hInv
    exact e.hj
  have hLogPow :
      Real.log (e.p : Real) <
        (N : Real) *
          Real.log
            (Robin1984.eventGainRatio ((e.p : Real) ^ (-1 : Int)) e.j) := by
    have hLog := Real.log_lt_log e.prime_pos hPow
    simpa [Real.log_pow] using hLog
  have hDiv :
      Real.log (e.p : Real) / (N : Real) <
        Real.log
          (Robin1984.eventGainRatio ((e.p : Real) ^ (-1 : Int)) e.j) := by
    have hScaled :=
      (div_lt_div_iff_of_pos_right hNReal).2 hLogPow
    calc
      Real.log (e.p : Real) / (N : Real) <
          ((N : Real) *
              Real.log
                (Robin1984.eventGainRatio
                  ((e.p : Real) ^ (-1 : Int)) e.j)) / (N : Real) := hScaled
      _ = Real.log
          (Robin1984.eventGainRatio ((e.p : Real) ^ (-1 : Int)) e.j) := by
        exact startup_mul_div_cancel_left_pos _ _ hNReal
  have hFinal :=
    (div_lt_div_iff_of_pos_right e.log_prime_pos).2 hDiv
  have hBound :
      1 / (N : Real) <
        Real.log
            (Robin1984.eventGainRatio ((e.p : Real) ^ (-1 : Int)) e.j) /
          Real.log (e.p : Real) := by
    calc
      1 / (N : Real) =
          (Real.log (e.p : Real) / (N : Real)) /
            Real.log (e.p : Real) := by
        exact
          (startup_div_div_cancel_left_pos _ _ e.log_prime_pos hNReal).symm
      _ < Real.log
            (Robin1984.eventGainRatio ((e.p : Real) ^ (-1 : Int)) e.j) /
          Real.log (e.p : Real) := hFinal
  rw [Robin1984.Event.threshold, Robin1984.event_gain_eq_log_eventGainRatio]
  simpa [zpow_neg_one] using hBound

/-- A rational power certificate puts an event threshold below `1 / N`. -/
theorem event_threshold_lt_one_div_nat_of_gainRatio_pow_lt_prime
    {e : Robin1984.Event} {N : Nat} (hN : 0 < N)
    (hPow :
      (Robin1984.eventGainRatio ((e.p : Real) ^ (-1 : Int)) e.j) ^ N <
        (e.p : Real)) :
    e.threshold < 1 / (N : Real) := by
  have hNReal : (0 : Real) < (N : Real) := by
    exact_mod_cast hN
  have hRatioPos :
      0 < Robin1984.eventGainRatio ((e.p : Real) ^ (-1 : Int)) e.j := by
    apply Robin1984.eventGainRatio_pos
    rw [zpow_neg_one]
    exact inv_pos.mpr e.prime_pos
    rw [zpow_neg_one]
    have hpOne : (1 : Real) < (e.p : Real) := by
      exact_mod_cast e.hp.one_lt
    have hInv :=
      (div_lt_div_iff_of_pos_left (a := (1 : Real))
        (by norm_num : (0 : Real) < 1) e.prime_pos
        (by norm_num : (0 : Real) < 1)).2 hpOne
    simpa [one_div] using hInv
    exact e.hj
  have hLogPow :
      (N : Real) *
          Real.log
            (Robin1984.eventGainRatio ((e.p : Real) ^ (-1 : Int)) e.j) <
        Real.log (e.p : Real) := by
    have hLog := Real.log_lt_log (pow_pos hRatioPos N) hPow
    simpa [Real.log_pow] using hLog
  have hDiv :
      Real.log
          (Robin1984.eventGainRatio ((e.p : Real) ^ (-1 : Int)) e.j) <
        Real.log (e.p : Real) / (N : Real) := by
    have hScaled :=
      (div_lt_div_iff_of_pos_right hNReal).2 hLogPow
    calc
      Real.log
          (Robin1984.eventGainRatio ((e.p : Real) ^ (-1 : Int)) e.j) =
          ((N : Real) *
              Real.log
                (Robin1984.eventGainRatio
                  ((e.p : Real) ^ (-1 : Int)) e.j)) / (N : Real) := by
        exact (startup_mul_div_cancel_left_pos _ _ hNReal).symm
      _ < Real.log (e.p : Real) / (N : Real) := hScaled
  have hFinal :=
    (div_lt_div_iff_of_pos_right e.log_prime_pos).2 hDiv
  have hBound :
      Real.log
            (Robin1984.eventGainRatio ((e.p : Real) ^ (-1 : Int)) e.j) /
          Real.log (e.p : Real) <
        1 / (N : Real) := by
    calc
      Real.log
            (Robin1984.eventGainRatio ((e.p : Real) ^ (-1 : Int)) e.j) /
          Real.log (e.p : Real) <
          (Real.log (e.p : Real) / (N : Real)) /
            Real.log (e.p : Real) := hFinal
      _ = 1 / (N : Real) := by
        exact startup_div_div_cancel_left_pos _ _ e.log_prime_pos hNReal
  rw [Robin1984.Event.threshold, Robin1984.event_gain_eq_log_eventGainRatio]
  simpa [zpow_neg_one] using hBound

theorem prime_11 : Nat.Prime 11 := by norm_num

theorem one_pos_nat : 0 < (1 : Nat) := by norm_num

/-- The event whose admission changes `5040` into `55440`. -/
def ca5040To55440Event : Robin1984.Event :=
  Robin1984.layerEventOfPrime 11 1 prime_11 one_pos_nat

theorem ca5040To55440Event_threshold_eq_cutoff :
    ca5040To55440Event.threshold = ca5040To55440Cutoff := by
  rw [Robin1984.Event.threshold_eq_firstLayer_of_j_eq_one
    (e := ca5040To55440Event) (by rfl)]
  rfl

/-- Exact rational enclosure used to separate all non-tie startup events. -/
theorem ca5040To55440Cutoff_lower :
    (1 : Real) / 34 < ca5040To55440Cutoff := by
  rw [<- ca5040To55440Event_threshold_eq_cutoff]
  apply one_div_nat_lt_event_threshold_of_prime_lt_gainRatio_pow
    (e := ca5040To55440Event) (N := 34) (by norm_num)
  norm_num [ca5040To55440Event, Robin1984.layerEventOfPrime,
    Robin1984.eventGainRatio]

theorem ca5040To55440Cutoff_upper :
    ca5040To55440Cutoff < (1 : Real) / 22 := by
  rw [<- ca5040To55440Event_threshold_eq_cutoff]
  apply event_threshold_lt_one_div_nat_of_gainRatio_pow_lt_prime
    (e := ca5040To55440Event) (N := 22) (by norm_num)
  norm_num [ca5040To55440Event, Robin1984.layerEventOfPrime,
    Robin1984.eventGainRatio]

theorem factorization_5040_at_11 :
    Nat.factorization 5040 11 = 0 := by
  apply Nat.factorization_eq_zero_of_not_dvd
  norm_num

theorem ca5040To55440Event_is_first_missing :
    ca5040To55440Event.j =
      Nat.factorization 5040 ca5040To55440Event.p + 1 := by
  simp [ca5040To55440Event, Robin1984.layerEventOfPrime,
    factorization_5040_at_11]

/-- The two startup integers have exactly the same tangent objective. -/
theorem caLogObjective_55440_eq_5040_at_cutoff :
    caLogObjective ca5040To55440Cutoff 55440 =
      caLogObjective ca5040To55440Cutoff 5040 := by
  have hWeightZero :
      Robin1984.eventReducedWeight ca5040To55440Cutoff
          ca5040To55440Event = 0 :=
    Robin1984.eventReducedWeight_eq_zero_of_threshold_eq
      ca5040To55440Event_threshold_eq_cutoff
  have hVariation :=
    eventReducedWeight_add_first_eq_logVariation
      (n := 5040) (eps := ca5040To55440Cutoff)
      (first := ca5040To55440Event)
      (by norm_num) ca5040To55440Event_is_first_missing
  rw [hVariation] at hWeightZero
  norm_num [ca5040To55440Event, Robin1984.layerEventOfPrime] at hWeightZero
  linarith

/-- One startup CA certificate suffices: the exact tie promotes it to `55440`. -/
theorem colossallyAbundantWith_55440_of_5040
    (h5040 : IsColossallyAbundantWith 5040 ca5040To55440Cutoff) :
    IsColossallyAbundantWith 55440 ca5040To55440Cutoff := by
  have hLogEq := caLogObjective_55440_eq_5040_at_cutoff
  unfold caLogObjective at hLogEq
  have h55440Pos : 0 < caObjective ca5040To55440Cutoff 55440 :=
    caObjective_pos (by norm_num)
  have h5040Pos : 0 < caObjective ca5040To55440Cutoff 5040 :=
    caObjective_pos (by norm_num)
  have hObjEq :
      caObjective ca5040To55440Cutoff 55440 =
        caObjective ca5040To55440Cutoff 5040 :=
    le_antisymm
      ((Real.log_le_log_iff h55440Pos h5040Pos).mp (le_of_eq hLogEq))
      ((Real.log_le_log_iff h5040Pos h55440Pos).mp (le_of_eq hLogEq.symm))
  exact And.intro h5040.eps_pos
    (And.intro (by norm_num)
      (by
        intro k hk
        rw [hObjEq]
        exact h5040.objective_max hk))

/-- A complete sign classification makes `base` maximize reduced packet
weight among every finite competitor packet. -/
theorem eventPacketReducedWeight_le_of_complete_signs
    {lambda : Real} {base events : Finset Robin1984.Event}
    (hBase : forall e : Robin1984.Event,
      Membership.mem base e -> 0 <= Robin1984.eventReducedWeight lambda e)
    (hOutside : forall e : Robin1984.Event,
      Membership.mem events e -> Not (Membership.mem base e) ->
        Robin1984.eventReducedWeight lambda e <= 0) :
    Robin1984.eventPacketReducedWeight lambda events <=
      Robin1984.eventPacketReducedWeight lambda base := by
  classical
  let common : Finset Robin1984.Event :=
    events.filter (fun e => Membership.mem base e)
  have hCommonEvent : common <= events := by
    exact Finset.filter_subset _ _
  have hCommonBase : common <= base := by
    intro e he
    exact (Finset.mem_filter.mp he).2
  have hEventSplit :=
    Finset.sum_sdiff hCommonEvent
      (f := fun e => Robin1984.eventReducedWeight lambda e)
  have hBaseSplit :=
    Finset.sum_sdiff hCommonBase
      (f := fun e => Robin1984.eventReducedWeight lambda e)
  have hEventRemainder :
      Finset.sum (events \ common)
          (fun e => Robin1984.eventReducedWeight lambda e) <= 0 := by
    calc
      Finset.sum (events \ common)
          (fun e => Robin1984.eventReducedWeight lambda e) <=
          Finset.sum (events \ common) (fun _ => 0) := by
        apply Finset.sum_le_sum
        intro e he
        have heParts := Finset.mem_sdiff.mp he
        have hNotBase : Not (Membership.mem base e) := by
          intro heBase
          exact heParts.2
            (Finset.mem_filter.mpr (And.intro heParts.1 heBase))
        exact hOutside e heParts.1 hNotBase
      _ = 0 := by simp
  have hBaseRemainder :
      0 <= Finset.sum (base \ common)
        (fun e => Robin1984.eventReducedWeight lambda e) := by
    apply Finset.sum_nonneg
    intro e he
    exact hBase e (Finset.mem_sdiff.mp he).1
  unfold Robin1984.eventPacketReducedWeight
  linarith

theorem factorization_5040_at_2 : Nat.factorization 5040 2 = 4 := by
  have hMul := congrArg (fun f => f 2)
    (Nat.factorization_mul (a := 16) (b := 315)
      (by norm_num) (by norm_num))
  have hLeft : Nat.factorization 16 2 = 4 := by
    simpa using Nat.factorization_pow_self (p := 2) (n := 4) Nat.prime_two
  have hRight : Nat.factorization 315 2 = 0 :=
    Nat.factorization_eq_zero_of_not_dvd (by norm_num)
  calc
    Nat.factorization 5040 2 =
        Nat.factorization 16 2 + Nat.factorization 315 2 := by
      simpa using hMul
    _ = 4 := by rw [hLeft, hRight]

theorem factorization_5040_at_3 : Nat.factorization 5040 3 = 2 := by
  have hp : Nat.Prime 3 := by norm_num
  have hMul := congrArg (fun f => f 3)
    (Nat.factorization_mul (a := 9) (b := 560)
      (by norm_num) (by norm_num))
  have hLeft : Nat.factorization 9 3 = 2 := by
    simpa using Nat.factorization_pow_self (p := 3) (n := 2) hp
  have hRight : Nat.factorization 560 3 = 0 :=
    Nat.factorization_eq_zero_of_not_dvd (by norm_num)
  calc
    Nat.factorization 5040 3 =
        Nat.factorization 9 3 + Nat.factorization 560 3 := by
      simpa using hMul
    _ = 2 := by rw [hLeft, hRight]

theorem factorization_5040_at_5 : Nat.factorization 5040 5 = 1 := by
  have hp : Nat.Prime 5 := by norm_num
  have hMul := congrArg (fun f => f 5)
    (Nat.factorization_mul (a := 5) (b := 1008)
      (by norm_num) (by norm_num))
  have hLeft : Nat.factorization 5 5 = 1 := hp.factorization_self
  have hRight : Nat.factorization 1008 5 = 0 :=
    Nat.factorization_eq_zero_of_not_dvd (by norm_num)
  calc
    Nat.factorization 5040 5 =
        Nat.factorization 5 5 + Nat.factorization 1008 5 := by
      simpa using hMul
    _ = 1 := by rw [hLeft, hRight]

theorem factorization_5040_at_7 : Nat.factorization 5040 7 = 1 := by
  have hp : Nat.Prime 7 := by norm_num
  have hMul := congrArg (fun f => f 7)
    (Nat.factorization_mul (a := 7) (b := 720)
      (by norm_num) (by norm_num))
  have hLeft : Nat.factorization 7 7 = 1 := hp.factorization_self
  have hRight : Nat.factorization 720 7 = 0 :=
    Nat.factorization_eq_zero_of_not_dvd (by norm_num)
  calc
    Nat.factorization 5040 7 =
        Nat.factorization 7 7 + Nat.factorization 720 7 := by
      simpa using hMul
    _ = 1 := by rw [hLeft, hRight]

theorem cutoff_lt_event_threshold_of_pow22_certificate
    (e : Robin1984.Event)
    (hPow :
      (e.p : Real) <
        (Robin1984.eventGainRatio ((e.p : Real) ^ (-1 : Int)) e.j) ^ 22) :
    ca5040To55440Cutoff < e.threshold :=
  lt_trans ca5040To55440Cutoff_upper
    (one_div_nat_lt_event_threshold_of_prime_lt_gainRatio_pow
      (e := e) (N := 22) (by norm_num) hPow)

theorem event_threshold_lt_cutoff_of_pow34_certificate
    (e : Robin1984.Event)
    (hPow :
      (Robin1984.eventGainRatio ((e.p : Real) ^ (-1 : Int)) e.j) ^ 34 <
        (e.p : Real)) :
    e.threshold < ca5040To55440Cutoff :=
  lt_trans
    (event_threshold_lt_one_div_nat_of_gainRatio_pow_lt_prime
      (e := e) (N := 34) (by norm_num) hPow)
    ca5040To55440Cutoff_lower

def ca5040Top2 : Robin1984.Event :=
  Robin1984.layerEventOfPrime 2 4 Nat.prime_two (by norm_num)

def ca5040Top3 : Robin1984.Event :=
  Robin1984.layerEventOfPrime 3 2 (by norm_num) (by norm_num)

def ca5040Top5 : Robin1984.Event :=
  Robin1984.layerEventOfPrime 5 1 (by norm_num) one_pos_nat

def ca5040Top7 : Robin1984.Event :=
  Robin1984.layerEventOfPrime 7 1 (by norm_num) one_pos_nat

def ca5040FirstMissing2 : Robin1984.Event :=
  Robin1984.layerEventOfPrime 2 5 Nat.prime_two (by norm_num)

def ca5040FirstMissing3 : Robin1984.Event :=
  Robin1984.layerEventOfPrime 3 3 (by norm_num) (by norm_num)

def ca5040FirstMissing5 : Robin1984.Event :=
  Robin1984.layerEventOfPrime 5 2 (by norm_num) (by norm_num)

def ca5040FirstMissing7 : Robin1984.Event :=
  Robin1984.layerEventOfPrime 7 2 (by norm_num) (by norm_num)

theorem cutoff_lt_ca5040Top2_threshold :
    ca5040To55440Cutoff < ca5040Top2.threshold := by
  apply cutoff_lt_event_threshold_of_pow22_certificate
  change (2 : Real) <
    (Robin1984.eventGainRatio ((2 : Real) ^ (-1 : Int)) 4) ^ 22
  have hRatio :
      Robin1984.eventGainRatio ((2 : Real) ^ (-1 : Int)) 4 =
        (31 : Real) / 30 := by
    norm_num [Robin1984.eventGainRatio]
  rw [hRatio]
  norm_num

theorem cutoff_lt_ca5040Top3_threshold :
    ca5040To55440Cutoff < ca5040Top3.threshold := by
  apply cutoff_lt_event_threshold_of_pow22_certificate
  change (3 : Real) <
    (Robin1984.eventGainRatio ((3 : Real) ^ (-1 : Int)) 2) ^ 22
  have hRatio :
      Robin1984.eventGainRatio ((3 : Real) ^ (-1 : Int)) 2 =
        (13 : Real) / 12 := by
    norm_num [Robin1984.eventGainRatio]
  rw [hRatio]
  norm_num

theorem cutoff_lt_ca5040Top5_threshold :
    ca5040To55440Cutoff < ca5040Top5.threshold := by
  apply cutoff_lt_event_threshold_of_pow22_certificate
  change (5 : Real) <
    (Robin1984.eventGainRatio ((5 : Real) ^ (-1 : Int)) 1) ^ 22
  have hRatio :
      Robin1984.eventGainRatio ((5 : Real) ^ (-1 : Int)) 1 =
        (6 : Real) / 5 := by
    norm_num [Robin1984.eventGainRatio]
  rw [hRatio]
  norm_num

theorem cutoff_lt_ca5040Top7_threshold :
    ca5040To55440Cutoff < ca5040Top7.threshold := by
  apply cutoff_lt_event_threshold_of_pow22_certificate
  change (7 : Real) <
    (Robin1984.eventGainRatio ((7 : Real) ^ (-1 : Int)) 1) ^ 22
  have hRatio :
      Robin1984.eventGainRatio ((7 : Real) ^ (-1 : Int)) 1 =
        (8 : Real) / 7 := by
    norm_num [Robin1984.eventGainRatio]
  rw [hRatio]
  norm_num

theorem ca5040FirstMissing2_threshold_lt_cutoff :
    ca5040FirstMissing2.threshold < ca5040To55440Cutoff := by
  apply event_threshold_lt_cutoff_of_pow34_certificate
  change (Robin1984.eventGainRatio ((2 : Real) ^ (-1 : Int)) 5) ^ 34 <
    (2 : Real)
  have hRatio :
      Robin1984.eventGainRatio ((2 : Real) ^ (-1 : Int)) 5 =
        (63 : Real) / 62 := by
    norm_num [Robin1984.eventGainRatio]
  rw [hRatio]
  norm_num

theorem ca5040FirstMissing3_threshold_lt_cutoff :
    ca5040FirstMissing3.threshold < ca5040To55440Cutoff := by
  apply event_threshold_lt_cutoff_of_pow34_certificate
  change (Robin1984.eventGainRatio ((3 : Real) ^ (-1 : Int)) 3) ^ 34 <
    (3 : Real)
  have hRatio :
      Robin1984.eventGainRatio ((3 : Real) ^ (-1 : Int)) 3 =
        (40 : Real) / 39 := by
    norm_num [Robin1984.eventGainRatio]
  rw [hRatio]
  norm_num

theorem ca5040FirstMissing5_threshold_lt_cutoff :
    ca5040FirstMissing5.threshold < ca5040To55440Cutoff := by
  apply event_threshold_lt_cutoff_of_pow34_certificate
  change (Robin1984.eventGainRatio ((5 : Real) ^ (-1 : Int)) 2) ^ 34 <
    (5 : Real)
  have hRatio :
      Robin1984.eventGainRatio ((5 : Real) ^ (-1 : Int)) 2 =
        (31 : Real) / 30 := by
    norm_num [Robin1984.eventGainRatio]
  rw [hRatio]
  norm_num

theorem ca5040FirstMissing7_threshold_lt_cutoff :
    ca5040FirstMissing7.threshold < ca5040To55440Cutoff := by
  apply event_threshold_lt_cutoff_of_pow34_certificate
  change (Robin1984.eventGainRatio ((7 : Real) ^ (-1 : Int)) 2) ^ 34 <
    (7 : Real)
  have hRatio :
      Robin1984.eventGainRatio ((7 : Real) ^ (-1 : Int)) 2 =
        (57 : Real) / 56 := by
    norm_num [Robin1984.eventGainRatio]
  rw [hRatio]
  norm_num

end

end Robin1984
end

/- Inlined module Robin1984.Equivalence.RobinTangentTransfer. -/
section
/-!
## Provenance

- Classification: **Primarily project-original**.
- Mathematical source: No external theorem is directly formalized; published inputs retain their attribution in the imported modules and project bibliography.
- Formalization note: The retained definitions, interfaces, reductions, or proof assembly are primarily original to this formalization.
- PROVENANCE-END
-/

/-!
# Transferring Robin's inequality through tangent CA maximizers

These statements quantify over arbitrary actual exponent states at actual
first-layer frontiers.  A maximizer for the tangent colossally abundant
objective transfers Robin's inequality back to the original integer.
-/

namespace Robin1984

noncomputable section


/-- Constructive tangent-support transfer: if `q` has at least the fixed
Robin-tangent CA objective of `n`, then Robin at `q` implies Robin at `n`. -/
theorem nativeRobinInequality_of_tangentCAObjective_ge
    {n q : Nat}
    (hnCut : 5040 < n)
    (hqCut : 5040 < q)
    (hObj :
      caLogObjective (robinFrontierCutoff n) n <=
        caLogObjective (robinFrontierCutoff n) q)
    (hqRobin : Robin1984.Core.NativeRobinInequality q) :
    Robin1984.Core.NativeRobinInequality n := by
  have hnPos : 0 < n := Nat.zero_lt_of_lt hnCut
  have hqPos : 0 < q := Nat.zero_lt_of_lt hqCut
  have hnNe : Not (n = 0) := Nat.ne_of_gt hnPos
  have hqNe : Not (q = 0) := Nat.ne_of_gt hqPos
  have hnLogOne : 1 < Real.log (n : Real) := by
    have hnRealPos : (0 : Real) < (n : Real) := by
      exact_mod_cast hnPos
    rw [Real.lt_log_iff_exp_lt hnRealPos]
    exact lt_trans Real.exp_one_lt_three
      (by exact_mod_cast (by omega : 3 < n))
  have hqLogOne : 1 < Real.log (q : Real) := by
    have hqRealPos : (0 : Real) < (q : Real) := by
      exact_mod_cast hqPos
    rw [Real.lt_log_iff_exp_lt hqRealPos]
    exact lt_trans Real.exp_one_lt_three
      (by exact_mod_cast (by omega : 3 < q))
  have hObjLog := hObj
  rw [caLogObjective_eq_log_abundancy_sub
        (eps := robinFrontierCutoff n) hnPos,
      caLogObjective_eq_log_abundancy_sub
        (eps := robinFrontierCutoff n) hqPos] at hObjLog
  unfold robinFrontierCutoff at hObjLog
  have hTangent :=
    log_log_sub_le_frontier_tangent_global hnLogOne hqLogOne
  have hqMargin : 0 < Robin1984.lyapunov (actualExponentState q) :=
    (actualExponentState_lyapunov_pos_iff_nativeRobinInequality hqCut).2
      hqRobin
  have hnMargin : 0 < Robin1984.lyapunov (actualExponentState n) := by
    unfold Robin1984.lyapunov at hqMargin
    unfold Robin1984.lyapunov
    rw [actualExponentState_logN_eq_log hqNe,
      actualExponentState_logSigmaOverN_eq_log_abundancy hqNe] at hqMargin
    rw [actualExponentState_logN_eq_log hnNe,
      actualExponentState_logSigmaOverN_eq_log_abundancy hnNe]
    linarith
  exact
    (actualExponentState_lyapunov_pos_iff_nativeRobinInequality hnCut).1
      hnMargin

/-- A Robin-good colossally abundant maximizer at `n`'s own tangent cutoff
constructively covers `n`. -/
theorem nativeRobinInequality_of_tangent_colossallyAbundant
    {n q : Nat}
    (hnCut : 5040 < n)
    (hqCut : 5040 < q)
    (hCA : IsColossallyAbundantWith q (robinFrontierCutoff n))
    (hqRobin : Robin1984.Core.NativeRobinInequality q) :
    Robin1984.Core.NativeRobinInequality n := by
  apply nativeRobinInequality_of_tangentCAObjective_ge hnCut hqCut
  case hObj =>
    exact hCA.logObjective_max (by omega : 1 < n)
  case hqRobin =>
    exact hqRobin

/-- If `5040` and `55440` are CA maximizers at a shared transition parameter,
then every maximizer at a smaller positive parameter lies above `5040`. -/
theorem tangentCAMaximizer_above_5040_of_shared_5040_55440
    {n q : Nat} {eps0 : Real}
    (hnCut : 5040 < n)
    (hEps : robinFrontierCutoff n < eps0)
    (h5040 : IsColossallyAbundantWith 5040 eps0)
    (h55440 : IsColossallyAbundantWith 55440 eps0)
    (hqCA : IsColossallyAbundantWith q (robinFrontierCutoff n)) :
    5040 < q := by
  by_contra hNot
  have hqLe : q <= 5040 := Nat.le_of_not_gt hNot
  have hqPos : 0 < q := Nat.zero_lt_of_lt hqCA.one_lt
  have hLambdaPos : 0 < robinFrontierCutoff n :=
    robinFrontierCutoff_pos_of_cutoff hnCut
  have hEq :
      caLogObjective eps0 5040 = caLogObjective eps0 55440 :=
    le_antisymm
      (h55440.logObjective_max (by norm_num : 1 < 5040))
      (h5040.logObjective_max (by norm_num : 1 < 55440))
  have hSmall :
      caLogObjective eps0 q <= caLogObjective eps0 5040 :=
    h5040.logObjective_max hqCA.one_lt
  have hMax :
      caLogObjective (robinFrontierCutoff n) 55440 <=
        caLogObjective (robinFrontierCutoff n) q :=
    hqCA.logObjective_max (by norm_num : 1 < 55440)
  rw [caLogObjective_eq_log_abundancy_sub (by norm_num : 0 < 5040),
      caLogObjective_eq_log_abundancy_sub (by norm_num : 0 < 55440)] at hEq
  rw [caLogObjective_eq_log_abundancy_sub hqPos,
      caLogObjective_eq_log_abundancy_sub (by norm_num : 0 < 5040)] at hSmall
  rw [caLogObjective_eq_log_abundancy_sub (by norm_num : 0 < 55440),
      caLogObjective_eq_log_abundancy_sub hqPos] at hMax
  have hqCastLe : (q : Real) <= (5040 : Real) := by
    exact_mod_cast hqLe
  have hLogqLe : Real.log (q : Real) <= Real.log (5040 : Real) :=
    Real.log_le_log (by exact_mod_cast hqPos) hqCastLe
  have hLogStep : Real.log (5040 : Real) < Real.log (55440 : Real) :=
    Real.log_lt_log (by norm_num) (by norm_num)
  have hPenaltyNonneg :
      0 <= (eps0 - robinFrontierCutoff n) *
        (Real.log (5040 : Real) - Real.log (q : Real)) :=
    mul_nonneg (sub_nonneg.mpr hEps.le) (sub_nonneg.mpr hLogqLe)
  have hStepPositive :
      0 < (eps0 - robinFrontierCutoff n) *
        (Real.log (55440 : Real) - Real.log (5040 : Real)) :=
    mul_pos (sub_pos.mpr hEps) (sub_pos.mpr hLogStep)
  have hSmallTransport :
      (Real.log (abundancy q) -
          robinFrontierCutoff n * Real.log (q : Real)) -
        (Real.log (abundancy 5040) -
          robinFrontierCutoff n * Real.log (5040 : Real)) =
      ((Real.log (abundancy q) - eps0 * Real.log (q : Real)) -
        (Real.log (abundancy 5040) - eps0 * Real.log (5040 : Real))) -
      (eps0 - robinFrontierCutoff n) *
        (Real.log (5040 : Real) - Real.log (q : Real)) := by
    ring
  have hSmallAtLambda :
      Real.log (abundancy q) -
          robinFrontierCutoff n * Real.log (q : Real) <=
        Real.log (abundancy 5040) -
          robinFrontierCutoff n * Real.log (5040 : Real) := by
    apply sub_nonpos.mp
    rw [hSmallTransport]
    apply sub_nonpos.mpr
    exact (sub_nonpos.mpr hSmall).trans hPenaltyNonneg
  have hStepTransport :
      (Real.log (abundancy 55440) -
          robinFrontierCutoff n * Real.log (55440 : Real)) -
        (Real.log (abundancy 5040) -
          robinFrontierCutoff n * Real.log (5040 : Real)) =
      ((Real.log (abundancy 55440) - eps0 * Real.log (55440 : Real)) -
        (Real.log (abundancy 5040) - eps0 * Real.log (5040 : Real))) +
      (eps0 - robinFrontierCutoff n) *
        (Real.log (55440 : Real) - Real.log (5040 : Real)) := by
    ring
  have hStepAtLambda :
      Real.log (abundancy 5040) -
          robinFrontierCutoff n * Real.log (5040 : Real) <
        Real.log (abundancy 55440) -
          robinFrontierCutoff n * Real.log (55440 : Real) := by
    apply sub_pos.mp
    rw [hStepTransport]
    have hBaseZero :
        (Real.log (abundancy 55440) -
            eps0 * Real.log (55440 : Real)) -
          (Real.log (abundancy 5040) -
            eps0 * Real.log (5040 : Real)) = 0 :=
      sub_eq_zero.mpr hEq.symm
    exact add_pos_of_nonneg_of_pos hBaseZero.ge hStepPositive
  exact (not_lt_of_ge (hMax.trans hSmallAtLambda)) hStepAtLambda

end

end Robin1984
end

/- Inlined module Robin1984.Finite.RobinTangentStartupComplete. -/
section
/-!
## Provenance

- Classification: **Primarily project-original**.
- Mathematical source: Robin (1984) supplies the exceptional cutoff and finite proof obligation.
- Formalization note: The rational certificate formats, interval partition, tangent argument, and exact startup verification are primarily project-authored.
- PROVENANCE-END
-/

/-!
# Complete constructive startup certificate for Robin tangent coverage

This module propagates the eight certified boundary signs across the complete
prime-power event packet and proves the classical CA startup pair.
-/

namespace Robin1984

noncomputable section

structure CA5040EventsPackage where
  events : Finset Robin1984.Event
  eq_actual : events = actualExponentEvents 5040

def ca5040EventsPackage : CA5040EventsPackage :=
  Classical.choice (show Nonempty CA5040EventsPackage from
    ⟨{ events := actualExponentEvents 5040, eq_actual := rfl }⟩)

/-- Opaque name for the concrete startup packet.  Keeping the generated
finset behind this projection prevents elaboration from evaluating all rows. -/
def ca5040Events : Finset Robin1984.Event := ca5040EventsPackage.events

theorem ca5040Events_eq_actualExponentEvents :
    ca5040Events = actualExponentEvents 5040 := by
  exact ca5040EventsPackage.eq_actual

theorem mem_ca5040Events_iff (e : Robin1984.Event) :
    Membership.mem ca5040Events e <->
      e.j <= Nat.factorization 5040 e.p := by
  rw [ca5040Events_eq_actualExponentEvents]
  exact mem_actualExponentEvents_iff (n := 5040) (e := e)
    (by norm_num : Not (5040 = 0))

theorem eventReducedWeight_nonneg_of_actual_5040_top
    (e top : Robin1984.Event)
    (he : Membership.mem ca5040Events e)
    (hSame : e.p = top.p)
    (hFactor : Nat.factorization 5040 e.p = top.j)
    (hTop : ca5040To55440Cutoff < top.threshold) :
    0 <= Robin1984.eventReducedWeight ca5040To55440Cutoff e := by
  have hLayer : e.j <= top.j := by
    rw [<- hFactor]
    exact
      (mem_ca5040Events_iff e).mp he
  have hThreshold : top.threshold <= e.threshold :=
    Robin1984.event_threshold_antitone_same_prime hSame hLayer
  exact
    (Robin1984.eventReducedWeight_nonneg_iff_threshold
      ca5040To55440Cutoff e).mpr
        (le_trans hTop.le hThreshold)

theorem eventReducedWeight_nonpos_of_not_actual_5040_firstMissing
    (e first : Robin1984.Event)
    (heNot : Not (Membership.mem ca5040Events e))
    (hSame : first.p = e.p)
    (hFactor : first.j = Nat.factorization 5040 e.p + 1)
    (hFirst : first.threshold < ca5040To55440Cutoff) :
    Robin1984.eventReducedWeight ca5040To55440Cutoff e <= 0 := by
  have hNotLayer : Not (e.j <= Nat.factorization 5040 e.p) := by
    intro hLayer
    exact heNot
      ((mem_ca5040Events_iff e).mpr hLayer)
  have hLayer : first.j <= e.j := by
    rw [hFactor]
    omega
  have hThreshold : e.threshold <= first.threshold :=
    Robin1984.event_threshold_antitone_same_prime hSame hLayer
  exact
    (Robin1984.eventReducedWeight_nonpos_iff_threshold
      ca5040To55440Cutoff e).mpr
        (le_trans hThreshold hFirst.le)

theorem eleven_le_prime_of_not_two_three_five_seven
    {p : Nat} (hp : Nat.Prime p)
    (h2 : Not (p = 2)) (h3 : Not (p = 3))
    (h5 : Not (p = 5)) (h7 : Not (p = 7)) :
    11 <= p := by
  by_contra hNot
  have hpLt : p < 11 := Nat.lt_of_not_ge hNot
  have hpTwo : 2 <= p := hp.two_le
  interval_cases p
  all_goals norm_num at hp
  all_goals omega

/-- The actual `5040` packet has the globally correct signs: every included
event is nonnegative and every excluded event, at every prime and layer, is
nonpositive. -/
theorem actualExponentEvents_5040_complete_signs :
    And
      (forall e : Robin1984.Event,
        Membership.mem ca5040Events e ->
          0 <= Robin1984.eventReducedWeight ca5040To55440Cutoff e)
      (forall e : Robin1984.Event,
        Not (Membership.mem ca5040Events e) ->
          Robin1984.eventReducedWeight ca5040To55440Cutoff e <= 0) := by
  constructor
  case left =>
    intro e he
    have hLayer :=
      (mem_ca5040Events_iff e).mp he
    have hFactorPos : Not (Nat.factorization 5040 e.p = 0) := by
      intro hZero
      rw [hZero] at hLayer
      have hj := e.hj
      omega
    have hDvd : Dvd.dvd e.p 5040 :=
      Nat.dvd_of_factorization_pos hFactorPos
    have hCases := prime_dvd_5040_cases e.hp hDvd
    exact Or.elim hCases
      (fun hpEq =>
        eventReducedWeight_nonneg_of_actual_5040_top e ca5040Top2 he
          (by simpa [ca5040Top2, Robin1984.layerEventOfPrime] using hpEq)
          (by
            rw [hpEq]
            simpa [ca5040Top2, Robin1984.layerEventOfPrime] using
              factorization_5040_at_2)
          cutoff_lt_ca5040Top2_threshold)
      (fun hRest3 => Or.elim hRest3
        (fun hpEq =>
          eventReducedWeight_nonneg_of_actual_5040_top e ca5040Top3 he
            (by simpa [ca5040Top3, Robin1984.layerEventOfPrime] using hpEq)
            (by
              rw [hpEq]
              simpa [ca5040Top3, Robin1984.layerEventOfPrime] using
                factorization_5040_at_3)
            cutoff_lt_ca5040Top3_threshold)
        (fun hRest5 => Or.elim hRest5
          (fun hpEq =>
            eventReducedWeight_nonneg_of_actual_5040_top e ca5040Top5 he
              (by simpa [ca5040Top5, Robin1984.layerEventOfPrime] using hpEq)
              (by
                rw [hpEq]
                simpa [ca5040Top5, Robin1984.layerEventOfPrime] using
                  factorization_5040_at_5)
              cutoff_lt_ca5040Top5_threshold)
          (fun hpEq =>
            eventReducedWeight_nonneg_of_actual_5040_top e ca5040Top7 he
              (by simpa [ca5040Top7, Robin1984.layerEventOfPrime] using hpEq)
              (by
                rw [hpEq]
                simpa [ca5040Top7, Robin1984.layerEventOfPrime] using
                  factorization_5040_at_7)
              cutoff_lt_ca5040Top7_threshold)))
  case right =>
    intro e heNot
    by_cases hCases :
        Or (e.p = 2) (Or (e.p = 3) (Or (e.p = 5) (e.p = 7)))
    case pos =>
      exact Or.elim hCases
        (fun hpEq =>
          eventReducedWeight_nonpos_of_not_actual_5040_firstMissing
            e ca5040FirstMissing2 heNot
            (by simpa [ca5040FirstMissing2, Robin1984.layerEventOfPrime] using
              hpEq.symm)
            (by
              rw [hpEq, factorization_5040_at_2]
              norm_num [ca5040FirstMissing2, Robin1984.layerEventOfPrime])
            ca5040FirstMissing2_threshold_lt_cutoff)
        (fun hRest3 => Or.elim hRest3
          (fun hpEq =>
            eventReducedWeight_nonpos_of_not_actual_5040_firstMissing
              e ca5040FirstMissing3 heNot
              (by simpa [ca5040FirstMissing3, Robin1984.layerEventOfPrime] using
                hpEq.symm)
              (by
                rw [hpEq, factorization_5040_at_3]
                norm_num [ca5040FirstMissing3, Robin1984.layerEventOfPrime])
              ca5040FirstMissing3_threshold_lt_cutoff)
          (fun hRest5 => Or.elim hRest5
            (fun hpEq =>
              eventReducedWeight_nonpos_of_not_actual_5040_firstMissing
                e ca5040FirstMissing5 heNot
                (by simpa [ca5040FirstMissing5, Robin1984.layerEventOfPrime] using
                  hpEq.symm)
                (by
                  rw [hpEq, factorization_5040_at_5]
                  norm_num [ca5040FirstMissing5, Robin1984.layerEventOfPrime])
                ca5040FirstMissing5_threshold_lt_cutoff)
            (fun hpEq =>
              eventReducedWeight_nonpos_of_not_actual_5040_firstMissing
                e ca5040FirstMissing7 heNot
                (by simpa [ca5040FirstMissing7, Robin1984.layerEventOfPrime] using
                  hpEq.symm)
                (by
                  rw [hpEq, factorization_5040_at_7]
                  norm_num [ca5040FirstMissing7, Robin1984.layerEventOfPrime])
                ca5040FirstMissing7_threshold_lt_cutoff)))
    case neg =>
      have h2 : Not (e.p = 2) := fun hpEq => hCases (Or.inl hpEq)
      have h3 : Not (e.p = 3) :=
        fun hpEq => hCases (Or.inr (Or.inl hpEq))
      have h5 : Not (e.p = 5) :=
        fun hpEq => hCases (Or.inr (Or.inr (Or.inl hpEq)))
      have h7 : Not (e.p = 7) :=
        fun hpEq => hCases (Or.inr (Or.inr (Or.inr hpEq)))
      have hpGe : 11 <= e.p :=
        eleven_le_prime_of_not_two_three_five_seven e.hp h2 h3 h5 h7
      let first : Robin1984.Event :=
        Robin1984.layerEventOfPrime e.p 1 e.hp one_pos_nat
      have hSamePrime : first.p = e.p := by rfl
      have hLayer : first.j <= e.j := by
        exact Nat.succ_le_of_lt e.hj
      have hSamePrimeThreshold : e.threshold <= first.threshold :=
        Robin1984.event_threshold_antitone_same_prime hSamePrime hLayer
      have hFirstThreshold : first.threshold <= ca5040To55440Event.threshold :=
        Robin1984.firstLayerEvent_threshold_antitone
          (e := ca5040To55440Event) (f := first)
          (by rfl) (by rfl) hpGe
      have hFirstCutoff : first.threshold <= ca5040To55440Cutoff := by
        rw [<- ca5040To55440Event_threshold_eq_cutoff]
        exact hFirstThreshold
      exact
        (Robin1984.eventReducedWeight_nonpos_iff_threshold
          ca5040To55440Cutoff e).mpr
            (le_trans hSamePrimeThreshold hFirstCutoff)

/-- The explicit startup packet proves that `5040` is a textbook CA maximizer
at the exact `5040 -> 55440` tangent parameter. -/
theorem colossallyAbundantWith_5040_at_cutoff :
    IsColossallyAbundantWith 5040 ca5040To55440Cutoff := by
  have hSigns := actualExponentEvents_5040_complete_signs
  have hEpsPos : 0 < ca5040To55440Cutoff :=
    lt_trans (by norm_num : (0 : Real) < 1 / 34)
      ca5040To55440Cutoff_lower
  exact And.intro hEpsPos
    (And.intro (by norm_num)
      (by
        intro k hk
        have hkPos : 0 < k := Nat.zero_lt_of_lt hk
        have hPacket :
            Robin1984.eventPacketReducedWeight ca5040To55440Cutoff
                (actualExponentEvents k) <=
              Robin1984.eventPacketReducedWeight ca5040To55440Cutoff
                ca5040Events :=
          eventPacketReducedWeight_le_of_complete_signs
            (lambda := ca5040To55440Cutoff)
            (base := ca5040Events)
            (events := actualExponentEvents k)
            (fun e he => hSigns.1 e he)
            (fun e _he heNot => hSigns.2 e heNot)
        have hLog :
            caLogObjective ca5040To55440Cutoff k <=
              caLogObjective ca5040To55440Cutoff 5040 := by
          rw [caLogObjective_eq_actualExponentEvents_eventPacketReducedWeight
              (eps := ca5040To55440Cutoff) (n := k)
              (Nat.ne_of_gt hkPos),
            caLogObjective_eq_actualExponentEvents_eventPacketReducedWeight
              (eps := ca5040To55440Cutoff) (n := 5040)
              (by norm_num : Not (5040 = 0))]
          simpa only [ca5040Events_eq_actualExponentEvents] using hPacket
        unfold caLogObjective at hLog
        exact
          (Real.log_le_log_iff
            (caObjective_pos hkPos)
            (caObjective_pos (by norm_num : 0 < 5040))).mp hLog))

theorem colossallyAbundantWith_55440_at_cutoff :
    IsColossallyAbundantWith 55440 ca5040To55440Cutoff :=
  colossallyAbundantWith_55440_of_5040
    colossallyAbundantWith_5040_at_cutoff

theorem tangentCAMaximizer_above_5040_at_startup_cutoff
    {n q : Nat}
    (hnCut : 5040 < n)
    (hEps : robinFrontierCutoff n < ca5040To55440Cutoff)
    (hqCA : IsColossallyAbundantWith q (robinFrontierCutoff n)) :
    5040 < q :=
  tangentCAMaximizer_above_5040_of_shared_5040_55440
    hnCut hEps colossallyAbundantWith_5040_at_cutoff
      colossallyAbundantWith_55440_at_cutoff hqCA

end

end Robin1984
end

/- Inlined module Robin1984.Finite.RobinFiniteStartupCATangent. -/
section

/-!
## Provenance

- Classification: **Primarily project-original**.
- Mathematical source: Robin (1984) supplies the exceptional cutoff and finite proof obligation.
- Formalization note: The rational certificate formats, interval partition, tangent argument, and exact startup verification are primarily project-authored.
- PROVENANCE-END
-/

/-!
# Common CA tangent on the finite Robin startup interval

The common `5040`/`55440` CA parameter gives one logarithmic abundancy
tangent.  After the substitution `y = log n`, the gap between the Robin bound
and that tangent is concave, so its minimum on a closed interval occurs at an
endpoint.
-/

namespace Robin1984

open Set

noncomputable section

/-- For a nonnegative slope, `log (log y) - eps * y` is concave on `y > 1`.
This is the exact transformed gap between the logarithmic Robin bound and a
fixed CA tangent, up to an additive constant. -/
theorem concaveOn_log_log_sub_mul
    {eps : Real} (hEps : 0 <= eps) :
    ConcaveOn Real (Set.Ioi (1 : Real)) (fun y : Real =>
      Real.log (Real.log y) - eps * y) := by
  have hImage :
      Real.log '' Set.Ioi (1 : Real) = Set.Ioi (0 : Real) := by
    ext z
    constructor
    case mp =>
      intro hz
      choose y hy hyEq using hz
      rw [<- hyEq]
      exact Real.log_pos hy
    case mpr =>
      intro hz
      apply Exists.intro (Real.exp z)
      have hExpMem : Membership.mem (Set.Ioi (1 : Real)) (Real.exp z) := by
        change 1 < Real.exp z
        simpa only [Real.exp_zero] using Real.exp_lt_exp.mpr hz
      exact And.intro hExpMem (Real.log_exp z)
  have hInner :
      ConcaveOn Real (Set.Ioi (1 : Real)) Real.log :=
    strictConcaveOn_log_Ioi.concaveOn.subset
      (Set.Ioi_subset_Ioi (by norm_num : (0 : Real) <= 1))
      (convex_Ioi 1)
  have hOuter :
      ConcaveOn Real (Real.log '' Set.Ioi (1 : Real)) Real.log := by
    rw [hImage]
    exact strictConcaveOn_log_Ioi.concaveOn
  have hOuterMono :
      MonotoneOn Real.log (Real.log '' Set.Ioi (1 : Real)) := by
    rw [hImage]
    exact Real.strictMonoOn_log.monotoneOn
  have hComposed :
      ConcaveOn Real (Set.Ioi (1 : Real)) (fun y : Real =>
        Real.log (Real.log y)) := by
    have hRaw := hOuter.comp hInner hOuterMono
    change ConcaveOn Real (Set.Ioi (1 : Real))
      (fun y : Real => Real.log (Real.log y)) at hRaw
    exact hRaw
  have hLinear :
      ConvexOn Real (Set.Ioi (1 : Real)) (fun y : Real => eps * y) := by
    simpa only [id_eq, smul_eq_mul] using
      (convexOn_id (convex_Ioi (1 : Real))).smul hEps
  exact hComposed.sub hLinear

/-- The transformed CA-tangent gap is bounded below by the smaller endpoint
value on every closed subinterval of `y > 1`. -/
theorem min_logLogCATangentEndpoint_le
    {eps a b y : Real} (hEps : 0 <= eps)
    (ha : 1 < a) (hab : a <= b)
    (hy : Membership.mem (Set.Icc a b) y) :
    min (Real.log (Real.log a) - eps * a)
          (Real.log (Real.log b) - eps * b) <=
      Real.log (Real.log y) - eps * y := by
  have hConcave := concaveOn_log_log_sub_mul hEps
  exact hConcave.min_le_of_mem_Icc ha (ha.trans_le hab) hy

/-- Exact logarithmic gap between Robin's bound and the common `5040` CA
tangent, written in the variable `y = log n`. -/
def ca5040RobinLogTangentGapAtLog (y : Real) : Real :=
  Real.eulerMascheroniConstant + Real.log (Real.log y) -
    Real.log (abundancy 5040) -
      ca5040To55440Cutoff * (y - Real.log (5040 : Real))

/-- The certified CA maximizer places every positive integer below the common
`5040` logarithmic tangent. -/
theorem log_abundancy_sub_commonStartupCutoff_log_le_5040
    {n : Nat} (hn : 1 < n) :
    Real.log (abundancy n) -
          ca5040To55440Cutoff * Real.log (n : Real) <=
      Real.log (abundancy 5040) -
        ca5040To55440Cutoff * Real.log (5040 : Real) := by
  have hMax :=
    colossallyAbundantWith_5040_at_cutoff.logObjective_max hn
  rw [caLogObjective_eq_log_abundancy_sub
      (eps := ca5040To55440Cutoff) (n := n) (by omega),
    caLogObjective_eq_log_abundancy_sub
      (eps := ca5040To55440Cutoff) (n := 5040) (by norm_num)] at hMax
  exact hMax

/-- Positivity of the two transformed endpoint gaps proves Robin throughout
the intervening integer interval.  The only arithmetic input is the already
proved common `5040` CA maximizer. -/
theorem nativeRobinInequality_of_commonStartupTangentEndpoints
    {L U n : Nat}
    (hLCut : 5040 < L) (hLU : L <= U)
    (hLn : L <= n) (hnU : n <= U)
    (hLeft :
      0 < ca5040RobinLogTangentGapAtLog (Real.log (L : Real)))
    (hRight :
      0 < ca5040RobinLogTangentGapAtLog (Real.log (U : Real))) :
    Robin1984.Core.NativeRobinInequality n := by
  let eps : Real := ca5040To55440Cutoff
  let a : Real := Real.log (L : Real)
  let b : Real := Real.log (U : Real)
  let y : Real := Real.log (n : Real)
  let c : Real :=
    Real.eulerMascheroniConstant - Real.log (abundancy 5040) +
      eps * Real.log (5040 : Real)
  have hNcut : 5040 < n := lt_of_lt_of_le hLCut hLn
  have hNOne : 1 < n := by omega
  have hEps : 0 <= eps :=
    (colossallyAbundantWith_5040_at_cutoff.eps_pos).le
  have hLPos : (0 : Real) < (L : Real) := by positivity
  have hNPos : (0 : Real) < (n : Real) := by positivity
  have ha : 1 < a := by
    dsimp only [a]
    rw [Real.lt_log_iff_exp_lt hLPos]
    exact Real.exp_one_lt_three.trans
      (by exact_mod_cast (lt_trans (by norm_num : 3 < 5040) hLCut))
  have hab : a <= b := by
    dsimp only [a, b]
    exact Real.log_le_log hLPos (by exact_mod_cast hLU)
  have hy : Membership.mem (Set.Icc a b) y := by
    apply And.intro
    case left =>
      dsimp only [a, y]
      exact Real.log_le_log hLPos (by exact_mod_cast hLn)
    case right =>
      dsimp only [b, y]
      exact Real.log_le_log hNPos (by exact_mod_cast hnU)
  have hEndpoint := min_logLogCATangentEndpoint_le hEps ha hab hy
  have hLeftExpanded :
      0 < c + (Real.log (Real.log a) - eps * a) := by
    dsimp only [c, a, eps]
    unfold ca5040RobinLogTangentGapAtLog at hLeft
    linarith
  have hRightExpanded :
      0 < c + (Real.log (Real.log b) - eps * b) := by
    dsimp only [c, b, eps]
    unfold ca5040RobinLogTangentGapAtLog at hRight
    linarith
  have hMinPositive :
      0 < c + min
        (Real.log (Real.log a) - eps * a)
        (Real.log (Real.log b) - eps * b) := by
    rcases le_total
        (Real.log (Real.log a) - eps * a)
        (Real.log (Real.log b) - eps * b) with hAB | hBA
    case inl =>
      rw [min_eq_left hAB]
      exact hLeftExpanded
    case inr =>
      rw [min_eq_right hBA]
      exact hRightExpanded
  have hGapPositive :
      0 < c + (Real.log (Real.log y) - eps * y) := by
    linarith
  have hCATangent :=
    log_abundancy_sub_commonStartupCutoff_log_le_5040 hNOne
  have hLogRobin :
      Real.log (abundancy n) <
        Real.eulerMascheroniConstant +
          Real.log (Real.log (Real.log (n : Real))) := by
    dsimp only [c, y, eps] at hGapPositive
    linarith
  have hRobinLog := log_robinBoundRatio_eq_of_cutoff hNcut
  have hLogComparison :
      Real.log (abundancy n) < Real.log (robinBoundRatio n) := by
    rw [hRobinLog]
    exact hLogRobin
  have hAbPos : 0 < abundancy n := abundancy_pos (by omega)
  have hBoundPos : 0 < robinBoundRatio n :=
    robinBoundRatio_pos_of_cutoff hNcut
  have hRatio : abundancy n < robinBoundRatio n := by
    have hExp := Real.exp_lt_exp.mpr hLogComparison
    rw [Real.exp_log hAbPos, Real.exp_log hBoundPos] at hExp
    exact hExp
  exact
    (nativeRobinInequality_iff_abundancy_lt_bound (by omega)).mpr hRatio

end

end Robin1984
end

/- Inlined module Robin1984.Finite.RobinFiniteStartupCATangentEndpoints. -/
section

/-!
## Provenance

- Classification: **Primarily project-original**.
- Mathematical source: Robin (1984) supplies the exceptional cutoff and finite proof obligation.
- Formalization note: The rational certificate formats, interval partition, tangent argument, and exact startup verification are primarily project-authored.
- PROVENANCE-END
-/

/-!
# Explicit endpoint estimates for the common startup CA tangent

All transcendental comparisons in this module are reduced to rational Taylor
bounds for `Real.exp`.  They certify the two endpoints used by the concavity
theorem in `RobinFiniteStartupCATangent`.
-/

namespace Robin1984

noncomputable section

private theorem exp_one_lt_2719_div_1000 :
    Real.exp 1 < (2719 : Real) / 1000 := by
  refine lt_of_le_of_lt
    (Real.exp_bound' (x := (1 : Real)) (by norm_num) (by norm_num)
      (n := 9) (by norm_num)) ?_
  norm_num [Finset.sum_range_succ, Nat.factorial_succ]

private theorem exp_12_div_25_lt_1617_div_1000 :
    Real.exp ((12 : Real) / 25) < (1617 : Real) / 1000 := by
  refine lt_of_le_of_lt
    (Real.exp_bound' (x := (12 : Real) / 25) (by norm_num) (by norm_num)
      (n := 8) (by norm_num)) ?_
  norm_num [Finset.sum_range_succ, Nat.factorial_succ]

private theorem exp_3_div_5_lt_1823_div_1000 :
    Real.exp ((3 : Real) / 5) < (1823 : Real) / 1000 := by
  refine lt_of_le_of_lt
    (Real.exp_bound' (x := (3 : Real) / 5) (by norm_num) (by norm_num)
      (n := 9) (by norm_num)) ?_
  norm_num [Finset.sum_range_succ, Nat.factorial_succ]

private theorem exp_191_div_200_lt_13_div_5 :
    Real.exp ((191 : Real) / 200) < (13 : Real) / 5 := by
  refine lt_of_le_of_lt
    (Real.exp_bound' (x := (191 : Real) / 200) (by norm_num) (by norm_num)
      (n := 10) (by norm_num)) ?_
  norm_num [Finset.sum_range_succ, Nat.factorial_succ]


theorem ca5040To55440Cutoff_lt_one_div_27 :
    ca5040To55440Cutoff < (1 : Real) / 27 := by
  rw [<- ca5040To55440Event_threshold_eq_cutoff]
  apply event_threshold_lt_one_div_nat_of_gainRatio_pow_lt_prime
    (e := ca5040To55440Event) (N := 27) (by norm_num)
  norm_num [ca5040To55440Event, Robin1984.layerEventOfPrime,
    Robin1984.eventGainRatio]


private theorem log_143_lt_five :
    Real.log 143 < 5 := by
  rw [Real.log_lt_iff_lt_exp (by norm_num : (0 : Real) < 143)]
  refine lt_of_lt_of_le ?_
    (Real.sum_le_exp_of_nonneg (by norm_num : (0 : Real) <= 5) 10)
  norm_num [Finset.sum_range_succ, Nat.factorial_succ]


theorem ca5040To55440Cutoff_mul_log_143_lt_five_div_27 :
    ca5040To55440Cutoff * Real.log 143 < (5 : Real) / 27 := by
  have hLogPos : 0 < Real.log (143 : Real) := Real.log_pos (by norm_num)
  calc
    ca5040To55440Cutoff * Real.log 143 <
        ((1 : Real) / 27) * Real.log 143 :=
      mul_lt_mul_of_pos_right ca5040To55440Cutoff_lt_one_div_27 hLogPos
    _ < ((1 : Real) / 27) * 5 := by
      exact mul_lt_mul_of_pos_left log_143_lt_five (by norm_num)
    _ = (5 : Real) / 27 := by ring

theorem sigmaOneNat_5040_eq_19344 :
    Robin1984.Core.sigmaOneNat 5040 = 19344 := by
  set_option maxRecDepth 100000 in
    decide

theorem abundancy_5040_eq_403_div_105 :
    abundancy 5040 = (403 : Real) / 105 := by
  unfold abundancy
  rw [sigmaOneNat_5040_eq_19344]
  norm_num

theorem log_abundancy_5040_lt_269_div_200 :
    Real.log (abundancy 5040) < (269 : Real) / 200 := by
  rw [abundancy_5040_eq_403_div_105]
  rw [Real.log_lt_iff_lt_exp (by norm_num : (0 : Real) < 403 / 105)]
  refine lt_of_lt_of_le ?_
    (Real.sum_le_exp_of_nonneg (by norm_num : (0 : Real) <= 269 / 200) 11)
  norm_num [Finset.sum_range_succ, Nat.factorial_succ]


private theorem exp_337_div_25_lt_720720 :
    Real.exp ((337 : Real) / 25) < 720720 := by
  calc
    Real.exp ((337 : Real) / 25) =
        Real.exp 1 ^ 13 * Real.exp ((12 : Real) / 25) := by
      rw [show (337 : Real) / 25 = 13 * 1 + 12 / 25 by norm_num,
        Real.exp_add]
      congr 1
      simpa only [Nat.cast_ofNat, mul_one] using
        (Real.exp_nat_mul (1 : Real) 13)
    _ < ((2719 : Real) / 1000) ^ 13 * Real.exp ((12 : Real) / 25) := by
      gcongr
      exact exp_one_lt_2719_div_1000
    _ < ((2719 : Real) / 1000) ^ 13 * ((1617 : Real) / 1000) := by
      gcongr
      exact exp_12_div_25_lt_1617_div_1000
    _ < 720720 := by norm_num

private theorem exp_13_div_5_lt_337_div_25 :
    Real.exp ((13 : Real) / 5) < (337 : Real) / 25 := by
  calc
    Real.exp ((13 : Real) / 5) =
        Real.exp 1 ^ 2 * Real.exp ((3 : Real) / 5) := by
      rw [show (13 : Real) / 5 = 2 * 1 + 3 / 5 by norm_num,
        Real.exp_add]
      congr 1
      simpa only [Nat.cast_ofNat, mul_one] using
        (Real.exp_nat_mul (1 : Real) 2)
    _ < ((2719 : Real) / 1000) ^ 2 * Real.exp ((3 : Real) / 5) := by
      gcongr
      exact exp_one_lt_2719_div_1000
    _ < ((2719 : Real) / 1000) ^ 2 * ((1823 : Real) / 1000) := by
      gcongr
      exact exp_3_div_5_lt_1823_div_1000
    _ < (337 : Real) / 25 := by norm_num

theorem log_log_log_720720_gt_191_div_200 :
    (191 : Real) / 200 <
      Real.log (Real.log (Real.log (720720 : Real))) := by
  have hLog :
      (337 : Real) / 25 < Real.log (720720 : Real) := by
    rw [Real.lt_log_iff_exp_lt (by norm_num : (0 : Real) < 720720)]
    exact exp_337_div_25_lt_720720
  have hLogPos : 0 < Real.log (720720 : Real) := by positivity
  have hLogLog :
      (13 : Real) / 5 < Real.log (Real.log (720720 : Real)) := by
    rw [Real.lt_log_iff_exp_lt hLogPos]
    exact exp_13_div_5_lt_337_div_25.trans hLog
  have hLogLogPos : 0 < Real.log (Real.log (720720 : Real)) := by positivity
  rw [Real.lt_log_iff_exp_lt hLogLogPos]
  exact exp_191_div_200_lt_13_div_5.trans hLogLog

set_option maxRecDepth 10000 in
theorem seventy_two_div_125_lt_eulerMascheroniConstant :
    (72 : Real) / 125 < Real.eulerMascheroniConstant := by
  have hSeqLower :
      (72 : Real) / 125 < Real.eulerMascheroniSeq 1000 := by
    unfold Real.eulerMascheroniSeq
    norm_num only [Nat.cast_add, Nat.cast_one, Nat.cast_ofNat]
    have hLogUpper :
        Real.log 1001 < (harmonic 1000 : Real) - 72 / 125 := by
      rw [Real.log_lt_iff_lt_exp (by positivity : (0 : Real) < 1001)]
      refine lt_of_lt_of_le ?_
        (Real.sum_le_exp_of_nonneg
          (by
            norm_num [harmonic] :
            (0 : Real) <= (harmonic 1000 : Real) - 72 / 125)
          25)
      norm_num [harmonic, Finset.sum_range_succ, Nat.factorial_succ]
    linarith
  exact hSeqLower.trans
    (Real.eulerMascheroniSeq_lt_eulerMascheroniConstant 1000)


theorem ca5040RobinLogTangentGapAtLog_720720_pos :
    0 < ca5040RobinLogTangentGapAtLog
      (Real.log (720720 : Real)) := by
  have hLogRatio :
      Real.log (720720 : Real) - Real.log (5040 : Real) = Real.log 143 := by
    rw [show (720720 : Real) = 5040 * 143 by norm_num,
      Real.log_mul (by norm_num) (by norm_num)]
    ring
  unfold ca5040RobinLogTangentGapAtLog
  rw [hLogRatio]
  linarith [seventy_two_div_125_lt_eulerMascheroniConstant,
    log_log_log_720720_gt_191_div_200,
    log_abundancy_5040_lt_269_div_200,
    ca5040To55440Cutoff_mul_log_143_lt_five_div_27]


end

end Robin1984
end

/- Inlined module Robin1984.Finite.RobinFiniteStartupCATangent7560. -/
section
/-!
## Provenance

- Classification: **Primarily project-original**.
- Mathematical source: Robin (1984) supplies the exceptional cutoff and finite proof obligation.
- Formalization note: The rational certificate formats, interval partition, tangent argument, and exact startup verification are primarily project-authored.
- PROVENANCE-END
-/

/-!
# The remaining common-CA startup tangent from 7560

The lower endpoint is sharpened from `10080` to `7560`.  This leaves the
finite arithmetic interval `5041 <= n < 7560`, where the exact factor
certificate uses the sharp bound `35 * sigma n <= 127 * n`.
-/

namespace Robin1984

noncomputable section

private theorem exp_one_lt_27183_div_10000 :
    Real.exp 1 < (27183 : Real) / 10000 := by
  refine lt_of_le_of_lt
    (Real.exp_bound' (x := (1 : Real)) (by norm_num) (by norm_num)
      (n := 12) (by norm_num)) ?_
  norm_num [Finset.sum_range_succ, Nat.factorial_succ]

private theorem exp_93_div_100_lt_507_div_200 :
    Real.exp ((93 : Real) / 100) < (507 : Real) / 200 := by
  refine lt_of_le_of_lt
    (Real.exp_bound' (x := (93 : Real) / 100) (by norm_num) (by norm_num)
      (n := 16) (by norm_num)) ?_
  norm_num [Finset.sum_range_succ, Nat.factorial_succ]

private theorem exp_3917_div_5000_lt_2189_div_1000 :
    Real.exp ((3917 : Real) / 5000) < (2189 : Real) / 1000 := by
  refine lt_of_le_of_lt
    (Real.exp_bound' (x := (3917 : Real) / 5000) (by norm_num) (by norm_num)
      (n := 16) (by norm_num)) ?_
  norm_num [Finset.sum_range_succ, Nat.factorial_succ]

private theorem exp_189_div_1000_lt_12081_div_10000 :
    Real.exp ((189 : Real) / 1000) < (12081 : Real) / 10000 := by
  refine lt_of_le_of_lt
    (Real.exp_bound' (x := (189 : Real) / 1000) (by norm_num) (by norm_num)
      (n := 10) (by norm_num)) ?_
  norm_num [Finset.sum_range_succ, Nat.factorial_succ]

private theorem exp_2189_div_1000_lt_893_div_100 :
    Real.exp ((2189 : Real) / 1000) < (893 : Real) / 100 := by
  calc
    Real.exp ((2189 : Real) / 1000) =
        Real.exp 1 ^ 2 * Real.exp ((189 : Real) / 1000) := by
      rw [show (2189 : Real) / 1000 = 2 * 1 + 189 / 1000 by norm_num,
        Real.exp_add]
      congr 1
      simpa only [Nat.cast_ofNat, mul_one] using
        (Real.exp_nat_mul (1 : Real) 2)
    _ < ((27183 : Real) / 10000) ^ 2 *
        Real.exp ((189 : Real) / 1000) := by
      gcongr
      exact exp_one_lt_27183_div_10000
    _ < ((27183 : Real) / 10000) ^ 2 *
        ((12081 : Real) / 10000) := by
      gcongr
      exact exp_189_div_1000_lt_12081_div_10000
    _ < (893 : Real) / 100 := by norm_num

private theorem exp_893_div_100_lt_7560 :
    Real.exp ((893 : Real) / 100) < 7560 := by
  calc
    Real.exp ((893 : Real) / 100) =
        Real.exp 1 ^ 8 * Real.exp ((93 : Real) / 100) := by
      rw [show (893 : Real) / 100 = 8 * 1 + 93 / 100 by norm_num,
        Real.exp_add]
      congr 1
      simpa only [Nat.cast_ofNat, mul_one] using
        (Real.exp_nat_mul (1 : Real) 8)
    _ < ((27183 : Real) / 10000) ^ 8 *
        Real.exp ((93 : Real) / 100) := by
      gcongr
      exact exp_one_lt_27183_div_10000
    _ < ((27183 : Real) / 10000) ^ 8 * ((507 : Real) / 200) := by
      gcongr
      exact exp_93_div_100_lt_507_div_200
    _ < 7560 := by norm_num

private theorem exp_3_div_50_lt_531_div_500 :
    Real.exp ((3 : Real) / 50) < (531 : Real) / 500 := by
  refine lt_of_le_of_lt
    (Real.exp_bound' (x := (3 : Real) / 50) (by norm_num) (by norm_num)
      (n := 8) (by norm_num)) ?_
  norm_num [Finset.sum_range_succ, Nat.factorial_succ]

private theorem exp_103_div_50_lt_eight :
    Real.exp ((103 : Real) / 50) < 8 := by
  calc
    Real.exp ((103 : Real) / 50) =
        Real.exp 1 ^ 2 * Real.exp ((3 : Real) / 50) := by
      rw [show (103 : Real) / 50 = 2 * 1 + 3 / 50 by norm_num,
        Real.exp_add]
      congr 1
      simpa only [Nat.cast_ofNat, mul_one] using
        (Real.exp_nat_mul (1 : Real) 2)
    _ < ((27183 : Real) / 10000) ^ 2 *
        Real.exp ((3 : Real) / 50) := by
      gcongr
      exact exp_one_lt_27183_div_10000
    _ < ((27183 : Real) / 10000) ^ 2 * ((531 : Real) / 500) := by
      gcongr
      exact exp_3_div_50_lt_531_div_500
    _ < 8 := by norm_num

private theorem exp_eight_lt_5041 :
    Real.exp 8 < 5041 := by
  calc
    Real.exp 8 = Real.exp 1 ^ 8 := by
      simpa only [Nat.cast_ofNat, mul_one] using
        (Real.exp_nat_mul (1 : Real) 8)
    _ < ((27183 : Real) / 10000) ^ 8 := by
      gcongr
      exact exp_one_lt_27183_div_10000
    _ < 5041 := by norm_num

private theorem log_three_halves_lt_203_div_500 :
    Real.log ((3 : Real) / 2) < (203 : Real) / 500 := by
  rw [Real.log_lt_iff_lt_exp (by norm_num : (0 : Real) < 3 / 2)]
  refine lt_of_lt_of_le ?_
    (Real.sum_le_exp_of_nonneg
      (by norm_num : (0 : Real) <= 203 / 500) 6)
  norm_num [Finset.sum_range_succ, Nat.factorial_succ]

theorem ca5040To55440Cutoff_mul_log_three_halves_lt_203_div_13500 :
    ca5040To55440Cutoff * Real.log ((3 : Real) / 2) <
      (203 : Real) / 13500 := by
  have hLogPos : 0 < Real.log ((3 : Real) / 2) :=
    Real.log_pos (by norm_num)
  calc
    ca5040To55440Cutoff * Real.log ((3 : Real) / 2) <
        ((1 : Real) / 27) * Real.log ((3 : Real) / 2) :=
      mul_lt_mul_of_pos_right ca5040To55440Cutoff_lt_one_div_27 hLogPos
    _ < ((1 : Real) / 27) * ((203 : Real) / 500) := by
      exact mul_lt_mul_of_pos_left log_three_halves_lt_203_div_500
        (by norm_num)
    _ = (203 : Real) / 13500 := by ring

set_option maxRecDepth 30000 in
theorem five_hundred_seventy_seven_div_1000_lt_eulerMascheroniConstant :
    (577 : Real) / 1000 < Real.eulerMascheroniConstant := by
  have hSeqLower :
      (577 : Real) / 1000 < Real.eulerMascheroniSeq 3000 := by
    unfold Real.eulerMascheroniSeq
    norm_num only [Nat.cast_add, Nat.cast_one, Nat.cast_ofNat]
    have hLogUpper :
        Real.log 3001 < (harmonic 3000 : Real) - 577 / 1000 := by
      rw [Real.log_lt_iff_lt_exp (by positivity : (0 : Real) < 3001)]
      refine lt_of_lt_of_le ?_
        (Real.sum_le_exp_of_nonneg
          (by
            norm_num [harmonic] :
            (0 : Real) <= (harmonic 3000 : Real) - 577 / 1000)
          28)
      norm_num [harmonic, Finset.sum_range_succ, Nat.factorial_succ]
    linarith
  exact hSeqLower.trans
    (Real.eulerMascheroniSeq_lt_eulerMascheroniConstant 3000)

theorem log_log_log_7560_gt_3917_div_5000 :
    (3917 : Real) / 5000 <
      Real.log (Real.log (Real.log (7560 : Real))) := by
  have hLog : (893 : Real) / 100 < Real.log (7560 : Real) := by
    rw [Real.lt_log_iff_exp_lt (by norm_num : (0 : Real) < 7560)]
    exact exp_893_div_100_lt_7560
  have hLogPos : 0 < Real.log (7560 : Real) := by positivity
  have hLogLog :
      (2189 : Real) / 1000 < Real.log (Real.log (7560 : Real)) := by
    rw [Real.lt_log_iff_exp_lt hLogPos]
    exact exp_2189_div_1000_lt_893_div_100.trans hLog
  have hLogLogPos : 0 < Real.log (Real.log (7560 : Real)) := by
    positivity
  rw [Real.lt_log_iff_exp_lt hLogLogPos]
  exact exp_3917_div_5000_lt_2189_div_1000.trans hLogLog

theorem ca5040RobinLogTangentGapAtLog_7560_pos :
    0 < ca5040RobinLogTangentGapAtLog
      (Real.log (7560 : Real)) := by
  have hLogRatio :
      Real.log (7560 : Real) - Real.log (5040 : Real) =
        Real.log ((3 : Real) / 2) := by
    rw [show (7560 : Real) = 5040 * (3 / 2) by norm_num,
      Real.log_mul (by norm_num) (by norm_num)]
    ring
  unfold ca5040RobinLogTangentGapAtLog
  rw [hLogRatio]
  linarith [five_hundred_seventy_seven_div_1000_lt_eulerMascheroniConstant,
    log_log_log_7560_gt_3917_div_5000,
    log_abundancy_5040_lt_269_div_200,
    ca5040To55440Cutoff_mul_log_three_halves_lt_203_div_13500]

/-- The common CA tangent covers every startup integer from 7560 onward. -/
theorem nativeRobinInequality_startup_from_7560
    {n : Nat} (hLower : 7560 <= n) (hUpper : n < 720720) :
    Robin1984.Core.NativeRobinInequality n := by
  apply nativeRobinInequality_of_commonStartupTangentEndpoints
    (L := 7560) (U := 720720)
  . norm_num
  . norm_num
  . exact hLower
  . omega
  . exact ca5040RobinLogTangentGapAtLog_7560_pos
  . exact ca5040RobinLogTangentGapAtLog_720720_pos

theorem exp_eulerMascheroniConstant_gt_177_div_100 :
    (177 : Real) / 100 < Real.exp Real.eulerMascheroniConstant := by
  have hTaylor :
      (177 : Real) / 100 < Real.exp ((72 : Real) / 125) := by
    refine lt_of_lt_of_le ?_
      (Real.sum_le_exp_of_nonneg
        (by norm_num : (0 : Real) <= 72 / 125) 7)
    norm_num [Finset.sum_range_succ, Nat.factorial_succ]
  exact hTaylor.trans
    (Real.exp_lt_exp.mpr seventy_two_div_125_lt_eulerMascheroniConstant)

theorem one_hundred_three_div_50_lt_log_log_of_5041_le
    {n : Nat} (hLower : 5041 <= n) :
    (103 : Real) / 50 < Real.log (Real.log (n : Real)) := by
  have hLog5041 : (8 : Real) < Real.log (5041 : Real) := by
    rw [Real.lt_log_iff_exp_lt (by norm_num : (0 : Real) < 5041)]
    exact exp_eight_lt_5041
  have hLog5041Pos : 0 < Real.log (5041 : Real) := by positivity
  have hFixed :
      (103 : Real) / 50 < Real.log (Real.log (5041 : Real)) := by
    rw [Real.lt_log_iff_exp_lt hLog5041Pos]
    exact exp_103_div_50_lt_eight.trans hLog5041
  have hCast : (5041 : Real) <= (n : Real) := by exact_mod_cast hLower
  have hLogMono :
      Real.log (5041 : Real) <= Real.log (n : Real) :=
    Real.log_le_log (by norm_num) hCast
  have hLogLogMono :
      Real.log (Real.log (5041 : Real)) <=
        Real.log (Real.log (n : Real)) :=
    Real.log_le_log hLog5041Pos hLogMono
  exact hFixed.trans_le hLogLogMono

/-- The exact rational divisor-sum envelope closes Robin on the remaining
finite block. -/
theorem nativeRobinInequality_of_sigmaOneNat_le_127_div_35
    {n : Nat} (hLower : 5041 <= n)
    (hSigma : 35 * Robin1984.Core.sigmaOneNat n <= 127 * n) :
    Robin1984.Core.NativeRobinInequality n := by
  have hn : 0 < n := by omega
  have hnReal : (0 : Real) < (n : Real) := by exact_mod_cast hn
  have hSigmaCast :
      (35 : Real) * Robin1984.Core.sigmaOneNat n <=
        127 * (n : Real) := by
    exact_mod_cast hSigma
  have hSigmaLinear :
      (Robin1984.Core.sigmaOneNat n : Real) <=
        ((127 : Real) / 35) * n := by
    nlinarith
  have hAbundancy : abundancy n <= (127 : Real) / 35 := by
    unfold abundancy
    calc
      (Robin1984.Core.sigmaOneNat n : Real) / n <=
          (((127 : Real) / 35) * n) / n :=
        div_le_div_of_nonneg_right hSigmaLinear hnReal.le
      _ = (127 : Real) / 35 := by field_simp [hnReal.ne']
  have hExp := exp_eulerMascheroniConstant_gt_177_div_100
  have hLogLog := one_hundred_three_div_50_lt_log_log_of_5041_le hLower
  have hProduct :
      ((177 : Real) / 100) * ((103 : Real) / 50) <
        Real.exp Real.eulerMascheroniConstant *
          Real.log (Real.log (n : Real)) := by
    calc
      ((177 : Real) / 100) * ((103 : Real) / 50) <
          Real.exp Real.eulerMascheroniConstant * ((103 : Real) / 50) :=
        mul_lt_mul_of_pos_right hExp (by norm_num)
      _ < Real.exp Real.eulerMascheroniConstant *
          Real.log (Real.log (n : Real)) :=
        mul_lt_mul_of_pos_left hLogLog (Real.exp_pos _)
  have hBound : (127 : Real) / 35 < robinBoundRatio n := by
    unfold robinBoundRatio
    exact (by norm_num : (127 : Real) / 35 <
      (177 / 100) * (103 / 50)).trans hProduct
  exact (nativeRobinInequality_iff_abundancy_lt_bound hn).mpr
    (hAbundancy.trans_lt hBound)

end

end Robin1984
end

section

/-!
# Testing Robin's inequality on power-weighted abundancy maxima

Write `A(n) = σ(n)/n`, where `σ` is the sum of the positive divisors. The main
theorem, `RobinRecord.universal_iff_shaped_weighted_maxima`, characterizes the
inequality `A(n) < exp(γ) · log(log n)` for every integer `n > 5040`. It suffices
to test the strict abundancy records `r ≥ 10080` with nonincreasing prime
exponents for which some positive `e` makes `A(r)/r^e` maximal on `[10080,∞)`.

The paired-divisor certificates check that 10080 is a strict abundancy record.
On 5041 through 10079 the largest abundancy is 80/21, attained at 7560.
A harmonic approximation to Euler's constant verifies Robin's inequality
throughout this initial interval.

Given a counterexample `n ≥ 10080`, choose `e = 1 / (log n · log(log n))`.
The bound `A(m) ≤ 1 + log m` guarantees that `A(m)/m^e` attains a maximum on
the tail. The logarithmic tangent inequality transfers the counterexample to
that maximum. Comparison with 10080 makes the maximizing integer a strict
global abundancy record. Exchanging prime factors gives its exponent order.

The divisor-pair calculation follows Sky's LeanClassics.RobinCheck. The
prime-layer identity and the logarithmic comparison have antecedents in Jonas
Whidden's Robin1984. Source details accompany the corresponding proofs.
-/

/- The square-root divisor pairing below is adapted from Sky's LeanClassics.RobinCheck,
rh-lab-robin-lagarias commit dc12df6aaf4fa88fc9e6534b81ed67b89c99d8e4, Apache-2.0. -/
open Finset
open ArithmeticFunction (sigma)
namespace RobinRecord
def pairTerm (n d : ℕ) : ℕ :=
  if n % d = 0 then (if d * d ≤ n then (if d * d = n then d else d + n / d) else 0) else 0

/-- `∑_{d ≤ k} pairTerm n d`. -/
def sumPairs (n : ℕ) : ℕ → ℕ
  | 0 => pairTerm n 0
  | k + 1 => sumPairs n k + pairTerm n (k + 1)

lemma sumPairs_eq (n k : ℕ) : sumPairs n k = ∑ d ∈ range (k + 1), pairTerm n d := by
  induction k with
  | zero => simp [sumPairs]
  | succ k ih => rw [sumPairs, ih, sum_range_succ (n := k + 1)]

private lemma cofactor_sq_le_iff {n d : ℕ} (hn : 0 < n) (hd : d ∣ n) :
    n / d * (n / d) ≤ n ↔ n ≤ d * d := by
  obtain ⟨e, rfl⟩ := hd
  have hd0 : 0 < d := Nat.pos_of_ne_zero (by rintro rfl; simp at hn)
  have he0 : 0 < e := Nat.pos_of_ne_zero (by rintro rfl; simp at hn)
  rw [Nat.mul_div_cancel_left e hd0]
  constructor
  · intro h
    have : e ≤ d := by nlinarith
    nlinarith
  · intro h
    have : e ≤ d := by nlinarith
    nlinarith

/-- `σ(n) = ∑_{d ≤ k} pairTerm n d` whenever `0 < n < (k + 1)²`. -/
theorem sigma_eq_sumPairs {n k : ℕ} (hn : 0 < n) (hk : n < (k + 1) * (k + 1)) :
    sigma 1 n = sumPairs n k := by
  rw [ArithmeticFunction.sigma_one_apply, sumPairs_eq]
  -- split `∑ d` by `d² ≤ n`, and turn the large divisors into cofactors
  have hsplit : ∑ d ∈ n.divisors, d = ∑ d ∈ n.divisors, (if d * d ≤ n then d else 0) +
      ∑ d ∈ n.divisors, (if d * d ≤ n then 0 else d) := by
    rw [← sum_add_distrib]
    refine sum_congr rfl fun d _ => ?_
    split_ifs <;> simp
  have hswap : ∑ d ∈ n.divisors, (if d * d ≤ n then 0 else d) =
      ∑ d ∈ n.divisors, (if d * d < n then n / d else 0) := by
    rw [← Nat.sum_div_divisors n (fun d => if d * d ≤ n then 0 else d)]
    refine sum_congr rfl fun d hd => ?_
    have hdn := (Nat.mem_divisors.mp hd).1
    have := cofactor_sq_le_iff hn hdn
    by_cases h1 : n / d * (n / d) ≤ n
    · rw [if_pos h1, if_neg (by omega)]
    · rw [if_neg h1, if_pos (by omega)]
  have hdiv : ∑ d ∈ n.divisors, d = ∑ d ∈ n.divisors, pairTerm n d := by
    rw [hsplit, hswap, ← sum_add_distrib]
    refine sum_congr rfl fun d hd => ?_
    have hmod : n % d = 0 := Nat.mod_eq_zero_of_dvd (Nat.mem_divisors.mp hd).1
    simp only [pairTerm, hmod, if_true]
    split_ifs <;> omega
  rw [hdiv]
  have hpt : ∀ d, pairTerm n d ≠ 0 → d ∣ n ∧ d ≤ k := fun d h => by
    unfold pairTerm at h
    by_cases hm : n % d = 0
    · rw [if_pos hm] at h
      by_cases hs : d * d ≤ n
      · refine ⟨Nat.dvd_of_mod_eq_zero hm, ?_⟩
        by_contra hdk
        have : (k + 1) * (k + 1) ≤ d * d := Nat.mul_self_le_mul_self (by omega)
        omega
      · rw [if_neg hs] at h; exact absurd rfl h
    · rw [if_neg hm] at h; exact absurd rfl h
  rw [← sum_filter_of_ne (p := fun d => d ≤ k) (fun d _ h => (hpt d h).2),
    ← sum_filter_of_ne (s := range (k + 1)) (p := fun d => d ∣ n) (fun d _ h => (hpt d h).1)]
  congr 1
  ext d
  simp only [mem_filter, Nat.mem_divisors, mem_range]
  constructor
  · rintro ⟨⟨hd, -⟩, hdk⟩; exact ⟨by omega, hd⟩
  · rintro ⟨hdk, hd⟩; exact ⟨⟨hd, hn.ne'⟩, by omega⟩

end RobinRecord

namespace RobinRecord
open ArithmeticFunction (sigma)

def checkRow (n : ℕ) : Bool :=
  if n = 0 then true else if n ≤ 5040 then decide (105 * sumPairs n 70 ≤ 403 * n)
  else if n < 10080 then decide (21 * sumPairs n 100 ≤ 80*n) else true

def checkBlock (i : ℕ) : Bool :=
  (List.range 128).all (fun j => checkRow (128*i+j))

theorem checked (all : ∀ i : Fin 79, checkBlock i.val = true) (n : ℕ) (h : n < 10080) :
    checkRow n = true := by
  have hn : n/128 < 79 := by omega
  have hi := all ⟨n/128, hn⟩
  unfold checkBlock at hi
  have hh := List.all_eq_true.mp hi (n%128) (List.mem_range.mpr (Nat.mod_lt _ (by decide)))
  change checkRow (128*(n/128)+n%128) = true at hh
  rwa [show 128*(n/128)+n%128 = n by omega] at hh

end RobinRecord

namespace RobinRecord
open ArithmeticFunction (sigma)

section Blocks

set_option maxRecDepth 4096 in
theorem block0 : checkBlock 0 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block1 : checkBlock 1 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block2 : checkBlock 2 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block3 : checkBlock 3 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block4 : checkBlock 4 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block5 : checkBlock 5 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block6 : checkBlock 6 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block7 : checkBlock 7 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block8 : checkBlock 8 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block9 : checkBlock 9 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block10 : checkBlock 10 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block11 : checkBlock 11 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block12 : checkBlock 12 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block13 : checkBlock 13 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block14 : checkBlock 14 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block15 : checkBlock 15 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block16 : checkBlock 16 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block17 : checkBlock 17 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block18 : checkBlock 18 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block19 : checkBlock 19 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block20 : checkBlock 20 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block21 : checkBlock 21 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block22 : checkBlock 22 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block23 : checkBlock 23 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block24 : checkBlock 24 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block25 : checkBlock 25 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block26 : checkBlock 26 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block27 : checkBlock 27 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block28 : checkBlock 28 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block29 : checkBlock 29 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block30 : checkBlock 30 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block31 : checkBlock 31 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block32 : checkBlock 32 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block33 : checkBlock 33 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block34 : checkBlock 34 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block35 : checkBlock 35 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block36 : checkBlock 36 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block37 : checkBlock 37 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block38 : checkBlock 38 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block39 : checkBlock 39 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block40 : checkBlock 40 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block41 : checkBlock 41 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block42 : checkBlock 42 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block43 : checkBlock 43 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block44 : checkBlock 44 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block45 : checkBlock 45 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block46 : checkBlock 46 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block47 : checkBlock 47 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block48 : checkBlock 48 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block49 : checkBlock 49 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block50 : checkBlock 50 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block51 : checkBlock 51 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block52 : checkBlock 52 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block53 : checkBlock 53 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block54 : checkBlock 54 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block55 : checkBlock 55 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block56 : checkBlock 56 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block57 : checkBlock 57 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block58 : checkBlock 58 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block59 : checkBlock 59 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block60 : checkBlock 60 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block61 : checkBlock 61 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block62 : checkBlock 62 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block63 : checkBlock 63 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block64 : checkBlock 64 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block65 : checkBlock 65 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block66 : checkBlock 66 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block67 : checkBlock 67 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block68 : checkBlock 68 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block69 : checkBlock 69 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block70 : checkBlock 70 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block71 : checkBlock 71 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block72 : checkBlock 72 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block73 : checkBlock 73 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block74 : checkBlock 74 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block75 : checkBlock 75 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block76 : checkBlock 76 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block77 : checkBlock 77 = true := by decide +kernel
set_option maxRecDepth 4096 in
theorem block78 : checkBlock 78 = true := by decide +kernel

end Blocks

theorem all_blocks (i : Fin 79) : checkBlock i.val = true := by
  rcases i with ⟨i, hi⟩
  change checkBlock i = true
  interval_cases i
  · exact block0
  · exact block1
  · exact block2
  · exact block3
  · exact block4
  · exact block5
  · exact block6
  · exact block7
  · exact block8
  · exact block9
  · exact block10
  · exact block11
  · exact block12
  · exact block13
  · exact block14
  · exact block15
  · exact block16
  · exact block17
  · exact block18
  · exact block19
  · exact block20
  · exact block21
  · exact block22
  · exact block23
  · exact block24
  · exact block25
  · exact block26
  · exact block27
  · exact block28
  · exact block29
  · exact block30
  · exact block31
  · exact block32
  · exact block33
  · exact block34
  · exact block35
  · exact block36
  · exact block37
  · exact block38
  · exact block39
  · exact block40
  · exact block41
  · exact block42
  · exact block43
  · exact block44
  · exact block45
  · exact block46
  · exact block47
  · exact block48
  · exact block49
  · exact block50
  · exact block51
  · exact block52
  · exact block53
  · exact block54
  · exact block55
  · exact block56
  · exact block57
  · exact block58
  · exact block59
  · exact block60
  · exact block61
  · exact block62
  · exact block63
  · exact block64
  · exact block65
  · exact block66
  · exact block67
  · exact block68
  · exact block69
  · exact block70
  · exact block71
  · exact block72
  · exact block73
  · exact block74
  · exact block75
  · exact block76
  · exact block77
  · exact block78

theorem first_ratio {n : ℕ} (h : 1 ≤ n) (hn : n ≤ 5040) : 105*sigma 1 n ≤403*n := by
  have eqn := checked all_blocks n (by omega)
  rw [checkRow, if_neg (by omega), if_pos hn, decide_eq_true_iff] at eqn
  rw [sigma_eq_sumPairs (k:=70) (by omega) (by omega)]
  exact eqn

theorem second_ratio {n : ℕ} (h : 5041 ≤ n) (hn : n < 10080) : 21*sigma 1 n ≤80*n := by
  have eqn := checked all_blocks n hn
  rw [checkRow, if_neg (by omega), if_neg (by omega), if_pos hn, decide_eq_true_iff] at eqn
  rw [sigma_eq_sumPairs (k:=100) (by omega) (by omega)]
  exact eqn

theorem values : sigma 1 10080=39312 ∧ sigma 1 5040=19344 ∧ sigma 1 7560=28800 := by
  rw [sigma_eq_sumPairs (n:=10080) (k:=100) (by decide) (by decide),
      sigma_eq_sumPairs (n:=5040) (k:=70) (by decide) (by decide),
      sigma_eq_sumPairs (n:=7560) (k:=86) (by decide) (by decide)]
  decide +kernel

theorem certified_ratios :
    (∀ m : ℕ, 1 ≤ m → m ≤ 5040 → 10080*sigma 1 m < 39312*m) ∧ sigma 1 10080=39312 ∧
    (∀ n : ℕ, 5041 ≤ n → n < 10080 → 21*sigma 1 n ≤ 80*n) ∧ sigma 1 5040=19344 ∧
    (∀ n : ℕ, 1 ≤ n → n ≤ 5040 → 105*sigma 1 n ≤ 403*n) ∧ sigma 1 7560=28800 := by
  refine ⟨?_, values.1, fun _ => second_ratio, values.2.1, fun _ => first_ratio, values.2.2⟩
  intro m hm htop
  have := first_ratio hm htop
  omega

end RobinRecord

namespace RobinRecord
open Real

set_option maxRecDepth 10000 in
/-- A lower bound from the 511th lower harmonic approximation and six terms of the
exponential series. -/
theorem exp_gamma_lower : (1.7788 : ℝ) < exp eulerMascheroniConstant := by
  have hh : (68145 / 10000 : ℚ) < harmonic 511 := by decide +kernel
  have hh' : (68145 / 10000 : ℝ) < (harmonic 511 : ℝ) := by
    have hhR := (Rat.cast_lt (K := ℝ)).2 hh
    push_cast at hhR
    exact hhR
  have hg := eulerMascheroniSeq_lt_eulerMascheroniConstant 511
  change (harmonic 511 : ℝ) - log (511 + 1) < eulerMascheroniConstant at hg
  rw [show (511 + 1 : ℝ) = 2^9 by norm_num, log_pow] at hg
  have h : (0.576 : ℝ) < eulerMascheroniConstant := by
    norm_num at hg
    linarith [log_two_lt_d9]
  have ht := sum_le_exp_of_nonneg (show (0:ℝ) ≤ 0.576 by norm_num) 6
  norm_num [Finset.sum_range_succ, Nat.factorial] at ht
  exact lt_trans (by linarith : (1.7788 : ℝ) < exp 0.576) (exp_lt_exp.mpr h)


/-- A rational lower bound for the iterated logarithm at Robin's first index. -/
theorem double_log_5041 : (2142 / 1000 : ℝ) < Real.log (Real.log 5041) := by
  have a : Real.exp (1071 / 2000) ≤ 17084 / 10000 := by
    apply (Real.exp_bound' (n := 6) (by norm_num) (by norm_num) (by norm_num)).trans
    norm_num [Finset.sum_range_succ, Nat.factorial]
  have b : Real.exp (213 / 400) ≤ 17035 / 10000 := by
    apply (Real.exp_bound' (n := 6) (by norm_num) (by norm_num) (by norm_num)).trans
    norm_num [Finset.sum_range_succ, Nat.factorial]
  have first : Real.exp (2142 / 1000) < 213 / 25 := by
    rw [show (2142 / 1000 : ℝ) = (4 : ℕ) * (1071 / 2000 : ℝ) by norm_num, Real.exp_nat_mul]
    exact (pow_le_pow_left₀ (Real.exp_pos _).le a 4).trans_lt (by norm_num)
  have second : Real.exp (213 / 25) < 5041 := by
    rw [show (213 / 25 : ℝ) = (16 : ℕ) * (213 / 400 : ℝ) by norm_num, Real.exp_nat_mul]
    exact (pow_le_pow_left₀ (Real.exp_pos _).le b 16).trans_lt (by norm_num)
  exact (Real.lt_log_iff_exp_lt (Real.log_pos (by norm_num))).2
    (first.trans ((Real.lt_log_iff_exp_lt (by norm_num)).2 second))

/-- The largest divisor-sum ratio in the initial interval is below Robin's
right-hand factor already at the first index. -/
theorem initial_threshold : (80 / 21 : ℝ) <
    exp eulerMascheroniConstant * log (log 5041) := by
  calc
    (80 / 21 : ℝ) < 1.7788 * (2142 / 1000) := by norm_num
    _ < exp eulerMascheroniConstant * log (log 5041) :=
      (mul_lt_mul_of_pos_right exp_gamma_lower (by norm_num : 0 < (2142 / 1000 : ℝ))).trans
        (mul_lt_mul_of_pos_left double_log_5041 (exp_pos _))

end RobinRecord

namespace RobinRecord
open Real
open ArithmeticFunction (sigma)

/-- Every integer strictly between 5040 and 10080 satisfies Robin's inequality. -/
theorem initial_interval (n : ℕ) (hn : 5040 < n) (upperN : n < 10080) :
    (sigma 1 n : ℝ) < exp eulerMascheroniConstant * n * log (log n) := by
  have band := certified_ratios.2.2.1
  have interval := band n (by omega) upperN
  have pos : (0 : ℝ) < n := by exact_mod_cast (by omega : 0 < n)
  have normalized : (sigma 1 n : ℝ) ≤ (80/21:ℝ)*n := by
    have realbound : (21:ℝ)*(sigma 1 n:ℝ) ≤ 80*n := by exact_mod_cast interval
    linarith
  have mono : log (log (5041:ℝ)) ≤ log (log n) :=
    log_le_log (log_pos (by norm_num)) (log_le_log (by norm_num) (by exact_mod_cast (by omega : 5041 ≤ n) : (5041:ℝ) ≤ n))
  calc
    (sigma 1 n : ℝ) ≤ (80/21:ℝ)*n := normalized
    _ < (exp eulerMascheroniConstant * log (log 5041))*n := mul_lt_mul_of_pos_right RobinRecord.initial_threshold pos
    _ ≤ (exp eulerMascheroniConstant * log (log n))*n :=
      mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left mono (exp_pos _).le) pos.le
    _ = _ := by ring

end RobinRecord

end

open Real ArithmeticFunction in
theorem RobinInline.startup (n : ℕ) (lo : 5040 < n) (hi : n < 720720) :
    (sigma 1 n : ℝ) < exp eulerMascheroniConstant * n * log (log n) := by
  by_cases small : n < 7560
  · exact RobinRecord.initial_interval n lo (by omega)
  · exact Robin1984.nativeRobinInequality_startup_from_7560 (by omega) hi
