"""Replay the archived standalone Robin finite-interval proof in pinned Mathlib."""
from pathlib import Path
import hashlib
import json
import os
import subprocess

root = Path(__file__).resolve().parent
for name, expected in json.loads((root/'manifest.json').read_text()).items():
    if hashlib.sha256((root/name).read_bytes()).hexdigest() != expected:
        raise SystemExit(f'Checksum mismatch for {name}')
version = subprocess.check_output(['lean','--version'],text=True)
if 'version 4.33.1' not in version:
    raise SystemExit(f'Expected Lean 4.33.1, found {version.strip()}')
if sys_pin := os.environ.get('ROBIN_MATHLIB_GIT',str(Path.cwd())):
    pin = subprocess.run(['git','-C',sys_pin,'rev-parse','HEAD'],text=True,capture_output=True)
    if pin.returncode or pin.stdout.strip() != '0df444a360eaa60ab8c11dca51a86af692955474':
        raise SystemExit('Run this command in the pinned Mathlib checkout, or set ROBIN_MATHLIB_GIT to it')
build = root/'build'
build.mkdir(exist_ok=True)
env = {**os.environ, 'LEAN_PATH': os.pathsep.join([str(build),os.environ.get('LEAN_PATH','')]),'LEAN_NUM_THREADS':'1'}
for module in ('StartupInline','StartupInlineAudit'):
    cmd = ['lean','-j1','-M10200','-o',str(build/(module+'.olean')),module+'.lean']
    result = subprocess.run(cmd,cwd=root,env=env,capture_output=True,text=True)
    if result.returncode:
        raise SystemExit(result.stdout+result.stderr)
    if module=='StartupInlineAudit':
        audit = "'RobinInline.startup' depends on axioms: [propext, Classical.choice, Quot.sound]"
        if result.stdout.strip()!=audit or result.stderr.strip():
            raise SystemExit(f'Unexpected audit output: {result.stdout}{result.stderr}')
        print(audit)
    elif result.stdout.strip() or result.stderr.strip():
        raise SystemExit(f'Unexpected compiler diagnostic: {result.stdout}{result.stderr}')
