# The exact Robin criterion in Lean 4.33.1

`VerifiedRobin.original` has the exact type of the registered Formal Conjectures
statement `RiemannHypothesis.robin_criterion`. It asserts that the Riemann hypothesis holds if and only if
every integer n greater than 5040 satisfies σ(n) < exp(γ) n log(log n). Both implications come from Jonas Whidden’s Robin1984
development. Sky’s FCRobinLagarias interface identifies the two divisor-sum
definitions by definitional equality.

The terminal compilation imported 352 freshly compiled donor dependencies and the
original Formal Conjectures article. The receipts give the SHA-256 for each source
and compiled module. The audit records the exact adapter and Robin1984’s
equivalence theorem, each depending only on propext, Classical.choice and
Quot.sound. The article and dependencies also contain unrelated declarations
with placeholders, outside those two theorem dependency sets.

## Replay

Under Linux, prepare a checkout of google-deepmind/formal-conjectures at
9097e2f90e66d2f6244209cb1c07f7120d17ec53, with its dependencies and Mathlib
cache available. From that checkout, run `lake build FormalConjectures.Paper.RiemannHypothesisEquivalents`
then `lake env python3 /absolute/path/to/rebuild.py`. The source driver checks
the pins, validates archive checksums, and compiles all 354 included modules
on Lean 4.33.1 with one thread. An interrupted build can resume using verified local
source and object digests. The finite certificates require several GiB of memory
and a long CPU run. Their receipts in source-compilation.json document the measured
costs on the verification machine.

## Sources

- Jonas Whidden, *Robin1984*, Apache-2.0, commit e3697139babfe0f6cc7a76a08bf41a92aa7a2978. [Source](https://github.com/kimihiro64/Robin1984/tree/e3697139babfe0f6cc7a76a08bf41a92aa7a2978)
- Sky, *FCRobinLagarias*, Apache-2.0, commit dc12df6aaf4fa88fc9e6534b81ed67b89c99d8e4. [Robin divisor-sum interface](https://github.com/ChironTheCentaur/rh-lab-robin-lagarias/blob/dc12df6aaf4fa88fc9e6534b81ed67b89c99d8e4/FCRobinLagarias/Robin.lean)
- The Formal Conjectures Authors, *RiemannHypothesisEquivalents*. [Registered article](https://github.com/google-deepmind/formal-conjectures/blob/9097e2f90e66d2f6244209cb1c07f7120d17ec53/FormalConjectures/Paper/RiemannHypothesisEquivalents.lean)

`origins.json` records the exact PrimeNumberTheoremAnd, LeanCert, LeanArchitect,
Mathlib, Robin1984 and Formal Conjectures revisions. The authors’ licences and
notices are included. The archive is a multi-module research supplement. The
Left to Solve submission gate caps a single proof file at 524288 bytes and
permits Mathlib imports after the registered article.
