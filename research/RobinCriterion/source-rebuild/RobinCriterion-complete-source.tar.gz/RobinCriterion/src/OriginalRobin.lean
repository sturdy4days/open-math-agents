import FormalConjectures.Paper.RiemannHypothesisEquivalents
import Robin1984.Equivalence.Equivalence

/-!
The strict Robin criterion in the original Formal Conjectures statement. The
underlying proof is Jonas Whidden's Robin1984, Apache-2.0, pinned at
e3697139babfe0f6cc7a76a08bf41a92aa7a2978. The identification of the two
divisor-sum conventions follows FCRobinLagarias.Robin by Sky.
-/
namespace VerifiedRobin

theorem original : type_of% @RiemannHypothesis.robin_criterion := by
  rw [Robin1984.riemannHypothesis_iff_nativeRobinInequalityAll]
  rfl

end VerifiedRobin

#print axioms VerifiedRobin.original
#print axioms Robin1984.riemannHypothesis_iff_nativeRobinInequalityAll
