import Robin1984.Finite.Certificates.Row02
/-!
## Provenance

- Classification: **Primarily project-original**.
- Mathematical source: Robin's 1984 finite-range obligation supplies the target; the certificate data have no external source attribution.
- Formalization note: The block or row representation, generated exact data, and kernel-checked verification are original to this formalization.
- PROVENANCE-END
-/

/-!
# Finite Robin certificate row 03

This row covers the log-height interval
`[29149999 / 500000, 47544747 / 500000]`. It uses 7 cutoff thresholds, beginning at
`76`. Its stored rational slope, gain bound, height bound, and endpoint
logarithm bounds define one instance of `RobinFiniteRow`.

The row theorem verifies the layer-sign, prime-product, and endpoint tangent
conditions required by `RobinFiniteRowChecks`, using kernel decisions for the
generated exact arithmetic. The resulting soundness theorem proves Robin's
inequality whenever `log n` lies in this interval.
-/

namespace Robin1984

def robinFiniteRow03 : RobinFiniteRow where
  lo := (29149999 / 500000)
  hi := (47544747 / 500000)
  lambda := (3004424868557 / 1000000000000000)
  gainUpper := (767256912829 / 100000000000)
  heightMantissa := (30083315737470684755 / 18446744073709551616)
  logLoLower := (2032801029 / 500000000)
  logHiLower := (4554818489 / 1000000000)
  heightExponent := 116
  cuts := [76, 11, 5, 3, 2, 2, 2]

def robinFiniteRow03Blocks : List RobinPrimeProductBlock := [
  robinPrimeBlock000,
  robinPrimeBlock001,
  robinPrimeBlock002,
  robinPrimeBlock003]

theorem robinFiniteRow03Blocks_checks :
    forall b, Membership.mem robinFiniteRow03Blocks b -> RobinPrimeProductBlockChecks b := by
  intro b hb
  simp only [robinFiniteRow03Blocks, List.mem_cons, List.not_mem_nil, or_false] at hb
  rcases hb with hb | hb | hb | hb
  all_goals subst b
  . exact robinPrimeBlock000_checks
  . exact robinPrimeBlock001_checks
  . exact robinPrimeBlock002_checks
  . exact robinPrimeBlock003_checks

set_option maxRecDepth 100000 in
set_option maxHeartbeats 40000000 in
theorem robinFiniteRow03_products : RobinFiniteProductChecks robinFiniteRow03 := by
  apply RobinFiniteProductChecks.of_first_layer_blocks
    (c := 76) (tail := [11, 5, 3, 2, 2, 2]) (bs := robinFiniteRow03Blocks) rfl
  . decide +kernel
  . exact robinFiniteRow03Blocks_checks
  . decide +kernel

set_option maxRecDepth 100000 in
set_option maxHeartbeats 40000000 in
theorem robinFiniteRow03_checks : RobinFiniteRowChecks robinFiniteRow03 := by
  apply And.intro
  . decide +kernel
  . apply And.intro
    . exact robinFiniteRow03_products
    . decide +kernel

end Robin1984
