import Robin1984.Finite.Certificates.Row16
/-!
## Provenance

- Classification: **Primarily project-original**.
- Mathematical source: Robin's 1984 finite-range obligation supplies the target; the certificate data have no external source attribution.
- Formalization note: The block or row representation, generated exact data, and kernel-checked verification are original to this formalization.
- PROVENANCE-END
-/

/-!
# Finite Robin certificate row 17

This row covers the log-height interval
`[1248690297 / 250000, 3045165617 / 500000]`. It uses 15 cutoff thresholds, beginning at
`5542`. Its stored rational slope, gain bound, height bound, and endpoint
logarithm bounds define one instance of `RobinFiniteRow`.

The row theorem verifies the layer-sign, prime-product, and endpoint tangent
conditions required by `RobinFiniteRowChecks`, using kernel decisions for the
generated exact arithmetic. The resulting soundness theorem proves Robin's
inequality whenever `log n` lies in this interval.
-/

namespace Robin1984

def robinFiniteRow17 : RobinFiniteRow where
  lo := (1248690297 / 250000)
  hi := (3045165617 / 500000)
  lambda := (20930175389 / 1000000000000000)
  gainUpper := (15346057284307 / 1000000000000)
  heightMantissa := (33170835240659712169 / 18446744073709551616)
  logLoLower := (4258072439 / 500000000)
  logHiLower := (2178614437 / 250000000)
  heightExponent := 8057
  cuts := [5542, 101, 24, 11, 7, 5, 4, 3, 3, 2, 2, 2, 2, 2, 2]

def robinFiniteRow17Blocks : List RobinPrimeProductBlock := [
  robinPrimeBlock000,
  robinPrimeBlock001,
  robinPrimeBlock002,
  robinPrimeBlock003,
  robinPrimeBlock004,
  robinPrimeBlock005,
  robinPrimeBlock006,
  robinPrimeBlock007,
  robinPrimeBlock008,
  robinPrimeBlock009,
  robinPrimeBlock010,
  robinPrimeBlock011,
  robinPrimeBlock012,
  robinPrimeBlock013,
  robinPrimeBlock014,
  robinPrimeBlock015,
  robinPrimeBlock016,
  robinPrimeBlock017,
  robinPrimeBlock018,
  robinPrimeBlock019,
  robinPrimeBlock020,
  robinPrimeBlock021,
  robinPrimeBlock022]

theorem robinFiniteRow17Blocks_checks :
    forall b, Membership.mem robinFiniteRow17Blocks b -> RobinPrimeProductBlockChecks b := by
  intro b hb
  simp only [robinFiniteRow17Blocks, List.mem_cons, List.not_mem_nil, or_false] at hb
  rcases hb with hb | hb | hb | hb | hb | hb | hb | hb | hb | hb | hb | hb | hb | hb | hb | hb | hb | hb | hb | hb | hb | hb | hb
  all_goals subst b
  . exact robinPrimeBlock000_checks
  . exact robinPrimeBlock001_checks
  . exact robinPrimeBlock002_checks
  . exact robinPrimeBlock003_checks
  . exact robinPrimeBlock004_checks
  . exact robinPrimeBlock005_checks
  . exact robinPrimeBlock006_checks
  . exact robinPrimeBlock007_checks
  . exact robinPrimeBlock008_checks
  . exact robinPrimeBlock009_checks
  . exact robinPrimeBlock010_checks
  . exact robinPrimeBlock011_checks
  . exact robinPrimeBlock012_checks
  . exact robinPrimeBlock013_checks
  . exact robinPrimeBlock014_checks
  . exact robinPrimeBlock015_checks
  . exact robinPrimeBlock016_checks
  . exact robinPrimeBlock017_checks
  . exact robinPrimeBlock018_checks
  . exact robinPrimeBlock019_checks
  . exact robinPrimeBlock020_checks
  . exact robinPrimeBlock021_checks
  . exact robinPrimeBlock022_checks

set_option maxRecDepth 100000 in
set_option maxHeartbeats 40000000 in
theorem robinFiniteRow17_products : RobinFiniteProductChecks robinFiniteRow17 := by
  apply RobinFiniteProductChecks.of_first_layer_blocks
    (c := 5542) (tail := [101, 24, 11, 7, 5, 4, 3, 3, 2, 2, 2, 2, 2, 2]) (bs := robinFiniteRow17Blocks) rfl
  . decide +kernel
  . exact robinFiniteRow17Blocks_checks
  . decide +kernel

set_option maxRecDepth 100000 in
set_option maxHeartbeats 40000000 in
theorem robinFiniteRow17_checks : RobinFiniteRowChecks robinFiniteRow17 := by
  apply And.intro
  . decide +kernel
  . apply And.intro
    . exact robinFiniteRow17_products
    . decide +kernel

end Robin1984
