"""Rebuild the Robin equivalence from source under the pinned Formal Conjectures environment."""
from graphlib import TopologicalSorter
from pathlib import Path
import hashlib
import json
import os
import subprocess

root=Path(__file__).resolve().parent
graph=json.loads((root/'dependencies.json').read_text())
def sha(p):
    with p.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
for name,expected in json.loads((root/'manifest.json').read_text()).items():
    if sha(root/name)!=expected:
        raise SystemExit(f'Archive hash mismatch for {name}')
if 'version 4.33.1' not in subprocess.check_output(['lean','--version'],text=True):
    raise SystemExit('Expected Lean 4.33.1')
fc=Path(os.environ.get('ROBIN_FORMAL_CONJECTURES',str(Path.cwd())))
def require_pin(path,expected):
    pin=subprocess.run(['git','-C',path,'rev-parse','HEAD'],text=True,capture_output=True)
    if pin.returncode or pin.stdout.strip()!=expected:
        raise SystemExit(f'Expected {expected} at {path}')
require_pin(fc,'9097e2f90e66d2f6244209cb1c07f7120d17ec53')
require_pin(fc/'.lake/packages/mathlib','0df444a360eaa60ab8c11dca51a86af692955474')
obj=root/'rebuilt';obj.mkdir(exist_ok=True)
env={**os.environ,'LEAN_PATH':os.pathsep.join([str(obj),os.environ.get('LEAN_PATH','')]),'LEAN_NUM_THREADS':'1'}
record=obj/'receipts.json'
receipts=json.loads(record.read_text()) if record.exists() else {}
audit=None
for mod in TopologicalSorter(graph['nodes']).static_order():
    rel=Path(*mod.split('.')); source=root/'src'/rel.with_suffix('.lean'); output=obj/rel.with_suffix('.olean')
    sig=sha(source)
    deps={n:receipts[n]['object'] for n in graph['nodes'][mod]}
    before=receipts.get(mod,{})
    if mod!='OriginalRobin' and output.is_file() and before.get('source')==sig and before.get('deps')==deps and before.get('object')==sha(output):
        continue
    output.parent.mkdir(parents=True,exist_ok=True)
    print('Building',mod,flush=True)
    log=obj/rel.with_suffix('.log')
    with log.open('w') as out:
        proc=subprocess.run(['lean','-j1','-M11000','-o',str(output),str(rel.with_suffix('.lean'))],
                            cwd=root/'src',env=env,stdout=out,stderr=subprocess.STDOUT)
    if proc.returncode:raise SystemExit(f'Lean failed on {mod}; see {log}')
    receipts[mod]={'source':sig,'object':sha(output),'deps':deps}
    old=record.with_suffix('.tmp');old.write_text(json.dumps(receipts,indent=2)+'\n');old.replace(record)
    if mod=='OriginalRobin':audit=log.read_text()
expected=["'"+n+"' depends on axioms: [propext, Classical.choice, Quot.sound]" for n in
          ('VerifiedRobin.original','Robin1984.riemannHypothesis_iff_nativeRobinInequalityAll')]
if audit is None or audit.splitlines()!=expected:
    raise SystemExit(f'Unexpected endpoint audit: {audit}')
print(audit,end='')
